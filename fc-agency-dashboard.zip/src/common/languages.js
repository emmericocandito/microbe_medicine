import usFlag from "../assets/images/flags/us.jpg"
import israel from "../assets/images/flags/israel.jpg"

const languages = {
  he: {
    label: "עברית",
    flag: israel,
  },
  eng: {
    label: "English",
    flag: usFlag,
  },
}

export default languages
