import React from "react"
import { Container, Row, Col } from "reactstrap"
//i18n
import { useTranslation } from "react-i18next"

const Footer = () => {
  const { t } = useTranslation();
  return (
    <React.Fragment>
      <footer className="footer">
        <Container fluid={true}>
          <Row>
            <div className="col-12">
              © {new Date().getFullYear()} {t('copyright')} <span className="d-none d-sm-inline-block"> <i className="mdi mdi-heart text-danger"></i></span>
            </div>
          </Row>
        </Container>
      </footer>
    </React.Fragment>
  )
}

export default Footer
