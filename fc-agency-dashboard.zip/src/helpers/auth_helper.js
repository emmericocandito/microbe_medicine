import axios from "axios"
import { setAuthTokenOfAxios, post, del, get, put } from "./api_helper"
import * as url from "./url_helper"
import querystring from 'querystring';

// Gets the logged in user data from local session
const getLoggedInUser = () => {
  const user = localStorage.getItem("user")
  if (user) return JSON.parse(user)
  return null
}

// is user is logged in
const isUserAuthenticated = () => {
  return getLoggedInUser() !== null
}

// get profile
const getJwtProfile = async data => {
  return new Promise((resolve, reject) => {
    axios.post(
        url.baseURL + url.GET_PROFILE,
        querystring.stringify(data),
        { headers: { 'Authorization': `Basic ${basic_token}`, 'Content-Type': 'application/x-www-form-urlencoded', 'Access-Control-Allow-Origin': '*' }, }
      )
      .then(response => {
        if (response.data.access_token) {
          resolve(response);
        } else {
          reject(response.data.error_description);
        }
      })
      .catch(error => {
        let message = 'invalid_username_or_password'

        if (error.error_description) {
          message = error.error_description;
        }
        reject(message);
      })
  });
}

// edit profile
const postJwtUpdateProfile = data => post(url.POST_EDIT_PROFILE, data)

// Register Method
const postJwtRegister = data => {
  return new Promise((resolve, reject) => {
    axios.post(
        url.baseURL + url.POST_REGISTER,
        data,
        { headers: {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, }
      )
      .then(response => {
        if (response.data.error != null && response.data.error.message != null) {
          reject(response.data.error.message);
        } else {
          resolve(response.data);
        }
      })
      .catch(error => {
        let message = 'failed to register'

        if (error.error_description) {
          message = error.error_description;
        }
        reject(message);
      })
  });
}

const username = 'adminPanel'
const password = '2e@w35sQ'
const basic_token = Buffer.from(`${username}:${password}`, 'utf8').toString('base64')

// Login Method
const postJwtLogin = async data => {
  return new Promise((resolve, reject) => {
    axios.post(
        url.baseURL + url.POST_LOGIN,
        querystring.stringify(data),
        { headers: { 'Authorization': `Basic ${basic_token}`, 'Content-Type': 'application/x-www-form-urlencoded', 'Access-Control-Allow-Origin': '*' }, }
      )
      .then(response => {
        if (response.data.access_token) {
          setAuthTokenOfAxios(response.data.access_token);
          resolve(response);
        } else {
          setTokens(null);
          reject(response.data.error_description);
        }
      })
      .catch(error => {
        setTokens(null);
        let message = 'invalid_username_or_password'

        if (error.error_description) {
          message = error.error_description;
        }
        reject(message);
      })
  });
}

const postJwtLoginWithToken = async () => {
  return new Promise((resolve, reject) => {
    axios.post(
      url.baseURL + url.POST_LOGIN,
      querystring.stringify({
        grant_type: 'refresh_token',
        refresh_token: getRefreshToken(),
      }),
      { headers: { 'Authorization': `Basic ${basic_token}`, 'Content-Type': 'application/x-www-form-urlencoded', 'Access-Control-Allow-Origin': '*' }, }
    )
    .then(response => {
      if (response.data.access_token) {
        setTokens(response.data.access_token, response.data.refresh_token);
        setAuthTokenOfAxios(response.data.access_token);
        resolve(response.data.access_token);
      } else {
        setTokens(null);
        reject(new Error('Failed to login with token.'));
      }
    })
    .catch(error => {
      setTokens(null);
      reject(new Error('Failed to login with token.'));
    });
  });
};

// postForgetPwd
const postJwtForgetPwd = data => {
  return new Promise((resolve, reject) => {
    axios.post(
        url.baseURL + url.POST_PASSWORD_FORGET,
        data,
        { headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, }
      )
      .then(response => {
        if (response.data.error) {
          reject(response.data.error.message[0]);
        } else {
          resolve(response);
        }
      })
      .catch(error => {
        let message = 'failed to send request for forget password'

        if (error.error_description) {
          message = error.error_description;
        }
        reject(message);
      })
  });
}

// postResetPwd
const postResetPwd = data => {
  return new Promise((resolve, reject) => {
    axios.post(
        url.baseURL + url.POST_PASSWORD_RESET,
        data,
        { headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }, }
      )
      .then(response => {
        if (response.data.error) {
          reject(response.data.error.message[0]);
        } else {
          resolve(response);
        }
      })
      .catch(error => {
        let message = 'failed to send request for reset password'

        if (error.error_description) {
          message = error.error_description;
        }
        reject(message);
      })
  });
}

// set / get tokens
const setTokens = (access_token, refresh_token) => {
  if (access_token && refresh_token) {
    localStorage.setItem('jwt_access_token', access_token);
    localStorage.setItem('jwt_refresh_token', refresh_token);
    axios.defaults.headers.common.Authorization = `Bearer ${access_token}`;
  } else {
    localStorage.removeItem('jwt_access_token');
    localStorage.removeItem('jwt_refresh_token');
    delete axios.defaults.headers.common.Authorization;
  }
}

const getAccessToken = () => {
  return localStorage.getItem('jwt_access_token');
}
const getRefreshToken = () => {
  return localStorage.getItem('jwt_refresh_token');
}

export {
  getLoggedInUser,
  isUserAuthenticated,
  postJwtRegister,
  postJwtLogin,
  postJwtLoginWithToken,
  postJwtForgetPwd,
  postResetPwd,
  getJwtProfile,
  postJwtUpdateProfile,
  setTokens,
  getAccessToken,
  getRefreshToken
}
