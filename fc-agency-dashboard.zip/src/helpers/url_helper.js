export const baseURL = process.env.REACT_APP_API_ENDPOINT;
// export const baseURL = process.env.REACT_APP_API_ENDPOINT_STAGING;

// LOGIN
export const POST_LOGIN = "connect/token"
export const POST_REGISTER = "api/user/self-register"
export const POST_PASSWORD_FORGET = "api/user/forgotpass"
export const POST_PASSWORD_RESET = "api/user/resetpass"

// PROFILE
export const GET_PROFILE = "/connect/userinfo"
export const POST_EDIT_PROFILE = "/post-jwt-profile"
