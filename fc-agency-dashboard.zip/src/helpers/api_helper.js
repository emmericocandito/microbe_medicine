import axios from "axios"
import * as url from "./url_helper"
import { getAccessToken, postJwtLoginWithToken } from "./auth_helper"
import { error } from "toastr";

// pass new generated access token here
const axiosApi = axios.create({
  baseURL: url.baseURL,
  headers: {
    'Content-Type': 'application/json',
  }
})
setAuthTokenOfAxios(getAccessToken());

axiosApi.interceptors.response.use(
  response => {
    return response;
  },
  async error => {
    if (error.response && error.response.status === 401) {
      const originalRequest = error.config;

      // if you ever get an unauthorized response, try get access token using the refresh token
      const newAccessToken = await postJwtLoginWithToken();
      originalRequest.headers['Authorization'] = `Bearer ${newAccessToken}`;
      return axiosApi(originalRequest);
    }

    if (error.response && error.response.status === 400 && error.response?.data.error_description != null) {
      logoutUser()
    }

    return Promise.reject(error);
  }
);

export function setAuthTokenOfAxios(token) {
  axiosApi.defaults.headers.common["Authorization"] = `Bearer ${token}`;
}

export async function get(url, config = {}) {
  return await axiosApi
    .get(url, { ...config })
    .then(response => response.data)
}

export async function post(url, data, config = {}) {
  return axiosApi
    .post(url, { ...data }, { ...config })
    .then(response => response.data)
}

export async function put(url, data, config = {}) {
  return axiosApi
    .put(url, { ...data }, { ...config })
    .then(response => response.data)
}

export async function del(url, config = {}) {
  return await axiosApi
    .delete(url, { ...config })
    .then(response => response.data)
}
