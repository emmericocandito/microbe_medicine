import PropTypes from 'prop-types'
import React, { useState, useEffect, useRef } from "react"
import MetaTags from 'react-meta-tags';
import { Container, Row, Col, Button, Card, CardBody, InputGroup } from "reactstrap"
import { post, del, get, put } from "helpers/api_helper"

// import images
import servicesIcon1 from "../../assets/images/services-icon/01.png";
import servicesIcon2 from "../../assets/images/services-icon/02.png";
import servicesIcon3 from "../../assets/images/services-icon/03.png";
import servicesIcon4 from "../../assets/images/services-icon/04.png";

import { Audio } from "react-loader-spinner";

// date range picker
import Flatpickr from "react-flatpickr"
import "flatpickr/dist/themes/material_blue.css"
import "react-datepicker/dist/react-datepicker.css"
import "flatpickr/dist/l10n/he.js"
import "flatpickr/dist/l10n/default.js"

//i18n
import { withTranslation } from "react-i18next"

const Dashboard = props => {
  const lang = localStorage.getItem("I18N_LANGUAGE") || "eng";
  const defaultFromDate = new Date();
  defaultFromDate.setDate(defaultFromDate.getDate() - 150);
  const [searchFrom, setSearchFrom] = useState(defaultFromDate);
  const [searchTo, setSearchTo] = useState(new Date());

  const [bookingData, setBookingData] = useState([]);
  
  const [countConfirmed, setCountConfirmed] = useState(0);
  const [totalConfirmed, setTotalConfirmed] = useState(0);
  const [profitConfirmed, setProfitConfirmed] = useState(0);
  const [countWaiting, setCountWaiting] = useState(0);
  const [totalWaiting, setTotalWaiting] = useState(0);
  const [profitWaiting, setProfitWaiting] = useState(0);

  const [loadingStatus, setLoadingStatus] = useState(true)
  const [marketerUrl, setMarketerUrl] = useState("")
  const [agencyName, setAgencyName] = useState("")
  const [roleCaption, setRoleCaption] = useState(`${props.t("Marketer Url")} : `)

  useEffect(async () => {
    if (localStorage.getItem("authUser")) {
      const userData = JSON.parse(localStorage.getItem("authUser"));
      setRoleCaption(`${props.t("Marketer Url")} : `);
      switch(userData.role){
        case 'agency':
          // get marketer id
          const marketerInfo = await getMarketerInfo();
          if(marketerInfo){
            setAgencyName(marketerInfo.odyAgentCode);
            setMarketerUrl(`https://flyingcarpet.co.il\?marketerId=${marketerInfo.code}`)
            break;
          }
        case 'partner':
          setAgencyName("");
          setMarketerUrl(`https://flyingcarpet.co.il\?partnerId=${userData.uid}`)
          break;
        }
    }

    // load booking data
    loadBookingData();
  }, [])

  const initData = () => {
    setBookingData([]);
    setCountConfirmed(0);
    setTotalConfirmed(0);
    setProfitConfirmed(0);
    setCountWaiting(0);
    setTotalWaiting(0);
    setProfitWaiting(0);


    setTotalDiscount(0);
    setTotalPrice(0);
    setTotalPaid(0);
  }

  // get marketer info of user
  const getMarketerInfo = async (uid) => {
    const response = await get(`api/user/authorizedAgency/domestic`);
    if(!response.error){
      return response;
    }

    return false;
  }

  // load booking data
  const loadBookingData = async () => {
    setLoadingStatus(true);

    post('/domestic/api/analysis/bookings/searchByAgency', {
      BookDateFrom: formatDate(searchFrom, 'y-m-d'),
      BookDateTo: formatDate(searchTo, 'y-m-d'),
      // BookSubmitted: true,
      CardVerified: true,
    }).then(response => {
      if(response.error) {
        setLoadingStatus(false);
        initData();
      } else {
        const data = response.data;

        const orders = [];
        data.forEach((order) => {
          let status = '', profitStatus = '';

          const pnrStatus = order.confirmedPnrStatus?.hotelStatus.toLowerCase() || "";
          switch (pnrStatus) {
            case 'ok':
              status = 'מאושר';
              break;
            case 'rq':
              status = 'מחכה לאישור';
              break;
            case 'canceled': case 'cxl':
              status = 'מבוטל';
              break;
            default:
              status = pnrStatus;
          }

          const finalStatus = order.finalPnrState?.hotelStatus.toLowerCase() || '';
          switch(finalStatus) {
            case 'waiting':
              profitStatus = 'Waiting';
              break;
            case 'confirmed':
              profitStatus = 'Confirmed';
              break;
          }

          orders.push({
            id: order.bookingTransId,
            date: order.bookDate.substr(0, 10),
            pnr: order.pnr,
            name: order.payerName,
            hotel: order.hotelName,
            checkIn: order.checkinDate,
            checkOut: order.checkoutDate,
            fullPrice: order.originalAmount,
            discount: Math.round(order.equivalentDiscount),
            paidPrice: order.payedAmount,
            status: status,
            profitStatus,
          });
        });

        setLoadingStatus(false);

        // set states
        setBookingData(orders);
        const profits = response?.profits || null;
        setCountConfirmed(profits?.countConfirmed || 0);
        setTotalConfirmed(profits?.totalConfirmed || 0);
        setProfitConfirmed(profits?.totalConfirmed * profits?.commissionConfirmed || 0);
        setCountWaiting(profits?.countWaiting || 0);
        setTotalWaiting(profits?.totalWaiting || 0);
        setProfitWaiting(profits?.totalWaiting * profits?.commissionWaiting || 0);

      }
    }).catch((error) => {
      setLoadingStatus(false);
      initData();
    })
  }

  const formatDate = (date, format = 'd-m-Y') => {
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var mdate = date.getDate();
    if (month < 10) {
      month = '0' + month;
    }
    if (mdate < 10) {
      mdate = '0' + mdate;
    }

    if (format === 'y-m-d') {
      return `${year}-${month}-${mdate}`;
    } else {
      return `${mdate}-${month}-${year}`;
    }
  }

  const changeDateFormat = (strDate) => {
    return(`${strDate.substr(8, 2)}-${strDate.substr(5, 2)}-${strDate.substr(0, 4)}`);
  }

  // event handlers
  const handleSearchButtonClick = () => {
    loadBookingData();
  }

  const handleChangeRange = (dates) => {
    setSearchFrom(dates[0]);
    if (dates.length > 1) {
      setSearchTo(dates[1]);
    }
  }

  return (
    <React.Fragment>
      <div className="page-content">
        <MetaTags>
          <title>Dashboard | Marketer Dashboard</title>
        </MetaTags>
        <Container fluid>
          <div className="page-title-box">
            <Row className="align-items-center">
              <Col md={6}>
                <h6 className="page-title">{props.t("Profit")}</h6>
                <ol className="breadcrumb m-0">
                  <li className="breadcrumb-item active">{props.t("Welcome")}</li>
                </ol>
              </Col>
              <Col md={6}>
                <Row>
                  <Col md={4} />
                  <Col md={5}>
                    <InputGroup>
                      <Flatpickr
                        className="form-control d-block"
                        options={{
                          mode: "range",
                          maxDate: 'today',
                          dateFormat: "d-m-Y",
                          locale: lang === 'he' ? 'he' : 'default' ,
                          defaultDate: [formatDate(searchFrom), formatDate(searchTo)]
                        }}
                        onChange={handleChangeRange}
                      />
                    </InputGroup>
                  </Col>
                  <Col md={3}>
                    <Button
                      color="primary"
                      className="btn-block float-end w-100"
                      onClick={handleSearchButtonClick}
                    >
                      {props.t("Load Stats")}
                    </Button>
                  </Col>
                </Row>
              </Col>
            </Row>
            <Row className='mt-4'>
              <Col xl={8} md={6}>
                  <div className="mb-1">
                    <span>{roleCaption}</span>
                    <a href={marketerUrl} className="font-size-14" target="_blank">
                      { marketerUrl }
                    </a>
                  </div>
              </Col>
              <Col xl={4} md={6}>
                  <div className="mb-1">
                    {
                      agencyName === "" ? '' :
                      <div className="font-size-14">{props.t("Agency Name")} : {agencyName} </div>
                    }
                  </div>
              </Col>
            </Row>
          </div>
          {
            loadingStatus ?
              <>
                <Row>
                  <Audio
                    height="80"
                    width="100"
                    radius="10"
                    color="#626ed4"
                    ariaLabel="loading"
                    wrapperStyle={{justifyContent : "space-evenly"}}
                  />
                </Row>
              </>
              : <>
                <Row>
                  <Col xl={3} md={6}>
                    <Card className="mini-stat bg-primary text-white">
                      <CardBody>
                        <div className="mb-4">
                          <div className="float-start mini-stat-img me-4">
                            <img src={servicesIcon1} alt="" />
                          </div>
                          <h5 className="font-size-16 text-uppercase mt-0 text-white-50">
                            Confirmed Booking
                          </h5>
                          <h4 className="fw-medium font-size-24">
                            {countConfirmed}
                          </h4>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                  <Col xl={3} md={6}>
                    <Card className="mini-stat bg-primary text-white">
                      <CardBody>
                        <div className="mb-4">
                          <div className="float-start mini-stat-img me-4">
                            <img src={servicesIcon2} alt="" />
                          </div>
                          <h5 className="font-size-16 text-uppercase mt-0 text-white-50">
                            Waiting Booking
                          </h5>
                          <h4 className="fw-medium font-size-24">
                            {countWaiting}
                          </h4>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                  <Col xl={3} md={6}>
                    <Card className="mini-stat bg-primary text-white">
                      <CardBody>
                        <div className="mb-4">
                          <div className="float-start mini-stat-img me-4">
                            <img src={servicesIcon3} alt="" />
                          </div>
                          <h5 className="font-size-16 text-uppercase mt-0 text-white-50">
                            Total Confirmed
                          </h5>
                          <h4 className="fw-medium font-size-24">
                            {profitConfirmed} ₪
                          </h4>
                          {/* <div className="fs-5">
                            <span className="mb-0 me-2"> Confirmed Price : {totalConfirmed}₪</span>
                          </div> */}
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                  <Col xl={3} md={6}>
                    <Card className="mini-stat bg-primary text-white">
                      <CardBody>
                        <div className="mb-4">
                          <div className="float-start mini-stat-img me-4">
                            <img src={servicesIcon4} alt="" />
                          </div>
                          <h5 className="font-size-16 text-uppercase mt-0 text-white-50">
                            Total Waiting
                          </h5>
                          <h4 className="fw-medium font-size-24">
                            {profitWaiting} ₪
                          </h4>                          
                          {/* <div className="fs-5">
                            <span className="mb-0 me-2"> Waiting Price : {totalWaiting}₪</span>
                          </div> */}
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                </Row>

                <Row>
                  <Col xl={12}>
                    <Card>
                      <CardBody>
                        <h4 className="card-title mb-4">{props.t("Latest Transaction")}</h4>
                        <div className="table-responsive">
                          <table className="table table-hover table-centered table-nowrap mb-0">
                            <thead>
                              <tr>
                                <th scope="col">{props.t("Booking Date")}</th>
                                <th scope="col">{props.t("PNR")}</th>
                                {/* <th scope="col">{props.t("Client Name")}</th> */}
                                {/* <th scope="col">{props.t("Hotel Name")}</th> */}
                                <th scope="col">{props.t("CheckIn Date")}</th>
                                <th scope="col">{props.t("CheckOut Date")}</th>
                                <th scope="col">{props.t("Full Price")}</th>
                                <th scope="col">{props.t("Discount")}</th>
                                <th scope="col">{props.t("Paid Price")}</th>
                                <th scope="col">{props.t("Status Order")}</th>
                                <th scope="col">{props.t("status-profit")}</th>
                              </tr>
                            </thead>
                            <tbody>
                              {
                                bookingData.map(bookRow => {
                                  return <tr key={bookRow.id}>
                                    <td>{changeDateFormat(bookRow.date)}</td>
                                    <td>{bookRow.pnr}</td>
                                    {/* <td>{bookRow.name}</td> */}
                                    {/* <td>{bookRow.hotel}</td> */}
                                    <td>{changeDateFormat(bookRow.checkIn)}</td>
                                    <td>{changeDateFormat(bookRow.checkOut)}</td>
                                    <td>₪{bookRow.fullPrice}</td>
                                    <td>{bookRow.discount}</td>
                                    <td>₪{bookRow.paidPrice}</td>
                                    <td>{bookRow.status}</td>
                                    <td>{bookRow.profitStatus}</td>
                                  </tr>
                                })
                              }
                            </tbody>
                          </table>
                        </div>
                      </CardBody>
                    </Card>
                  </Col>
                </Row>
                </>
          }
        </Container>
      </div>

    </React.Fragment>
  )
}

Dashboard.propTypes = {
  t: PropTypes.any
}

export default withTranslation()(Dashboard)
