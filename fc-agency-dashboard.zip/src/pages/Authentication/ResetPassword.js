import PropTypes from 'prop-types'
import MetaTags from 'react-meta-tags';
import React from "react"
import { Row, Col, Alert, Card, CardBody, Container } from "reactstrap"

// Redux
import { connect } from "react-redux"
import { withRouter, Link } from "react-router-dom"

// availity-reactstrap-validation
import { AvForm, AvField } from "availity-reactstrap-validation"

// action
import { userResetPassword } from "../../store/actions"

// import images
import logoSm from "../../assets/images/logo-sm.png";

const ResetPasswordPage = props => {
  const searchParams = new URLSearchParams(location.search);
  const username = searchParams.get('username');
  const token = searchParams.get('token');
  const email = searchParams.get('email');

  useEffect(() => {
    // go to login page
    if(props.resetSuccessMsg !== "") {
      setTimeout(() => {
        props.history.push(`/login?username=${username}`);
      }, 1000)
    }
  }, [props.resetSuccessMsg]);

  function handleValidSubmit(event, values) {
    values.token = token;
    props.userResetPassword(values, props.history)
  }

  return (
    <React.Fragment>
      <MetaTags>
        <title>Reset Password | FlyingCarpet Marketer Admin Dashboard</title>
      </MetaTags>
      <div className="account-pages my-5 pt-5">
        <Container>
          <Row className="justify-content-center">
            <Col md={8} lg={6} xl={4}>
              <Card className="overflow-hidden">
                <div className="bg-primary">
                  <div className="text-primary text-center p-4">
                    <h5 className="text-white font-size-20 p-2">Reset Password</h5>
                    <a href="index.html" className="logo logo-admin">
                      <img src={logoSm} height="24" alt="logo" />
                    </a>
                  </div>
                </div>
                <CardBody className="p-4">

                  {props.resetError ? (
                    <Alert color="danger" style={{ marginTop: "13px" }} className="mt-5">
                      {props.resetError}
                    </Alert>
                  ) : null}
                  {props.resetSuccessMsg ? (
                    <Alert color="success" style={{ marginTop: "13px" }} className="mt-5">
                      {props.resetSuccessMsg}
                    </Alert>
                  ) : null}

                  <AvForm
                    className="form-horizontal mt-4"
                    onValidSubmit={(e, v) => handleValidSubmit(e, v)}
                  >
                    <div className="mb-3">
                      <AvField
                        id="email"
                        name="email"
                        label="Email"
                        value={email}
                        placeholder="Enter email"
                        type="email"
                        disabled={true}
                        required
                      />
                    </div>
                    <div className="mb-3">
                      <AvField
                        name="username"
                        label="Username"
                        type="text"
                        placeholder="Enter username"
                        value={username}
                        disabled={true}
                        required
                      />
                    </div>
                    <div className="mb-3">
                      <AvField
                        name="password"
                        label="Password"
                        type="password"
                        validate={{
                          required: { value: true, errorMessage: 'Password is required' },
                          minLength: { value: 8, errorMessage: 'Password must be at least 8 characters' },
                          pattern: {
                            value: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^a-zA-Z0-9])/,
                            errorMessage:
                              'Passwords must have at least one non-alphanumeric character, one digit, and one uppercase letter',
                          },
                        }}
                      />
                    </div>
                    <div className="mb-3">
                      <AvField
                        name="confirmPassword"
                        label="Confirm Password"
                        type="password"
                        validate={{
                          required: { value: true, errorMessage: 'Confirm Password is required' },
                          match: { value: 'password', errorMessage: 'Passwords do not match' }
                        }}
                      />
                    </div>
                    <Row className="mb-3">
                      <Col className="text-end">
                        <button
                          className="btn btn-primary w-md waves-effect waves-light"
                          type="submit"
                          disabled={props.loading}
                        >
                          Submit
                        </button>
                      </Col>
                    </Row>
                  </AvForm>
                </CardBody>
              </Card>
              <div className="mt-5 text-center">
                <p>Remember It ? <Link to="login" className="fw-medium text-primary"> Sign In here </Link> </p>
                <p>
                  © {new Date().getFullYear()} FlyingCarpet{" "}
                  <i className="mdi mdi-heart text-danger" />
                </p>
              </div>
            </Col>
          </Row>
        </Container>
      </div>
    </React.Fragment>
  )
}

ResetPasswordPage.propTypes = {
  resetError: PropTypes.any,
  resetSuccessMsg: PropTypes.any,
  history: PropTypes.object,
  userResetPassword: PropTypes.func
}

const mapStatetoProps = state => {
  const { resetError, resetSuccessMsg, loading } = state.ResetPassword
  return { resetError, resetSuccessMsg, loading }
}

export default withRouter(
  connect(mapStatetoProps, { userResetPassword })(ResetPasswordPage)
)
