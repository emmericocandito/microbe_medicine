import { call, put, takeEvery, takeLatest } from "redux-saga/effects"

// Login Redux States
import { LOGIN_USER, LOGOUT_USER } from "./actionTypes"
import { apiError, loginSuccess, logoutUserSuccess } from "./actions"
import { setTokens } from "helpers/auth_helper"
import jwt from 'jwt-decode';

//Include Both Helper File with needed methods
import {
  postJwtLogin,
  postSocialLogin,
} from "../../../helpers/auth_helper"

function* loginUser({ payload: { user, history } }) {
  try {
    const response = yield call(postJwtLogin, {
      username: user.username,
      password: user.password,
      grant_type: 'password',
      scope: 'adminAPI offline_access profile openid'
    })


    if (response.data.access_token) {
      const userData = jwt(response.data.access_token);
      localStorage.setItem("authUser", JSON.stringify({
        username: userData.name,
        email: userData.email,
        uid: userData.sub,
        role: userData.role,
      }))
      setTokens(response.data.access_token, response.data.refresh_token);
      yield put(loginSuccess(response))

      history.push("/dashboard")
    } else {
      reject(response.data.error_description);
    }
  } catch (error) {
    yield put(apiError(error))
  }
}

function* logoutUser({ payload: { history } }) {
  try {
    setTokens(null);
    // yield put(logoutUserSuccess(response))

    history.push("/login")
  } catch (error) {
    yield put(apiError(error))
  }
}

function* authSaga() {
  yield takeEvery(LOGIN_USER, loginUser)
  yield takeEvery(LOGOUT_USER, logoutUser)
}

export default authSaga
