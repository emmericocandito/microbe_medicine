import { takeEvery, fork, put, all, call } from "redux-saga/effects"

// Login Redux States
import { RESET_PASSWORD } from "./actionTypes"
import { userResetPasswordSuccess, userResetPasswordError } from "./actions"

//Include Both Helper File with needed methods
import {
  postResetPwd,
} from "../../../helpers/auth_helper"

//If user is send successfully send mail link then dispatch redux action's are directly from here.
function* resetPassword({ payload: { data, history } }) {
  try {
    const response = yield call(postResetPwd, data)
    if (response) {
      yield put(
        userResetPasswordSuccess(
          "Password is changed."
        )
      )
    }
  } catch (error) {
    yield put(userResetPasswordError(error))
  }
}

export function* watchUserPasswordReset() {
  yield takeEvery(RESET_PASSWORD, resetPassword)
}

function* resetPasswordSaga() {
  yield all([fork(watchUserPasswordReset)])
}

export default resetPasswordSaga
