console.log('public');
Android.doNativeFunction();
