<template>
  <div>
    <div v-if="page === 'footer'" class="row">
      <div class="col-12 col-sm-12 col-md-5 text-center show-message form-group">{{$t("footer.member-login-alert")}}</div>
      <div class="col-12 col-sm-6 col-md-3 text-center">
        <b-form-group id="input-group-phone" label-for="input-phone" v-if="!memberSid">
          <b-form-input
            id="input-phone"
            v-model="phoneNumber"
            :placeholder="$t('login.phone-number')"
            required
            type="number"
          ></b-form-input>
        </b-form-group>
        <b-form-group id="input-group-code" label-for="input-code" v-else-if="!isLogin">
          <b-form-input
            id="input-code"
            v-model="verifyCode"
            :placeholder="$t('login.verify-code')"
            required
            type="number"
          ></b-form-input>
        </b-form-group>
        <b-form-group id="input-group-logout" v-else>
          <b-button @click="logout" variant="danger" class="w-100">{{$t('login.log-out')}}</b-button>
        </b-form-group>
      </div>
      <div class="col-12 col-sm-3 col-md-2 text-center">
        <b-button size="lz" variant="primary" @click="send" :disabled="isSending" v-if="!isLogin" class="w-100 form-group">
          <span v-if="memberSid && isSending"><b-spinner small type="grow"></b-spinner>{{$t('login.loging')}}</span>
          <span v-else-if="!memberSid && isSending"><b-spinner small type="grow"></b-spinner>{{$t('login.sending')}}</span>
          <span v-else-if="memberSid && !isLogin">{{$t('login.login')}}</span>
          <span v-else>{{$t('login.send')}}</span>
        </b-button>
      </div>
    </div>
    <div v-else class="ml-1 mb-1">
      <b-button class="btn-login" v-b-modal.modal-login :variant="!!memberSid ? 'success' : 'primary'" v-if="!isLogin">
        <i class="fas fa-user"/> {{$t("login.club-member-login")}}</b-button>
      <b-button class="btn-login" variant="info" v-b-modal.modal-login v-else-if="user.refund && user.refund > 0" :dir="(lang === 'en')? 'ltr': 'rtl'">
        {{$t("login.after-login-with-refund", {
          name: `${user.firstName} ${user.lastName}`,
          refund: user.refund,
          fullPrice: oldShekelPrice,
          fullPriceWithRefund: totalShekelPrice,
        })}}
      </b-button>
      <b-button class="btn-login" variant="info" v-b-modal.modal-login v-else :dir="(lang === 'en')? 'ltr': 'rtl'">
        {{$t("login.after-login-without-refund", {
          name: `${user.firstName} ${user.lastName}`,
        })}}
      </b-button>

      <b-modal id="modal-login" v-model="modalShow" :dir="(lang !== 'he') ? 'ltr': 'rtl'" >
        <template #modal-header="{ close }">
          <h5>{{ $t('login.member-login') }}</h5>
          <b-button size="sm" @click="close()" variant="second">
            <i class="fa fa-times"></i>
          </b-button>
        </template>

        <template #default>
          <b-alert variant="danger" show v-if="!!message">{{ message }}</b-alert>

          <b-form-group id="input-group-phone" :label="`${$t('login.phone-number')}:`" label-for="input-phone" v-if="!memberSid" :class="{'he': lang === 'he'}">
            <b-form-input
              id="input-phone"
              v-model="phoneNumber"
              :placeholder="$t('login.phone-number')"
              required
              dir="ltr"
              type="number"
            ></b-form-input>
          </b-form-group>
          <b-form-group id="input-group-code" :label="`${$t('login.verify-code')}:`" label-for="input-code" v-else-if="!isLogin" :class="{'he': lang === 'he'}">
            <b-alert variant="success" show>{{ $t('login.verify-code-message') }}</b-alert>
            <b-form-input
              id="input-code"
              v-model="verifyCode"
              :placeholder="$t('login.verify-code')"
              required
              dir="ltr"
              type="number"
            ></b-form-input>
          </b-form-group>
          <b-form-group id="input-group-logout" v-else>
            <b-button @click="logout" variant="danger" class="w-100">{{$t('login.log-out')}}</b-button>
          </b-form-group>
        </template>

        <template #modal-footer="{ close }">
          <b-button size="sm" variant="success" @click="send" :disabled="isSending" v-if="!isLogin">
            <span v-if="memberSid && isSending"><b-spinner small type="grow"></b-spinner>{{$t('login.loging')}}</span>
            <span v-else-if="!memberSid && isSending"><b-spinner small type="grow"></b-spinner>{{$t('login.sending')}}</span>
            <span v-else-if="memberSid && !isLogin">{{$t('login.login')}}</span>
            <span v-else>{{$t('login.send')}}</span>
          </b-button>
          <b-button size="sm" variant="danger" @click="close()" v-if="!isLogin" :disabled="isSending">
          {{$t('login.cancel')}}
          </b-button>
          <b-button size="sm" variant="danger" @click="clear" v-if="memberSid && !isLogin" :disabled="isSending">
          {{$t('login.clear')}}
          </b-button>
        </template>

      </b-modal>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';
import { BFormGroup, BFormInput, BSpinner, BButton, BAlert, VBModal } from 'bootstrap-vue';

export default {
  name: 'login',
  data() {
    return {
      phoneNumber: '',
      verifyCode: '',
      modalShow: false,
    };
  },
  directives: {
    'b-modal': VBModal,
  },
  props: {
    oldShekelPrice: {
      default: 0,
      type: Number,
    },
    totalShekelPrice: {
      default: 0,
      type: Number,
    },
    page: {
      default: '',
      type: String,
    },
  },
  components: {
    BFormGroup,
    BFormInput,
    BSpinner,
    BButton,
    BAlert,
  },
  computed: {
    ...mapGetters({
      isLogin: 'IS_AUTHORIZED',
      memberSid: 'GET_MEMBER_SID',
      user: 'GET_MEMBER',
      isSending: 'GET_IS_AUTHORING',
      lang: 'GET_LANGUAGE',
      message: 'GET_ERROR_MESSAGE',
    }),
  },
  watch: {
    phoneNumber() {
      this.$store.commit('SET_PHONE_NUMBER', this.phoneNumber);
    },
    verifyCode() {
      this.$store.commit('SET_VERIFY_CODE', this.verifyCode);
    },
    modalShow() {
      this.phoneNumber = '';
      this.verifyCode = '';
      this.$store.commit('SET_ERROR_MESSAGE', null);
    },
    isLogin() {
      this.modalShow = false;
    },
  },
  created() {
    this.$store.dispatch('VERIFY_LOGIN_STATE');
  },
  methods: {
    async send() {
      if (this.phoneNumber !== '' && this.verifyCode === '') await this.$store.dispatch('REQUEST_BY_PHONE_NUMBER');
      if (this.verifyCode !== '') await this.$store.dispatch('REQUEST_BY_VERIFY_CODE');
    },
    async logout() {
      this.$bvModal.msgBoxConfirm(this.$t('login.log-out-confirm-box-title'), {
        title: this.$t('login.confirm'),
        size: 'sm',
        buttonSize: 'sm',
        okVariant: 'danger',
        okTitle: this.$t('login.yes'),
        cancelTitle: this.$t('login.no'),
        footerClass: 'p-2',
        hideHeaderClose: false,
        centered: true,
      })
        .then(async (value) => {
          if (value) await this.$store.dispatch('REQUEST_LOGOUT');
        });
    },
    async clear() {
      await this.$store.commit('SET_MEMBER_SID', null);
    },
  },
};
</script>

<style>
/* #modal-login{
  text-align: unset;
} */
.he .d-block, .he .alert{
  text-align: right;
}
#modal-login .modal-dialog {
  width: 800px;
}
@media(max-width: 600px){
  #modal-login .modal-dialog {
    width: 90%;
  }
}
</style>
