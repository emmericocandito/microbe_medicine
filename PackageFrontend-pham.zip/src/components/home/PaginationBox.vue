<template>
  <section class="paginationbox">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="d-flex align-items-center my-5">
            <h6 class="mr-3">{{$t('home.pagination-title')}}</h6>
            <nav class="custom-pagi" aria-label="Page navigation">
              <ul class="pagination d-flex flex-wrap mb-0">
                <li class="page-item active"><a class="page-link" href="#">1</a></li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
                <li class="page-item"><a class="page-link" href="#">4</a></li>
                <li class="page-item"><a class="page-link" href="#">5</a></li>
                <li class="page-item"><a class="page-link" href="#">6</a></li>
                <li class="page-item"><a class="page-link" href="#">7</a></li>
                <li class="page-item"><a class="page-link" href="#">8</a></li>
                <li class="page-item"><a class="page-link" href="#">9</a></li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'PaginationBox',
  components: {
    // NavMenu: () => import('@/components/menu/NavMenu'),
    // ContentWrapper: () => import('@/components/content/ContentWrapper')
  },
  props: {
    msg: String,
  },
};
</script>
