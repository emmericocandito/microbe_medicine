<template>
  <section class="bookNow">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 col-md-12">
          <p class="text-one">{{$t('home.book-now.text-one')}}</p>
          <h1 class="text-main">{{$t('home.book-now.traveling')}}</h1>
          <h4 class="text-two">{{$t('home.book-now.book-your-trip')}}</h4>
          <span class="text-main-two">{{$t('home.book-now.title')}}</span>
          <button class="btn btn-themeBlue">{{$t('home.book-now.book-now')}}</button>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'BookNow',
  components: {
    // NavMenu: () => import('@/components/menu/NavMenu'),
    // ContentWrapper: () => import('@/components/content/ContentWrapper')
  },
  props: {
    msg: String,
  },
};
</script>

<style scoped>
  .row > div{
    /* text-align:right; */
  }
</style>
