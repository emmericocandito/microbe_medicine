<template>
  <li class="list_tickets_item" ref="searchItem">
    <div class="tickets_date_group">
      <div class="tickets_date_year"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
        {{year}}
      </font></font></div>
      <div class="tickets_date_day"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
        {{date}}
      </font></font></div>
      <div><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
      {{day}}
      </font></font></div>
      </div>
      <div class="tickets_maininfo_group">
      <div class="tickets_name_txt"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;" class="">
        {{labelEvent}}
      </font></font></div>
      <div class="tickets_place_group w-clearfix">
        <div class="tickets_place_txt town_country">
          <font style="vertical-align: inherit;">{{labelCity}} &nbsp;</font></div>
        <div class="tickets_place_txt town_country">
          <font style="vertical-align: inherit;">
            <font style="vertical-align: inherit;"> | </font>
            <font style="vertical-align: inherit;">{{labelCountry}}</font>
          </font>
        </div>
      </div>
      </div>
      <div class="tickets_price_order_group">
        <!-- <a class="tickets_order_button w-inline-block" href="#" @click="orderNow"> -->
        <b-link :to="productQuery" class="tickets_order_button w-inline-block" @click="storeScrollPosition">
          <div>
            <font style="vertical-align: inherit;">
              <font style="vertical-align: inherit;">
                {{ $t('search-result.order-now') }}
              </font>
            </font>
          </div>
        </b-link>
        <!-- </a> -->
        <div class="tickets_price_group">
          <div class="tickets_price_currency">
            <font style="vertical-align: inherit;">
              <font style="vertical-align: inherit;">{{labelPrice}}</font>
            </font>
          </div>
      </div>
    </div>
  </li>
</template>
<script>
import {
  BLink,
// BCollapse,
// VBToggle,
// BFormRating,
// BImg,
// BBadge,
// BFormRadio,
} from 'bootstrap-vue';
import { mapGetters } from 'vuex';
import dayjs from 'dayjs';
import gMixin from '@/utils/mixins';

export default {
  name: 'EventItem',
  components: {
    BLink,
    // BCollapse,
    // BFormRating,
    // BImg,
    // BBadge,
    // BFormRadio,
    // CustomTooltip: () => import('@/components/atoms/CustomTooltip'),
  },
  directives: {
    // 'b-toggle': VBToggle,
  },
  mixins: [gMixin],
  props: {
    event: {
      type: Object,
      default: null,
    },
    itemIndex: {
      type: Number,
      default: 0,
    },
  },
  computed: {
    ...mapGetters({
      category: 'GET_CURRENT_CATEGORY',
      packages: 'GET_PACKAGES',
      lang: 'GET_LANGUAGE',
      destinationImages: 'GET_DESTINATION_IMAGES',
      device: 'GET_DEVICE',
      isAgencyLogin: 'IS_AGENCY_AUTHORIZED',
      searchItemLocation: 'GET_SEARCH_ITEM_LOCATION',
      isOdysseySite: 'GET_ODYSSEY_AGENT_STATE',
      odyAgentCode: 'GET_SELECTED_ODYSSEY_AGENT_CODE',
      isFcAgentMarketerMode: 'GET_FC_AGENT_MARKETER_MODE',
      subjects: 'GET_SUBJECTS',
    }),
    dateEvent() {
      return dayjs(this.event.EventPrice[0].dat);
    },
    year() {
      return this.dateEvent.locale(this.lang).format('YYYY');
    },
    date() {
      return this.dateEvent.locale(this.lang).format('D MMMM');
    },
    day() {
      return this.dateEvent.locale(this.lang).format('hh:mm dddd');
    },
    markLang() {
      return `nameTranslation${this.getMarkLanguage(this.lang, 3)}`;
    },
    labelEvent() {
      let label = '';
      const subject = this.subjects.filter((subj) => subj.code === this.event.subj_id)[0],
        nameSubject = subject[this.markLang] || subject.nameTranslationEng,
        nameEvent = this.event.EventName[0].Htl_Name; // pending to take the name under language selected
      label = `${nameSubject} : ${nameEvent}`;
      return label;
    },
    currPack() {
      return this.packages.find((item) => item.packId === this.event.packId);
    },
    labelCity() {
      return this.currPack.translations?.flightDestinationName?.[this.event.EventName[0].Htl_City]?.[this.lang] ?? this.EventName[0].Htl_City;
    },
    labelCountry() {
      return this.currPack.translations?.flightDestinationCountry?.[this.event.EventName[0].Htl_City]?.[this.lang] ?? this.EventName[0].Htl_City;
    },
    minPriceHotel() {
      let activeHotel = this.currPack.hotels[0];
      this.currPack.hotels.forEach((hotel) => {
        if (activeHotel.Price > hotel.Price) activeHotel = hotel;
      });
      return activeHotel;
    },
    labelPrice() {
      let minPriceTicket = 10000000;
      this.event.EventPrice.forEach((ticket) => {
        if (minPriceTicket > ticket.price) minPriceTicket = ticket.price;
      });
      return this.getPriceWithSymbol(this.event.EventPrice[0].cc, minPriceTicket + this.minPriceHotel.Price);
    },
    flightDiscounted() {
      return this.minPriceHotel.flightDiscounted;
    },
    productQuery() {
      const body = {
        packId: this.currPack.packId,
        laId: this.minPriceHotel.hotelId,
        dateFrom: this.currPack.flights[this.flightInx]?.FlightDetail[0]?.FL_Date,
        flights: `${this.currPack.flights[this.flightInx]?.FlightDetail[0]?.FL_ID}${this.currPack.flights[this.flightInx]?.FlightDetail[1]?.FL_ID}`,
        adult: this.query.adult,
        child: this.query.child,
        infant: this.query.infant,
        categoryId: this.query.categoryId,
        roomType: this.minPriceHotel.Room_Type,
        roomClass: this.minPriceHotel.Room_Class,
        discount: this.minPriceHotel.discountPercent > 5 && this.minPriceHotel.discountedFlights,
        event: this.event.LA_ID,
      };
      return `/product-page?${new URLSearchParams(body).toString()}`;
    },
  },
  data() {
    return {
      query: this.$route.query,
      flightInx: 0,
    };
  },
  watch: {
    lang() {
    },
  },
  created() {
  },
  mounted() {
    if (this.searchItemLocation?.index === this.itemIndex) {
      setTimeout(() => {
        document.querySelector('.st-content').scrollTo(0, this.searchItemLocation.offset);
      }, 100);
    }
    this.refObjectTop = this.$refs.searchItem.offsetTop;
  },
  methods: {
    storeScrollPosition() {
      this.$store.commit('SET_SEARCH_ITEM_LOCATION', { offset: this.refObjectTop, index: this.itemIndex });
    },
  },
};
</script>

<style scoped>

</style>
<style>

</style>
