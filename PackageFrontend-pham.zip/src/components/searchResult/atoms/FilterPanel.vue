<template>
  <div class="card card-body border-0 px-0 filter-panel">
    <div id="accordionParent1" class="accordion sidePanel">
      <sidebar-filter-slide
        v-if="options.priceSlider"
        :item="options.priceSlider"
        @change="fireFilterPrice"
      />
    </div>

    <div class="accordion sidePanel" v-for="(val, inx) in options" :key="inx">
      <SidebarFilterCheckbox :item='val' @change="filterCheckbox" v-if="val && val.kind !== 'slider'"/>
    </div>
  </div>
</template>

<script>
export default {
  components: {
    SidebarFilterSlide: () => import('@/components/searchResult/atoms/SidebarFilterSlide'),
    SidebarFilterCheckbox: () => import('@/components/searchResult/atoms/SidebarFilterCheckbox'),
  },
  props: {
    options: {
      type: Object,
      default: null,
    },
  },
  data() {
    return {
      filterConditions: {},
      element: null,
    };
  },
  watch: {
    options() {
    },
  },
  created() {
  },
  methods: {
    fireFilterPrice(pValue) {
      this.$set(this.filterConditions, 'price', pValue);
      this.$emit('change', this.filterConditions);
    },
    filterCheckbox(value) {
      this.$set(this.filterConditions, value.kind, value.value);
      this.$emit('change', this.filterConditions);
    },
  },
};
</script>

<style scoped>
  .accordion{
    margin: 5px 0;
  }
  .filter-panel{
    position: sticky;
    top: 25px;
    height: 100vh;
    overflow-y: scroll;
    margin-top: 20px;
    direction: ltr;
  }
  .filter-panel div{
    width: calc(100% - 3px);
    margin-left: 3px;
    direction: rtl;
  }
@media (max-width: 479px) {
  .filter-panel{
    height: auto;
  }
}
</style>
<style>
.filter-panel .btn.btn-link {
  text-decoration: none;
}
</style>
