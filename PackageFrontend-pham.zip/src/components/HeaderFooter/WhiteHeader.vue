<template>
  <div class="header_top">
    <div class="container">
      <div class="d-flex justify-content-between align-items-center">
        <div class="logo d-flex">
          <a href="/"><img :src="`${speedSizeDomain}/assets/img/flying-carpet.png`" alt="flying-carpet" title=""  width="100" height="100"/></a>
          <!-- <a :href="domesticLink" class="mr-4" v-if="device === 'desktop' && marketerId === ''">
            <button class="btn btnDomestic btn-theme-onWhite">
              {{ $t("top-nav.domestic-tourism") }}
            </button>
          </a> -->
        </div>
        <div class="address_area">
          <!-- <div class="address_box">
            <p>{{$t("top-header.vacation-country")}}</p>
            <a href="tel:037771032" class="call">03-7771032</a>
          </div> -->
          <div class="address_box">
            <p v-if="device === 'desktop'">{{$t("top-header.vacation-abroad")}}</p>
            <a :href="`tel:${phoneNumber}`" class="call"><span v-if="device === 'desktop'">{{phoneNumber}} </span><i class="fas fa-phone-alt"></i></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { VBToggle } from 'bootstrap-vue';
import { mapGetters } from 'vuex';
import imageUrlMixin from '@/utils/imageUrlMixin';

const { VUE_APP_GOOGLE_PHONE_NUMBER, VUE_APP_FACEBOOK_PHONE_NUMBER } = process.env;

export default {
  mixins: [imageUrlMixin],
  directives: {
    'b-toggle': VBToggle,
  },
  data() {
    return {
      isScroll: true,
    };
  },
  computed: {
    ...mapGetters({
      device: 'GET_DEVICE',
      // marketerId: 'GET_MARKETER_ID',
      whiteLabel: 'GET_WHITE_LABEL_DATA',
      marketerAgencyContent: 'GET_MARKETER_AGENCY_CONTENT',
    }),
    phoneNumber() {
      const { marketerAgencyContent } = this;
      const utmSource = this.$route.query.utm_source;
      const phone = utmSource === 'google' ? VUE_APP_GOOGLE_PHONE_NUMBER : VUE_APP_FACEBOOK_PHONE_NUMBER;
      // eslint-disable-next-line no-nested-ternary
      return utmSource ? phone : (marketerAgencyContent === null) ? this.whiteLabel.phoneNumber : marketerAgencyContent.phoneNumber;
    },
    domesticLink() {
      return process.env.VUE_APP_DOMESTIC_DOMAIN;
    },
  },
  mounted() {
    document.querySelector('.st-content').addEventListener('scroll', this.onScroll);
  },
  methods: {
    onScroll(event) {
      this.isScroll = Number(event.target.scrollTop) > 150;
    },
  },
};
</script>
<style scoped>
.header_top {
  background-color: #ffffff;
  padding: 5px 0px;
}
.header_top .logo img {
  width: 100%;
  object-fit: cover;
}
.header_top .address_area .address_box p {
  color: #425b6d;
  font-size: 1.0rem;
  font-weight: 600;
  padding: 0;
  margin: 0 0 0;
  text-align: center;
}
.header_top .address_area .address_box .call {
  color: rgba(var(--theme-primary));
  font-size: 1.2rem;
  font-weight: 600;
  text-decoration: none;
}
.header_top .address_area .address_box .call:hover{
  color: #3fa1f1;
}
.header_top .address_area .address_box {
  display: inline-block;
  margin-left: 4.5rem;
  text-align: center;
}
/* .btn.btn-theme-onWhite {
  color: rgba(var(--theme-primary));
  border-color: rgba(var(--theme-primary));
}
.btn.btn-theme-onWhite:hover {
    border-color: transparent;
    background-color: rgba(var(--theme-primary));
    color: #ffffff;
} */

@media (max-width: 990px) {
  .header_top .address_area .address_box {
    margin-left: 5rem;
  }
  .header_top .address_area .address_box .call {
    font-size: 2rem;
  }
}
</style>
