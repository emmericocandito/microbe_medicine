<template>
  <div class="contactFormWrapper container mt-5">
    <div class="w-100">
      <form action="#" id="contactUs">
        <input type="hidden" name="formID" value="cancellationForm" />
        <input
          type="hidden"
          name="formTitle"
          value="טופס בקשה לביטול הזמנה"
        />
        <div class="">
          <div class="col-xs-12">
            <div class="textWrap">
              <h2>טופס בקשה לביטול הזמנה</h2>
              <p>טופס הבקשה לביטול הזמנה הינו להזמנה שבוצעה באתר בלבד</p>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-6 col-xs-12">
            <div class="inputWrap">
              <label for="orderID">מס' הזמנה</label>
              <input
                id="orderID"
                name="orderID"
                type="text"
                role="textbox"
                style="box-shadow: none;"
              />
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-6 col-xs-12">
            <div class="inputWrap">
              <label for="fullName"><span>*</span>שם מלא באנגלית</label>
              <input
                id="fullName"
                name="fulltName"
                type="text"
                required=""
                role="textbox"
                style="box-shadow: none;"
              />
            </div>
          </div>
          <div class="col-sm-6 col-xs-12">
            <div class="inputWrap">
              <label for="idNum"><span>*</span>מס' תעודת זהות</label>
              <input
                id="idNum"
                name="idNum"
                type="text"
                required=""
                role="textbox"
                style="box-shadow: none;"
              />
            </div>
          </div>
          <div class="col-sm-6 col-xs-12">
            <div class="inputWrap">
              <label for="phone"><span>*</span>טלפון (שהוזן בהזמנה)</label>
              <input
                id="phone"
                name="phone"
                type="tel"
                required=""
                role="textbox"
                style="box-shadow: none;"
              />
            </div>
          </div>
          <div class="col-sm-6 col-xs-12">
            <div class="inputWrap">
              <label for="email"><span>*</span>אימייל</label>
              <input
                id="email"
                name="email"
                type="email"
                required=""
                role="textbox"
                style="box-shadow: none;"
              />
            </div>
          </div>
          <div class="col-xs-12">
            <div class="inputWrap p-3">
              <label for="msgContent"><span>*</span>סיבת הבקשה לביטול</label>
              <textarea
                name="contact_content"
                id="msgContent"
                cols="30"
                rows="10"
                required=""
                style="margin: 0px; height: 146px;resize: none;"
              ></textarea>
            </div>
          </div>
          <div class="col-sm-6 col-xs-12">
            <div
              class="g-recaptcha"
              data-sitekey="6LcvaBAUAAAAAB-geW2IyrWcENZ69euhYPzexHTR"
            >
              <div style="width: 304px; height: 78px;">
                <div>
                  <iframe
                    title="reCAPTCHA"
                    src="https://www.google.com/recaptcha/api2/anchor?ar=1&amp;k=6LcvaBAUAAAAAB-geW2IyrWcENZ69euhYPzexHTR&amp;co=aHR0cHM6Ly93d3cuZmx5aW5nLmNvLmlsOjQ0Mw..&amp;hl=en&amp;v=UrRmT3mBwY326qQxUfVlHu1P&amp;size=normal&amp;cb=k1uofc9jkb2k"
                    width="304"
                    height="78"
                    role="presentation"
                    name="a-f96usrklq2aw"
                    frameborder="0"
                    scrolling="no"
                    sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox"
                  ></iframe>
                </div>
                <textarea
                  id="g-recaptcha-response"
                  name="g-recaptcha-response"
                  class="g-recaptcha-response"
                  style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"
                ></textarea>
              </div>
              <iframe style="display: none;"></iframe>
            </div>
          </div>
          <div class="col-sm-6 col-xs-12">
            <div class="inputWrap">
              <button type="submit" role="button">
                <span data-loading="עוד רגע :)">שלח</span>
                {{ "\xa0" }}{{ "\xa0" }}{{ "\xa0" }}
                <i class="fa fa-arrow-left"></i>
              </button>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>

<style scoped>
.col-xs-12{
  width: 100%;
}
@media (min-width: 1200px) {
  .container {
    width: 1170px;
  }
}
@media (min-width: 992px) {
  .container {
    width: 970px;
  }
}
@media (min-width: 768px) {
  .container {
    width: 750px;
  }
}
.container {
  padding-right: 15px;
  padding-left: 15px;
  margin-right: auto;
  margin-left: auto;
}
.contactFormWrapper .textWrap {
  border-bottom: 1px solid #bfbfbf;
  padding-bottom: 20px;
  margin-bottom: 20px;
}
.contactFormWrapper .textWrap h2 {
  color: #003656;
  font-size: 1.25rem;
  font-weight: 500;
}
.contactFormWrapper .textWrap p {
  color: #5f5f5f;
  font-size: 1.125rem;
  font-weight: 500;
  margin: 0;
}
.contactFormWrapper
  .inputWrap
  input:not([type="checkbox"]):not([type="range"]) {
  border-color: #0a85b1;
  color: #343434;
}
.inputWrap input:not([type="checkbox"]):not([type="range"]) {
  width: 100% !important;
  padding-right: 15px;
  padding-left: 15px;
}
.inputWrap input:not([type="checkbox"]):not([type="range"]) {
  width: 100%;
  height: 49px;
  border-radius: 25px;
  border: 1px solid #fff;
  padding: 0 15px;
  color: #fff;
  -webkit-appearance: none;
}
.contactFormWrapper .inputWrap textarea {
  width: 100%;
  height: 149px;
  border-radius: 25px;
  border: 1px solid #0a85b1;
  color: #343434;
  padding: 15px;
}
.contactFormWrapper .inputWrap {
  margin-bottom: 20px;
}
.contactFormWrapper button[type="submit"] {
  width: 300px;
  height: 50px;
  border-radius: 25px;
  background: #10c386;
  border: 2px solid #10c386;
  color: #fff;
  font-size: 1.125rem;
  margin: 30px 0;
  transition: all 0.25s ease-in-out;
  -moz-transition: all 0.25s ease-in-out;
  -webkit-transition: all 0.25s ease-in-out;
}
.contactFormWrapper button[type="submit"]:hover,
.contactFormWrapper button[type="submit"]:focus {
  background: #fff;
  color: #10c386;
  transition: all 0.25s ease-in-out;
  -moz-transition: all 0.25s ease-in-out;
  -webkit-transition: all 0.25s ease-in-out;
}
</style>
