<template>
  <div class="verified-card">
    <div v-if="loading">
      <content-loading type="product" />
    </div>
    <div v-else class="apparea">
      <!----- header area start ----->
      <header class="header-area" v-if="isDesktopApp">
        <div class="d-flex justify-content-center">
          <figure class="logo bonauf-app-logo" @click="gotoHome"><img :src="`${speedSizeDomain}/assets/img/app/logo.png`" alt="#" title="" /></figure>
        </div>
      </header>
      <!----- header area stop ----->
      <div v-if="variant != 'success'" class="mb-3 container">
        <b-card-group deck>
          <b-card
            :border-variant="variantClass"
            :header-bg-variant="variantClass"
            :body-text-variant="variantClass"
            align="right"
          >
            <b-card-text :dir="lang == 'he' ? 'rtl' : 'ltr'">{{ message }}</b-card-text>

            <!-- <div class="row">
              <div class="col-12 col-md-6">
                <b-card-text><a :href="bookingInfoPageLink" target="_blank">{{$t('booking.error-link-message')}}</a></b-card-text>
              </div>
              <div class="col-12 col-md-6">
                <b-button variant="outline-primary" :disabled="orderNo==='N/A'"><a :href="`/check-booking`" target="_blank">Show booking information</a></b-button>
              </div>
            </div> -->
            <b-overlay :show="sendingMessage" rounded="sm" class="d-inline-block" spinner-variant="primary">
              <b-button variant="primary" v-if="isOdysseySite" :disabled="sendingMessage || successfullySentMessage" @click="sendMessage">{{$t("booking.send-message-button")}}</b-button>
            </b-overlay>
          </b-card>
        </b-card-group>
        <button class="btn btn-primary" @click="goToDebit" v-if="allowRetry">
          {{ $t('booking.try-again-debit') }}
        </button>
      </div>

      <payer-confirm-app :payer="payer" />

      <hotel-confirm-app :bookedHotel="bookedHotel" v-if="stateBooking == 'FH'" />

      <div class="please_mall_area order-area card kremlin-area" >
        <div class="plase_mall_contain_box kremlin-list">
          <h2>
            <span>{{ $t('booking.please-note') }}:</span>
            {{ $t('booking.attached-mail') }}
          </h2>
          <ul class="please_mall_contain_body" v-if="showLink || this.devMode">
            <li class="please_mall" v-if="pdfUrlReceipt || this.devMode">
              <div>
                <div class="icon_box">
                  <b-link
                    :href="pdfUrlReceipt"
                    @click.prevent="
                      downloadTickets(pdfUrlReceipt, 'Receipt')
                    "
                    >
                    <img :src="`${speedSizeDomain}/assets/img/after-booking-icon14.png`" class="col-10" width="100" height="100" alt="after-booking"/>
                  </b-link>
                </div>
                <h5>{{ $t('booking.receipt') }}</h5>
              </div>
            </li>
            <li class="please_mall" v-if="pdfUrlTerms || this.devMode">
              <div>
                <div class="icon_box">
                  <b-link
                    :href="pdfUrlReceipt"
                    @click.prevent="
                      downloadTickets(pdfUrlTerms, 'pdfUrlTerms')
                    "
                    >
                    <img :src="`${speedSizeDomain}/assets/img/after-booking-icon15.png`" width="100" height="100" alt="after-booking"/></b-link>
                </div>
                <h5>{{ $t('booking.general-terms') }}</h5>
              </div>
            </li>
            <li class="please_mall" v-if="pdfUrlItinerary || this.devMode">
              <div>
                <div class="icon_box">
                  <b-link
                    :href="pdfUrlItinerary"
                    @click.prevent="
                      downloadTickets(pdfUrlItinerary, 'Itinerary')
                    "
                    ><img :src="`${speedSizeDomain}/assets/img/after-booking-icon16.png`" width="100" height="100" alt="after-booking"
                  /></b-link>
                </div>
                <h5>{{ $t('booking.itinerary') }}</h5>
              </div>
            </li>
            <li class="please_mall" v-if="pdfUrlTicket || this.devMode">
              <div>
                <div class="icon_box">
                  <b-link
                    :href="pdfUrlTicket"
                    @click.prevent="downloadTickets(pdfUrlTicket, 'Ticket')"
                    ><img :src="`${speedSizeDomain}/assets/img/after-booking-icon17.png`" width="100" height="100" alt="after-booking"/>
                  </b-link>
                </div>
                <h5>{{ $t('booking.flight-tickets') }}</h5>
              </div>
            </li>
            <li class="please_mall" v-if="pdfUrlHotelVoucher || this.devMode">
              <div>
                <div class="icon_box">
                  <b-link
                    :href="pdfUrlHotelVoucher"
                    @click.prevent="
                      downloadTickets(pdfUrlHotelVoucher, 'HotelVoucher')
                    "
                    ><img :src="`${speedSizeDomain}/assets/img/after-booking-icon18.png`" width="100" height="100" alt="after-booking"
                  /></b-link>
                </div>
                <h5>{{ $t('booking.hotel-voucher') }}</h5>
              </div>
            </li>
          </ul>
        </div>
      </div>

      <flight-confirm-app :flights="flights" />
      <div v-if="isMobileApp" class="d-flex mt-3">
        <div class="m-auto app-rate">
          <input class="btn btn-primary" :value="$t('product-page.rate-app-button')" type="button" name="submit"  id="btnSubmit" @click="handleRatingApp" />
          {{ $t("product-page.rate-app-label") }}
        </div>
      </div>
    </div>
    <!-- <b-toast
      id="waiting"
      :autoHideDelay="waitingTime"
      solid
      :class="[lang == 'he' ? 'rtl' : 'ltr']"
    >
      <template #toast-title>
        <div class="d-flex flex-grow-1 align-items-baseline">
          <h3>{{ $t('booking.waiting') }}</h3>
        </div>
      </template>
      <div class="d-flex">
        <h5>{{ $t('booking.waiting-populating') }}</h5>
        <img :src="`${speedSizeDomain}/assets/img/waiting.gif`" alt="waiting"/>
      </div>
    </b-toast> -->
  </div>
</template>

<script>
import { BCardGroup, BCard, BCardText, BButton, BOverlay, BLink } from 'bootstrap-vue';
import dayjs from 'dayjs';
import { mapGetters } from 'vuex';
import gMixin from '@/utils/mixins';
import googleAnalytics from '@/utils/googleAnalytics';
import imageUrlMixin from '@/utils/imageUrlMixin';

const { VUE_APP_CHANNEL_MOBILE_APP,
//  VUE_APP_ADMIN_ENDPOINT,
} = process.env;

export default {
  components: {
    BCardGroup,
    BCard,
    BCardText,
    BButton,
    BOverlay,
    BLink,
    ContentLoading: () => import('@/components/atoms/ContentLoading'),
    PayerConfirmApp: () => import('@/components/booking/atoms/PayerConfirmApp'),

    HotelConfirmApp: () => import('@/components/booking/atoms/HotelConfirmApp'),
    FlightConfirmApp: () => import('@/components/booking/atoms/FlightConfirmApp'),
  },
  mixins: [gMixin, googleAnalytics, imageUrlMixin],
  computed: {
    ...mapGetters({
      isDesktopApp: 'GET_BONAUF_DESKTOP_APP',
      devMode: 'GET_MODE',
      isLoading: 'GET_LOADING_STATE',
      lang: 'GET_LANGUAGE',
      device: 'GET_DEVICE',
      marketerAgency: 'GET_MARKETER_AGENCY',
      typeChannel: 'GET_TYPE_CHANNEL',
      bypassPaymentState: 'GET_BYPASS_PAYMENT_STATE',
      bookingDataID: 'GET_BOOKING_DATA_ID',
      isOdysseySite: 'GET_ODYSSEY_AGENT_STATE',
    }),
    // bookingInfoPageLink() {
    //   return `${VUE_APP_ADMIN_ENDPOINT}/bookingInfo/${this.bookingDataID}`;
    // },
    getBetweenDateString() {
      let dateString = '';
      if (this.product && this.product.flights) {
        const checkIn = dayjs(this.product.flights[0]?.FlightDetail[0]?.FL_Date).add(Number(this.product.hotel_shift_1), 'day'),
          checkOut = checkIn.add(Number(this.product.duration_1), 'day');
        if (this.lang === 'he') {
          dateString = `${this.getWeek(checkIn)} ${dayjs(checkIn).format('DD/MM/YY')} - ${this.getWeek(checkOut)} ${dayjs(checkOut).format('DD/MM/YY')} (${this.product.hotels[0]?.duration} ${this.$t('search-result.night')})`;
        } else {
          dateString = `${this.getWeek(checkIn)} ${dayjs(checkIn).format('DD/MM/YY')} - 
            ${this.getWeek(checkOut)} ${dayjs(checkOut).format('DD/MM/YY')} (${this.hotels[0]?.duration} ${this.$t('search-result.night')})`;
        }
      }
      return dateString;
    },
  },
  data() {
    return {
      loading: false,
      bookingStage: 3,
      variantClass: 'success',
      variant: 'success',
      paymentSucceeded: 0,
      header: '',
      message: '',

      stateBooking: 'FH',

      allowRetry: 'false',
      showLink: false,

      pdfUrlTerms: null,
      pdfUrlItinerary: null,
      pdfUrlHotelVoucher: null,
      pdfUrlTicket: null,
      pdfUrlReceipt: null,

      orderNo: 'N/A',
      payer: null,
      payerJSON: '',
      price: 0,
      bookedHotel: null,
      flights: {
        outward: {},
        inward: {},
      },
      boolNotFinal: false,

      product: null,
      response: null,

      downDocument: null,

      showWaiting: false,
      waitingTime: 10 * 60 * 1000,

      isMobileApp: false,

      successfullySentMessage: false,
      sendingMessage: false,
    };
  },
  watch: {
    isLoading() {
      this.loading = this.isLoading;
    },
    lang: 'updateLabelWithLang',
  },
  async created() {
    this.isMobileApp = this.typeChannel === VUE_APP_CHANNEL_MOBILE_APP;
    this.$emit('setBookingStage', 3);
    window.scrollTo(0, 0);
    const product = JSON.parse(window.sessionStorage.getItem('production'));
    this.product = product;
    this.stateBooking = product.category.packageType;
    const BookingDetailInfo = JSON.parse(
      window.sessionStorage.getItem('BookingDetailInfo'),
    );
    this.payer = {
      orderNo: '',
      status: '',
      name: '',
      mobile: '',
      email: '',
      price: '',
    };
    this.payer = (this.bypassPaymentState) ? BookingDetailInfo.data.paxList[0] : BookingDetailInfo.data.payer;
    this.payer.orderNo = this.orderNo;
    this.payer.status = 'ERROR';
    this.payer.price = this.lang === 'he' ? `(₪${BookingDetailInfo.data.priceNIS}) ${this.getPriceWithSymbol(this.product.cc, BookingDetailInfo.data.price)}` : `${this.getPriceWithSymbol(this.product.cc, BookingDetailInfo.data.price)}`;

    if (this.stateBooking === 'FH') {
      // const fromDate = dayjs(product.fromDate).add(
      //     Number(product.hotel_shift_1),
      //   ),
      //   toDate = fromDate.add(product.duration_1, 'day');

      // const rooms = JSON.parse(window.sessionStorage.getItem('roomList'));
      // const paxes = {
      //   adult: 0, child: 0, infant: 0,
      // };
      // rooms.forEach((room) => {
      //   paxes.adult += room.adult;
      //   paxes.child += room.child;
      //   paxes.infant += room.infant;
      // });

      const hotels = JSON.parse(window.sessionStorage.getItem('roomList')).roomList;
      this.bookedHotel = {
        packCategCode: product.category.code,
        hotelPrice: 0,
        hotelName: product.hotels?.[0]?.hotelName,
        address: this.addressString(),
        // personString: this.getPersonString(paxes.adult, paxes.child, paxes.infant),
        grade: Number(product.hotels?.[0]?.grade.substr(0, 1)) || 0,
        period: this.getBetweenDateString,
        basisCode: product.hotels?.[0]?.basic_fare,
        supplements: product.addSupplement,
        hotels,
        imageList: [],
        translations: null,
      };

      // for (let i = 0; i < product.addSupplement.length; i++) {
      //   this.bookedHotel.transfer += product.translations.suppName[product.addSupplement[i].suppId][this.lang] + " ";
      // }

      /* for (let i = 0; i < hotels.length; i++) {
        this.bookedHotel.hotelPrice += hotels[i].price;
      } */

      const priceNIS = BookingDetailInfo.data.priceNIS !== undefined || BookingDetailInfo.data.priceNIS !== null ? BookingDetailInfo.data.priceNIS : 0,
        priceUSD = BookingDetailInfo.data.price !== undefined || BookingDetailInfo.data.price !== null ? BookingDetailInfo.data.price : 0;
      this.bookedHotel.price = this.lang === 'he' ? `( ₪${priceNIS} ) ${this.getPriceWithSymbol(this.product.cc, priceUSD)}` : `${this.getPriceWithSymbol(this.product.cc, priceUSD)}`;
      this.bookedHotel.hotelPrice = this.bookedHotel.price;

      // this.bookedHotel.price = BookingDetailInfo.data.price;
      // this.bookedHotel.hotelPrice = BookingDetailInfo.data.price;

      this.bookedHotel.imageList = this.bookedHotel.imageList.concat(
        product.perspectiveUrls,
      );
      this.bookedHotel.imageList = this.bookedHotel.imageList.concat(
        product.galleryUrls,
      );
      this.bookedHotel.translations = product.translations;
    }

    const flightID = `${BookingDetailInfo?.data?.outwardFlight?.flightId}${BookingDetailInfo?.data?.inwardFlight?.flightId}`;
    let idxFlight = product.flights.findIndex((flight) => `${flight.fl_id1}${flight.fl_id2}` === flightID);
    if (idxFlight < -1) {
      console.log('error for finding flight');
      idxFlight = 0;
    }
    const outwardFlight = product.flights[idxFlight].FlightDetail[0],
      inwardFlight = product.flights[idxFlight].FlightDetail[1];

    this.flights.outward = {
      airlineName: outwardFlight.arl_Name,
      airlineCode: outwardFlight.airlineInfo.code || outwardFlight.FL_AIRLINE,
      airlineNumber: outwardFlight.FL_Flt_Number,
      airlineID: outwardFlight.FL_ID,
      departureCode: outwardFlight.FL_From_Route,
      departureAddress: outwardFlight.FL_From_Route,
      depature: this.getFullDate(
        outwardFlight.FL_Date,
        outwardFlight.FL_Dep_Hour,
      ),
      arrival: this.getFullDate(
        outwardFlight.landingDate,
        outwardFlight.FL_Arrv_Hour,
      ),
      arrivalCode: outwardFlight.FL_To_Route,
      arrivalAddress: outwardFlight.FL_To_Route,
      including: outwardFlight.FL_Max_Weight,
      confirmed: outwardFlight.Authorization_msg,
    };

    this.flights.inward = {
      airlineName: inwardFlight.arl_Name,
      airlineCode: inwardFlight.airlineInfo.code || inwardFlight.FL_AIRLINE,
      airlineNumber: inwardFlight.FL_Flt_Number,
      airlineID: inwardFlight.FL_ID,
      departureCode: inwardFlight.FL_From_Route,
      departureAddress: inwardFlight.FL_From_Route,
      depature: this.getFullDate(
        inwardFlight.FL_Date,
        inwardFlight.FL_Dep_Hour,
      ),
      arrival: this.getFullDate(
        inwardFlight.landingDate,
        inwardFlight.FL_Arrv_Hour,
      ),
      arrivalCode: inwardFlight.FL_To_Route,
      arrivalAddress: inwardFlight.FL_To_Route,
      including: inwardFlight.FL_Max_Weight,
      confirmed: inwardFlight.Authorization_msg,
    };

    await this.makeOrder();

    // window.addEventListener('beforeunload', this.ClosingWindow);
  },
  mounted() {
    this.$bvToast.show('waiting');
    // this.makeOrder();

    if (document.querySelector('.st-content')) document.querySelector('.st-content').scrollTo(0, 0);
  },
  destroyed() {
    // window.removeEventListener('beforeunload', this.ClosingWindow);
  },
  methods: {
    gotoHome() {
      this.$router.push('/app?channel=App');
    },
    addAnalytics() {
      // const axel = `${Math.random()}`;
      // const a = axel * 10000000000000;
      // document.write(`<img src='${a}? width="1" height="1" alt=""/>`);
    },
    async makeOrder() {
      let refresh = false;
      const { query } = this.$route;
      const paymentTransUid = query.params;

      const BookingDetailInfo = JSON.parse(
        window.sessionStorage.getItem('BookingDetailInfo'),
      );
      if (!this.bypassPaymentState) {
        BookingDetailInfo.data.payer.IdenticationNumber = query.Tz;
      }
      window.sessionStorage.setItem('BookingDetailInfo', JSON.stringify(BookingDetailInfo));
      // this.$bvToast.show('waiting');

      const { marketerId } = this.$route.query;
      this.$store.commit('SET_MARKETER_ID', marketerId);
      if (marketerId) { await this.$store.dispatch('FETCH_AGENCY_FROM_MARKETER_ID'); }

      const payload = { paymentTransUid };
      if (this.bypassPaymentState) { // If B2B marketer or bypass payment marketer
        const retryState = JSON.parse(window.sessionStorage.getItem('retryState'));
        payload.retryState = retryState?.readOnly || false;
      }
      let res = await this.$store.dispatch('GET_BOOKED_INFO', payload);
      if (this.bypassPaymentState) { // If B2B marketer or bypass payment marketer
        window.sessionStorage.setItem('BookingDataID', res.bookingTransactionId);
      }

      if (res.data && res.data.error && Number(res.data.error.code) === 1) {
        res = await this.$store.dispatch('GET_SUCCEED_BOOKING');
        refresh = true;
      }
      this.response = res;
      await this.updateLabelWithLang();
      setTimeout(() => {
        if (this.showLink && !refresh) {
          if (this.pdfUrlTerms) this.downloadTickets(this.pdfUrlTerms, 'pdfUrlTerms');
          if (this.pdfUrlItinerary) this.downloadTickets(this.pdfUrlItinerary, 'Itinerary');
          if (this.pdfUrlHotelVoucher) this.downloadTickets(this.pdfUrlHotelVoucher, 'HotelVoucher');
          if (this.pdfUrlTicket) this.downloadTickets(this.pdfUrlTicket, 'Ticket');
          if (this.pdfUrlReceipt) this.downloadTickets(this.pdfUrlReceipt, 'Receipt');
        }
      }, 500);

      // this.addAnalytics();

      // if (!window.location.host.includes('vercel') && !refresh && this.response && this.response.status === 200 && !this.response.data.error && [8, 9].includes(this.response.data.status.code)) {
      if (this.availableEmitEventGA4ByDomain() && !refresh) {
        let name = '', listName = '', brand = '', checkInOut = '';
        let discount = 0, numberRoom = 0, nameCategory = '', bookState = '';

        nameCategory = this.product.category.name[this.lang];
        if (res.status.code === 8) {
          bookState = 'Saved Only';
        } else if (res.status.code === 9) {
          bookState = 'Successful Debit';
        }

        if (this.product.category.code !== 'Flight_Only') {
          // name = `${this.bookedHotel.hotelName} - ${this.product?.translations?.city?.[this.product.destination_1]?.he}`;
          discount = this.product.discountPercent;
          numberRoom = this.bookedHotel.hotels?.length ?? 0;
          name = this.bookedHotel.hotelName;
          checkInOut = this.bookedHotel.period;
          brand = this.bookedHotel.hotelName;
        } else {
          discount = this.product.discountPercentFO;
          name = `flight to ${this.product?.translations?.flightDestinationName?.[this.product.destination_1]?.he}`;
          checkInOut = `${this.product.flights[0].FlightDetail[0].FL_Date} - ${this.product.flights[0].FlightDetail[0].landingDate}`;
          brand = this.flights.outward.airlineName;
          listName = '';
        }

        const affiliation = this.isMobileApp ? 'BO NAUF' : 'Flying Carpet';
        const currencyCode = this.convertCurrencyCode(BookingDetailInfo.data?.currency);
        this.gtag('event', 'purchase', {
          transaction_id: this.response?.data?.pnr ?? '', // RANDON NUMBER
          value: this.response?.data?.totalPayment || 0,
          affiliation,
          currency: currencyCode,
          tax: 0,
          shipping: 0,
          // coupon: 'COUPON',
          items: [
            {
              item_id: this.response?.data?.pnr ?? '', // PNR
              item_name: name,
              affiliation,
              // coupon: "if using coupon please indicare here coupon name",
              index: 0,
              discount,
              item_brand: brand,
              item_category: checkInOut,
              item_category2: numberRoom,
              item_category3: nameCategory,
              item_category4: bookState,
              item_category5: this.response?.data?.pnr ?? '',
              item_list_id: '',
              item_list_name: listName,
              item_variant: '0',
              location_id: '0',
              quantity: 1,
              price: this.response?.data?.totalPayment || 0, // TOTAL SUM

            },
          ],
        });

        // this.gtag('event', 'purchase', {
        //   transaction_id: this.response?.data?.pnr ?? '', // RANDON NUMBER
        //   value: this.response?.data?.totalPayment || 0,
        //   // affiliation: marketerId === undefined || marketerId === '' ? 'Flying Carpet' : this.marketerAgency,
        //   affiliation,
        //   currency: currencyCode,
        //   // currency: 'USD',
        //   tax: 0,
        //   shipping: 0,
        //   items: [
        //     {
        //       id: this.response?.data?.pnr ?? '', // PNR
        //       // affiliation: marketerId === undefined || marketerId === '' ? 'Flying Carpet' : this.marketerAgency,
        //       affiliation,
        //       name, /// DEAL TYPE
        //       list_name: listName, // DESTINATION
        //       brand, // HOTEL NAME OR FLIGHT
        //       category: 'FLYING CHULL', // STATIC
        //       variant: 'ONLINE DEAL', // STATIC
        //       list_position: 1,
        //       quantity: 1,
        //       price: this.response?.data?.totalPayment || 0, // TOTAL SUM
        //     },
        //   ],
        // });
      }
      // const _oneself = this;
      // setTimeout(() => {
      //   _oneself.$bvToast.hide('waiting');
      // }, 200);
    },
    showWaitingToast(pType) {
      if (pType === 'show') {
        const h = this.$createElement;
        const vNodesMsg = h('div', { class: ['dp-flex'] }, [
          h('span', {}, this.$t('booking.waiting-populating')),
          h('b-img', { props: { src: `${this.speedSizeDomain}/assets/img/waiting.gif` } }),
        ]);
        const vNodesTitle = h(
          'div',
          { class: ['d-flex', 'flex-grow-1', 'align-items-baseline'] },
          [h('strong', {}, this.$t('booking.waiting'))],
        );
        this.$bvToast.toast([vNodesMsg], {
          title: [vNodesTitle],
          solid: true,
          noAutoHide: true,
          ok: false,
          bodyClass: this.lang === 'he' ? 'rtl' : 'ltr',
        });
      } else if (pType === 'hide') {
        this.$bvToast.hide();
      }
    },
    async updateLabelWithLang() {
      const { translations } = this.product;
      this.flights.outward.departureAddress = translations?.flightDestinationName[this.flights.outward.departureCode][this.lang] || this.flights.outward?.departureAddress;
      this.flights.inward.departureAddress = translations?.flightDestinationName[this.flights.inward.departureCode][this.lang] || this.flights.inward?.departureAddress;
      this.flights.outward.arrivalAddress = translations?.flightDestinationName[this.flights.outward.arrivalCode][this.lang] || this.flights.outward?.arrivalAddress;
      this.flights.inward.arrivalAddress = translations?.flightDestinationName[this.flights.inward.arrivalCode][this.lang] || this.flights.inward?.arrivalAddress;

      // if need translate for flights.confirmed, please add it here
      if (this.response && this.response.status === 200) {
        const stateBook = this.response.data,
          { error } = stateBook;

        this.payer.price = this.lang === 'he' ? `(₪${stateBook.totalPaymentInNIS}) ${this.getPriceWithSymbol(this.product.cc, stateBook.totalPayment)}` : `${this.getPriceWithSymbol(this.product.cc, stateBook.totalPayment)}`;
        if (this.bookedHotel) {
          this.bookedHotel.hotelPrice = this.payer.price;
          this.bookedHotel.period = this.getBetweenDateString;
        }
        // this.showLink = stateBook.paymentSucceeded;
        if (!error) {
          this.showLink = true;
          this.pdfUrlTerms = stateBook.pdfUrlTerms;
          this.pdfUrlItinerary = stateBook.pdfUrlItinerary;
          this.pdfUrlHotelVoucher = stateBook.pdfUrlHotelVoucher;
          this.pdfUrlTicket = stateBook.pdfUrlTicket;
          this.pdfUrlReceipt = stateBook.pdfUrlReceipt;

          this.variantClass = 'success';
          this.header = this.variant.toUpperCase();
          this.message = stateBook.messageToVisitor[this.lang];
          this.orderNo = stateBook.pnr;
          this.payer.orderNo = this.orderNo;

          if (stateBook.paymentSucceeded) {
            this.variant = this.$t('booking.success');
            this.payer.status = 'OK';
            // this.payer.price = stateBook.totalPayment;
            // if (this.bookedHotel) this.bookedHotel.hotelPrice = stateBook.totalPayment;

            this.allowRetry = false;
            window.sessionStorage.setItem('retryState', null);
          } else if (stateBook.status.code === 8) {
            this.variant = this.$t('booking.warning');
            // this.message = error.message[this.lang] || error.message.en;
            // if (this.devMode) this.showLink = true;
            this.payer.status = 'RQ';
            // this.payer.price = stateBook.totalPayment;
            // if (this.bookedHotel) this.bookedHotel.hotelPrice = stateBook.totalPayment;

            this.allowRetry = false;
            window.sessionStorage.setItem('retryState', null);
          }
        } else if (error) {
          if (stateBook.status.code === -3 || stateBook.status.code === -4 || stateBook.status.code === -6 || stateBook.status.code === -7) {
            this.payer.status = 'REFUSE';
          } else {
            this.payer.status = 'ERROR';
          }
          this.showLink = false;
          this.variant = this.$t('booking.danger');
          this.header = this.$t('booking.error');
          this.variantClass = 'warning';
          this.message = error.message[this.lang] || error.message.en;
          this.orderNo = stateBook.pnr || 'N/A';
          this.payer.orderNo = this.orderNo;
          // this.payer.price = stateBook.totalPayment;

          // if (this.bookedHotel) this.bookedHotel.hotelPrice = stateBook.totalPayment;
          const retryState = {
            readOnly: error.retryPaymentMethodOnly,
          };
          window.sessionStorage.setItem('retryState', JSON.stringify(retryState));
          if (error.retryAllowed) {
            this.allowRetry = true;
            // if(error.retryPaymentMethodOnly ){
            //     window.removeEventListener('beforeunload', this.ClosingWindow);
            //     window.history.go(-4);
            // }
          } else {
            this.allowRetry = false;
          }
        }

        this.payer = JSON.parse(JSON.stringify(this.payer));
      } else {
        this.header = this.$t('booking.error');
        this.variant = this.$t('booking.danger');
        // this.message = this.response.error.message;
        this.message = this.$t('booking.error');
        this.variantClass = 'danger';
        this.allowRetry = false;
        // this.allowRetry = true;
        // let retryState = {
        //     readOnly: false,
        // };
        // window.sessionStorage.setItem("retryState", JSON.stringify(retryState));
      }
    },
    goToDebit() {
      // window.removeEventListener('beforeunload', this.ClosingWindow);
      const info = JSON.parse(window.sessionStorage.getItem('production'));
      let body = {};
      if (this.stateBooking === 'FH') {
        body = {
          packID: info.packId,
          laID: info.hotels[0].La_ID,
          flights: info.outwardFlight.flightId + info.inwardFlight.flightId,
        };
        this.$router.push({ path: '/booking/hotel-flight/app', query: body });
      } else if (this.stateBooking === 'F') {
        body = {
          packID: info.packId,
          flights: info.outwardFlight.flightId + info.inwardFlight.flightId,
        };
        this.$router.push({ path: '/booking/flight/app', query: body });
      }
    },
    async ClosingWindow() {
      const bookingDataID = this.bookingDataID || window.sessionStorage.getItem('BookingDataID');
      await this.$store.dispatch('SEND_CLOSING_NOTICE', {
        bookDataID: bookingDataID,
        withData: false,
      });
    },
    getFullDate(pDate, pTime) {
      const data = { dateTime: '', notFinal: false };
      if (pTime === 'NOT_FINAL') {
        data.dateTime = dayjs(pDate).format('DD/MM/YYYY');
        data.notFinal = true;
      } else {
        data.dateTime = dayjs(`${pDate} ${pTime}`).format('DD/MM/YYYY, hh:mm a');
        data.notFinal = false;
      }
      return data;
    },
    downloadTickets(pURL, pName) {
      this.$bvToast.toast(this.$t('booking.waiting-downloading'), {
        title: this.$t('booking.downloading'),
        autoHideDelay: 30 * 1000,
        appendToast: true,
        variant: 'info',
        noCloseButton: true,
        bodyClass: this.lang === 'he' ? 'rtl' : 'ltr',
      });
      const fileName = `${pName}.pdf`;
      if (!window.ActiveXObject) {
        const save = document.createElement('a');
        save.href = pURL;
        save.target = '_blank';
        save.download = fileName;
        if (navigator.userAgent.toLowerCase().match(/(ipad|iphone|safari)/) && navigator.userAgent.search('Chrome') < 0) {
          document.location = save.href;
          // window event not working here
        } else {
          // const evt = new MouseEvent('click', {
          //   view: window,
          //   bubbles: true,
          //   cancelable: false,
          // });
          const evt = new MouseEvent('click');
          save.dispatchEvent(evt);
          (window.URL || window.webkitURL).revokeObjectURL(save.href);
        }
      } else if (!!window.ActiveXObject && document.execCommand) {
        const _window = window.open(pURL, '_blank');
        _window.document.close();
        _window.document.execCommand('SaveAs', true, fileName);
        _window.close();
      }
    },
    handleRatingApp() {
      window.location = 'https://admin1.flyingcarpet.co.il/upload/rating.html#success';
    },
    async sendMessage() {
      this.sendingMessage = true;
      const response = await this.$store.dispatch('SEND_MESSAGE_TO_CLIENT');
      this.sendingMessage = false;
      let message = '';
      if (response === 'error') {
        this.successfullySentMessage = false;
        message = 'error';
      } else {
        this.successfullySentMessage = true;
        message = response;
      }
      this.$bvToast.toast(message, {
        title: 'Confirm',
        solid: true,
        noAutoHide: true,
        ok: false,
        bodyClass: 'ltr',
      });
    },
    getWeek(str) {
      const week = [
        this.$t('weekAllName.sun'),
        this.$t('weekAllName.mon'),
        this.$t('weekAllName.tue'),
        this.$t('weekAllName.wed'),
        this.$t('weekAllName.thu'),
        this.$t('weekAllName.fri'),
        this.$t('weekAllName.sat'),
      ];
      return week[dayjs(str).day()];
    },
    addressString() {
      if (!this.product) return '';
      return this.product.category.code === 'Organize_tour_packages' ? this.product.hotels[0].cityName : this.product.hotels[0].address;
    },
    // getPersonString(adult, child, infant) {
    //   let str = ` ${this.$t('product-page.adult-number')}: ${adult}`;
    //   if (child) str += `, ${this.$t('product-page.child')}: ${child}`;
    //   if (infant) str += `, ${this.$t('product-page.infant')}; ${infant}`;
    //   return str;
    // },
  },
};
</script>

<style>
#waiting.ltr {
  direction: ltr;
}
#waiting.rtl {
  direction: rtl;
}
#waiting h5 {
  padding: 15px 5px;
  font-size: 15px;
}
#waiting img {
  width: 100px;
}
#waiting h3 {
  font-size: 22px;
  font-weight: 600;
  color: #313131;
  text-align: center;
}
</style>

<style scoped>

@import '/assets/css/bonaufApp.css';

.card-deck .card {
  margin-bottom: 25px;
}
button.backDebit {
  background: #0061ab;
  color: #fff;
  margin: 10px 10px;
}

h1 {
  font-size: 45px;
  font-weight: 400;
  color: #0e436b;
  text-align: center;
  text-transform: uppercase;
  margin-bottom: 30px;
}

.after_booking_area .order_no_box {
  width: 100%;
  height: 120px;
  box-sizing: border-box;
  border-radius: 5px;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  padding: 40px 20px;
  margin-bottom: 25px;
}
.after_booking_area .order_no_box .order_no_div {
  width: 100%;
  text-align: left;
}
.after_booking_area .order_no_box .order_no_div h2 {
  margin: 0 0;
  padding: 6px 0;
  color: #fff;
  font-size: 26px;
  font-weight: 400;
  text-transform: uppercase;
}
.after_booking_area .order_no_box .order_no_div h2 strong.order_no {
  color: #79bff5;
}
.after_booking_area .order_no_box .order_no_div p {
  margin: 0 0;
  color: #fff;
  font-size: 15px;
}
.after_booking_area .order_no_box .order_no_div p a {
  text-decoration: underline;
  color: #fff;
  transition: 0.5s;
}
.after_booking_area .order_no_box .order_no_div p a:hover {
  text-decoration: none;
}

.please_mall_area {
  margin-top: 30px;
  margin-bottom: 25px;
}
.please_mall_area .plase_mall_contain_box {
  border: 1px solid #949494;
}
.please_mall_area .plase_mall_contain_box h3 {
  padding: 20px 20px;
  border-bottom: 1px solid #949494;
  font-size: 24px;
  text-transform: uppercase;
}
.please_mall_area .plase_mall_contain_box h3 span {
  color: #0763ab;
}
.please_mall_area .please_mall_contain_body {
  padding: 30px 20px;
}
.please_mall_contain_body .please_mall {
  width: 100%;
  text-align: center;
}
.please_mall_contain_body .please_mall .icon_box {
  width: 88px;
  height: 82px;
  border: 1px solid #0763ab;
  border-radius: 5px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0px auto 0px;
  padding-top: 15px;
}
.please_mall_contain_body .please_mall h5 {
  text-transform: uppercase;
  color: #000;
  margin: 0 0;
  font-size: 18px;
  padding-bottom: 10px;
}
.please_mall_area .img_box {
  height: 275px;
  overflow: hidden;
  border-radius: 5px;
}

#btnSubmit {
  color: #fff;
  background-color: #0061ab;
  border-color: #0061ab;
  font-size: 26px;
  font-weight: bold;
}

 .desktop-app .after_booking_area .order_no_box {
    width: 100%;
    height: auto;
    background-position: right;
    padding: 5px 20px;
    margin-bottom: 15px;
  }
  .desktop-app .order_no_box .d-flex {
    display: block !important;
  }
  .desktop-app .after_booking_area .order_no_box .order_no_div p {
    font-size: 12px;
  }
  .desktop-app .after_booking_area .order_no_box .order_no_div h2 {
    font-size: 16px;
  }
  .desktop-app .please_mall_area .img_box {
    height: auto;
  }
  .desktop-app .please_mall_area .plase_mall_contain_box h3 {
    padding: 14px 13px;
    font-size: 15px;
    text-transform: uppercase;
    text-align: center;
  }
  .desktop-app .please_mall_area .please_mall_contain_body {
    padding: 0px 10px 15px;
  }
  .desktop-app .please_mall_area .please_mall_contain_body .d-flex {
    display: block !important;
  }
  .desktop-app .please_mall_area .please_mall_contain_body .please_mall {
    margin-top: 15px;
  }
  .desktop-app .please_mall_area .please_mall_contain_body .please_mall {
    width: 50%;
    /* text-align: center;
    box-shadow: 2px 3px 2px 2px rgb(0 0 0 / 6%);
    border-radius: 5px; */
  }

  .desktop-app .please_mall_area .please_mall_contain_body .please_mall > div{
    text-align: center;
    box-shadow: 3px 5px 2px 1px rgb(0 0 0 / 20%);
    border-radius: 10px;
  }

  .desktop-app .apparea .card-deck .border-success {
    width: 100%;
    box-sizing: border-box;
    position: relative;
    background-clip: padding-box;
    border: 1px solid;
    border-image: linear-gradient(45deg, #fb6d2f, #f9ff00) 1;
    padding: 12px;
    box-shadow: 0 0 12px rgb(169 169 169 / 60%);
    background-color: #ffffff;
    margin-bottom: 20px;
  }
  .desktop-app .plase_mall_contain_box h2 {
    background: linear-gradient(90deg, #0293d0 0%, rgba(132,219,255,1) 100%);
    padding: 15px;
    box-sizing: border-box;
    color: #ffffff;
    font-family: 'FbCoherentiSansBold';
    font-size: 20px;
    text-align: center;
    display: flex;
    align-items: center;
  }
  .desktop-app .please_mall_area.kremlin-area .kremlin-list ul li{
    width: 50% !important;
    max-width: 50%;
    float: right;
    padding: 5px 30px;
  }
  .desktop-app .please_mall .icon_box img {
    padding: 15px;
  }
  .desktop-app .please_mall_area.kremlin-area .please_mall_contain_body .please_mall .icon_box{
    border: unset;
  }

  .desktop-app .please_mall_area.order-area.card.kremlin-area{
    border: unset;
  }
  .desktop-app .please_mall_area .plase_mall_contain_box.kremlin-list{
    border: unset;
  }

@media (min-width: 991.98px) and (max-width: 1200px) {
  .please_mall_contain_body .please_mall .icon_box {
    width: 70px;
    height: 70px;
  }
}

@media (max-width: 1200px) {
  .please_mall_area .img_box img {
    width: 100%;
  }
}

@media (max-width: 479px) {
  .after_booking_area .order_no_box {
    width: 100%;
    height: auto;
    background-position: right;
    padding: 5px 20px;
    margin-bottom: 15px;
  }
  .order_no_box .d-flex {
    display: block !important;
  }
  .after_booking_area .order_no_box .order_no_div p {
    font-size: 12px;
  }
  .after_booking_area .order_no_box .order_no_div h2 {
    font-size: 16px;
  }
  .please_mall_area .img_box {
    height: auto;
  }
  .please_mall_area .plase_mall_contain_box h3 {
    padding: 14px 13px;
    font-size: 15px;
    text-transform: uppercase;
    text-align: center;
  }
  .please_mall_area .please_mall_contain_body {
    padding: 0px 10px 15px;
  }
  .please_mall_area .please_mall_contain_body .d-flex {
    display: block !important;
  }
  .please_mall_area .please_mall_contain_body .please_mall {
    margin-top: 15px;
  }
  .please_mall_area .please_mall_contain_body .please_mall {
    width: 50%;
    /* text-align: center;
    box-shadow: 2px 3px 2px 2px rgb(0 0 0 / 6%);
    border-radius: 5px; */
  }

  .please_mall_area .please_mall_contain_body .please_mall > div{
    text-align: center;
    box-shadow: 3px 5px 2px 1px rgb(0 0 0 / 20%);
    border-radius: 10px;
  }

  .apparea .card-deck .border-success {
    width: 100%;
    box-sizing: border-box;
    position: relative;
    background-clip: padding-box;
    border: 1px solid;
    border-image: linear-gradient(45deg, #fb6d2f, #f9ff00) 1;
    padding: 12px;
    box-shadow: 0 0 12px rgb(169 169 169 / 60%);
    background-color: #ffffff;
    margin-bottom: 20px;
  }
  .plase_mall_contain_box h2 {
    background: linear-gradient(90deg, #0293d0 0%, rgba(132,219,255,1) 100%);
    padding: 15px;
    box-sizing: border-box;
    color: #ffffff;
    font-family: 'FbCoherentiSansBold';
    font-size: 22px;
    text-align: center;
    display: flex;
    align-items: center;
  }
  .please_mall_area.kremlin-area .kremlin-list ul li{
    width: 50% !important;
    max-width: 50%;
    float: right;
    padding: 5px 30px;
  }
  .please_mall .icon_box img {
    padding: 15px;
  }
  .please_mall_area.kremlin-area .please_mall_contain_body .please_mall .icon_box{
    border: unset;
  }

  .please_mall_area.order-area.card.kremlin-area{
    border: unset;
  }
  .please_mall_area .plase_mall_contain_box.kremlin-list{
    border: unset;
  }
}
</style>
