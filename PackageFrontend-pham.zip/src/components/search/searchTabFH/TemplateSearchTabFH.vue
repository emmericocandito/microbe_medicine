<template>
  <div>Template Search Tab For Hotel Flight</div>
</template>

<script>
import { mapGetters } from 'vuex';

const { VUE_APP_ENABLE_AGENT_CODE } = process.env;

export default {
  name: 'TemplateSearchTab',
  props: {
    category: {
      type: Object,
      default: null,
    },
    type: {
      type: String,
      default: 'tabs',
    },
    agentList: {
      type: Array,
      default: () => [],
    },
  },
  computed: {
    ...mapGetters({
      device: 'GET_DEVICE',
      currCategory: 'GET_CURRENT_CATEGORY',
      availSubjects: 'GET_SUBJECTS',
      calendarData: 'GET_CALENDAR_DATA',
      isLoading: 'GET_LOADING_STATE',
      lang: 'GET_LANGUAGE',
      isLanding: 'GET_IS_LANDING_PAGE',
      landingInfo: 'GET_LANDING_INFO',
      marketerId: 'GET_MARKETER_ID',
      isOdysseySite: 'GET_ODYSSEY_AGENT_STATE',
      odyAgentCode: 'GET_SELECTED_ODYSSEY_AGENT_CODE',
      loginOdyAgentCode: 'GET_LOGIN_ODYSSEY_AGENT_CODE',
      isFcAgentMarketerMode: 'GET_FC_AGENT_MARKETER_MODE',
      searchContent: 'GET_SEARCH_CONTENT',
    }),
    destinations() {
      return this.currCategory.destinations;
    },
    subjects() {
      return this.searchContent?.subject || [];
    },
    months() {
      return this.searchContent?.month || [];
    },
    disableLeague() {
      return this.availSubjects.length === 0;
    },
    disableMonths() {
      return this.availableDates.length === 0;
    },
    searchDisable() {
      let boolDisable = true;
      if (!this.isSportPack) {
        boolDisable = !this.destination || ((!this.fromDate || !this.toDate) && this.months.length === 0) || !this.countAdult;
      } else {
        boolDisable = this.subjects.length === 0 || this.months.length === 0 || !this.countAdult;
      }
      return boolDisable;
    },
    countAdult: {
      get() {
        return this.$store.getters.GET_SEARCH_CONTENT.adult ? this.$store.getters.GET_SEARCH_CONTENT.adult : 2;
      },
      set(value) {
        this.$store.dispatch('SET_SEARCH_ITEM', ['adult', value]);
      },
    },
    countChild: {
      get() {
        return this.$store.getters.GET_SEARCH_CONTENT.child ? this.$store.getters.GET_SEARCH_CONTENT.child : 0;
      },
      set(value) {
        this.$store.dispatch('SET_SEARCH_ITEM', ['child', value]);
      },
    },
    countInfant: {
      get() {
        return this.$store.getters.GET_SEARCH_CONTENT.infant ? this.$store.getters.GET_SEARCH_CONTENT.infant : 0;
      },
      set(value) {
        this.$store.dispatch('SET_SEARCH_ITEM', ['infant', value]);
      },
    },
    availableDates() {
      const { calendarData } = this;
      if (!calendarData) return [];
      return [...this.calendarData];
    },
    availableSubject() {
      const { currCategory, availSubjects } = this;
      if (!currCategory || !availSubjects) return [];
      return availSubjects.filter((sub) => (sub.active && currCategory.subjectCodes.findIndex((code) => (sub.code.includes(code))) > -1));
    },
    destinationText() {
      const { destination, lang } = this;
      if (!destination) return '';

      const destinationList = this.currCategory.destinations;
      const currentItem = destinationList.find((dest) => dest.code === destination);
      return `${currentItem?.name?.[lang] ?? destination}`;
    },
    disableDestination() {
      return this.isOdysseySite && (this.agent === '' || this.agent === null);
    },
    disableCalendar() {
      return this.destination === '';
    },
    disableOccupancy() {
      return (this.fromDate === '' || this.toDate === '') && this.months.length === 0;
    },
    categoryOptions() {
      const { lang } = this;
      let options = [];
      options = this.category?.series?.map((cate) => ({
        text: cate.name[lang],
        value: cate.code,
      }));
      return options;
    },
    hotDestinations() {
      return this.category?.hotDestinations ?? [];
    },
    listLeague() {
      return this.isSportPack;
    },
    isSportPack() {
      return this.currCategory.code === 'sport_pack';
    },
  },
  watch: {
    currCategory: 'changedCategory',
    lang() {},
    agent() {
      this.$store.commit('SET_SELECTED_ODYSSEY_AGENT_CODE', this.agent);
    },
    // $route() {
    //   this.$router.go();
    // },
  },
  data() {
    return {
      categoryId: null,
      // availableDates: [],
      minDate: 'today',
      travelWork: false,
      isOrganized: false,

      selectedCategory: '',
      destination: '',
      selectFamilyAll: 'all',
      fromDate: '',
      toDate: '',
      destinationChanged: false,
      dropdownShow: false,
      progressValue: 0,
      agent: '',
      changeEnableAgentCode: VUE_APP_ENABLE_AGENT_CODE,
    };
  },
  created() {
    this.agent = this.odyAgentCode;
  },
  async beforeMount() {
    // if (!this.calendarData) {
    //   await this.$store.dispatch('FETCH_CALENDAR_DATA');
    // }
    this.changedCategory();
  },
  methods: {
    submitSearch(event) {
      event.preventDefault();
      const categoryId = this.currCategory.code;
      this.$store.dispatch('UPDATE_CURRENT_CATEGORY', { categoryId });
      if (this.isLoading) {
        // this.$bvModal.msgBoxConfirm(
        //   this.$t('search-tab.is-loading-warning-message'),
        //   {
        //     title: this.$t('search-tab.is-loading-warning-title'),
        //     size: 'sm',
        //     buttonSize: 'sm',
        //     okVariant: 'danger',
        //     okTitle: this.$t('login.yes'),
        //     cancelTitle: this.$t('login.no'),
        //     headerClass: 'p-2 border-bottom-0',
        //     footerClass: 'p-2 border-top-0',
        //     centered: true,
        //   },
        // )
        //   .then((value) => {
        //     if (value) {
        //       this.$store.dispatch('FETCH_STOP');
        //       this.applySearch();
        //     }
        //   });
        this.$store.dispatch('FETCH_STOP');
        setTimeout(() => { this.applySearch(); }, 100);

        return false;
      }
      this.applySearch();
      return true;
    },
    applySearch() {
      if (this.type === 'mobile') {
        this.$emit('closeSearchMobile');
      }

      if (this.searchDisable) {
        return false;
      }
      let body = {}, path = '/search-result';
      if (!this.isSportPack) {
        body = {
          dest: this.destination,
          fromDate: this.fromDate,
          toDate: this.toDate,
          categoryId: this.currCategory.code,
          adult: this.countAdult,
          child: this.countChild,
          infant: this.countInfant,
          odyAgentCode: this.agent,
        };
      } else {
        body = {
          categoryId: this.currCategory.code,
          dest: encodeURIComponent(this.currCategory.destinations.map((item) => item.code).join(',')),
          yearMonth: this.months.map((item) => item.value).join(','),
          subjectIds: this.subjects.map((item) => item.value).join(','),
          adult: this.countAdult,
          child: this.countChild,
          infant: this.countInfant,
          odyAgentCode: this.agent,
        };
        path = '/search-result-sportpack';
      }
      if (this.$route.query.utm_source) body.utm_source = this.$route.query.utm_source;
      if (this.$route.query.secret) body.secret = this.$route.query.secret; // temporary param for Ran's search
      if (this.isLanding) body.utm_source = this.landingInfo.utm_source;
      if (this.marketerId) body.marketerId = this.marketerId;
      if (this.isFcAgentMarketerMode) body['fc-agent-mode'] = '';
      const { query } = this.$route;
      if (Object.keys(body).every((key) => String(body[key]) === String(query[key]))) return false;

      this.$router.push({ path, query: body });
      if (this.isLanding) {
        const queryString = `${path}?${new URLSearchParams(body).toString()}`;
        window.location.href = queryString;
      }
      return true;
    },
    resetDate() {
      this.$store.dispatch('SET_SEARCH_ITEM', ['from', '']);
      this.$store.dispatch('SET_SEARCH_ITEM', ['to', '']);
    },
    optionSelect(value) {
      if (this.device === 'desktop') {
        this.destinationChanged = value;
      }
    },
    async changed(dest) {
      if (!dest || (Array.isArray(dest) && !dest[0])) return false;
      this.resetDate();
      this.destination = dest.length ? dest[0].value : dest.value;

      const categorySubjectIdList = this.currCategory.subjectCodes.map(
        (item) => item,
      );

      await this.$store.dispatch('FETCH_CALENDAR_DATA', { dest: this.destination, subjects: categorySubjectIdList });
      return true;
    },
    async changedLeague(pLeague) {
      if (!pLeague) return;
      this.$store.dispatch('SET_SEARCH_ITEM', ['subject', pLeague]);
      this.$store.dispatch('SET_SEARCH_ITEM', ['month', []]);
      if (this.isSportPack) {
        await this.$store.dispatch('FETCH_CALENDAR_DATA', {
          dest: this.currCategory.destinations.map((d) => d.code),
          subjects: pLeague.map((item) => item.value),
        });
      }
    },
    changeMonths(pMonths) {
      if (!pMonths) return;
      this.$store.dispatch('SET_SEARCH_ITEM', ['month', pMonths]);
    },
    chooseDate(date) {
      this.fromDate = date.from;
      this.toDate = date.to;
    },
    finalDateSelect(value) {
      this.dropdownShow = value;
    },
    changeCount({ adult, child, infant }) {
      this.countAdult = adult;
      this.countChild = child;
      this.countInfant = infant;
    },
    async changedCategory() {
      this.selectedCategory = this.currCategory.code;
      this.categoryId = this.currCategory.code;
      this.isOrganized = this.currCategory.code === 'Organize_tour_packages';
    },
    async selectingSeriesCategory() {
      this.destinationChanged = false;
      this.categoryId = this.selectedCategory;
      this.$store.dispatch('UPDATE_CURRENT_CATEGORY', { categoryId: this.selectedCategory });
      this.$store.dispatch('RESET_SEARCH_CONTENT');
    },
  },
};
</script>
