<template>
  <div class="plaindetails-box">
    <!------- tooltip box start ------->
    <div class='tooltipmainbox'>
      <button class="btn-tooltip" @click="toggleTooltip"><i class="fa-solid fa-circle-info"></i></button>
      <div class="tooltip active" v-show="showTooltip">
          <h6>{{ $t("flight-only.baggage-details-title") }}</h6>
          <ul>
              <li>
                  <img :src="`${speedSizeDomain}/assets/img/app/trolley.png`" alt="#" class="icon" />
                  {{$t("flight-only.bag-description", {weight: maxBag})}}
              </li>
              <li>
                  <img :src="`${speedSizeDomain}/assets/img/app/suitcase.png`" alt="#" class="icon" />
                  {{$t("flight-only.luggage-description", {weight: maxLuggage})}}
              </li>
          </ul>
      </div>
    </div>
    <!------- tooltip box stop ------->
    <figure class="logo"><img v-if="!flight.FlightDetail[idxFlightDetail].airlineNotConfirmed" :src="logoFlight" alt="" title="" /></figure>
    <div class="plain-date">
      <div class="d-flex justify-content-between align-items-center" v-if="direction === 'departure'">
        <div class="box">
          <h3>{{ departureTime }}</h3>
          <h4>{{ departureRoute }}</h4>
        </div>
        <figure class="flight-box">
          <img :src="`${speedSizeDomain}/assets/img/app/flight-img1.png`" alt="#" title="" />
        </figure>
        <div class="box">
          <h3>{{ arriveTime }}</h3>
          <h4>{{ arriveRoute }}</h4>
        </div>
      </div>
      <div class="d-flex justify-content-between align-items-center" v-else>
        <div class="box">
          <h3>{{ arriveTime }}</h3>
          <h4>{{ arriveRoute }}</h4>
        </div>
        <figure class="flight-box">
          <img class="arrive" :src="`${speedSizeDomain}/assets/img/app/flight-img1.png`" alt="#" title="" />
        </figure>
        <div class="box">
          <h3>{{ departureTime }}</h3>
          <h4>{{ departureRoute }}</h4>
        </div>
      </div>
    </div>
    <p><span>{{ descriptionFlight }}<br/>{{ codeFlight }}</span><br/>{{ authorizeFlight }}</p>
    <h5>{{ Math.min(flight.avl1, flight.avl2) > 8 ? '' : `${$t("search-result.number-seats-left")}: ${Math.min(flight.avl1,flight.avl2)}`}}</h5>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';
import imageUrlMixin from '@/utils/imageUrlMixin';

export default {
  name: 'SingleFlightItem',
  mixins: [imageUrlMixin],
  props: {
    flight: {
      type: Object,
      default: null,
    },
    showExtraInfo: {
      type: Boolean,
      default: false,
    },
    direction: {
      type: String,
      default: 'departure',
    },
  },
  data() {
    return {
      showTooltip: false,
      maxLuggage: 0,
      maxBag: 0,
    };
  },
  computed: {
    ...mapGetters({
      lang: 'GET_LANGUAGE',
    }),
    idxFlightDetail() {
      return this.direction === 'departure' ? 0 : 1;
    },
    descriptionFlight() {
      return this.flight.FlightDetail[this.idxFlightDetail]?.airlineInfo?.desc1 ?? '';
    },
    codeFlight() {
      return this.flight.FlightDetail[this.idxFlightDetail].FL_IsFinal ? `${this.flight.FlightDetail[this.idxFlightDetail].airlineInfo.code || this.flight.FlightDetail[this.idxFlightDetail].FL_AIRLINE} - ${this.flight.FlightDetail[this.idxFlightDetail].FL_Flt_Number}` : '';
    },
    authorizeFlight() {
      return this.flight.FlightDetail[this.idxFlightDetail].Authorization_msg;
    },
    logoFlight() {
      return (this.flight.FlightDetail[this.idxFlightDetail].airlineInfo && this.flight.FlightDetail[this.idxFlightDetail].airlineInfo.desc2) || `${this.speedSizeDomain}/assets/img/flying.png`;
    },
    departureRoute() {
      return (this.flight.translations && this.flight.translations.flightDestinationName[this.flight.FlightDetail[this.idxFlightDetail].FL_From_Route] && this.flight.translations.flightDestinationName[this.flight.FlightDetail[this.idxFlightDetail].FL_From_Route][this.lang]) || this.flight.FlightDetail[this.idxFlightDetail].FL_From_Route;
    },
    departureTime() {
      return this.flight.FlightDetail[this.idxFlightDetail].FL_Dep_Hour;
    },
    arriveRoute() {
      return (this.flight.translations && this.flight.translations.flightDestinationName[this.flight.FlightDetail[this.idxFlightDetail].FL_To_Route] && this.flight.translations.flightDestinationName[this.flight.FlightDetail[this.idxFlightDetail].FL_To_Route][this.lang]) || this.flight.FlightDetail[this.idxFlightDetail].FL_To_Route;
    },
    arriveTime() {
      return this.flight.FlightDetail[this.idxFlightDetail].FL_Arrv_Hour;
    },
  },
  created() {
    this.maxBag = this.flight.FlightDetail[this.idxFlightDetail]?.FL_Max_Weight_Hand || 5;
    this.maxLuggage = this.flight.FlightDetail[this.idxFlightDetail]?.FL_Max_Weight || this.flight.FlightDetail[this.idxFlightDetail]?.maxWeight;
  },
  methods: {
    toggleTooltip() {
      this.showTooltip = !this.showTooltip;
    },
  },
};
</script>

<style>
  .heading h1{
    font-weight: bold;
  }
  .plaindetails-box .tooltipmainbox .tooltip.active {
      display: inline-block;
      opacity: 1;
  }
  .plaindetails-box .logo img{
    max-height: 50px;
    width: auto;
  }
  .plaindetails-box .plain-date .flight-box img.arrive{
    -webkit-transform: scaleX(-1);
    translform: scaleX(-1);
  }
</style>
