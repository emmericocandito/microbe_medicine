<template>
  <div class="w-100">
    <div class="text-center associated-selection" :class="{'mb-4': device==='mobile', 'w-50 mx-auto': device==='desktop'}">
      <!-- :dropdownShouldOpen="() => true" -->
      <v-select v-model="selectedDate" :options="productsListOptions" :searchable="false" dir="rtl" :selectable="optionSelectable" :clearable="false">
        <template #selected-option="{ startLabel, endLabel, duration }">
          <div class="mr-1" style="position: relative;">
            <span style="text-wrap: nowrap;">
              <span class="associated-selection-label align-self-center">{{ $t('product-page.choose-dates') }}</span><br/>
              {{startLabel}}-{{ endLabel }}-{{ duration }} {{ $t('search-result.night') }}
            </span>
          </div>
        </template>

        <template #list-header>
          <div class="option row associated-selection-header">
            <span style="width: 29%;" class="text-center"> {{ $t('booking.departure-date') }}</span>
            <span style="width: 29%;" class="text-center">{{ $t('booking.arrival-date') }}</span>
            <span style="width: 12%;" class="text-center">{{ $t('booking.no-nights') }}</span>
            <span style="width: 15%;" class="text-center" v-if="adult===2 && child===0">{{ $t('booking.average-price-per-one-double') }}</span>
            <span style="width: 15%;" class="text-center" v-else-if="adult > 0">{{ $t('booking.average-price-per-one-regular', {adult, child}) }}</span>
            <span style="width: 15%;" class="text-center"></span>
          </div>
        </template>

        <template v-slot:option="{ startLabel, endLabel, duration, disabled, priceString }">
          <div class="option row associated-selection-option" :class="disabled ? 'thin-line' : ''">
            <span style="width: 29%;"> {{ startLabel }}</span>
            <span style="width: 29%;">{{ endLabel }}</span>
            <span style="width: 12%;">{{ duration }}</span>
            <span style="width: 15%;">{{ priceString }}</span>
            <span style="width: 15%;"><b-button size="sm" variant="primary">{{ $t('booking.choose') }}</b-button></span>
          </div>
        </template>
      </v-select>
    </div>
  </div>
</template>

<script>
import vSelect from 'vue-select';
import 'vue-select/dist/vue-select.css';
import { mapGetters } from 'vuex';
import dayjs from 'dayjs';

export default {
  name: 'associated-products-list',
  props: {
    productsList: {
      type: Array,
      default: () => [],
    },
  },
  components: {
    vSelect,
  },
  data() {
    return {
      selectedDate: null,
      initialValue: {
        startLabel: '0000-00-00 00:00',
        endLabel: '0000-00-00 00:00',
        duration: 0,
        value: -1,
        label: '',
        productLink: '',
        disabled: true,
      },
    };
  },
  computed: {
    ...mapGetters({
      device: 'GET_DEVICE',
      isNotFirstEnter: 'GET_CHANGED_DATE_STATE_FOR_MACCABI_AGENCY',
    }),
    adult() {
      return +this.$route.query.adult;
    },
    child() {
      return +this.$route.query.child;
    },
    productsListOptions() {
      const { productsList } = this;

      return productsList.map((product, inx) => {
        const startDate = product.packStartDate;
        const startTime = '';
        const startWeekName = this.weekDaysNames[dayjs(startDate).day()];
        const endDate = product.packEndDate;
        const endTime = '';
        const endWeekName = this.weekDaysNames[dayjs(endDate).day()];

        const diff = dayjs(endDate).diff(startDate, 'day');

        return {
          startLabel: `${startWeekName} ${dayjs(startDate).format('DD/MM/YY')} ${startTime}`,
          endLabel: `${endWeekName} ${dayjs(endDate).format('DD/MM/YY')} ${endTime}`,
          duration: diff,
          productLink: product.productPageUrl,
          value: inx,
          label: '',
          adult: product.adults,
          child: product.children,
          priceString: `${product.currenySymbol}${product.avgPrice.toFixed(0)}`,
          disabled: false,
        };
      });
    },
    weekDaysNames() {
      return [
        this.$t('weekName.sun'),
        this.$t('weekName.mon'),
        this.$t('weekName.tue'),
        this.$t('weekName.wed'),
        this.$t('weekName.thu'),
        this.$t('weekName.fri'),
        this.$t('weekName.sat'),
      ];
    },
  },
  watch: {
    selectedDate() {
      this.refreshWithNewProduct();
    },
  },
  mounted() {
    this.getCurrentProduct();
  },
  methods: {
    getProductLinkParamObj(product) {
      return Object.fromEntries(new URLSearchParams(product.productLink.substr(product.productLink.indexOf('?'), product.productLink.length)));
    },
    getCurrentProduct() {
      const { productsListOptions } = this;
      const { query } = this.$route;
      this.selectedDate = productsListOptions.find(
        (product) => this.compareObjects(query, this.getProductLinkParamObj(product)),
      );
    },
    compareObjects(obj1, obj2) {
      const keys1 = Object.keys(obj1);
      const keys2 = Object.keys(obj2);

      if (keys1.length !== keys2.length) {
        return false;
      }

      // eslint-disable-next-line no-restricted-syntax
      for (const key of keys1) {
        if (obj1[key] && obj2[key] && obj1[key] !== obj2[key]) {
          return false;
        }
      }

      return true;
    },
    refreshWithNewProduct() {
      const { selectedDate } = this;
      const { query } = this.$route;
      if (this.compareObjects(query, this.getProductLinkParamObj(selectedDate))) return true;

      this.$router.push({ path: selectedDate.productLink });
      this.$emit('update');
      this.$store.commit('SET_CHANGED_DATE_FOR_MACCABI_AGENCY_PAGE', true);
      return true;
    },
    optionSelectable(option) {
      return !option.disabled;
    },
  },
};
</script>

<style>
  #did-you-know {
    cursor: pointer;
    width: 20px;
    height: 20px;
  }
  .maccabi-remark {
    font-size: 1.2rem;
  }
  .associated-selection .vs__selected-options{
    height: 3rem;
  }
  .associated-selection .vs__dropdown-option {
    padding: 0;
    border-top: solid 1px gray;
    text-align: center;
  }
  .associated-selection .vs__dropdown-option:last-child {
    border-bottom: solid 1px gray;
  }
  .associated-selection .v-select .vs__dropdown-menu {
    overflow-x: hidden;
    padding-bottom: 0;
  }
  /* .associated-selection.w-75 .vs--open {
    width: 75%;
  } */
  .associated-selection-label {
    font-size: 1.2rem;
    font-weight: 500;
  }

  .associated-selection-header {
    margin: 0;
    font-weight: 600;
  }
  .associated-selection-header span:not(:last-child){
    border-left: solid 1px gray;
  }
  .associated-selection-header span{
    /* height: 80px; */
    background-color: rgb(197, 222, 243);
    align-items: center;
    display: inline-grid;
    line-height: 1rem;
  }

  .associated-selection-option {
    padding: 0;
    margin: 0;
  }
  .associated-selection-option span:not(:last-child){
    border-left: solid 1px gray;
  }
  .associated-selection-option span{
    align-items: flex-start;
    padding: 0.5rem;
    margin: 0;
  }

  .associated-selection .vs--single .vs__selected {
    display: block;
    margin: auto;
  }
  .associated-selection .vs__search {
    flex-grow: unset;
  }
  .associated-selection .vs--single.vs--open .vs__selected {
    position: inherit;
  }
  .empoyee-subsidy-message {
    font-size: 2rem;
    font-weight: bold;
    color: purple;
  }
  .thin-line::after {
    content: '';
    transform: translateY(-20px);
    border-top: 1px solid gray;
    width: 78%;
    margin-right: 25px;
  }
@media (max-width: 479px) {
  .empoyee-subsidy-message {
    font-size: 1.5rem;
  }
  .thin-line::after {
    width: 85%;
    margin-right: 5px;
  }
}
</style>
