<template>
  <div class="btn-group" :class="{'opacity-button': !isMe}">
    <button class="btn btnoutline dropdown-toggle" type="button" id="dropdownMenuClickableInside" data-bs-toggle="dropdown" aria-expanded="false">
    {{selected ? $t(`sabre.search-panel.${selected}`) : $t('sabre.search-panel.directions')}}
    </button>

    <select-direction type="dropdown" propsClassName="dropdown-menu durationflightdropdown dropdown-menu-end" aria-labelledby="dropdownMenuClickableInside"/>

  </div>
</template>

<script>
import { mapGetters } from 'vuex';
import dropdownOpenState from '@/sabre/common/mixins/dropdownOpenState';

export default {
  name: 'radio-dropdown',
  mixins: [dropdownOpenState],
  components: {
    selectDirection: () => import('./selectDirection'),
  },
  computed: {
    ...mapGetters({
      selected: 'GET_SABRE_SELECTED_FLIGHT_DIRECTION',
    }),
  },
};
</script>
