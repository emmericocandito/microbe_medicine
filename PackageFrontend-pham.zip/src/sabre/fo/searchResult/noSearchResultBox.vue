<template>
   <div class="earchresults_noresultsarea mb-5">
    <div class="noresultsarea_box">
      <img src="/assets/sabre-img/noresults.png" alt="#">
    </div>
  </div>
</template>
