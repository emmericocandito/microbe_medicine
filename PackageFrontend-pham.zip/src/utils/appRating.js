// (() => {
//   const btnRatingApp = document.querySelector('.ratingApp');
//   console.log(btnRatingApp, 1111);
//   if (btnRatingApp) {
//     btnRatingApp.addEventListener('click', () => {
//       console.log(1111);
//       // if (typeof Android !== 'undefined') Android.doNativeFunction();
//     });
//   }
// })();

(() => {
  console.log('utils');
})();

// Android.doNativeFunction();
