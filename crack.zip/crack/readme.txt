1. Install, use trial key: DR26T22-G2XLGJZ-44PFBEJ-MCBZK36
2. Add this lines to hosts file:
0.0.0.0 apps.corel.com 
0.0.0.0 mc.corel.com 
0.0.0.0 origin-mc.corel.com 
0.0.0.0 iws.corel.com 
0.0.0.0 ipm.corel.com
0.0.0.0 2.18.12.147
0.0.0.0 googletagmanager.com
0.0.0.0 corelstore.com
0.0.0.0 www.corelstore.com
0.0.0.0 deploy.akamaitechnologies.com 
0.0.0.0 compute-1.amazonaws.com
0.0.0.0 dev1.ipm.corel.public.corel.net
0.0.0.0 ipp.corel.com

3. Copy PASMUTILITY.dll to "C:\Program Files\Corel\PASMUtility\v1\"