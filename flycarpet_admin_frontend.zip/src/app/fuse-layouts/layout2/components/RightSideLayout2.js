import React from 'react';

function RightSideLayout2() {
	return (
		<>
		</>
	);
}

export default React.memo(RightSideLayout2);
