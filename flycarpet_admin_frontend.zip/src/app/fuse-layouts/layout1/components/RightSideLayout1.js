import React from 'react';

function RightSideLayout1(props) {
	return (
		<>
		
		</>
	);
}

export default React.memo(RightSideLayout1);
