import React from 'react';
import Login from '../../login/Login';
const token = window.localStorage.getItem('jwt_access_token');
const Deal = {
	settings: {
		layout: token == null ? {
			config: {
				navbar: {
					display: false
				},
				toolbar: {
					display: false
				},
				footer: {
					display: false
				},
				leftSidePanel: {
					display: false
				},
				rightSidePanel: {
					display: false
				}
			}
		} : {
				config: {}
			}
	},
	routes: token == null ? [
		{
			path: '/',
			component: Login
		}
	] :[
		{
			path: '/camingo/camingoDealBuilder',
			component: React.lazy(() => import('./CamingoDealInsert/index'))
		},
		{
			path: '/camingo/camingoDealUpdate',
			component: React.lazy(() => import('./CamingoDealUpdate/index'))
		},
		{
			path: '/camingo/camingoAutoDeal',
			component: React.lazy(() => import('./CamingoAutoDeal/index'))
		}
	]
};

export default Deal;
