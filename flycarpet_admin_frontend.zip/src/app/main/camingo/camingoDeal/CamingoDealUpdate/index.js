import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../../store';
import DealUpdateHeader from './DealUpdateHeader';
import DealUpdateTable from './DealUpdateTable';

function CamingoDealUpdate() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<DealUpdateHeader />}
			content={<DealUpdateTable />}
			innerScroll
		/>
	);
}

export default withReducer('BasicData', reducer)(CamingoDealUpdate);
