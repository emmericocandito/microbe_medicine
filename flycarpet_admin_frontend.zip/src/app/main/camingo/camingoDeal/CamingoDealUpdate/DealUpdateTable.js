import axios from 'axios';
import _ from '@lodash';
import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import {
	Checkbox, Table, TableBody, TableCell, TablePagination, TableRow, Modal,
	Backdrop, Fade, TextField, Button, Select, FormControl, FormHelperText, FormControlLabel,
	CircularProgress, Grid, TextareaAutosize, Chip, Input, MenuItem, ListItemText
} from '@material-ui/core';
import FuseLoading from '@fuse/core/FuseLoading';
import FuseScrollbars from '@fuse/core/FuseScrollbars';
import { makeStyles } from '@material-ui/core/styles';
import DateTimePicker from 'react-datetime-picker';
import Rating from '@material-ui/lab/Rating';
import SentimentSatisfiedAltIcon from '@material-ui/icons/SentimentSatisfiedAltOutlined';
import SearchIcon from '@material-ui/icons/Search';
import ImageUploader from "react-images-upload";
import ChooseBadgeColor from '../ChooseBadge';
import DealUpdateTableHead from './DealUpdateTableHead';

import { useBasicAgencyInfo } from 'app/main/store/hooks';
import { AddDscPcntByAgency } from 'app/main/BasicComponents/AddDscPcntByAgency';
import { baseURL } from './../../../utils';

function DealUpdateTable(props) {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			margin: theme.spacing(0, 1),
			minWidth: 120,
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			textAlign: "center",
			maxHeight: "100vh",
			overflowY: "auto",
		},
		button_group:
		{
			padding: 30,
			textAlign: 'center',
		},
		buttons:
		{
			marginRight: '10px'
		},
		fo_circular: {
			textAlign: 'center',
			position: 'absolute',
			left: '50%',
			transform: 'translatex(-50%)'
		},
		deleteImage: {
			position: 'absolute',
			top: '1px',
			right: '7px',
			color: '#fff',
			background: '#ff4081',
			borderRadius: '50%',
			textAign: 'center',
			cursor: 'pointer',
			fontSize: '17px',
			fontWeight: 'bold',
			lineHeight: '20px',
			width: '20px',
			height: '20px'
		},
		chip: {
			height: '15px'
		},
		chips: {
			display: 'flex',
			flexWrap: 'wrap',
		},
	}));

	const classes = useStyles();
	const ITEM_HEIGHT = 48;
	const ITEM_PADDING_TOP = 8;
	const MenuProps = {
		PaperProps: {
			style: {
				maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
				width: 250,
			},
		},
	};

	const [dealLength, setDealLength] = useState(0);
	const [warningOpen, setWarningOpen] = useState(false);
	const [openFilter, setOpenFilter] = useState(false);
	const [warningText, setWarningText] = useState(null);
	const [loading, setLoading] = useState(true);
	const [loadingCircle, setLoadingCircle] = useState(false);
	const [selected] = useState([]);
	const [data, setData] = useState([]);
	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [confirmText, setConfirmText] = useState(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});

	const [dealId, setDealID] = useState(null);
	const [hotelId, setHotelID] = useState(null)
	const [dealCategoryList, setDealCategoryList] = useState([]);
	const [dealCategory, setDealCategory] = useState([]);
	const [nDiscountValue, setDiscountValue] = useState(0);
	const [hotelName, setHotelName] = useState(props.name);
	const [immediateDebit, setImmediateDebit] = useState(true);
	const [autoUpdatePrice, setAutoUpdatePrice] = useState(false);
	const [promotion, setPromotion] = useState(false);
	const [inputPriority, setInputPriority] = useState(null);
	const [active, setActive] = useState(false);
	const [startDate, setStartDate] = useState('')
	const [endDate, setEndDate] = useState('');
	const [nRoomRemark, setRoomRemark] = useState(null);
	const [nPriceRemarkHe, setInputPriceRemarkHe] = useState(null);
	const [nPriceRemarkEn, setInputPriceRemarkEn] = useState(null);
	const [nPriceRemarkRu, setInputPriceRemarkRu] = useState(null);
	const [siteToShowIn, setSiteToShowIn] = useState(2);
	const [imageURL, setImageURL] = useState(props.imageSrc);
	const [image, setImage] = useState(null);
	const [adult, setAdult] = useState(null);
	const [child, setChild] = useState(null);
	const [infant, setInfant] = useState(null);
	const [checkinDate, setCheckInDate] = useState(null);
	const [checkoutDate, setCheckOutDate] = useState(null);
	const [totalPrice, setTotalPrice] = useState(null);
	const [basisCode, setBasisCode] = useState(null);
	const [basisName, setBasisName] = useState(null);
	const [hotelCode, setHotelCode] = useState(null);
	const [source, setSource] = useState(null);
	const [category, setCategory] = useState(null);
	const [roomCode, setRoomCode] = useState(null);
	const [priceList, setPriceList] = useState(null);

	const [isShowOnHome, setIsShowOnHome] = useState(false);
	const [isShowOnLP, setIsShowOnLP] = useState(false);

	const [nFilterHotelName, setFilterHotelName] = useState(null);
	const [nFilterDealCategoryId, setFilterDealCategoryId] = useState(null);
	const [nFilterSiteToShowIn, setFilterSiteToShowIn] = useState(null)
	const [nFilterCheckinDate, setFilterCheckinDate] = useState(null);
	const [nFilterCheckoutDate, setFilterCheckoutDate] = useState(null);
	const [nFilterAdult, setFilterAdult] = useState(null);
	const [nFilterChild, setFilterChild] = useState(null);
	const [nFilterInfant, setFilterInfant] = useState(null);
	const [nFilterDiscountPercent, setFiterDiscountPercent] = useState(null);
	const [nFilterTotalPrice, setFilterTotalPrice] = useState(null);
	const [nFilterPriceRemark, setFilterRemark] = useState(null);
	const [nFilterBasisCode, setFilterBasisCode] = useState(null);
	const [nFilterBasisName, setFilterBasisName] = useState(null);
	const [nFilterActive, setFilterActive] = useState(null);
	const [nFilterImmediateDebit, setFilterActiveImmediateDebit] = useState(null);
	const [nFilterAutoUpdatePrice, setFilterAutoUpdatePrice] = useState(null);
	const [nFilterPromotion, setFilterPromotion] = useState(null);
	const [nFilterImageURL, setFilterImageURL] = useState(null);
	const [nFilterIsSalesDeal, setFilterIsSalesDeal] = useState('');
	const [nFilterOnHomePage, setFilterOnHomePage] = useState('');
	const [nFilterOnLandingPage, setFilterOnLandingPage] = useState('');
	const [nFilterSource, setFilterSource] = useState(null);
	const [nFilterManual, setFilterManual] = useState(null);
	const [open, setOpen] = React.useState(false);

	const [nBadgeColor, setBadgeColor] = useState('');
	const [nBadgeTextHe, setBadgeTextHe] = useState('');
	const [nBadgeTextEn, setBadgeTextEn] = useState('');
	const [nBadgeTextRu, setBadgeTextRu] = useState('');
	const [hasSpecial, setHasSpecial] = useState(false);
	const [specialDiscountValue, setSpecialDiscountValue] = useState(0);
	const [specialStartDate, setSpecialStartDate] = useState('')
	const [specialEndDate, setSpecialEndDate] = useState('');

	const [discountListByAgency, setDiscountListByAgency] = useState([]);

	const {
		basicNoAtnmAgencyInfo,
		fetchNoAtnmBasicAgencyInfo,
	} = useBasicAgencyInfo();

	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}

	async function getDealCategoryData() {
		const response = await axios.get(`${baseURL}camingo/api/dealCategory/onlyActive?from=1&to=1000`)
		const data = response.data;
		setDealCategoryList(data)
	}

	async function reopen(from, to) {
		const filterActive = nFilterActive === '' || nFilterActive === null ? null : (nFilterActive === "true" ? true : false);
		const filterImmediateDebit = nFilterImmediateDebit === '' || nFilterImmediateDebit === null ? null : (nFilterImmediateDebit === "true" ? true : false);
		const filterAutoPriceUpdate = nFilterAutoUpdatePrice === '' || nFilterAutoUpdatePrice === null ? null : (nFilterAutoUpdatePrice === "true" ? true : false);
		const filterPromotion = nFilterPromotion === '' || nFilterPromotion === null ? null : (nFilterPromotion === "true" ? true : false);
		const filterIsSalesDeal = nFilterIsSalesDeal === '' || nFilterIsSalesDeal === null ? null : (nFilterIsSalesDeal === "true" ? true : false);
		const isHomePageDeal = (nFilterOnHomePage === '') ? null : nFilterOnHomePage === 'true';
		const isLandingPageDeal = (nFilterOnLandingPage === '') ? null : nFilterOnLandingPage === 'true';
		const isManualDeal = (nFilterManual === '' || nFilterManual === null) ? null : nFilterManual === 'true';
		await axios({
			method: 'post',
			url: baseURL + 'camingo/api/deal/search?' + 'from=' + from + '&to=' + to,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"siteToShowIn": nFilterSiteToShowIn === null ? null : Number(nFilterSiteToShowIn),
				"dealCategoryId": nFilterDealCategoryId,
				// "hotelId": null,
				"checkinDate": nFilterCheckinDate,
				"checkoutDate": nFilterCheckoutDate,
				"adult": nFilterAdult === null ? null : Number(nFilterAdult),
				"child": nFilterChild === null ? null : Number(nFilterChild),
				"infant": nFilterInfant === null ? null : Number(nFilterInfant),
				"discountPercent": nFilterDiscountPercent === null ? null : Number(nFilterDiscountPercent),
				"totalPrice": nFilterTotalPrice === null ? null : Number(nFilterTotalPrice),
				"priceRemark": nFilterPriceRemark,
				"hotelName": nFilterHotelName,
				"imageUrl": nFilterImageURL,
				"basisCode": nFilterBasisCode,
				"basisName": nFilterBasisName,
				"immediateDebit": filterImmediateDebit,
				"priority": null,
				"autoUpdatePrice": filterAutoPriceUpdate,
				"promotion": filterPromotion,
				"isSalesDeal": filterIsSalesDeal,
				"error": null,
				"effectInDate": null,
				"source": nFilterSource === null ? null : +nFilterSource,
				"isManualDeal": isManualDeal,
				"active": filterActive,
				isHomePageDeal, isLandingPageDeal
			}
		}).then(response => {
			setDealLength(response.data['total']);
			setData(response.data['data']);
			setLoading(false);
			setOpen(false);
		}).catch(error => {
			setLoading(false);
			setWarningOpen(true);
			setWarningText("Error");
		});
	}
	useEffect(() => {
		fetchNoAtnmBasicAgencyInfo({ operation: 2 });
		reopen(1, 10);
		getDealCategoryData()
	}, [])

	async function confirmProcess() {
		await axios.delete(baseURL + 'camingo/api/deal/' + dealId, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		})
		setConfirmOpen(false);
		reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
	}

	async function handleUpdate() {
		if (dealCategory.length === 0) {
			setWarningText("please select DealCategory");
			setWarningOpen(true);
		} else {
			setLoadingCircle(true);
			let priority = inputPriority === null ? null : Number(inputPriority);
			let data = new FormData();
			data.append('hotelId', hotelId);
			dealCategory.forEach(item => {
				data.append('dealCategoryIds', item);
			})
			data.append('checkinDate', checkinDate);
			data.append('checkoutDate', checkoutDate);
			data.append('adult', Number(adult));
			data.append('child', Number(child));
			data.append('infant', Number(infant));
			data.append('totalPrice', Number(totalPrice));
			data.append('siteToShowIn', Number(siteToShowIn));
			data.append('discountPercent', Number(nDiscountValue));
			data.append('roomRemark', nRoomRemark);
			data.append('PriceRemarkTrans.He', nPriceRemarkHe);
			data.append('PriceRemarkTrans.En', nPriceRemarkEn);
			data.append('PriceRemarkTrans.Ru', nPriceRemarkRu);
			data.append('hotelName', hotelName);
			data.append('basisCode', basisCode);
			data.append('basisName', basisName);
			data.append('priority', priority);
			data.append('immediateDebit', immediateDebit);
			data.append('autoUpdatePrice', autoUpdatePrice);
			data.append('active', active);
			data.append('startDate', new Date(startDate).toISOString());
			data.append('endDate', new Date(endDate).toISOString());
			data.append('imageUrl', imageURL);
			data.append('promotion', promotion);
			data.append('source', source);
			data.append('atlantisPriceCategCode', category || null);
			data.append('hotelCode', hotelCode);
			data.append('roomCode', roomCode);
			data.append('isHomePageDeal', isShowOnHome);
			data.append('isLandingPageDeal', isShowOnLP);

			if (priceList !== null)
				data.append('priceList', priceList);

			if (nBadgeColor !== null)
				data.append('badgeColor', nBadgeColor);
			if (nBadgeTextHe !== null)
				data.append('BadgeTextTrans.He', nBadgeTextHe);
			if (nBadgeTextEn !== null)
				data.append('BadgeTextTrans.En', nBadgeTextEn);
			if (nBadgeTextRu !== null)
				data.append('BadgeTextTrans.Ru', nBadgeTextRu);
			if (hasSpecial) {
				data.append('specialDiscount.discountPercent', specialDiscountValue);
				data.append('specialDiscount.startDate', specialStartDate ? new Date(specialStartDate).toISOString() : new Date(startDate).toISOString());
				data.append('specialDiscount.endDate', specialEndDate ? new Date(specialEndDate).toISOString() : new Date(endDate).toISOString());
			}
			if (image !== null && image.length > 0) {
				data.append('imageFile', image[0]);
			}

			for (let i = 0; i < discountListByAgency.length; i++) {
				data.append(`discPctByAgency.${discountListByAgency[i].agencyCode}`, discountListByAgency[i].discount);
			}

			await axios({
				method: 'post',
				url: baseURL + 'camingo/api/deal/' + dealId,
				headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token') },
				data: data
			}).then(response => {
				setLoadingCircle(false);
				if (response.data.error !== null && response.data.error.message != null) {
					setWarningText(response.data.error.message);
					setWarningOpen(true);
				} else {
					setLoadingCircle(false);
					setOpen(false);
					reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
					inputInitial();
				}
			}).catch(error => {
				setLoadingCircle(false);
				setWarningText("HTTP REQUEST ERROR");
				setWarningOpen(true);
				return;
			});
		}
	};

	////////////////////////////////////////
	const handleBadgeInfo = (list) => {
		setBadgeColor(list[0]);
		setBadgeTextHe(list[1]);
		setBadgeTextEn(list[2]);
		setBadgeTextRu(list[3]);
	}
	function handleChangeStartDate(event) {
		setStartDate(event);
	}
	function handleChangeEndDate(event) {
		setEndDate(event);
	}
	function handleChangeCheckbox1() {
		setImmediateDebit(!immediateDebit)
	}
	function handleChangeCheckbox2() {
		setAutoUpdatePrice(!autoUpdatePrice)
	}
	function handleChangeCheckbox3() {
		setPromotion(!promotion)
	}
	function handleChangeCheckbox() {
		setActive(!active)
	}
	function onChangeHotelName(event) {
		setHotelName(event.target.value.trim())
	}
	function onChangePriceRemarkHe(event) {
		setInputPriceRemarkHe(event.target.value)
	}
	function onChangePriceRemarkEn(event) {
		setInputPriceRemarkEn(event.target.value)
	}
	function onChangePriceRemarkRu(event) {
		setInputPriceRemarkRu(event.target.value)
	}
	function onChangePriority(event) {
		setInputPriority(event.target.value);
	}
	function onSelectDealCategory(event) {
		setDealCategory(event.target.value || []);
	}
	const getCategoryNameFromID = (pId) => {
		const category = _.find(dealCategoryList, (item) => { return item.id === pId });
		return category?.name || category?.nameEn || '';
	}
	function handleChangeDiscountValue(event) {
		if (event.target.value === '') {
			setDiscountValue(0);
		}
		else {
			setDiscountValue(event.target.value);
		}
	}
	function handleChangeSiteToShowIn(event) {
		setSiteToShowIn(event.target.value);
	}
	function handleChangeSpecialDiscountValue(event) {
		setSpecialDiscountValue(Number(event.target.value));
	}
	function handleChangeSpecialStartDate(event) {
		setSpecialStartDate(event);
	}
	function handleChangeSpecialEndDate(event) {
		setSpecialEndDate(event);
	}
	function handleChangeHasSpecial(event) {
		setHasSpecial(!hasSpecial);
	}
	/////////////////////////////////

	function onFilterChangeHotelName(event) {
		if (event.target.value === '') {
			setFilterHotelName(null);
		}
		else {
			setFilterHotelName(event.target.value);
		}
	}
	function onFilterSelectDealCategory(event) {
		if (event.target.value === '') {
			setFilterDealCategoryId(null);
		}
		else {
			setFilterDealCategoryId(event.target.value);
		}
	}
	function onFilterChangeDiscountValue(event) {
		if (event.target.value === '') {
			setFiterDiscountPercent(null);
		}
		else {
			setFiterDiscountPercent(event.target.value);
		}
	}
	function onFilterChangeSiteToShowIn(event) {
		if (event.target.value === '') {
			setFilterSiteToShowIn(null);
		}
		else {
			setFilterSiteToShowIn(event.target.value);
		}
	}
	function onFilterChangeBasisCode(event) {
		if (event.target.value === '') {
			setFilterBasisCode(null);
		}
		else {
			setFilterBasisCode(event.target.value);
		}
	}
	function onFilterChangeBasisName(event) {
		if (event.target.value === '') {
			setFilterBasisName(null);
		}
		else {
			setFilterBasisName(event.target.value);
		}
	}
	function onFilterChangeAdult(event) {
		if (event.target.value === '') {
			setFilterAdult(null)
		}
		else {
			setFilterAdult(event.target.value)
		}
	}
	function onFilterChangeChild(event) {
		if (event.target.value === '') {
			setFilterChild(null)
		}
		else {
			setFilterChild(event.target.value)
		}
	}
	function onFilterChangeInfant(event) {
		if (event.target.value === '') {
			setFilterInfant(null)
		}
		else {
			setFilterInfant(event.target.value)
		}
	}
	function onFilterChangeImgURL(event) {
		if (event.target.value === '') {
			setFilterImageURL(null)
		}
		else {
			setFilterImageURL(event.target.value)
		}
	}
	function onFilterChangeTotalPrice(event) {
		if (event.target.value === '') {
			setFilterTotalPrice(null)
		}
		else {
			setFilterTotalPrice(event.target.value)
		}
	}
	function onFilterChangePriceRemark(event) {
		setFilterRemark(event.target.value || null);
	}
	function onChangeFilterCheckOutDate(event) {
		if (event.target.value === '') {
			setFilterCheckoutDate(null);
		} else {
			setFilterCheckoutDate(event.target.value);
		}
	}
	function onChangeFilterCheckInDate(event) {
		if (event.target.value === '') {
			setFilterCheckinDate(null);
		} else {
			setFilterCheckinDate(event.target.value);
		}
	}

	function onFilterImmediateDebit(event) {
		if (event.target.value === '') {
			setFilterActiveImmediateDebit(null)
		}
		else {
			setFilterActiveImmediateDebit(event.target.value)
		}
	}
	function onFilterAutoUpdatePrice(event) {
		if (event.target.value === '') {
			setFilterAutoUpdatePrice(null)
		}
		else {
			setFilterAutoUpdatePrice(event.target.value)
		}
	}
	function onFilterPromotion(event) {
		if (event.target.value === '') {
			setFilterPromotion(null)
		}
		else {
			setFilterPromotion(event.target.value)
		}
	}
	function handleChangeFilterSource(event) {
		if (event.target.value === '') {
			setFilterSource(null);
		}
		else {
			setFilterSource(event.target.value)
		}
	}
	function handleChangeFilterManual(event) {
		setFilterManual(event.target.value);
	}

	function handleChangeFilterIsSalesDeal(event) {
		setFilterIsSalesDeal(event.target.value);
	}
	function onFilterActive(event) {
		if (event.target.value === '') {
			setFilterActive(null)
		}
		else {
			setFilterActive(event.target.value)
		}
	}
	const handleChangeFilterOnHomePage = (event) => {
		setFilterOnHomePage(event.target.value || '');
	};
	const handleChangeFilterOnLandingPage = (event) => {
		setFilterOnLandingPage(event.target.value || '');
	};

	const handleOpen = (index) => {
		setDealID(data[index].id);
		setSiteToShowIn(data[index].siteToShowIn);
		setDealCategory(data[index].dealCategoryIds);
		setHotelID(data[index].hotelId);
		setRoomRemark(data[index].roomRemark);
		setInputPriceRemarkHe(data[index].priceRemarkTrans.He);
		setInputPriceRemarkEn(data[index].priceRemarkTrans.En);
		setInputPriceRemarkRu(data[index].priceRemarkTrans.Ru);
		setDiscountValue(data[index].discountPercent);
		setHotelName(data[index].hotelName);
		setInputPriority(data[index].priority);
		// setStartDate(data[index].startDate?.substring(0, 10) || data[index].checkinDate?.substring(0, 10));
		// setEndDate(data[index].endDate?.substring(0, 10) || data[index].checkoutDate?.substring(0, 10));
		setStartDate(data[index].startDate || data[index].checkinDate);
		setEndDate(data[index].endDate || data[index].checkoutDate);
		setActive(data[index].active);
		setAutoUpdatePrice(data[index].autoUpdatePrice);
		setPromotion(data[index].promotion)
		setImmediateDebit(data[index].immediateDebit);
		setImageURL((data[index].imageUrl === "null" || data[index].imageUrl === null) ? null : data[index].imageUrl);
		// setImageURL(data[index].imageUrl);
		setBasisCode(data[index].basisCode);
		setBasisName(data[index].basisName);
		setAdult(data[index].adult);
		setChild(data[index].child);
		setInfant(data[index].infant);
		setCheckInDate(data[index].checkinDate);
		setCheckOutDate(data[index].checkoutDate);
		setTotalPrice(data[index].totalPrice);
		setHotelCode(data[index].hotelCode);
		setSource(data[index].source);
		setCategory(data[index].atlantisPriceCategCode);
		setRoomCode(data[index].roomCode);
		setPriceList(data[index].priceList);
		setBadgeColor(data[index].badgeColor);
		setBadgeTextHe(data[index].badgeTextTrans.He);
		setBadgeTextEn(data[index].badgeTextTrans.En);
		setBadgeTextRu(data[index].badgeTextTrans.Ru);
		setSpecialDiscountValue(data[index].specialDiscount?.discountPercent);
		setSpecialStartDate(data[index].specialDiscount?.startDate);
		setSpecialEndDate(data[index].specialDiscount?.endDate);
		setHasSpecial(!!data[index].specialDiscount);

		setIsShowOnHome(data[index].isHomePageDeal || false);
		setIsShowOnLP(data[index].isLandingPageDeal || false);

		if (data[index].discPctByAgency) {
			setDiscountListByAgency(Object.keys(data[index].discPctByAgency)
				.map((key) => ({ agencyCode: key, discount: data[index]['discPctByAgency'][key] })));
		} else {
			setDiscountListByAgency([]);
		}

		setOpen(true);
	};

	const deleteDeal = async (i) => {
		setDealID(data[i].id)
		setConfirmText("Do you want to drop this deal?");
		setConfirmOpen(true);
	}
	const handleClose = () => {
		inputInitial();
		setOpen(false);
	};
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}
	const handleCloseWarning = () => {
		setWarningOpen(false);
	}
	function inputInitial() {
		setDealID(null);
		setSiteToShowIn(2);
		setDealCategory([]);
		setHotelID(null);
		setInputPriceRemarkHe(null);
		setInputPriceRemarkEn(null);
		setInputPriceRemarkRu(null);
		setDiscountValue(0);
		setHotelName(props.name);
		setInputPriority(null);
		setStartDate(null);
		setEndDate(null);
		setActive(true);
		setAutoUpdatePrice(true);
		setPromotion(true)
		setImmediateDebit(true);
		setImageURL(null);
		setImage(null);
		setBasisCode(null);
		setBasisName(null);
		setAdult(null);
		setChild(null);
		setInfant(null);
		setCheckInDate(null);
		setCheckOutDate(null);
		setTotalPrice(null);
		setBadgeColor('');
		setBadgeTextHe('');
		setBadgeTextEn('');
		setBadgeTextRu('');
		setSpecialDiscountValue(0);
		setSpecialStartDate(null);
		setSpecialEndDate(null);
		setHasSpecial(false);
		setIsShowOnHome(false);
		setIsShowOnLP(false);

		setDiscountListByAgency([]);
	}
	function handleChangePage(event, value) {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage;
		reopen(from, to)
	}
	function handleChangeRowsPerPage(event) {
		setRowsPerPage(event.target.value);
		setPage(0);
		const temp = Number(event.target.value)
		const from = 1;
		const to = temp;
		reopen(from, to)

	}
	const onImageDrop = (picture) => {
		setImageURL(null);
		setImage(picture);
	};
	function searchDeal() {
		reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
		setOpenFilter(false);
	}
	const handleFilterClose = () => {
		setOpenFilter(false);
	};
	const openSearchModel = () => {
		setOpenFilter(true);
	};
	const getDateFormat = (date) => {
		var year = date.getFullYear();
		var month = date.getMonth() + 1;
		var mdate = date.getDate();
		if (month < 10) {
			month = '0' + month;
		}
		if (mdate < 10) {
			mdate = '0' + mdate;
		}
		return year + '-' + month + '-' + mdate;
	}
	const deleteImageURL = () => {
		setImageURL(null);
	}
	const deleteImageFile = () => {
		setImage(null);
	}
	const handleChangeIsShowOnHome = (event) => {
		setIsShowOnHome(event.target.checked ?? false);
	};
	const handleChangeIsShowOnLP = (event) => {
		setIsShowOnLP(event.target.checked ?? false);
	};
	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className="w-full flex flex-col">
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={openFilter}
				onClose={handleFilterClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={openFilter}>
					<div className={classes.paper}>
						<div className={classes.fo_circular}>
							{loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
						</div>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title' >Deal Filter</h2>
						</div>
						<div className={classes.formControl} style={{ display: 'grid' }}>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '40%' }}>
									<FormHelperText>DealCategory</FormHelperText>
									<Select
										native
										onChange={onFilterSelectDealCategory}
										defaultValue={nFilterDealCategoryId === null ? '' : nFilterDealCategoryId}
										name='Code'
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option value=''>...</option>
										{dealCategoryList === null ? '' : dealCategoryList.map((n, i) =>
											<option key={i} value={n.id}>{n.name || n.nameEn}</option>
										)}
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '40%', display: 'none' }}>
									<FormHelperText>SiteToShowIn</FormHelperText>
									<Select
										native
										onChange={onFilterChangeSiteToShowIn}
										defaultValue={nFilterSiteToShowIn === null ? '' : nFilterSiteToShowIn}
										name='Code'
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option value=''></option>
										<option value={0}>Homepage</option>
										<option value={1}>Internal site</option>
										<option value={2}>Both</option>
									</Select>
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '40%' }}>
									<FormHelperText>BasisCode</FormHelperText>
									<TextField value={nFilterBasisCode === null ? '' : nFilterBasisCode} onChange={onFilterChangeBasisCode} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '40%' }}>
									<FormHelperText>BasisName</FormHelperText>
									<TextField value={nFilterBasisName === null ? '' : nFilterBasisName} onChange={onFilterChangeBasisName} />
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Hotel</FormHelperText>
									<TextField value={nFilterHotelName === null ? '' : nFilterHotelName} onChange={onFilterChangeHotelName} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>discount(1~20%)</FormHelperText>
									<TextField
										id='standard-number'
										type='number'
										min='0'
										max='20'
										defaultValue={nFilterDiscountPercent === null ? '' : nFilterDiscountPercent}
										onChange={onFilterChangeDiscountValue}
										InputLabelProps={{
											shrink: true,
										}}
										InputProps={{
											inputProps: {
												min: 0,
												max: 20
											}
										}}
									/>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Source</FormHelperText>
									<Select
										native
										onChange={handleChangeFilterSource}
										value={nFilterSource || ''}
										inputProps={{
											id: 'filter-on-source',
										}}
									>
										<option aria-label='None' value=''>All</option>
										<option value='0'>CAMINGO</option>
										<option value='1'>GOC</option>
										<option value='2'>ISRO</option>
										<option value='3'>MINI</option>
									</Select>
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Adult</FormHelperText>
									<TextField value={nFilterAdult === null ? '' : nFilterAdult} onChange={onFilterChangeAdult} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Child</FormHelperText>
									<TextField value={nFilterChild === null ? '' : nFilterChild} onChange={onFilterChangeChild} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Infant</FormHelperText>
									<TextField value={nFilterInfant === null ? '' : nFilterInfant} onChange={onFilterChangeInfant} />
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>ImageURL</FormHelperText>
									<TextField value={nFilterImageURL === null ? '' : nFilterImageURL} onChange={onFilterChangeImgURL} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>TotalPrice</FormHelperText>
									<TextField value={nFilterTotalPrice === null ? '' : nFilterTotalPrice} onChange={onFilterChangeTotalPrice} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Manual Deal</FormHelperText>
									<Select
										native
										onChange={handleChangeFilterManual}
										value={nFilterManual || ''}
										inputProps={{
											id: 'filter-on-manual',
										}}
									>
										<option aria-label='None' value=''>All</option>
										<option value='true'>Yes</option>
										<option value='false'>No</option>
									</Select>
								</FormControl>
							</Grid>
							<FormControl required className={classes.formControl}>
								<FormHelperText>PriceRemark</FormHelperText>
								<TextField value={nFilterPriceRemark || ''} onChange={onFilterChangePriceRemark} />
							</FormControl>
						</div>
						<Grid container justify='space-around' style={{ margin: '5px 0px' }}>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>CheckIn</FormHelperText>
								<TextField
									id="filterdate-1"
									type="date"
									value={nFilterCheckinDate === null ? '' : nFilterCheckinDate}
									onChange={onChangeFilterCheckInDate}
									className={classes.textField1}
								/>
							</FormControl>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>CheckOut</FormHelperText>
								<TextField
									id="filterdate-2"
									type="date"
									value={nFilterCheckoutDate === null ? '' : nFilterCheckoutDate}
									onChange={onChangeFilterCheckOutDate}
									className={classes.textField1}
								/>
							</FormControl>
						</Grid>
						<div style={{ display: 'flex', padding: '5px', justifyContent: 'space-between' }}>
							<FormControl required className={classes.formControl}>
								<FormHelperText>ImmediateDebit</FormHelperText>
								<Select
									native
									onChange={onFilterImmediateDebit}
									value={nFilterImmediateDebit === null ? '' : nFilterImmediateDebit}
									inputProps={{
										id: 'age-native-required',
									}}
								>
									<option aria-label='None' value=''>All</option>
									<option value='true'>Active</option>
									<option value='false'>Unactive</option>
								</Select>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Sales Deal</FormHelperText>
								<Select
									native
									onChange={handleChangeFilterIsSalesDeal}
									value={nFilterIsSalesDeal}
									inputProps={{
										id: 'age-native-required',
									}}
								>
									<option aria-label='None' value=''>All</option>
									<option value='true'>Yes</option>
									<option value='false'>No</option>
								</Select>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>AutoUpdatePrice</FormHelperText>
								<Select
									native
									onChange={onFilterAutoUpdatePrice}
									value={nFilterAutoUpdatePrice === null ? '' : nFilterAutoUpdatePrice}
									inputProps={{
										id: 'age-native-required',
									}}
								>
									<option aria-label='None' value=''>All</option>
									<option value='true'>Active</option>
									<option value='false'>Unactive</option>
								</Select>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Promotion</FormHelperText>
								<Select
									native
									onChange={onFilterPromotion}
									value={nFilterPromotion === null ? '' : nFilterPromotion}
									inputProps={{
										id: 'age-native-required',
									}}
								>
									<option aria-label='None' value=''>All</option>
									<option value='true'>Active</option>
									<option value='false'>Unactive</option>
								</Select>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Active</FormHelperText>
								<Select
									native
									onChange={onFilterActive}
									value={nFilterActive === null ? '' : nFilterActive}
									inputProps={{
										id: 'age-native-required',
									}}
								>
									<option aria-label='None' value=''>All</option>
									<option value='true'>Active</option>
									<option value='false'>Unactive</option>
								</Select>
							</FormControl>
						</div>
						<Grid container justify='space-between' style={{ margin: '10px 0px', display: 'flex', justifyContent: 'space-between' }}>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>OnHomePage</FormHelperText>
								<Select
									native
									onChange={handleChangeFilterOnHomePage}
									value={nFilterOnHomePage}
									inputProps={{
										id: 'filter-on-home',
									}}
								>
									<option aria-label='None' value=''>All</option>
									<option value='true'>Yes</option>
									<option value='false'>No</option>
								</Select>
							</FormControl>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>OnLandingPage</FormHelperText>
								<Select
									native
									onChange={handleChangeFilterOnLandingPage}
									value={nFilterOnLandingPage}
									inputProps={{
										id: 'filter-on-landing-page',
									}}
								>
									<option aria-label='None' value=''>All</option>
									<option value='true'>Yes</option>
									<option value='false'>No</option>
								</Select>
							</FormControl>
						</Grid>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' onClick={searchDeal} color='secondary'>
								Search
							</Button>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleFilterClose}>
								Cancel
							</Button>
						</div>
					</div>

				</Fade>
			</Modal>
			<Modal
				open={confirmOpen}
				onClose={handleCloseConfirm}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Confirm</h2>
					<p id='server-modal-description'>{confirmText}</p>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={confirmProcess}>Confirm
					</Button>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={handleCloseConfirm}>Cancel
					</Button>
				</div>
			</Modal>
			<Modal
				open={warningOpen}
				onClose={handleCloseWarning}
				className={classes.modal}
				aria-labelledby="simple-modal-title"
				aria-describedby="simple-modal-description"
			>
				<div className={classes.paper}>
					<h2 id="server-modal-title" >Warning</h2>
					<p id="server-modal-description">{warningText}</p>
					<Button className="whitespace-no-wrap normal-case"
						variant="contained"
						color="secondary"
						onClick={handleCloseWarning}>Close
					</Button>
				</div>
			</Modal>
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={open}
				onClose={handleClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={open}>
					<div className={classes.paper}>
						<div className={classes.fo_circular}>
							{loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
						</div>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title' >Deal Builder</h2>
						</div>
						<div className={classes.formControl} style={{ display: 'grid' }}>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>DealCategory</FormHelperText>
									<Select
										labelId="Categories"
										id="categories"
										multiple
										value={dealCategory}
										onChange={onSelectDealCategory}
										input={<Input />}
										renderValue={(selected) => (
											<div className={classes.chips}>
												{selected.map((key, i) => (
													<Chip key={i} label={getCategoryNameFromID(key)} className={classes.chip} />
												))}
											</div>
										)}
										MenuProps={MenuProps}
									>
										{dealCategoryList === null ? '' : dealCategoryList.map((n, i) => (
											<MenuItem key={i} value={n.id} name={n.id}>
												<Checkbox checked={dealCategory.indexOf(n.id) > -1} />
												<ListItemText primary={n.name} />
											</MenuItem>
										))}
									</Select>

								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%', display: 'none' }}>
									<FormHelperText>DealCategory</FormHelperText>
									<Select
										native
										onChange={handleChangeSiteToShowIn}
										defaultValue={siteToShowIn}
										name='Code'
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option value={0}>Homepage</option>
										<option value={1}>Internal site</option>
										<option value={2}>Both</option>
									</Select>
								</FormControl>
							</Grid>

							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>HotelName</FormHelperText>
									<TextField defaultValue={hotelName === null ? '' : hotelName} onChange={onChangeHotelName} disabled={true} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>discount(1~20%)</FormHelperText>
									<TextField
										id='standard-number'
										type='number'
										min='0'
										max='20'
										defaultValue={nDiscountValue === null ? 0 : nDiscountValue}
										onChange={handleChangeDiscountValue}
										InputLabelProps={{
											shrink: true,
										}}
										InputProps={{
											inputProps: {
												min: 0,
												max: 20
											}
										}}
									/>
								</FormControl>
							</Grid>

							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Hebrew Price Remark</FormHelperText>
									<TextField onChange={onChangePriceRemarkHe} defaultValue={nPriceRemarkHe || ''} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>English Price Remark</FormHelperText>
									<TextField onChange={onChangePriceRemarkEn} defaultValue={nPriceRemarkEn || ''} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Russian Price Remark</FormHelperText>
									<TextField onChange={onChangePriceRemarkRu} defaultValue={nPriceRemarkRu || ''} />
								</FormControl>

							</Grid>

							<FormControl required className={classes.formControl}>
								<FormHelperText>Priority</FormHelperText>
								<Rating onChange={onChangePriority} name="customized-10" value={Number(inputPriority)} max={10} icon={<SentimentSatisfiedAltIcon />} />
							</FormControl>

						</div>
						{imageURL !== null ?
							<div style={{ display: 'inline-box', overflow: 'auto', position: 'relative' }}>
								<button className={classes.deleteImage} onClick={(e) => deleteImageURL()}>X</button>
								<img alt='' style={{ width: '100px', height: '100px', margin: '10px auto' }} src={imageURL} />
							</div>
							: null
						}
						{image === null ? null :
							<div style={{ position: 'relative' }}>
								<button className={classes.deleteImage} onClick={(e) => deleteImageFile()}>X</button>
								<img alt='' style={{ width: '100px', height: '100px', margin: '10px auto' }} src={URL.createObjectURL(image[0])} />
							</div>
						}

						<ImageUploader
							withIcon={false}
							buttonStyles={{ fontSize: '12px' }}
							fileContainerStyle={{ padding: '0px', boxShadow: 'none' }}
							buttonText={(image !== null || imageURL !== null) ? "Edit Deal Image" : "Add Deal Image"}
							withLabel={false}
							withPreview={false}
							onChange={onImageDrop}
							imgExtension={[".jpg", ".gif", ".png", ".gif", ".jpeg", ".jfif"]}
							maxFileSize={524288000}
							singleImage={true}
						/>
						<Grid container justify='space-around' style={{ margin: '10px 5px' }}>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>Rule Start Date</FormHelperText>
								<DateTimePicker
									className={classes.textField1}
									onChange={handleChangeStartDate}
									value={new Date(startDate)}
								/>
							</FormControl>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>Rule End Date</FormHelperText>
								<DateTimePicker
									className={classes.textField1}
									onChange={handleChangeEndDate}
									value={new Date(endDate)}
								/>
							</FormControl>
						</Grid>

						<div style={{ marginLeft: '20px' }}>
							<ChooseBadgeColor
								badgeColor={nBadgeColor || ''}
								badgeTextHe={nBadgeTextHe || ''}
								badgeTextEn={nBadgeTextEn || ''}
								badgeTextRu={nBadgeTextRu || ''}
								onChangeBadgeInfo={handleBadgeInfo} />
						</div>

						<AddDscPcntByAgency agencies={basicNoAtnmAgencyInfo} agencyDiscountList={discountListByAgency}
							onChangeDiscountListByAgency={(list) => setDiscountListByAgency(list)} />

						<FormControlLabel
							style={{ width: '40%' }}
							control={
								<Checkbox
									checked={hasSpecial}
									onChange={handleChangeHasSpecial}
									name='checkedA'
									color='primary'
								/>
							}
							label='Have Special Discount?'
							className={classes.checkboxform}
						/>
						<Grid container justify='space-around' style={{ margin: '5px 10px' }}>
							<FormControl required className={classes.formControl} style={{ width: '95%' }}>
								<FormHelperText>Special Discount(1 ~ 20%)</FormHelperText>
								<TextField
									id='standard-number'
									type='number'
									min='0'
									max='20'
									defaultValue={specialDiscountValue}
									onChange={handleChangeSpecialDiscountValue}
									disabled={!hasSpecial}
									InputLabelProps={{
										shrink: true,
									}}
									InputProps={{
										inputProps: {
											min: 0,
											max: 20
										}
									}}
								/>
							</FormControl>
						</Grid>

						<Grid container justify='space-around' style={{ margin: '5px 10px' }}>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>Special Start Date</FormHelperText>
								<DateTimePicker
									className={classes.textField1}
									onChange={handleChangeSpecialStartDate}
									disabled={!hasSpecial}
									value={specialStartDate ? new Date(specialStartDate) : new Date(startDate)}
								/>
							</FormControl>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>Special End Date</FormHelperText>
								<DateTimePicker
									className={classes.textField1}
									onChange={handleChangeSpecialEndDate}
									disabled={!hasSpecial}
									value={specialEndDate ? new Date(specialEndDate) : new Date(endDate)}
								/>
							</FormControl>
						</Grid>
						<div style={{ display: 'flex', padding: '5px' }}>
							<FormControlLabel
								control={
									<Checkbox
										checked={immediateDebit}
										onChange={handleChangeCheckbox1}
										name='checkedA'
										color='primary'
									/>
								}
								label='ImmediateDebit'
								className={classes.checkboxform}
							/>
							<FormControlLabel
								control={
									<Checkbox
										checked={autoUpdatePrice}
										onChange={handleChangeCheckbox2}
										name='checkedB'
										color='primary'
									/>
								}
								label='AutoUpdatePrice'
								className={classes.checkboxform}
							/>
							<FormControlLabel
								control={
									<Checkbox
										checked={promotion}
										onChange={handleChangeCheckbox3}
										name='checkedB'
										color='primary'
									/>
								}
								label='Promotion'
								className={classes.checkboxform}
							/>
							<FormControlLabel
								control={
									<Checkbox
										checked={active}
										onChange={handleChangeCheckbox}
										name='checkedC'
										color='primary'
									/>
								}
								label='Active'
								className={classes.checkboxform}
							/>
							<FormControlLabel
								control={
									<Checkbox
										checked={isShowOnHome}
										onChange={handleChangeIsShowOnHome}
										name='checkedB'
										color='primary'
									/>
								}
								label='ShowOnHomePage'
								className={classes.checkboxform}
							/>
							<FormControlLabel
								control={
									<Checkbox
										checked={isShowOnLP}
										onChange={handleChangeIsShowOnLP}
										name='checkedB'
										color='primary'
									/>
								}
								label='ShowOnLandingPage'
								className={classes.checkboxform}
							/>
						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' onClick={handleUpdate} color='secondary'>
								EDIT DEAL
							</Button>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleClose}>
								Cancel
							</Button>
						</div>
					</div>
				</Fade>
			</Modal>
			<div>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => openSearchModel()}
				>

					<span className='hidden sm:flex'><SearchIcon />Filter</span>
					<span className='flex sm:hidden'><SearchIcon /></span>
				</Button>
			</div>
			<FuseScrollbars className="flex-grow overflow-x-auto">
				<Table stickyHeader className="min-w-xl" aria-labelledby="tableTitle">
					<DealUpdateTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={data.length}
					/>
					<TableBody>
						{_.orderBy(
							data,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className="h-64 cursor-pointer"
									hover
									tabIndex={-1}
									key={n.id}
								>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										<img alt='' style={{ height: '50px', width: '50px' }} src={n.imageUrl} />
									</TableCell>
									<TableCell className="p-4 md:p-16 truncate" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.extendedProperties.sourceName}
									</TableCell>
									<TableCell className="p-4 md:p-16 truncate" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.hotelName}
									</TableCell>
									<TableCell className="p-4 md:p-16 truncate" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.roomCode}
									</TableCell>
									<TableCell className="p-4 md:p-16 truncate" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.basisName == null ? null : n.basisName}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										{n.basisCode}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										{n.totalPrice == null ? null : '$' + n.totalPrice}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										{n.priceList}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										{(new Date(n.checkinDate)).toString().substring(0, 16)}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										{(new Date(n.checkoutDate)).toString().substring(0, 16)}
									</TableCell>

									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										{n.priority}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										{n.discountPercent == null ? null : n.discountPercent + '%'}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										{n.extendedProperties.dealCategoryName}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										{n.priceRemark == null ? null : <TextareaAutosize
											style={{ background: 'transparent' }}
											rowsMax={3}
											rowsMin={3}
											aria-label="maximum height"
											value={n.priceRemark}
										/>
										}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										{(new Date(n.startDate)).toString().substring(0, 16)}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										{(new Date(n.endDate)).toString().substring(0, 16)}
									</TableCell>

									<TableCell className="p-4 md:p-16" component="th" scope="row" align="center" onClick={() => handleOpen(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.active && 'bg-red',
												n.active && 'bg-green',

											)}
										/>
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="center" onClick={() => handleOpen(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.immediateDebit && 'bg-red',
												n.immediateDebit && 'bg-green',

											)}
										/>
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="center" onClick={() => handleOpen(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.autoUpdatePrice && 'bg-red',
												n.autoUpdatePrice && 'bg-green',

											)}
										/>
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="center" onClick={() => handleOpen(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.promotion && 'bg-red',
												n.promotion && 'bg-green',

											)}
										/>
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => handleOpen(i)} tabIndex="0" type="button" title="Edit"><span className="MuiIconButton-label"><span className="material-icons MuiIcon-root" aria-hidden="true">edit</span></span><span className="MuiTouchRipple-root"></span></button>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component='th' scope='row' align='left'>
										<button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
											onClick={() => deleteDeal(i)}
											tabIndex='0' type='button' title='Edit'>
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className="flex-shrink-0 border-t-1"
				component="div"
				count={dealLength}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}

export default withRouter(DealUpdateTable);
