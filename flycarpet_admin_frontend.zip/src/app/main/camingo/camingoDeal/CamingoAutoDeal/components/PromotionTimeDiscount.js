
import React, { useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {Button, Grid, FormControl, TextField, FormHelperText, Table, TableHead, TableBody, TableRow, TableCell, Select} from '@material-ui/core';
// import Button from '@material-ui/core/Button';
// import Grid from '@material-ui/core/Grid';
// import FormControl from '@material-ui/core/FormControl';
// import TextField from '@material-ui/core/TextField';
// import FormHelperText from '@material-ui/core/FormHelperText';
// import Table from '@material-ui/core/Table';
// import TableHead from '@material-ui/core/TableHead';
// import TableBody from '@material-ui/core/TableBody';
// import TableRow from '@material-ui/core/TableRow';
// import TableCell from '@material-ui/core/TableCell';
// import Select from '@material-ui/core/Select';

const PromotionTimeDiscount = (props) => {
  const useStyles = makeStyles((theme) => ({
		formControl: {
			margin: '2px 5px',
			minWidth: 60,
			width: 'auto'
		},
		buttons: {
			marginLeft: '10px',
			height: '40px'
		},
	}));
	const classes = useStyles();

	const [nPromotionDay, setPromotionDay] = useState('');
	const [nPromotionTimeFrom, setPromotionTimeFrom] = useState(null);
	const [nPromotionTimeTo, setPromotionTimeTo] = useState(null);
	const [nSpecialDiscountPercent, setSpecialDiscountPercent] = useState(null);
	const [nDayList, setDayList] = useState([]);
	const [nAction, setActionState] = useState('add');
	const [nEditIndex, setEditIndex] = useState(null);

  useEffect(() => {
		setDayList(['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']);
  },[])

	const addPromotionTimeDiscountList = () => {
    const nPromotionTimeDiscountList = props.promotionTimeDiscountList ? [...props.promotionTimeDiscountList] : [];

		if(nSpecialDiscountPercent === '') return;
		const index = (!nPromotionTimeDiscountList)? -1: nPromotionTimeDiscountList.findIndex(d => (d.promotionTimeFrom === nPromotionTimeFrom && d.promotionTimeTo === nPromotionTimeTo && d.promotionDay === Number(nPromotionDay)))
		if(index === -1){
			const promotionTimeDiscountListTemp = {};
			promotionTimeDiscountListTemp.promotionDay = Number(nPromotionDay);
			promotionTimeDiscountListTemp.promotionTimeFrom = nPromotionTimeFrom === null ? '' : nPromotionTimeFrom;
			promotionTimeDiscountListTemp.promotionTimeTo = nPromotionTimeTo === null ? '' : nPromotionTimeTo;
			promotionTimeDiscountListTemp.specialDiscountPercent = nSpecialDiscountPercent === null ? 0 : Number(nSpecialDiscountPercent);
			if(!nPromotionTimeDiscountList){
        props.onChangePromotionTimeDiscount([promotionTimeDiscountListTemp]);
			}else{
        props.onChangePromotionTimeDiscount([...nPromotionTimeDiscountList, promotionTimeDiscountListTemp]);
			}
		}else{
			const promotionTimeDiscountListTemp = {};
			promotionTimeDiscountListTemp.promotionDay = Number(nPromotionDay);
			promotionTimeDiscountListTemp.promotionTimeFrom = nPromotionTimeFrom === null ? '' : nPromotionTimeFrom;
			promotionTimeDiscountListTemp.promotionTimeTo = nPromotionTimeTo === null ? '' : nPromotionTimeTo;
			promotionTimeDiscountListTemp.specialDiscountPercent = nSpecialDiscountPercent === '' ? 0 : Number(nSpecialDiscountPercent);
			nPromotionTimeDiscountList[index] = promotionTimeDiscountListTemp;
      props.onChangePromotionTimeDiscount(nPromotionTimeDiscountList);
		}
		setPromotionDay('');
		setPromotionTimeFrom('');
		setPromotionTimeTo('');
		setSpecialDiscountPercent(0);
	}
	const editPromotionTimeDiscountList = () => {
    const nPromotionTimeDiscountList = [...props.promotionTimeDiscountList];

		if(nSpecialDiscountPercent === '') return;

		if(nEditIndex !== null){
			const promotionTimeDiscountListTemp = {};
			promotionTimeDiscountListTemp.promotionDay = Number(nPromotionDay);
			promotionTimeDiscountListTemp.promotionTimeFrom = nPromotionTimeFrom === null ? '' : nPromotionTimeFrom;
			promotionTimeDiscountListTemp.promotionTimeTo = nPromotionTimeTo === null ? '' : nPromotionTimeTo;
			promotionTimeDiscountListTemp.specialDiscountPercent = nSpecialDiscountPercent === '' ? 0 : Number(nSpecialDiscountPercent);
			nPromotionTimeDiscountList[nEditIndex] = promotionTimeDiscountListTemp;
      props.onChangePromotionTimeDiscount(nPromotionTimeDiscountList);
		}
		restoreInitState();
	}
	const deletePromotionTimeDiscountListItem = async (i) => {
    const nPromotionTimeDiscountList = [...props.promotionTimeDiscountList]; // make a separate copy of the array
		var index = nPromotionTimeDiscountList.indexOf(nPromotionTimeDiscountList[i])
		if (index !== -1) {
			nPromotionTimeDiscountList.splice(index, 1);
      props.onChangePromotionTimeDiscount(nPromotionTimeDiscountList);
		}
		restoreInitState();
	}
	const cancelEdit = () => {
		restoreInitState();
	}

	const restoreInitState = () => {
		setPromotionDay('');
		setPromotionTimeFrom('');
		setPromotionTimeTo('');
		setSpecialDiscountPercent(0);

		setEditIndex(null);

		setActionState('add');
	}

  const handleChangePromotionDay = (event) => {
		if(event !== null){
			setPromotionDay(event.target.value);
		} else {
			setPromotionDay('');
		}
	}
  const handleChangePromotionTimeFrom = (event) => {
		if(event !== null){
			setPromotionTimeFrom(event.target.value);
		} else {
			setPromotionTimeFrom(null);
		}
	}
	const handleChangePromotionTimeTo = (event) => {
		if(event !== null){
			setPromotionTimeTo(event.target.value);
		} else {
			setPromotionTimeTo(null);
		}
	}
	const handleChangeSpecialDiscountPercent = (event) => {
		if (event !== null) {
			setSpecialDiscountPercent(event.target.value);
		}
		else {
			setSpecialDiscountPercent(null);
		}
	};
	const editItem = async (i) => {
    const nPromotionTimeDiscountList = [...props.promotionTimeDiscountList];
		setPromotionDay(nPromotionTimeDiscountList[i].promotionDay);
		setPromotionTimeFrom(nPromotionTimeDiscountList[i].promotionTimeFrom);
		setPromotionTimeTo(nPromotionTimeDiscountList[i].promotionTimeTo);
		setSpecialDiscountPercent(nPromotionTimeDiscountList[i].specialDiscountPercent);

		setEditIndex(i);
		
		setActionState('edit');
	}

  return (
    <div>
      <Grid container justify='space-between' style={{ margin: '10px 0px' }}>
				
				<FormControl required className={classes.formControl} style={{ width: '20%' }}>
					<FormHelperText>Day</FormHelperText>
					<Select
						native
						onChange={handleChangePromotionDay}
						value={nPromotionDay}
						inputProps={{
							id: 'age-native-required',
						}}
					>
						<option aria-label='None' value=''> </option>
						{
							nDayList.map((item, inx) => ( <option value={inx} key={inx}>{item}</option> ))
						}
					</Select>
				</FormControl>
        <FormControl required className={classes.formControl} style={{ width: '20%' }}>
          <FormHelperText>From Promotion Time</FormHelperText>
          <TextField
            id="time-1"
            type="time"
            value={nPromotionTimeFrom === null ? '' : nPromotionTimeFrom}
            onChange={handleChangePromotionTimeFrom}
            className={classes.textField1}
          />
        </FormControl>
        <FormControl required className={classes.formControl} style={{ width: '20%' }}>
          <FormHelperText>To Promotion Time</FormHelperText>
          <TextField
            id="time-2"
            type="time"
            value={nPromotionTimeTo === null ? '' : nPromotionTimeTo}
            onChange={handleChangePromotionTimeTo}
            className={classes.textField1}
          />
        </FormControl>
        <FormControl required className={classes.formControl} style={{ width: '20%' }}>
          <FormHelperText>Special Discount(%)</FormHelperText>
          <TextField
            id='standard-number'
            type='number'
            value={nSpecialDiscountPercent == null ? 0 : nSpecialDiscountPercent}
            onChange={handleChangeSpecialDiscountPercent}
            InputLabelProps={{
              shrink: true,
            }}
            InputProps={{
              inputProps: {
                min: 0,
                max: 100
              }
            }}
          />
        </FormControl>
        <FormControl required className={classes.formControl} style={{ width: '10%' }}>
          <Button className={classes.buttons} color='secondary' variant='contained' onClick={(nAction === 'edit') ? editPromotionTimeDiscountList : addPromotionTimeDiscountList }>
						{(nAction === 'edit') ? 'Update': 'Add'}
					</Button>
        </FormControl>
				{
					(nAction === 'edit') ?
						(<FormControl required className={classes.formControl}>
							<Button className={classes.buttons} color='secondary' variant='contained' onClick={cancelEdit}>Cancel</Button>
						</FormControl>) : null
				}
      </Grid>
      {!props.promotionTimeDiscountList || props.promotionTimeDiscountList.length === 0 ? null :
        <Table className={classes.table} aria-label="caption table">
          <TableHead>
            <TableRow>
              <TableCell>Day</TableCell>
              <TableCell>From Promotion Time</TableCell>
              <TableCell>To Promotion Time</TableCell>
              <TableCell>Special Discount($)</TableCell>
							<TableCell align="center">Edit</TableCell>
              <TableCell>Delete</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {props.promotionTimeDiscountList.map((n, index) => (
              <TableRow key={index}>
                <TableCell className='p-4 md:p-16' component="th" scope="row" size="small">{nDayList[n.promotionDay]}</TableCell>
                <TableCell className='p-4 md:p-16' component="th" scope="row" size="small">{n.promotionTimeFrom}</TableCell>
                <TableCell className='p-4 md:p-16' size="small">{n.promotionTimeTo}</TableCell>
                <TableCell className='p-4 md:p-16' size="small">{n.specialDiscountPercent}</TableCell>
								<TableCell className="w-40 md:w-64 text-center z-99" component='th' scope='row' align='left' size="small">
									<button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
										onClick={() => editItem(index)}
										tabIndex='0' type='button' title='Edit'>
										<span className='MuiIconButton-label'>
											<span className='material-icons MuiIcon-root' aria-hidden='true'>edit</span>
										</span>
										<span className='MuiTouchRipple-root'></span>
									</button>
								</TableCell>
                <TableCell className="w-40 md:w-64 text-center z-99" component='th' scope='row' align='left' size="small">
                    <button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
                    onClick={() => deletePromotionTimeDiscountListItem(index)}
                      tabIndex='0' type='button' title='Delete'>
                      <span className='MuiIconButton-label'>
                        <span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
                      </span>
                      <span className='MuiTouchRipple-root'></span>
                    </button>
                  </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      }
    </div>
  )
    
}

export default PromotionTimeDiscount;
