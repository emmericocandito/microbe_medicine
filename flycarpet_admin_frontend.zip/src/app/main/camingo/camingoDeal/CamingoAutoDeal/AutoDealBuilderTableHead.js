import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Tooltip from '@material-ui/core/Tooltip';
import React from 'react';
import i18next from 'i18next';

const rows = [
  {
    id: 'dealType',
    translate: 'dealType',
    align: 'left',
    disablePadding: false,
    label: 'Deal Type',
    sort: true
  },
  {
    id: 'dealsPerHotel',
    translate: 'dealsPerHotel',
    align: 'center',
    disablePadding: false,
    label: 'Deals Per Hotel',
    sort: true
  },
  {
    id: 'hotelChain',
    translate: 'hotelChain',
    align: 'left',
    disablePadding: false,
    label: 'Hotel Chain',
    sort: true
  },
  {
    id: 'hotelListHome',
    translate: 'hotelListHome',
    align: 'center',
    disablePadding: false,
    label: 'Hotel List For Home',
    sort: true
  },
  {
    id: 'hotelListLP',
    translate: 'hotelListLP',
    align: 'center',
    disablePadding: false,
    label: 'Hotel List LP',
    sort: true
  },
  {
    id: 'adults',
    translate: 'adults',
    align: 'left',
    disablePadding: false,
    label: 'adults',
    sort: true
  },
  {
    id: 'children',
    translate: 'children',
    align: 'left',
    disablePadding: false,
    label: 'children',
    sort: true
  },
  {
    id: 'dateRangeDiscount',
    translate: 'dateRangeDiscount',
    align: 'left',
    disablePadding: false,
    label: 'Date Range Discount',
    sort: true
  },
  {
    id: 'specialDiscount',
    translate: 'specialDiscount',
    align: 'left',
    disablePadding: false,
    label: 'Special Discount',
    sort: true
  },
  {
    id: 'startEndDate',
    translate: 'startEndDate',
    align: 'left',
    disablePadding: false,
    label: 'Start/End Date',
    sort: true
  },
  {
    id: 'showOnSlider',
    translate: 'showOnSlider',
    align: 'left',
    disablePadding: false,
    label: 'Slider',
    sort: true
  },
  {
    id: 'showOnHomePage',
    translate: 'showOnHomePage',
    align: 'left',
    disablePadding: false,
    label: 'HomePage',
    sort: true
  },
  {
    id: 'showOnLandingPage',
    translate: 'LandingPage',
    align: 'left',
    disablePadding: false,
    label: 'LandingPage',
    sort: true
  },
  {
    id: 'active',
    translate: 'active',
    align: 'left',
    disablePadding: false,
    label: 'active',
    sort: true
  },
  {
    id: 'Copy',
    translate: 'Copy',
    align: 'left',
    disablePadding: false,
    label: 'Copy',
    sort: true
  },
  {
    id: 'action',
    translate: 'action',
    align: 'left',
    disablePadding: false,
    label: 'Edit',
    sort: true
  },
  {
    id: 'delete',
    translate: 'delete',
    align: 'left',
    disablePadding: false,
    label: 'Delete',
    sort: true
  }

];

function ProductsTableHead(props) {
  const createSortHandler = property => event => {
    props.onRequestSort(event, property);
  };
  return (
    <TableHead>
      <TableRow className="h-64">
        {rows.map(row => {
          return (
            <TableCell
              className="p-4 md:p-16"
              key={row.id}
              align={row.align}
              padding={row.disablePadding ? 'none' : 'default'}
              sortDirection={props.order.id === row.id ? props.order.direction : false}
            >
              {row.sort && (
                <Tooltip
                  title="Sort"
                  placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                  enterDelay={300}
                >
                <TableSortLabel
                  active={props.order.id === row.id}
                  direction={props.order.direction}
                  onClick={createSortHandler(row.id)}
                >
                  {row.label}
                </TableSortLabel>
                </Tooltip>
              )}
            </TableCell>
          );
        }, this)}
      </TableRow>
    </TableHead>
  );
}

export default ProductsTableHead;
