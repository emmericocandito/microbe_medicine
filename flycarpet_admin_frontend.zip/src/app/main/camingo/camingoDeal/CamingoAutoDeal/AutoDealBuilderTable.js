import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { withRouter } from 'react-router-dom';
import FuseScrollbars from '@fuse/core/FuseScrollbars';
import FuseLoading from '@fuse/core/FuseLoading';
import axios from 'axios';
import _ from '@lodash';
import {
	Checkbox, Table, TableBody, TableCell, TablePagination, TableRow,
	Modal, Backdrop, Fade, TextField, Button, Grid, Select, FormControl, FormHelperText, FormControlLabel,
	CircularProgress, Chip, TableHead, Input, MenuItem, ListItemText
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import DateTimePicker from 'react-datetime-picker';
import SearchIcon from '@material-ui/icons/Search';
import store from 'app/store';
import { getDealType, selectorDealType } from 'app/main/store/Camingo/dealTypeSlice';
import { userAPI } from '../../../store/userAPI';
import { getDeals, selectorDeals, selectorDataLength } from '../../../store/Camingo/camingoAutoDealsSlice';
import { getDestination, selectorDestination } from '../../../store/Camingo/destinationSlice';
import { getHotelChain, selectorHotelChain } from '../../../store/Camingo/hotelChainSlice';
import { getHotels, selectorHotels, selectHotelsLoading } from '../../../store/Camingo/hotelsSlice';

import AutoDealBuilderTableHead from './AutoDealBuilderTableHead';
import SelectBadge from './SelectBadge';
import PromotionTimeDiscount from './components/PromotionTimeDiscount';

import { useBasicAgencyInfo } from 'app/main/store/hooks';
import { AddDscPcntByAgency } from 'app/main/BasicComponents/AddDscPcntByAgency';
import { baseURL } from './../../../utils';

function AutoDealBuilderTable(props) {
	const useStyles = makeStyles(theme => ({
		formControl: {
			margin: '2px 5px',
			minWidth: 60,
			width: '100%'
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
			minWidth: 120
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			maxHeight: '600px',
			overflowY: 'auto'
		},
		discountboxform: {
			display: 'grid'
		},
		checkboxform: {
			display: 'block'
		},
		chipStyle: {
			height: '20px',
			margin: '1px',
			color: 'white',
			fontSize: '12px',
			background: '#32606b'
		},
		chipStyle1: {
			height: '20px',
			margin: '1px',
			color: 'white',
			fontSize: '12px',
			background: '#4CAF50'
		},
		chipStyle2: {
			height: '20px',
			margin: '1px',
			color: 'white',
			fontSize: '12px',
			background: '#F44336'
		},
		button_group: {
			padding: 30,
			textAlign: 'center'
		},
		buttons: {
			marginLeft: '10px',
			height: '40px'
		},
		fo_circular: {
			textAlign: 'center',
			position: 'absolute',
			left: '50%',
			transform: 'translatex(-50%)'
		},
		chip: {
			height: '15px'
		},
		chips: {
			display: 'flex',
			flexWrap: 'wrap'
		},
		hotelNameWrapper: {
			width: '40rem',
			marginTop: '10px'
		},
		selectStyle: {
			margin: '15px 0px 0px 0px',
			minWidth: '160px'
		}
	}));
	const classes = useStyles();

	const ITEM_HEIGHT = 48;
	const ITEM_PADDING_TOP = 8;
	const MenuProps = {
		PaperProps: {
			style: {
				maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
				width: 250
			}
		}
	};

	const deals = useSelector(selectorDeals);
	const dealTypeList = useSelector(selectorDealType);
	const destinationList = useSelector(selectorDestination);
	const hotelList = useSelector(selectorHotels);
	const hotelChainList = useSelector(selectorHotelChain);
	const dataLength = useSelector(selectorDataLength);
	const hotelsLoading = useSelector(selectHotelsLoading);

	const [hotelListByDestChain, setHotelListByDestChain] = useState([]);

	const [ruleName, setRuleName] = useState('');
	const [nDealType, setDealType] = useState(null);
	const [nDealsPerHotel, setDealsPerHotel] = useState(5);
	const [nSelectedHotelChains, setSelectedHotelChains] = useState([]);

	const [nDestHotelsList, setDestHotelsList] = useState([]);
	const [nDestination, setDestination] = useState(null);
	const [nSelectedHotelsForHome, setSelectedHotelsForHome] = useState([]);
	const [nSelectedHotelsForLP, setSelectedHotelsForLP] = useState([]);
	const [nAdults, setAdults] = useState('2');
	const [nChildren, setChildren] = useState('0');

	const [checkinDateFrom, setCheckinDateFrom] = useState(null);
	const [checkinDateTo, setCheckinDateTo] = useState(null);
	const [nWeekendTargeted, setWeekendTargeted] = useState(false);
	const [nWeekendNights, setWeekendNights] = useState(0);
	const [nMidweekTargeted, setMidweekTargeted] = useState(false);
	const [nMidweekNights, setMidweekNights] = useState(0);
	const [dateRangeDiscountPercent, setDateRangeDiscountPercent] = useState(0);

	const [badgeColor, setBadgeColor] = useState(null);
	const [badgeText, setBadgeText] = useState(null);

	const [specialDiscountStateDate, setSpecialDiscountStartDate] = useState(null);
	const [specialDiscountEndDate, setSpecialDiscountEndDate] = useState(null);
	const [specialDiscountPercent, setSpecialDiscountPercent] = useState(null);

	const [sPromotionTimeDiscountList, setPromotionTimeDiscountList] = useState([]);

	const [startDate, setStartDate] = useState(null);
	const [endDate, setEndDate] = useState(null);

	const [includeFCHotels, setIncludeFCHotels] = useState(true);
	const [includeExternalHotels, setIncludeExternalHotels] = useState(false);
	const [isSpecificPaxDeal, setIsSpecificPaxDeal] = useState(false);
	const [isShowOnSlider, setIsShowOnSlider] = useState(false);
	const [isShowOnHome, setIsShowOnHome] = useState(false);
	const [isShowOnLP, setIsShowOnLP] = useState(false);
	const [isActive, setIsActive] = useState(false);
	const [isAutoForward, setIsAutoForward] = useState(false);

	const [nButtonText, setButtonText] = useState(null);
	const [loading, setLoading] = useState(false);
	const [loadingCircle, setLoadingCircle] = useState(false);
	const [selected] = useState([]);

	const [sActionHotelList, setActionHotelList] = useState('add');

	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [warningOpen, setWarningOpen] = useState(false);
	const [warningText, setWarningText] = useState(null);

	const [dealId, setDealID] = useState(null);
	const [confirmText, setConfirmText] = useState(null);
	const [confirmOpen, setConfirmOpen] = useState(false);

	const [nFilterDealType, setFilterDealType] = useState('');
	const [nFilterChain, setFilterChain] = useState('');
	const [nFilterDestination, setFilterDestination] = useState('');
	const [nFilterHotel, setFilterHotel] = useState('');
	const [nFilterActive, setFilterActive] = useState('');
	const [nFilterOnSlider, setFilterOnSlider] = useState('');
	const [nFilterOnHomePage, setFilterOnHomePage] = useState('');
	const [nFilterOnLandingPage, setFilterOnLandingPage] = useState('');

	const [discountListByAgency, setDiscountListByAgency] = useState([]);

	const {
		basicNoAtnmAgencyInfo,
		fetchNoAtnmBasicAgencyInfo,
	} = useBasicAgencyInfo();

	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});
	const [open, setOpen] = useState(false);
	const [openFilter, setOpenFilter] = useState(false);

	useEffect(() => {
		setLoading(true);
		fetchNoAtnmBasicAgencyInfo({ operation: 2 });
		store.dispatch(getHotels());
		store.dispatch(getDealType());
		store.dispatch(getDestination());
		store.dispatch(getHotelChain());
		reopen(1, rowsPerPage);
	}, []);

	useEffect(() => {
		setLoading(hotelsLoading === 'pending');
	}, [hotelsLoading]);

	async function reopen(from, to) {
		const dealTypeId = nFilterDealType || null;
		const chainId = nFilterChain || null;
		const destinationCode = nFilterDestination || null;
		const hotelId = nFilterHotel || null;
		const showOnSlider = nFilterOnSlider === '' ? null : nFilterOnSlider === 'true';
		const showOnHomePage = nFilterOnHomePage === '' ? null : nFilterOnHomePage === 'true';
		const showOnLandingPage = nFilterOnHomePage === '' ? null : nFilterOnHomePage === 'true';
		const active = nFilterActive === '' ? null : nFilterActive === 'true';
		const option = {
			range: { from, to },
			data: {
				dealTypeId,
				chainId,
				destinationCode,
				hotelId,
				showOnSlider,
				showOnHomePage,
				showOnLandingPage,
				active
			}
		};
		await store.dispatch(getDeals(option));
		setLoadingCircle(false);
		setLoading(false);
		setOpen(false);
	}
	const searchDiscount = () => {
		reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
		setOpenFilter(false);
	};
	const handleFilterClose = () => {
		setOpenFilter(false);
		setHotelListByDestChain([]);
	};
	const updateDeal = async i => {
		setActionHotelList('add');
		setButtonText('Edit');

		setDealID(deals[i].id);
		setRuleName(deals[i].ruleName);
		setDealType(deals[i].dealTypeId);
		setDealsPerHotel(deals[i].dealsPerHotel);
		setSelectedHotelChains(deals[i].chainIds);
		setDestHotelsList(deals[i].destHotelsList);

		setCheckinDateFrom(deals[i].dateRangeDiscount?.checkinDateFrom || '');
		setCheckinDateTo(deals[i].dateRangeDiscount?.checkinDateTo || '');
		setIsAutoForward(deals[i].dateRangeDiscount?.autoForward || false);
		setWeekendTargeted(deals[i].dateRangeDiscount?.weekendTargeted || false);
		setWeekendNights(deals[i].dateRangeDiscount?.numOfNightsWeekendTargeted || '');
		setMidweekTargeted(deals[i].dateRangeDiscount?.midweekTargeted || false);
		setMidweekNights(deals[i].dateRangeDiscount?.numOfNightsMidweekTargeted || '');
		setDateRangeDiscountPercent(deals[i].dateRangeDiscount?.discountPercent || 0);

		setSpecialDiscountStartDate(deals[i].specialDiscount?.startDate || '');
		setSpecialDiscountEndDate(deals[i].specialDiscount?.endDate || '');
		setSpecialDiscountPercent(deals[i].specialDiscount?.discountPercent || 0);
		setPromotionTimeDiscountList(deals[i].promotionTimeDiscounts || []);

		setIncludeFCHotels(deals[i].includeFCHotels || false);
		setIncludeExternalHotels(deals[i].includeExternalHotels || false);
		setAdults(deals[i].adults || 0);
		setChildren(deals[i].children || 0);
		setIsSpecificPaxDeal(deals[i].isSpecificPaxDeal || false);
		setIsShowOnSlider(deals[i].showOnSlider || false);
		setIsShowOnHome(deals[i].showOnHomePage || false);
		setIsShowOnLP(deals[i].showOnLandingPage || false);
		setIsActive(deals[i].active || false);
		setBadgeColor(deals[i].badgeColor || '');
		setBadgeText(deals[i].badgeText || '');

		setStartDate(deals[i].startDate || null);
		setEndDate(deals[i].endDate || null);

		if (deals[i].discPctByAgency) {
			setDiscountListByAgency(Object.keys(deals[i].discPctByAgency)
				.map((key) => ({ agencyCode: key, discount: deals[i]['discPctByAgency'][key] })));
		} else {
			setDiscountListByAgency([]);
		}
		setOpen(true);
		setHotelListByDestChain([]);
		setDestination(null);
	};
	const copyDeal = async i => {
		setActionHotelList('add');
		setButtonText('Copy');

		setDealID(deals[i].id);
		setRuleName(deals[i].ruleName);
		setDealType(deals[i].dealTypeId);
		setDealsPerHotel(deals[i].dealsPerHotel);
		setSelectedHotelChains(deals[i].chainIds);
		setDestHotelsList(deals[i].destHotelsList);

		setCheckinDateFrom(deals[i].dateRangeDiscount?.checkinDateFrom || '');
		setCheckinDateTo(deals[i].dateRangeDiscount?.checkinDateTo || '');
		setIsAutoForward(deals[i].dateRangeDiscount?.autoForward || false);
		setWeekendTargeted(deals[i].dateRangeDiscount?.weekendTargeted || false);
		setWeekendNights(deals[i].dateRangeDiscount?.numOfNightsWeekendTargeted || '');
		setMidweekTargeted(deals[i].dateRangeDiscount?.midweekTargeted || false);
		setMidweekNights(deals[i].dateRangeDiscount?.numOfNightsMidweekTargeted || '');
		setDateRangeDiscountPercent(deals[i].dateRangeDiscount?.discountPercent || 0);

		setSpecialDiscountStartDate(deals[i].specialDiscount?.startDate || '');
		setSpecialDiscountEndDate(deals[i].specialDiscount?.endDate || '');
		setSpecialDiscountPercent(deals[i].specialDiscount?.discountPercent || 0);

		setPromotionTimeDiscountList(deals[i].promotionTimeDiscounts || []);

		setIncludeFCHotels(deals[i].includeFCHotels || false);
		setIncludeExternalHotels(deals[i].includeExternalHotels || false);
		setAdults(deals[i].adults || 0);
		setChildren(deals[i].children || 0);
		setIsSpecificPaxDeal(deals[i].isSpecificPaxDeal || false);
		setIsShowOnSlider(deals[i].showOnSlider || false);
		setIsShowOnHome(deals[i].showOnHomePage || false);
		setIsShowOnLP(deals[i].showOnLandingPage || false);
		setIsActive(deals[i].active || false);
		setBadgeColor(deals[i].badgeColor || '');
		setBadgeText(deals[i].badgeText || '');

		setStartDate(deals[i].startDate || null);
		setEndDate(deals[i].endDate || null);

		if (deals[i].discPctByAgency) {
			setDiscountListByAgency(Object.keys(deals[i].discPctByAgency)
				.map((key) => ({ agencyCode: key, discount: deals[i]['discPctByAgency'][key] })));
		} else {
			setDiscountListByAgency([]);
		}
		setOpen(true);
		setHotelListByDestChain([]);
		setDestination(null);
	};
	const deleteDeal = async i => {
		setDealID(deals[i].id);
		setConfirmText('Do you want to drop this discount?');
		setConfirmOpen(true);
	};
	async function editProcess(index) {
		setLoadingCircle(true);
		let url = '';
		if (nButtonText === 'Edit') {
			url = `camingo/api/lastMinuteDealRule/${dealId}`;
		} else {
			url = 'camingo/api/lastMinuteDealRule/';
		}
		const reqData = {
			ruleName: ruleName || '',
			dealTypeId: nDealType,
			dealsPerHotel: +nDealsPerHotel,
			chainIds: nSelectedHotelChains,
			destHotelsList: nDestHotelsList,
			dateRangeDiscount: {
				checkinDateFrom,
				checkinDateTo,
				weekendTargeted: nWeekendTargeted,
				numOfNightsWeekendTargeted: Number(nWeekendNights),
				midweekTargeted: nMidweekTargeted,
				numOfNightsMidweekTargeted: Number(nMidweekNights),
				discountPercent: Number(dateRangeDiscountPercent),
				autoForward: isAutoForward
			},
			specialDiscount:
				specialDiscountStateDate && specialDiscountEndDate
					? {
						startDate: specialDiscountStateDate || null,
						endDate: specialDiscountEndDate || null,
						discountPercent: Number(specialDiscountPercent) || 0
					}
					: null,
			promotionTimeDiscounts: sPromotionTimeDiscountList,
			includeFCHotels: includeFCHotels,
			includeExternalHotels: includeExternalHotels,
			adults: Number(nAdults),
			children: Number(nChildren),
			isSpecificPaxDeal,
			showOnSlider: isShowOnSlider,
			showOnHomePage: isShowOnHome,
			showOnLandingPage: isShowOnLP,
			active: isActive,
			badgeColor,
			badgeText,
			startDate,
			endDate,
			discPctByAgency: discountListByAgency.length ? {} : null,
		};

		for (let i = 0; i < discountListByAgency.length; i++) {
			reqData.discPctByAgency[discountListByAgency[i].agencyCode] = discountListByAgency[i].discount;
		}

		try {
			const response = await userAPI.post(url, reqData);
			if (response.data.error && response.data.error.message) {
				setLoadingCircle(false);
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			} else {
				reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}
		} catch (error) {
			setLoadingCircle(false);
			setWarningOpen(true);
			setWarningText(error?.response?.data || 'something error');
		}
	}
	const addDeal = async () => {
		setActionHotelList('add');
		setButtonText('Add');

		setRuleName('');
		setDealType('');
		setDealsPerHotel(5);
		setSelectedHotelChains([]);
		setDestHotelsList([]);

		setCheckinDateFrom('');
		setCheckinDateTo('');
		setIsAutoForward(false);

		setWeekendTargeted(false);
		setWeekendNights('');
		setMidweekTargeted(false);
		setMidweekNights('');
		setDateRangeDiscountPercent(0);

		setSpecialDiscountStartDate('');
		setSpecialDiscountEndDate('');
		setSpecialDiscountPercent(0);
		setPromotionTimeDiscountList([]);

		setIncludeFCHotels(true);
		setIncludeExternalHotels(false);
		setAdults(2);
		setChildren(0);
		setIsSpecificPaxDeal(false);
		setIsShowOnSlider(false);
		setIsShowOnHome(false);
		setIsShowOnLP(false);
		setIsActive(false);
		setBadgeColor('');
		setBadgeText('');

		setStartDate(null);
		setEndDate(null);

		setDiscountListByAgency([]);

		setOpen(true);
		setHotelListByDestChain([]);
		setDestination(null);
	};

	// control the confirm & warning modal

	async function confirmProcess() {
		await axios.delete(`${baseURL}camingo/api/lastMinuteDealRule/${dealId}`, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				Authorization: `Bearer ${window.localStorage.getItem('jwt_access_token')}`
			}
		});
		setConfirmOpen(false);
		reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
	}
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	};
	const handleCloseWarning = () => {
		setWarningOpen(false);
	};
	const handleClose = () => {
		setOpen(false);
		setHotelListByDestChain([]);
	};
	const openSearchModel = () => {
		setOpenFilter(true);
	};
	const handleRequestSort = (event, property) => {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	};
	const handleChangePage = (event, value) => {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage;
		reopen(from, to);
	};
	const handleChangeRowsPerPage = event => {
		setPage(0);
		setRowsPerPage(event.target.value);
		reopen(1, event.target.value);
	};

	// filter

	const handleChangeFilterDealType = event => {
		setFilterDealType(event.target.value || '');
	};
	const handleChangeFilterHotelChain = event => {
		const chain = event.target.value || '';
		setFilterChain(chain);
	};
	const handleChangeFilterDestination = event => {
		const dest = event.target.value || '';
		setFilterDestination(dest);
	};
	const handleChangeFilterHotel = event => {
		setFilterHotel(event.target.value || '');
	};
	const handleChangeFilterOnSlider = event => {
		setFilterOnSlider(event.target.value || '');
	};
	const handleChangeFilterOnHomePage = event => {
		setFilterOnHomePage(event.target.value || '');
	};
	const handleChangeFilterOnLandingPage = event => {
		setFilterOnLandingPage(event.target.value || '');
	};
	const handleChangeFilterActive = event => {
		setFilterActive(event.target.value || '');
	};

	// open & update modal

	const handleChangeDealType = event => {
		setDealType(event.target.value || '');
	};
	const handleChangeDealsPerHotel = event => {
		setDealsPerHotel(event.target.value || 5);
	};
	const handleChangeRuleName = event => {
		setRuleName(event.target.value || '');
	};
	const handleChangeHotelChainSelected = event => {
		let chain = event.target.value || [];
		if (chain.findIndex(item => item === 'all') > -1 && hotelChainList.length !== nSelectedHotelChains.length) {
			chain = [...hotelChainList.map(item => item.id)];
		}
		if (chain.findIndex(item => item === 'all') > -1 && hotelChainList.length === nSelectedHotelChains.length) {
			chain = [];
		}
		setSelectedHotelChains(chain);
		setHotelListByDestChain(getFilteredHotelsByDestChin(nDestination, chain));
	};
	const handleChangeAdults = event => {
		setAdults(event.target.value || 0);
	};
	const handleChangeChildren = event => {
		setChildren(event.target.value || null);
	};
	const handleChangeDestination = event => {
		const dest = event.target.value || null;
		setDestination(dest);
		setHotelListByDestChain(getFilteredHotelsByDestChin(dest, nSelectedHotelChains));
	};
	const handleChangeHotelForHome = event => {
		setSelectedHotelsForHome(event.target.value || []);
	};
	const handleChangeHotelForLP = event => {
		setSelectedHotelsForLP(event.target.value || []);
	};
	const handleChangeCheckinDateFrom = event => {
		setCheckinDateFrom(event.target.value || '');
	};
	const handleChangeCheckinDateTo = event => {
		setCheckinDateTo(event.target.value || '');
	};
	const handleChangeIsAutoForward = event => {
		setIsAutoForward(!isAutoForward);
	};
	const handleChangeCheckboxWeekend = event => {
		setWeekendTargeted(event.target.checked || false);
	};
	const handleChangeWeekendNights = event => {
		setWeekendNights(event.target.value || '');
	};
	const handleChangeCheckboxMidweek = event => {
		setMidweekTargeted(event.target.checked || false);
	};
	const handleChangeMidweekNights = event => {
		setMidweekNights(event.target.value || '');
	};
	const handleChangeDateRangeDiscountPercent = event => {
		setDateRangeDiscountPercent(Number(event.target.value) ?? '');
	};
	const handleChangeSpecialStartDate = event => {
		setSpecialDiscountStartDate(event);
	};
	const handleChangeSpecialEndDate = event => {
		setSpecialDiscountEndDate(event);
	};
	const handleChangeSpecialDiscount = event => {
		setSpecialDiscountPercent(event.target.value ?? 0);
	};
	const handlePromotionTimeDiscount = list => {
		setPromotionTimeDiscountList(list);
	};
	const handleChangeIsShowOnSlider = event => {
		setIsShowOnSlider(event.target.checked ?? false);
	};
	const handleChangeIsShowOnHome = event => {
		setIsShowOnHome(event.target.checked ?? false);
	};
	const handleChangeIsShowOnLP = event => {
		setIsShowOnLP(event.target.checked ?? false);
	};
	const handleChangeIsActive = event => {
		setIsActive(event.target.checked ?? false);
	};
	const handleChangeIncludeFCHotels = event => {
		setIncludeFCHotels(event.target.checked ?? false);
	};
	const handleChangeIncludeExternalHotels = event => {
		setIncludeExternalHotels(event.target.checked ?? false);
	};
	const handleChangeIsSpecificPaxDeal = event => {
		setIsSpecificPaxDeal(event.target.checked ?? false);
	};
	const handleBadgeInfo = list => {
		setBadgeColor(list[0]);
		setBadgeText(list[1]);
	};
	const handleChangeStartDate = event => {
		setStartDate(event);
	};
	const handleChangeEndDate = event => {
		setEndDate(event);
	};

	const addDestHotelList = () => {
		const index = nDestHotelsList.findIndex(d => d.destinationCode === nDestination);
		if (sActionHotelList === 'add' && index === -1) {
			const destinationListTemp = {};
			destinationListTemp.destinationCode = nDestination;
			destinationListTemp.hotelIdsForHomepage =
				nSelectedHotelsForHome === null ? null : [...nSelectedHotelsForHome];
			destinationListTemp.hotelIdsForLp = nSelectedHotelsForLP === null ? null : [...nSelectedHotelsForLP];

			setDestHotelsList([...nDestHotelsList, destinationListTemp]);
		} else if (sActionHotelList === 'edit' && index !== -1) {
			const array = [...nDestHotelsList]; // make a separate copy of the array
			const destinationListTemp = {};
			destinationListTemp.destinationCode = nDestination;
			destinationListTemp.hotelIdsForHomepage =
				nSelectedHotelsForHome === null ? null : [...nSelectedHotelsForHome];
			destinationListTemp.hotelIdsForLp = nSelectedHotelsForLP === null ? null : [...nSelectedHotelsForLP];
			array[index] = destinationListTemp;
			setDestHotelsList(array);
		}
		exitDestHotelList();
	};
	const exitDestHotelList = () => {
		setDestination('');
		setSelectedHotelsForHome([]);
		setSelectedHotelsForLP([]);
		setActionHotelList('add');
	};
	const editDesHotelItem = async i => {
		setDestination(nDestHotelsList[i].destinationCode);
		setSelectedHotelsForHome(nDestHotelsList[i].hotelIdsForHomepage ?? []);
		setSelectedHotelsForLP(nDestHotelsList[i].hotelIdsForLp ?? []);

		setHotelListByDestChain(getFilteredHotelsByDestChin(nDestHotelsList[i].destinationCode, nSelectedHotelChains));
		setActionHotelList('edit');
	};
	const deleteDesHotelItem = async i => {
		const array = [...nDestHotelsList]; // make a separate copy of the array
		const index = array.indexOf(nDestHotelsList[i]);
		if (index !== -1) {
			array.splice(index, 1);
			setDestHotelsList(array);
		}
	};

	// get Label on multiple select

	const getLabelFromCodeOnHotelChainList = id => {
		const selHotelChain = _.find(hotelChainList, item => {
			return item.id === id;
		});
		return selHotelChain?.nameEn || '';
	};
	const getHotelNameFromIDOnList = pId => {
		const selHotel = _.find(hotelList, item => {
			return item.id === pId;
		});
		return selHotel?.hotelName || '';
	};
	const getFilteredHotelsByDestChin = (dest, chains) => {
		const resultArray = hotelList.filter(item => item.mainCityCode === dest);
		if (chains.length > 0) return resultArray.filter(item => chains.findIndex(d => d === item.hotelChainId) > -1);
		return resultArray;
	};

	if (loading) {
		return <FuseLoading />;
	}

	return (
		<div className="w-full flex flex-col">
			<Modal
				aria-labelledby="transition-modal-title"
				aria-describedby="transition-modal-description"
				className={classes.modal}
				open={openFilter}
				onClose={handleFilterClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500
				}}
			>
				<Fade in={openFilter}>
					<div className={classes.paper}>
						<div className={classes.fo_circular}>
							{loadingCircle ? <CircularProgress className="w-xs max-w-full" color="secondary" /> : null}
						</div>
						<div style={{ textAlign: 'center' }}>
							<h2 id="transition-modal-title">Filter Setting</h2>
						</div>
						<div style={{ display: 'grid' }}>
							<FormControl required className={classes.formControl}>
								<FormHelperText>
									Deal Type (Select a tab to place deals on. For default tab, select empty item)
								</FormHelperText>
								<Select
									native
									onChange={handleChangeFilterDealType}
									value={nFilterDealType || ''}
									inputProps={{
										id: 'filter-deal-type'
									}}
								>
									<option aria-label="None" value="" data-index={-1} />
									{dealTypeList === null
										? ''
										: _.orderBy(dealTypeList, ['name.he'], ['asc']).map((n, i) => (
											<option key={i} value={n.id} data-index={i}>
												{n.name}
											</option>
										))}
								</Select>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Hotel Chain</FormHelperText>
								<Select
									native
									onChange={handleChangeFilterHotelChain}
									value={nFilterChain || ''}
									inputProps={{
										id: 'filter-hotel-chain'
									}}
								>
									<option aria-label="None" value="" data-index={-1} />
									{hotelChainList === null
										? ''
										: _.orderBy(hotelChainList, ['nameEn'], ['asc']).map((n, i) => (
											<option key={i} value={n.id} data-index={i}>
												{n.nameEn}
											</option>
										))}
								</Select>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Destination</FormHelperText>
								<Select
									native
									onChange={handleChangeFilterDestination}
									value={nFilterDestination || ''}
									inputProps={{
										id: 'filter-destination'
									}}
								>
									<option aria-label="None" value="" />
									{destinationList === null
										? ''
										: _.orderBy(destinationList, ['name'], ['asc']).map((n, i) => (
											<option key={i} value={n.code}>
												{n.name}
											</option>
										))}
								</Select>
							</FormControl>

							<FormControl required className={classes.formControl}>
								<FormHelperText>Hotel</FormHelperText>
								<Select
									native
									value={nFilterHotel || ''}
									onChange={handleChangeFilterHotel}
									inputProps={{
										id: 'filter-hotel'
									}}
								>
									<option aria-label="None" value="" />
									{hotelList === null
										? ''
										: _.orderBy(hotelList, ['hotelName'], ['asc']).map((n, i) => (
											<option key={i} value={n.id}>
												{n.hotelName}
											</option>
										))}
								</Select>
							</FormControl>
						</div>
						<Grid
							container
							justify="space-between"
							style={{ margin: '10px 0px', display: 'flex', justifyContent: 'space-between' }}
						>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>OnSlider</FormHelperText>
								<Select
									native
									onChange={handleChangeFilterOnSlider}
									value={nFilterOnSlider}
									inputProps={{
										id: 'filter-on-slider'
									}}
								>
									<option aria-label="None" value="">
										All
									</option>
									<option value="true">Active</option>
									<option value="false">Inactive</option>
								</Select>
							</FormControl>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>OnHomePage</FormHelperText>
								<Select
									native
									onChange={handleChangeFilterOnHomePage}
									value={nFilterOnHomePage}
									inputProps={{
										id: 'filter-on-home'
									}}
								>
									<option aria-label="None" value="">
										All
									</option>
									<option value="true">Yes</option>
									<option value="false">No</option>
								</Select>
							</FormControl>
						</Grid>
						<Grid
							container
							justify="space-between"
							style={{ margin: '10px 0px', display: 'flex', justifyContent: 'space-between' }}
						>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>OnLandingPage</FormHelperText>
								<Select
									native
									onChange={handleChangeFilterOnLandingPage}
									value={nFilterOnLandingPage}
									inputProps={{
										id: 'filter-on-landing-page'
									}}
								>
									<option aria-label="None" value="">
										All
									</option>
									<option value="true">Yes</option>
									<option value="false">No</option>
								</Select>
							</FormControl>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>Active</FormHelperText>
								<Select
									native
									onChange={handleChangeFilterActive}
									value={nFilterActive}
									inputProps={{
										id: 'filter-active'
									}}
								>
									<option aria-label="None" value="">
										All
									</option>
									<option value="true">Active</option>
									<option value="false">Inactive</option>
								</Select>
							</FormControl>
						</Grid>
						<div className={classes.button_group}>
							<Button
								className={classes.buttons}
								variant="contained"
								color="secondary"
								onClick={searchDiscount}
							>
								Filter
							</Button>
							<Button
								className={classes.buttons}
								variant="contained"
								color="primary"
								onClick={handleFilterClose}
							>
								Cancel
							</Button>
						</div>
					</div>
				</Fade>
			</Modal>
			<div>
				<div className="spinner-border text-primary" role="status">
					<span className="sr-only">Loading...</span>
				</div>
				<Modal
					open={confirmOpen}
					onClose={handleCloseConfirm}
					className={classes.modal}
					aria-labelledby="simple-modal-title"
					aria-describedby="simple-modal-description"
				>
					<div className={classes.paper} style={{ textAlign: 'center' }}>
						<h2 id="server-modal-title">Confirm</h2>
						<p id="server-modal-description">{confirmText}</p>
						<Button
							className="whitespace-no-wrap normal-case"
							style={{ margin: '10px 5px' }}
							variant="contained"
							color="secondary"
							onClick={confirmProcess}
						>
							Confirm
						</Button>
						<Button
							className="whitespace-no-wrap normal-case"
							style={{ margin: '10px 5px' }}
							variant="contained"
							color="secondary"
							onClick={handleCloseConfirm}
						>
							Cancel
						</Button>
					</div>
				</Modal>
				<Modal
					open={warningOpen}
					onClose={handleCloseWarning}
					className={classes.modal}
					aria-labelledby="simple-modal-title"
					aria-describedby="simple-modal-description"
				>
					<div className={classes.paper} style={{ textAlign: 'center' }}>
						<h2 id="server-modal-title">Warning</h2>
						<p id="server-modal-description">{warningText}</p>
						<Button
							className="whitespace-no-wrap normal-case"
							variant="contained"
							color="secondary"
							onClick={handleCloseWarning}
						>
							Close
						</Button>
					</div>
				</Modal>
				<Modal
					aria-labelledby="transition-modal-title"
					aria-describedby="transition-modal-description"
					className={classes.modal}
					open={open}
					onClose={handleClose}
					closeAfterTransition
					BackdropComponent={Backdrop}
					BackdropProps={{
						timeout: 500
					}}
				>
					<Fade in={open}>
						<div className={classes.paper}>
							<div className={classes.fo_circular}>
								{loadingCircle ? (
									<CircularProgress className="w-xs max-w-full" color="secondary" />
								) : null}
							</div>
							<div style={{ textAlign: 'center' }}>
								<h2 id="transition-modal-title">Auto Deal Rule Builder</h2>
							</div>
							<div style={{ display: 'grid' }}>
								<FormControl required className={classes.formControl}>
									<FormHelperText>Rule Name</FormHelperText>
									<TextField
										className={classes.textfield}
										onChange={handleChangeRuleName}
										defaultValue={ruleName}
									/>
								</FormControl>
								<FormControl required className={classes.formControl}>
									<FormHelperText>
										Deal Type (Select a tab to place deals on. For default tab, select empty item)
									</FormHelperText>
									<Select
										native
										onChange={handleChangeDealType}
										value={nDealType === null ? '' : nDealType}
										inputProps={{
											id: 'select-deal-type'
										}}
									>
										<option aria-label="None" value="" data-index={-1} />
										{!dealTypeList
											? ''
											: dealTypeList.map((n, i) => (
												<option key={i} value={n.id} data-index={i}>
													{n.name}
												</option>
											))}
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl}>
									<FormHelperText>Hotel Chain</FormHelperText>
									<Select
										labelId="hotel-chain-multiple-select"
										id="hotel-chain-multiple"
										multiple
										input={<Input />}
										onChange={handleChangeHotelChainSelected}
										value={nSelectedHotelChains}
										renderValue={selected => (
											<div className={classes.chips}>
												{selected.map((key, i) => (
													<Chip
														key={i}
														label={getLabelFromCodeOnHotelChainList(key)}
														className={classes.chip}
													/>
												))}
											</div>
										)}
										MenuProps={MenuProps}
									>
										<MenuItem key="all" value="all">
											<Checkbox checked={nSelectedHotelChains.length === hotelChainList.length} />
											<ListItemText primary="All" />
										</MenuItem>
										{hotelChainList === null
											? ''
											: hotelChainList.map((n, i) => (
												<MenuItem key={i} value={n.id} name={n.id}>
													<Checkbox checked={nSelectedHotelChains.indexOf(n.id) > -1} />
													<ListItemText primary={n.nameEn} />
												</MenuItem>
											))}
									</Select>
								</FormControl>
							</div>

							<div style={{ padding: '10px', border: '1px solid',  borderRadius: '5px' }}>
								<div style={{ display: 'flex', marginTop: '10px' }}>
									<FormControl
										required
										className={classes.formControl}
										style={{ width: '50%', marginLeft: '5px' }}
									>
										<FormHelperText>Destination</FormHelperText>
										<Select
											native
											name="Destination"
											onChange={handleChangeDestination}
											value={nDestination === null ? '' : nDestination}
											inputProps={{
												id: 'select-destination'
											}}
										>
											<option aria-label="None" value={null} />
											{destinationList === null
												? ''
												: destinationList.map((n, i) => (
													<option key={i} value={n.code}>
														{n.name}
													</option>
												))}
										</Select>
									</FormControl>
									<div style={{ width: '100%', marginRight: '5px' }}>
										<FormControl className={classes.formControl}>
											<FormHelperText>Hotels For HomePage</FormHelperText>
											<Select
												labelId="select-multiple-hotel-home"
												id="multiple-hotel-home"
												multiple
												value={nSelectedHotelsForHome}
												onChange={handleChangeHotelForHome}
												input={<Input />}
												renderValue={selected => (
													<div className={classes.chips}>
														{selected.map((key, i) => (
															<Chip
																key={i}
																label={getHotelNameFromIDOnList(key)}
																className={classes.chip}
															/>
														))}
													</div>
												)}
												MenuProps={MenuProps}
											>
												{hotelListByDestChain === null
													? ''
													: hotelListByDestChain.map((n, i) => (
														<MenuItem key={i} value={n.id} name={n.id}>
															<Checkbox
																checked={nSelectedHotelsForHome.indexOf(n.id) > -1}
															/>
															<ListItemText primary={n.hotelName} />
														</MenuItem>
													))}
											</Select>
										</FormControl>
									</div>
									<div style={{ width: '100%', marginRight: '5px' }}>
										<FormControl className={classes.formControl}>
											<FormHelperText>Hotels For Landing Page</FormHelperText>
											<Select
												labelId="Hotels-For-LP-label"
												id="hotelsForLP"
												multiple
												value={nSelectedHotelsForLP}
												onChange={handleChangeHotelForLP}
												input={<Input />}
												renderValue={selected => (
													<div className={classes.chips}>
														{selected.map((key, i) => (
															<Chip
																key={i}
																label={getHotelNameFromIDOnList(key)}
																className={classes.chip}
															/>
														))}
													</div>
												)}
												MenuProps={MenuProps}
											>
												{hotelListByDestChain === null
													? ''
													: hotelListByDestChain.map((n, i) => (
														<MenuItem key={i} value={n.id} name={n.id}>
															<Checkbox
																checked={nSelectedHotelsForLP.indexOf(n.id) > -1}
															/>
															<ListItemText primary={n.hotelName} />
														</MenuItem>
													))}
											</Select>
										</FormControl>
									</div>
									{sActionHotelList === 'edit' ? (
										<Button
											className={classes.buttons}
											color="secondary"
											variant="contained"
											onClick={event => exitDestHotelList(event)}
										>
											exit
										</Button>
									) : null}
									<Button
										className={classes.buttons}
										color="secondary"
										variant="contained"
										onClick={event => addDestHotelList(event)}
									>
										{sActionHotelList}
									</Button>
								</div>

								<Table className={classes.table} aria-label="caption table">
									<TableHead>
										<TableRow>
											<TableCell>Destination</TableCell>
											<TableCell align="center">Hotels For Home</TableCell>
											<TableCell align="center">Hotels For LP</TableCell>
											<TableCell align="center">Edit</TableCell>
											<TableCell align="center">Delete</TableCell>
										</TableRow>
									</TableHead>
									<TableBody>
										{nDestHotelsList.map((n, index) => (
											<TableRow key={index}>
												<TableCell className="p-4 md:p-16" component="th" scope="row" size="small">
													{n.destinationCode}
												</TableCell>
												<TableCell className="p-4 md:p-16" align="right" size="small">
													{n.hotelIdsForHomepage
														? n.hotelIdsForHomepage.map((id, index) => (
															<span key={index}>{getHotelNameFromIDOnList(id)}, </span>
														))
														: ''}
												</TableCell>
												<TableCell className="p-4 md:p-16" align="right" size="small">
													{n.hotelIdsForLp
														? n.hotelIdsForLp.map((id, index) => (
															<span key={index}>{getHotelNameFromIDOnList(id)}, </span>
														))
														: ''}
												</TableCell>
												<TableCell
													className="w-40 md:w-64 text-center z-99"
													component="th"
													scope="row"
													align="left"
													size="small"
												>
													<button
														className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit"
														onClick={() => editDesHotelItem(index)}
														tabIndex="0"
														type="button"
														title="Edit"
													>
														<span className="MuiIconButton-label">
															<span
																className="material-icons MuiIcon-root"
																aria-hidden="true"
															>
																edit
															</span>
														</span>
														<span className="MuiTouchRipple-root" />
													</button>
												</TableCell>
												<TableCell
													className="w-40 md:w-64 text-center z-99"
													component="th"
													scope="row"
													align="left"
													size="small"
												>
													<button
														className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit"
														onClick={() => deleteDesHotelItem(index)}
														tabIndex="0"
														type="button"
														title="Delete"
													>
														<span className="MuiIconButton-label">
															<span
																className="material-icons MuiIcon-root"
																aria-hidden="true"
															>
																delete
															</span>
														</span>
														<span className="MuiTouchRipple-root" />
													</button>
												</TableCell>
											</TableRow>
										))}
									</TableBody>
								</Table>
							</div>

							<div className='justify-between flex'>
								<FormControl required className={classes.formControl}>
									<FormHelperText>Deals per Hotel</FormHelperText>
									<TextField
										className={classes.textfield}
										type="number"
										InputProps={{
											inputProps: {
												min: 1
											}
										}}
										onChange={handleChangeDealsPerHotel}
										defaultValue={nDealsPerHotel}
									/>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ margin: '0px 5px' }}>
									<FormHelperText>Adults</FormHelperText>
									<TextField
										className={classes.textfield}
										onChange={handleChangeAdults}
										defaultValue={nAdults}
									/>
								</FormControl>
								<FormControl required className={classes.formControl}>
									<FormHelperText>Children</FormHelperText>
									<TextField
										className={classes.textfield}
										onChange={handleChangeChildren}
										defaultValue={nChildren}
									/>
								</FormControl>
							</div>

							<div style={{ display: 'flex', margin: '30px 0px' }}>
								<FormControl required className={classes.formControl}>
									<FormHelperText>Checkin Date From</FormHelperText>
									<TextField
										id="date-checkinFrom"
										type="date"
										value={checkinDateFrom || ''}
										onChange={handleChangeCheckinDateFrom}
										className={classes.textField1}
									/>
								</FormControl>
								<FormControl required className={classes.formControl}>
									<FormHelperText>Checkin Date To</FormHelperText>
									<TextField
										id="date-checkinDateTo"
										type="date"
										value={checkinDateTo || ''}
										onChange={handleChangeCheckinDateTo}
										className={classes.textField1}
									/>
								</FormControl>
								<FormControl
									required
									className={classes.formControl}
									style={{ margin: '15px 0px 0px 20px' }}
								>
									<FormControlLabel
										control={
											<Checkbox
												checked={isAutoForward}
												onChange={handleChangeIsAutoForward}
												name="checkedB"
												color="primary"
											/>
										}
										label="Auto Forward"
										className={classes.checkboxform}
									/>
								</FormControl>
								<FormControl
									required
									className={classes.formControl}
									style={{ margin: '15px 0px 0px 20px', maxWidth: '110px' }}
								>
									<FormControlLabel
										control={
											<Checkbox
												checked={nWeekendTargeted ?? false}
												onChange={handleChangeCheckboxWeekend}
												name="checkedB"
												color="primary"
											/>
										}
										label="Weekend"
										className={classes.checkboxform}
									/>
								</FormControl>
								<FormControl required className={classes.selectStyle}>
									<FormHelperText>Nights for weekend checkins</FormHelperText>
									<Select
										native
										value={nWeekendNights || ''}
										onChange={handleChangeWeekendNights}
										inputProps={{
											id: 'weekend-nights'
										}}
										disabled={!nWeekendTargeted}
									>
										<option aria-label="None" value="" />
										<option aria-label="None" value={1}>
											1 night
										</option>
										<option aria-label="None" value={2}>
											2 nights
										</option>
										<option aria-label="None" value={3}>
											3 nights
										</option>
										<option aria-label="None" value={4}>
											4 nights
										</option>
									</Select>
								</FormControl>
								<FormControl
									required
									className={classes.formControl}
									style={{ margin: '15px 0px 0px 20px', maxWidth: '110px' }}
								>
									<FormControlLabel
										control={
											<Checkbox
												checked={nMidweekTargeted ?? false}
												onChange={handleChangeCheckboxMidweek}
												name="checkedB"
												color="primary"
											/>
										}
										label="Midweek"
										className={classes.checkboxform}
									/>
								</FormControl>
								<FormControl required className={classes.selectStyle}>
									<FormHelperText>Nights for midweek checkins</FormHelperText>
									<Select
										native
										value={nMidweekNights || ''}
										onChange={handleChangeMidweekNights}
										inputProps={{
											id: 'midweek-nights'
										}}
										disabled={!nMidweekTargeted}
									>
										<option aria-label="None" value="" />
										<option aria-label="None" value={1}>
											1 night
										</option>
										<option aria-label="None" value={2}>
											2 nights
										</option>
										<option aria-label="None" value={3}>
											3 nights
										</option>
										<option aria-label="None" value={4}>
											4 nights
										</option>
										<option aria-label="None" value={5}>
											5 nights
										</option>
									</Select>
								</FormControl>

								<FormControl
									required
									className={classes.formControl}
									style={{ margin: '15px 15px 0px', maxWidth: '70px' }}
								>
									<FormHelperText>Discount(%)</FormHelperText>
									<TextField
										className={classes.textfield}
										onChange={handleChangeDateRangeDiscountPercent}
										defaultValue={dateRangeDiscountPercent}
									/>
								</FormControl>
							</div>
							<Grid container justify="space-between" style={{ margin: '30px 0px' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Special Discount Start Date</FormHelperText>
									<DateTimePicker
										className={classes.textField1}
										onChange={handleChangeSpecialStartDate}
										value={specialDiscountStateDate ? new Date(specialDiscountStateDate) : ''}
									/>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Special Discount End Date</FormHelperText>
									<DateTimePicker
										className={classes.textField1}
										onChange={handleChangeSpecialEndDate}
										value={specialDiscountEndDate ? new Date(specialDiscountEndDate) : ''}
									/>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Discount(%)</FormHelperText>
									<TextField
										id="standard-number"
										type="number"
										value={specialDiscountPercent || 0}
										onChange={handleChangeSpecialDiscount}
										InputLabelProps={{
											shrink: true
										}}
										InputProps={{
											inputProps: {
												min: 1,
												max: 100
											}
										}}
									/>
								</FormControl>
							</Grid>

							<SelectBadge
								badgeColor={badgeColor || ''}
								badgeText={badgeText || ''}
								onChangeBadgeInfo={handleBadgeInfo}
							/>
							<div style={{ padding: '10px', border: '1px solid', borderRadius: '5px' }}>
								<AddDscPcntByAgency agencies={basicNoAtnmAgencyInfo} agencyDiscountList={discountListByAgency}
									onChangeDiscountListByAgency={(list) => setDiscountListByAgency(list)} />
							</div>

							<div style={{ padding: '10px', border: '1px solid', borderRadius: '5px' }}>
								<PromotionTimeDiscount
									promotionTimeDiscountList={sPromotionTimeDiscountList}
									onChangePromotionTimeDiscount={handlePromotionTimeDiscount}
								/>
							</div>

							<Grid container justify="space-between" style={{ margin: '30px 0px' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Start Rule Date</FormHelperText>
									<DateTimePicker
										className={classes.textField1}
										onChange={handleChangeStartDate}
										value={startDate ? new Date(startDate) : ''}
									/>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>End Rule Date</FormHelperText>
									<DateTimePicker
										className={classes.textField1}
										onChange={handleChangeEndDate}
										value={endDate ? new Date(endDate) : ''}
									/>
								</FormControl>
							</Grid>

							<div style={{ display: 'flex', margin: '30px 0px' }}>
								<FormControlLabel
									control={
										<Checkbox
											checked={includeFCHotels}
											onChange={handleChangeIncludeFCHotels}
											color="primary"
										/>
									}
									label="Atlantis Hotels"
									className={classes.checkboxform}
								/>
								<FormControlLabel
									control={
										<Checkbox
											checked={includeExternalHotels}
											onChange={handleChangeIncludeExternalHotels}
											color="primary"
										/>
									}
									label="External Hotels"
									className={classes.checkboxform}
								/>
								<FormControlLabel
									control={
										<Checkbox
											checked={isSpecificPaxDeal}
											onChange={handleChangeIsSpecificPaxDeal}
											name="checkedB"
											color="primary"
										/>
									}
									label="SpecificPaxDeal"
									className={classes.checkboxform}
								/>
								<FormControlLabel
									control={
										<Checkbox
											checked={isShowOnSlider}
											onChange={handleChangeIsShowOnSlider}
											name="checkedB"
											color="primary"
										/>
									}
									label="ShowOnSlider"
									className={classes.checkboxform}
								/>
								<FormControlLabel
									control={
										<Checkbox
											checked={isShowOnHome}
											onChange={handleChangeIsShowOnHome}
											name="checkedB"
											color="primary"
										/>
									}
									label="ShowOnHomePage"
									className={classes.checkboxform}
								/>
								<FormControlLabel
									control={
										<Checkbox
											checked={isShowOnLP}
											onChange={handleChangeIsShowOnLP}
											name="checkedB"
											color="primary"
										/>
									}
									label="ShowOnLandingPage"
									className={classes.checkboxform}
								/>
								<FormControlLabel
									control={
										<Checkbox
											checked={isActive}
											onChange={handleChangeIsActive}
											name="checkedB"
											color="primary"
										/>
									}
									label="Active"
									className={classes.checkboxform}
								/>
							</div>
							<div className={classes.button_group}>
								<Button
									className={classes.buttons}
									variant="contained"
									onClick={editProcess}
									color="secondary"
								>
									{nButtonText}
								</Button>
								<Button
									className={classes.buttons}
									variant="contained"
									color="primary"
									onClick={handleClose}
								>
									Cancel
								</Button>
							</div>
						</div>
					</Fade>
				</Modal>
			</div>
			<div>
				<Button
					className="whitespace-no-wrap normal-case"
					variant="contained"
					color="secondary"
					style={{ float: 'right', margin: '15px 15px 15px 5px' }}
					onClick={() => addDeal()}
				>
					<span className="hidden sm:flex">New Deal</span>
					<span className="flex sm:hidden">New</span>
				</Button>
				<Button
					className="whitespace-no-wrap normal-case"
					variant="contained"
					color="secondary"
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => openSearchModel()}
				>
					<span className="hidden sm:flex">
						<SearchIcon />
						Filter
					</span>
					<span className="flex sm:hidden">
						<SearchIcon />
					</span>
				</Button>
			</div>
			<FuseScrollbars className="flex-grow overflow-x-auto">
				<Table stickyHeader className="min-w-xl" aria-labelledby="tableTitle">
					<AutoDealBuilderTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={deals.length}
					/>
					<TableBody>
						{_.orderBy(
							deals,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow className="h-64 cursor-pointer" hover tabIndex={-1} key={n.id}>
									<TableCell
										className="p-4 md:p-16"
										component="th"
										scope="row"
										onClick={() => updateDeal(i)}
									>
										{dealTypeList && dealTypeList.find(item => n.dealTypeId == item.id)?.name || ''}
									</TableCell>

									<TableCell
										className="p-4 md:p-16"
										component="th"
										scope="row"
										onClick={() => updateDeal(i)}
									>
										{n.dealsPerHotel}
									</TableCell>

									<TableCell
										className="p-4 md:p-16"
										component="th"
										scope="row"
										onClick={() => updateDeal(i)}
									>
										{n.chainIds.map((chain, i) => (
											<Chip
												key={i}
												className={classes.chipStyle}
												label={hotelChainList?.find(item => item.id === chain).nameEn}
												variant="outlined"
											/>
										))}
									</TableCell>

									<TableCell
										className="p-4 md:p-16"
										component="th"
										scope="row"
										onClick={() => updateDeal(i)}
									>
										{n.destHotelsList.map((destHotel, i) => (
											<div key={i} className={classes.hotelNameWrapper}>
												{destHotel.hotelIdsForHomepage.map((hotelId, j) => (
													<Chip
														className={classes.chipStyle1}
														key={j}
														label={`${destinationList.find(
															item => destHotel.destinationCode === item.code
														)?.name || ''
															} > ${hotelList.find(item => item.id === hotelId)?.hotelName || ''
															}`}
														variant="outlined"
													/>
												))}
											</div>
										))}
									</TableCell>
									<TableCell
										className="p-4 md:p-16"
										component="th"
										scope="row"
										onClick={() => updateDeal(i)}
									>
										{n.destHotelsList.map((destHotel, i) => (
											<div key={i} className={classes.hotelNameWrapper}>
												{destHotel.hotelIdsForLp.map((hotelId, j) => (
													<Chip
														className={classes.chipStyle1}
														key={j}
														label={`${destinationList.find(
															item => destHotel.destinationCode === item.code
														)?.name || ''
															} > ${hotelList.find(item => item.id === hotelId)?.hotelName || ''
															}`}
														variant="outlined"
													/>
												))}
											</div>
										))}
									</TableCell>

									<TableCell
										className="p-4 md:p-16"
										component="th"
										scope="row"
										onClick={() => updateDeal(i)}
										align="center"
									>
										{n.adults}
									</TableCell>
									<TableCell
										className="p-4 md:p-16"
										component="th"
										scope="row"
										onClick={() => updateDeal(i)}
										align="center"
									>
										{n.children}
									</TableCell>

									<TableCell
										className="p-4 md:p-16"
										component="th"
										scope="row"
										align="left"
										onClick={() => updateDeal(i)}
									>
										{n.dateRangeDiscount === null ? null : (
											<div>
												<Chip
													className={classes.chipStyle2}
													label={`Checkin from ${n.dateRangeDiscount.checkinDateFrom}`}
													variant="outlined"
												/>
												<Chip
													className={classes.chipStyle2}
													label={`Checkin to ${n.dateRangeDiscount.checkinDateTo}`}
													variant="outlined"
												/>
												{n.dateRangeDiscount?.weekendTargeted ?? false ? (
													<Chip
														className={classes.chipStyle2}
														label="Weekend"
														variant="outlined"
													/>
												) : null}
												{n.dateRangeDiscount?.midweekTargeted ?? false ? (
													<Chip
														className={classes.chipStyle2}
														label="Midweek"
														variant="outlined"
													/>
												) : null}
												<Chip
													className={classes.chipStyle2}
													label={`${n.dateRangeDiscount.discountPercent}%`}
													variant="outlined"
												/>
											</div>
										)}
									</TableCell>

									<TableCell
										className="p-4 md:p-16"
										component="th"
										scope="row"
										align="left"
										onClick={() => updateDeal(i)}
									>
										{n.specialDiscount === null ? null : (
											<div>
												<Chip
													className={classes.chipStyle2}
													label={`${n.specialDiscount.startDate.slice(
														0,
														10
													)} -> ${n.specialDiscount.endDate.slice(0, 10)}`}
													variant="outlined"
												/>
												<Chip
													className={classes.chipStyle2}
													label={`${n.specialDiscount.discountPercent}%`}
													variant="outlined"
												/>
											</div>
										)}
									</TableCell>

									<TableCell
										className="p-4 md:p-16"
										component="th"
										scope="row"
										align="left"
										onClick={() => updateDeal(i)}
									>
										{n.startDate === null ? null : (
											<div>
												<Chip
													className={classes.chipStyle2}
													label={`${n.startDate.slice(0, 10)} -> ${n.endDate.slice(0, 10)}`}
													variant="outlined"
												/>
											</div>
										)}
									</TableCell>

									<TableCell
										className="p-4 md:p-16"
										component="th"
										scope="row"
										align="left"
										onClick={() => updateDeal(i)}
									>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.showOnSlider && 'bg-red',
												n.showOnSlider && 'bg-green'
											)}
										/>
									</TableCell>
									<TableCell
										className="p-4 md:p-16"
										component="th"
										scope="row"
										align="left"
										onClick={() => updateDeal(i)}
									>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.showOnHomePage && 'bg-red',
												n.showOnHomePage && 'bg-green'
											)}
										/>
									</TableCell>
									<TableCell
										className="p-4 md:p-16"
										component="th"
										scope="row"
										align="left"
										onClick={() => updateDeal(i)}
									>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.showOnLandingPage && 'bg-red',
												n.showOnLandingPage && 'bg-green'
											)}
										/>
									</TableCell>
									<TableCell
										className="p-4 md:p-16"
										component="th"
										scope="row"
										align="left"
										onClick={() => updateDeal(i)}
									>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.active && 'bg-red',
												n.active && 'bg-green'
											)}
										/>
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left">
										<button
											className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit"
											onClick={() => copyDeal(i)}
											tabIndex="0"
											type="button"
											title="Copy"
										>
											<span className="MuiIconButton-label">
												<span className="material-icons MuiIcon-root" aria-hidden="true">
													copy
												</span>
											</span>
											<span className="MuiTouchRipple-root" />
										</button>
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left">
										<button
											className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit"
											onClick={() => updateDeal(i)}
											tabIndex="0"
											type="button"
											title="Edit"
										>
											<span className="MuiIconButton-label">
												<span className="material-icons MuiIcon-root" aria-hidden="true">
													edit
												</span>
											</span>
											<span className="MuiTouchRipple-root" />
										</button>
									</TableCell>
									<TableCell
										className="w-40 md:w-64 text-center z-99"
										component="th"
										scope="row"
										align="left"
									>
										<button
											className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit"
											onClick={() => deleteDeal(i)}
											tabIndex="0"
											type="button"
											title="Edit"
										>
											<span className="MuiIconButton-label">
												<span className="material-icons MuiIcon-root" aria-hidden="true">
													delete
												</span>
											</span>
											<span className="MuiTouchRipple-root" />
										</button>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className="flex-shrink-0 border-t-1"
				component="div"
				count={dataLength}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}
export default withRouter(AutoDealBuilderTable);
