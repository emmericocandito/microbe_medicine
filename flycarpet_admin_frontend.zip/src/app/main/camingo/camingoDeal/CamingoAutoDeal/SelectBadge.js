
import React, { useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import FormControl from '@material-ui/core/FormControl';
import TextField from '@material-ui/core/TextField';
import FormHelperText from '@material-ui/core/FormHelperText';
import Select from '@material-ui/core/Select';

const ChooseColor = (props) => {
  const useStyles = makeStyles((theme) => ({
		formControl: {
			margin: '2px 5px',
			minWidth: 60,
		},
	}));
	const classes = useStyles();

	const [nColorList, setColorList] = useState([]);
	const [nColor, setBadgeColor] = useState('');
	const [nBadgeText, setBadgeText] = useState('');

  useEffect(() => {
		setColorList([
      {text: 'Red', value:'red'},
      {text: 'Black', value:'black'},
      {text: 'Gold', value:'gold'},
      {text: 'Orange', value:'orange'},
      {text: 'Green', value:'green'},
      {text: 'Pink', value:'pink'},
    ]);
		setBadgeColor(props.badgeColor);
    setBadgeText(props.badgeText);
  },[])
  useEffect(() => {
    updateBadgeInfo();
  },[nColor, nBadgeText]);

  const updateBadgeInfo = () => {
    props.onChangeBadgeInfo([nColor, nBadgeText]);
  }
  const handleChangeColor = (event) => {
		if(event !== null){
			setBadgeColor(event.target.value);
		} else {
			setBadgeColor('');
		}
	}
	const handleChangeBadgeText = (event) => {
		if (event !== null) {
			setBadgeText(event.target.value);
		}
		else {
			setBadgeText(null);
		}
	};

  return (
    <div>
      <Grid container justify='space-between' style={{ margin: '10px 0px' }}>
				<FormControl required className={classes.formControl} style={{ width: '30%' }}>
					<FormHelperText>Badge Color</FormHelperText>
					<Select
						native
						onChange={handleChangeColor}
						value={nColor}
						inputProps={{
							id: 'age-native-required',
						}}
					>
						<option aria-label='None' value=''> </option>
						{
							nColorList.map((item, inx) => ( <option value={item.value} key={inx}>{item.text}</option> ))
						}
					</Select>
				</FormControl>
        <FormControl required className={classes.formControl} style={{ width: '65%' }}>
          <FormHelperText>Badge Text</FormHelperText>
          <TextField
            id='standard-number'
            type='text'
            value={nBadgeText}
            onChange={handleChangeBadgeText}
            InputLabelProps={{
              shrink: true,
            }}
          />
        </FormControl>
      </Grid>
    </div>
  )
    
}

export default ChooseColor;
