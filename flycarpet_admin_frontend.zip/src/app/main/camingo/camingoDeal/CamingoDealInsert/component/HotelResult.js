import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { makeStyles } from '@material-ui/core/styles';
import 'react-tabs/style/react-tabs.css';
import {
    Card, CardHeader, CardMedia, CardContent, IconButton, Typography,
    Grid, Modal, Backdrop, Fade, Button, Select, FormControl, FormHelperText,
    FormControlLabel, Checkbox, CircularProgress, TextField, Chip, Input, MenuItem, ListItemText
} from '@material-ui/core';
import { red, deepOrange, green } from '@material-ui/core/colors';
import EditIcon from '@material-ui/icons/Edit';
import Rating from '@material-ui/lab/Rating';
import SentimentSatisfiedAltIcon from '@material-ui/icons/SentimentSatisfiedAltOutlined';
import Family from '@material-ui/icons/SupervisorAccountRounded';
import Business from '@material-ui/icons/Business';
import CenterFocusWeakRoundedIcon from '@material-ui/icons/CenterFocusWeakRounded';
import ImageUploader from "react-images-upload";
import ShowMoreText from 'react-show-more-text';
import DateTimePicker from 'react-datetime-picker';
import ChooseBadgeColor from '../../ChooseBadge';
import _ from '@lodash';
import { AddDscPcntByAgency } from 'app/main/BasicComponents/AddDscPcntByAgency';
import { baseURL } from 'app/main/utils';
import jwtService from 'app/services/jwtService';

var suppliers = ["CAMINGO", "GOC", "ISRO", "DAN", "MINI"];
function CamingoHotelResult(props) {

    const { roomRemark } = props;

    const useStyles = makeStyles((theme) => ({
        root: {
            maxWidth: '100%',
            textAlign: 'center',
            margin: '20px 10%',
            boxShadow: props.isMore ? '1px 1px 5px' : '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
            background: props.isMore ? 'antiquewhite' : 'none'
        },
        formControl: {
            margin: theme.spacing(0, 1),
            minWidth: 120,
        },
        modal: {
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
        },
        paper: {
            backgroundColor: theme.palette.background.paper,
            border: '2px solid #000',
            boxShadow: theme.shadows[5],
            padding: theme.spacing(2, 4, 3),
            textAlign: "center",
            maxHeight: "100vh",
            overflowY: "auto",
        },
        media: {
            width: 'auto',
            height: '150px',
            margin: '10px',
            borderRadius: '10px',
            border: '1px groove #d1d1d1'
        },
        expand: {
            transform: 'rotate(0deg)',
            marginLeft: 'auto',
            transition: theme.transitions.create('transform', {
                duration: theme.transitions.duration.shortest,
            }),
            background: '#00ab93',
            color: 'white',
            height: '35px',
            width: '35px',
            '&:hover': {
                backgroundColor: '#0069d9',
                boxShadow: 'none',
            },
            '&:active': {
                boxShadow: 'none',
                backgroundColor: '#0062cc',
            },
            '&:focus': {
                boxShadow: '0 0 0 0.2rem rgba(0,123,255,.5)',
            },
        },
        OKavatar: {
            padding: '0px',
            width: '25px',
            height: '25px',
            backgroundColor: green[500],
            fontSize: '15px'
        },
        RQavatar: {
            padding: '0px',
            width: '25px',
            height: '25px',
            backgroundColor: red[500],
            fontSize: '15px'
        },
        actionExtend: {
            alignItems: 'flex-end',
        },
        expandOpen: {
            transform: 'rotate(180deg)',
        },
        cardContent: {
            paddingTop: '0px',
            paddingBottom: '0px !important',
            textAlign: 'left',
            minHeight: '85px',
            marginBottom: '20px'
        },
        cardHeader: {
            textAlign: 'left',
            fontWeight: '600',
            fontSize: '20px',
            padding: '0px 16px'
        },
        square: {
            color: theme.palette.getContrastText(deepOrange[500]),
            backgroundColor: deepOrange[500],
        },
        chipStyle: {
            height: '20px',
            margin: '1px',
            color: '#6f6e6e',
            fontSize: '10px'
        },
        chipStyle1: {
            height: '20px',
            margin: '1px',
            color: 'white',
            fontSize: '10px',
            background: '#2797b2'
        },
        chipStyle2: {
            height: '20px',
            margin: '1px',
            color: 'white',
            fontSize: '10px',
            background: '#ea1111',
        },
        Flights: {
            display: 'block',
            textAlign: 'left',
            width: '100%'
        },
        gridContent: {
            textAlign: 'center',
            padding: '5px 10px !important',
        },
        gridContainer: {
            borderRadius: '5px',
            margin: '0px 20px'
        },
        gridItem: {
            padding: '0px !important'
        },
        title: {
            fontSize: '15px',
            margin: '0px 0px'
        },
        checkboxform: {
            marginLeft: '0px'
        },
        button_group: {
            padding: 30,
            textAlign: 'center',
        },
        more_button_group: {
            padding: 0,
            textAlign: 'right',
        },
        buttons: {
            marginLeft: '10px'
        },
        discountboxform: {
            display: 'grid',
            margin: '0 8px'
        },
        ntextArea: {
            border: '1px solid gray',
            minHeight: '35px !important',
            '&:hover': {
                outlineColor: '#000000cf',
                borderRadius: '0'
            },
            '&:active': {
                outlineColor: '#000000cf',
                borderRadius: '0'
            },
            '&:focus': {
                outlineColor: '#000000cf !important',
                borderRadius: '0'
            },
        },
        fo_circular: {
            textAlign: 'center',
            position: 'absolute',
            left: '50%',
            transform: 'translatex(-50%)'
        },
        deleteImage: {
            position: 'absolute',
            top: '1px',
            right: '7px',
            color: '#fff',
            background: '#ff4081',
            borderRadius: '50%',
            textAign: 'center',
            cursor: 'pointer',
            fontSize: '17px',
            fontWeight: 'bold',
            lineHeight: '20px',
            width: '20px',
            height: '20px'
        },
        chip: {
            height: '15px'
        },
        chips: {
            display: 'flex',
            flexWrap: 'wrap',
        },
    }));
    const classes = useStyles();
    const ITEM_HEIGHT = 48;
    const ITEM_PADDING_TOP = 8;
    const MenuProps = {
        PaperProps: {
            style: {
                maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
                width: 250,
            },
        },
    };

    const [open, setOpen] = useState(false);
    const [warningOpen, setWarningOpen] = useState(false);
    const [loadingCircle, setLoadingCircle] = useState(false);
    const [warningText, setWarningText] = useState(null);
    const [responseStateText, setStateText] = useState(null);

    const [hotelId, setHotelID] = useState(null)
    const [dealCategoryList, setDealCategoryList] = useState([]);
    const [dealCategory, setDealCategory] = useState([]);
    const [nDiscountValue, setDiscountValue] = useState(0);
    const [hotelName, setHotelName] = useState(props.name);
    const [immediateDebit, setImmediateDebit] = useState(true);
    const [autoUpdatePrice, setAutoUpdatePrice] = useState(false);
    const [promotion, setPromotion] = useState(false);
    const [inputPriority, setInputPriority] = useState(0);
    const [active, setActive] = useState(false);
    const [startDate, setStartDate] = useState('')
    const [endDate, setEndDate] = useState('');
    const [nPriceRemarkHe, setInputPriceRemarkHe] = useState(null);
    const [nPriceRemarkEn, setInputPriceRemarkEn] = useState(null);
    const [nPriceRemarkRu, setInputPriceRemarkRu] = useState(null);
    const [siteToShowIn, setSiteToShowIn] = useState(2);
    const [imageURL, setImageURL] = useState(props.imageSrc);
    const [image, setImage] = useState(null);

    const [isShowOnHome, setIsShowOnHome] = useState(true);
    const [isShowOnLP, setIsShowOnLP] = useState(false);

    const [nBadgeColor, setBadgeColor] = useState('');
    const [nBadgeTextHe, setBadgeTextHe] = useState('');
    const [nBadgeTextEn, setBadgeTextEn] = useState('');
    const [nBadgeTextRu, setBadgeTextRu] = useState('');
    const [hasSpecial, setHasSpecial] = useState(false);
    const [specialDiscountValue, setSpecialDiscountValue] = useState(0);
    const [specialStartDate, setSpecialStartDate] = useState('')
    const [specialEndDate, setSpecialEndDate] = useState('');

    const [hasMore, setHasMore] = useState(false);
    const [discountListByAgency, setDiscountListByAgency] = useState([]);

    useEffect(() => {
        getDealCategoryData();
        getHotelID(props.exCode, props.group);
        inputInitial();

        setHasMore(props.hasMore);
    }, []);

    const handleCloseWarning = () => {
        setWarningOpen(false);
    }
    const handleClose = () => {
        inputInitial()
        setOpen(false);
    };
    const OnInsertDealModal = () => {
        setOpen(true);
    }
    async function getHotelID(exCode, group) {
        var source = null;
        switch (group) {
            case 'ATLANTIS':
                source = 0;
                break;
            case 'GOC':
                source = 1;
                break;
            case 'ISRO':
                source = 2;
                break;
            case 'DAN':
                source = 3;
                break;
            case 'MINI':
                source = 4;
                break;
            default:
                break;
        }
        await axios({
            method: 'post',
            url: `${baseURL}camingo/api/hotelConversion/search?`,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            data: {
                'hotelExternalCode': exCode,
                'source': source,
            }
        }).then(response => {
            const data = response.data.data;
            setHotelID(data[0].id)
        }).catch(error => {
            console.log(error);
        });
    }
    async function getDealCategoryData() {
        const response = await axios.get(`${baseURL}camingo/api/dealCategory/onlyActive?from=1&to=1000`)
        const data = response.data;
        setDealCategoryList(data)
    }
    async function onInsertDeal() {
        if (dealCategory.length === 0) {
            setStateText('Warning');
            setWarningText("please select DealCategory");
            setWarningOpen(true);
        }
        else if (nDiscountValue == null) {
            setStateText('Warning');
            setWarningText("please apply discount");
            setWarningOpen(true);
        }
        else {
            setLoadingCircle(true);
            const priority = inputPriority == null ? null : Number(inputPriority);
            const source = suppliers.indexOf(props.group);
            const data = new FormData();
            // data.append('hotelId', hotelId);
            dealCategory.forEach(item => {
                data.append('dealCategoryIds', item);
            })
            data.append('checkinDate', props.checkIn);
            data.append('checkoutDate', props.checkOut);
            data.append('adult', props.adults);
            data.append('child', props.children);
            data.append('infant', props.infant);
            data.append('totalPrice', new Number(props.price));
            data.append('AtlantisPriceCategCode', props.category);
            data.append('siteToShowIn', new Number(siteToShowIn));
            if (nDiscountValue !== null && Number(nDiscountValue) <= 20) {
                data.append('discountPercent', new Number(nDiscountValue));
            }
            data.append('PriceRemarkTrans.He', nPriceRemarkHe);
            data.append('PriceRemarkTrans.En', nPriceRemarkEn);
            data.append('PriceRemarkTrans.Ru', nPriceRemarkRu);

            if (roomRemark !== null)
                data.append('roomRemark', roomRemark);

            data.append('hotelName', hotelName);
            data.append('basisCode', props.basis);
            if (props.basisName !== null) {
                data.append('basisName', props.basisName);
            }
            data.append('priority', priority);
            data.append('immediateDebit', immediateDebit);
            data.append('autoUpdatePrice', autoUpdatePrice);
            data.append('active', active);
            if (startDate !== null)
                data.append('startDate', startDate);

            if (endDate !== null)
                data.append('endDate', endDate);

            if (imageURL !== null)
                data.append('imageUrl', imageURL);

            if (props.priceList !== null)
                data.append('priceList', props.priceList);

            data.append('roomCode', props.roomCode);
            data.append('promotion', promotion);
            data.append('source', source);
            data.append('hotelCode', props.exCode);

            data.append('isHomePageDeal', isShowOnHome);
            data.append('isLandingPageDeal', isShowOnLP);

            for (let i = 0; i < discountListByAgency.length; i++) {
                data.append(`discPctByAgency.${discountListByAgency[i].agencyCode}`, discountListByAgency[i].discount);
            }

            if (nBadgeColor !== null)
                data.append('badgeColor', nBadgeColor);
            if (nBadgeTextHe !== null)
                data.append('BadgeTextTrans.He', nBadgeTextHe);
            if (nBadgeTextEn !== null)
                data.append('BadgeTextTrans.En', nBadgeTextEn);
            if (nBadgeTextRu !== null)
                data.append('BadgeTextTrans.Ru', nBadgeTextRu);
            if (hasSpecial) {
                data.append('specialDiscount.discountPercent', specialDiscountValue);
                data.append('specialDiscount.startDate', specialStartDate || startDate);
                data.append('specialDiscount.endDate', specialEndDate || endDate);
            }

            if (image !== null && image.length > 0) {
                data.append('imageFile', image[0]);
            }

            await axios({
                method: 'post',
                url: `${baseURL}camingo/api/deal`,
                headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
                data: data
            }).then(response => {
                setLoadingCircle(false);
                if (response.data.error !== null && [1, 2, 3].includes(Number(response.data.error.code))) {
                    setStateText('Warning');
                    setWarningText(response.data.error.message);
                    setWarningOpen(true);
                } else {
                    setOpen(false);
                    setStateText('Success');
                    setWarningText('Deal builder Success');
                    inputInitial();
                }
            }).catch(error => {
                let errorMessage = '';
                if (error.response) {
                    errorMessage = error.response.data.title;
                } else {
                    errorMessage = error.message;
                }

                setLoadingCircle(false);
                setStateText('Error');
                setWarningText(errorMessage);
                setWarningOpen(true);
            });
        }
    }

    function handleChangeStartDate(event) {
        if (event.target.value === '') {
            setStartDate(null);
        } else {
            setStartDate(event.target.value);
        }
    }
    function handleChangeEndDate(event) {
        if (event.target.value === '') {
            setEndDate(null);
        } else {
            setEndDate(event.target.value);
        }
    }
    function handleChangeCheckbox1() {
        setImmediateDebit(!immediateDebit)
    }
    function handleChangeCheckbox2() {
        setAutoUpdatePrice(!autoUpdatePrice)
    }
    function handleChangeCheckbox3() {
        setPromotion(!promotion)
    }
    function handleChangeCheckbox() {
        setActive(!active)
    }
    function onChangeHotelName(event) {
        setHotelName(event.target.value.trim());
    }
    function onChangePriceRemarkHe(event) {
        setInputPriceRemarkHe(event.target.value)
    }
    function onChangePriceRemarkEn(event) {
        setInputPriceRemarkEn(event.target.value)
    }
    function onChangePriceRemarkRu(event) {
        setInputPriceRemarkRu(event.target.value)
    }
    function onChangePriority(event) {
        setInputPriority(event.target.value);
    }
    function onSelectDealCategory(event) {
        setDealCategory(event.target.value || []);
    }
    const getCategoryNameFromID = (pId) => {
        const category = _.find(dealCategoryList, (item) => { return item.id === pId });
        return category?.name || category?.nameEn || '';
    }
    function handleChangeDiscountValue(event) {
        setDiscountValue(event.target.value);
    }
    function handleChangeSiteToShowIn(event) {
        setSiteToShowIn(event.target.value);
    }
    function inputInitial() {
        setDealCategory([]);
        // setHotelName(`${props.name} ${props.cityName || props.city}`);
        setHotelName(props.name);
        setDiscountValue(0);
        setImmediateDebit(true);
        setAutoUpdatePrice(true);
        setPromotion(false);
        setActive(true);
        setInputPriority(5);
        setStartDate(getDateBeforeOneDay(new Date()));
        setEndDate(props.checkIn);
        setInputPriceRemarkHe('חדר סטנדרטי זוגי כולל ארוחות בוקר');
        setInputPriceRemarkEn('Standard double room includes breakfast');
        setInputPriceRemarkRu('Стандартный двухместный номер с завтраком');
        setSiteToShowIn(2);
        setImage(null);
        setBadgeColor('');
        setBadgeTextHe('');
        setBadgeTextEn('');
        setBadgeTextRu('');
        setSpecialDiscountValue(0);
        setSpecialStartDate(new Date(getDateBeforeOneDay(new Date())).toISOString());
        setSpecialEndDate(new Date(props.checkIn).toISOString());
        setHasSpecial(false);
        setDiscountListByAgency([]);
    }
    const onImageDrop = (picture) => {
        setImageURL(null);
        setImage(picture);
    };
    const getDateFormat = (date) => {
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var mdate = date.getDate();
        if (month < 10) {
            month = '0' + month;
        }
        if (mdate < 10) {
            mdate = '0' + mdate;
        }
        return year + '-' + month + '-' + mdate;
    }
    const getDateBeforeOneDay = (checkIn) => {
        const date = new Date(checkIn);
        return getDateFormat(new Date(date.getTime() - 24 * 60 * 60 * 1000));
    }
    function executeOnClick(isExpanded) {
    }
    function handleChangeSpecialDiscountValue(event) {
        setSpecialDiscountValue(Number(event.target.value));
    }
    function handleChangeSpecialStartDate(event) {
        let date = new Date(event);
        setSpecialStartDate(date.toISOString());
    }
    function handleChangeSpecialEndDate(event) {
        let date = new Date(event);
        setSpecialEndDate(date.toISOString());
    }
    function handleChangeHasSpecial(event) {
        setHasSpecial(!hasSpecial);
    }
    const handleBadgeInfo = (list) => {
        setBadgeColor(list[0]);
        setBadgeTextHe(list[1]);
        setBadgeTextEn(list[2]);
        setBadgeTextRu(list[3]);
    }
    const deleteImageURL = () => {
        setImageURL(null);
    }
    const deleteImageFile = () => {
        setImage(null);
    }
    const showMoreItem = () => {
        props.updateIsMoreState(props.isShowMoreItem, props.index);
    }
    const handleChangeIsShowOnHome = (event) => {
        setIsShowOnHome(event.target.checked ?? false);
    };
    const handleChangeIsShowOnLP = (event) => {
        setIsShowOnLP(event.target.checked ?? false);
    };
    return (
        <Card className={classes.root}>
            <Grid container spacing={3}>
                <Grid item xs={12} sm={3} style={{ margin: 'auto' }}>
                    {props.imageSrc ?
                        <CardMedia className={classes.media} image={props.imageSrc} title={props.hotelName} />
                        :
                        <CardMedia className={classes.media} image={'/'} title={'empty'} />
                    }
                </Grid>
                <Grid item xs={12} sm={9}>
                    <CardHeader className={classes.cardHeader}
                        title={
                            <Typography style={{ fontSize: '20px', padding: '7px 0px' }} component='h1'>
                                {props.name}
                            </Typography>
                        }
                        action={
                            <IconButton aria-label='settings' style={{ marginTop: '5px' }} onClick={OnInsertDealModal}>
                                <EditIcon />
                            </IconButton>
                        }
                    />
                    <CardContent className={classes.cardContent}>
                        <Grid style={{ display: 'grid' }}>
                            <Typography className={classes.title} component='p'>
                                Price: {props.price}$
                            </Typography>

                            <div style={{ display: 'flex' }}>
                                <Typography className={classes.title} component='p'>
                                    <CenterFocusWeakRoundedIcon />
                                    {props.group}
                                </Typography>
                                <Typography className={classes.title} style={{ marginLeft: '10px' }} component='p'>
                                    <Family></Family>
                                    Adult: {props.adults} Children: {props.children} Infant: {props.infant}
                                </Typography>
                            </div>
                            {props.cityName == null ? null :
                                <Typography className={classes.title} component='p'>
                                    <Business></Business>
                                    {props.cityName}
                                </Typography>
                            }
                            <div style={{ display: 'flex' }}>
                                <Typography className={classes.title} component='p'>
                                    Basis: {props.basis}/{props.basisName}
                                </Typography>
                                <Typography className={classes.title} style={{ marginLeft: '10px' }} component='p'>
                                    RoomClass: {props.roomName}
                                </Typography>

                            </div>
                            <ShowMoreText
                                lines={3}
                                more='Show more'
                                less='Show less'
                                className='content-css'
                                anchorClass='my-anchor-css-class'
                                onClick={executeOnClick}
                                expanded={false}
                                style={{ marginBottom: '20px' }}
                                width={800}
                            >
                                {props.remark}
                            </ShowMoreText>

                            {hasMore ?
                                <div className={classes.more_button_group}>
                                    <Button className={classes.buttons} variant='contained' color='secondary' onClick={() => showMoreItem()}>
                                        {props.isShowMoreItem ? 'Hide More Item' : 'Show More Item'}
                                    </Button>
                                </div> : ''
                            }
                        </Grid>
                    </CardContent>
                </Grid>
            </Grid>
            <Modal
                aria-labelledby='transition-modal-title'
                aria-describedby='transition-modal-description'
                className={classes.modal}
                open={open}
                onClose={handleClose}
                closeAfterTransition
                BackdropComponent={Backdrop}
                BackdropProps={{
                    timeout: 500,
                }}
            >
                <Fade in={open}>
                    <div className={classes.paper}>
                        <div className={classes.fo_circular}>
                            {loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
                        </div>
                        <div style={{ textAlign: 'center' }}>
                            <h2 id='transition-modal-title' >Camingo Deal Builder</h2>
                        </div>
                        <div className={classes.formControl} style={{ display: 'grid' }}>
                            <Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
                                <FormControl required className={classes.formControl} style={{ width: '45%' }}>
                                    <FormHelperText>DealCategory</FormHelperText>
                                    <Select
                                        labelId="Categories"
                                        id="categories"
                                        multiple
                                        value={dealCategory}
                                        onChange={onSelectDealCategory}
                                        input={<Input />}
                                        renderValue={(selected) => (
                                            <div className={classes.chips}>
                                                {selected.map((key, i) => (
                                                    <Chip key={i} label={getCategoryNameFromID(key)} className={classes.chip} />
                                                ))}
                                            </div>
                                        )}
                                        MenuProps={MenuProps}
                                    >
                                        {dealCategoryList === null ? '' : dealCategoryList.map((n, i) => (
                                            <MenuItem key={i} value={n.id} name={n.id}>
                                                <Checkbox checked={dealCategory.indexOf(n.id) > -1} />
                                                <ListItemText primary={n.name || n.nameEn} />
                                            </MenuItem>
                                        ))}
                                    </Select>

                                </FormControl>
                                <FormControl required className={classes.formControl} style={{ width: '45%', display: 'none' }}>
                                    <FormHelperText>SiteToShowIn</FormHelperText>
                                    <Select
                                        native
                                        onChange={handleChangeSiteToShowIn}
                                        defaultValue={siteToShowIn}
                                        name='Code'
                                        inputProps={{
                                            id: 'age-native-required',
                                        }}
                                    >
                                        <option value={0}>Homepage</option>
                                        <option value={1}>Internal site</option>
                                        <option value={2}>Both</option>
                                    </Select>
                                </FormControl>
                            </Grid>

                            <Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
                                <FormControl required className={classes.formControl} style={{ width: '45%' }}>
                                    <FormHelperText>Hotel</FormHelperText>
                                    <TextField onChange={onChangeHotelName} defaultValue={hotelName || ''} disabled={true} />
                                </FormControl>
                                <FormControl required className={classes.formControl} style={{ width: '45%' }}>
                                    <FormHelperText>discount(1~20%)</FormHelperText>
                                    <TextField
                                        id='standard-number'
                                        type='number'
                                        min='0'
                                        max='20'
                                        defaultValue={nDiscountValue || ''}
                                        onChange={handleChangeDiscountValue}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            inputProps: {
                                                min: 0,
                                                max: 20
                                            }
                                        }}
                                    />
                                </FormControl>
                            </Grid>

                            <Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
                                <FormControl required className={classes.formControl} style={{ width: '30%' }}>
                                    <FormHelperText>Hebrew PriceRemark</FormHelperText>
                                    <TextField onChange={onChangePriceRemarkHe} defaultValue={nPriceRemarkHe || ''} />
                                </FormControl>
                                <FormControl required className={classes.formControl} style={{ width: '30%' }}>
                                    <FormHelperText>English PriceRemark</FormHelperText>
                                    <TextField onChange={onChangePriceRemarkEn} defaultValue={nPriceRemarkEn || ''} />
                                </FormControl>
                                <FormControl required className={classes.formControl} style={{ width: '30%' }}>
                                    <FormHelperText>Russian PriceRemark</FormHelperText>
                                    <TextField onChange={onChangePriceRemarkRu} defaultValue={nPriceRemarkRu || ''} />
                                </FormControl>
                            </Grid>

                            <Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>

                                <FormControl required className={classes.formControl}>
                                    <FormHelperText>Priority</FormHelperText>
                                    <Rating onChange={onChangePriority} name="customized-10" defaultValue={Number(inputPriority)} max={10} icon={<SentimentSatisfiedAltIcon />} />
                                </FormControl>
                            </Grid>

                        </div>
                        {imageURL !== null ?
                            <div style={{ display: 'inline-box', overflow: 'auto', position: 'relative' }}>
                                <button className={classes.deleteImage} onClick={(e) => deleteImageURL()}>X</button>
                                <img alt='' style={{ width: '100px', height: '100px', margin: '10px' }} src={imageURL} />
                            </div>
                            : null
                        }
                        {image === null ? null :
                            <div style={{ position: 'relative' }}>
                                <button className={classes.deleteImage} onClick={(e) => deleteImageFile()}>X</button>
                                <img alt='' style={{ width: '100px', height: '100px', margin: '20px auto' }} src={URL.createObjectURL(image[0])} />
                            </div>
                        }

                        <ImageUploader
                            withIcon={false}
                            buttonStyles={{ fontSize: '12px' }}
                            fileContainerStyle={{ padding: '0px', boxShadow: 'none' }}
                            buttonText="Add Deal Image"
                            withLabel={false}
                            withPreview={false}
                            onChange={onImageDrop}
                            imgExtension={[".jpg", ".gif", ".png", ".gif", ".jpeg", ".jfif"]}
                            maxFileSize={524288000}
                            singleImage={true}
                        />
                        <Grid container justify='space-around' style={{ margin: '5px 10px' }}>
                            <FormControl required className={classes.formControl} style={{ width: '45%' }}>
                                <FormHelperText>Rule Start Date</FormHelperText>
                                <TextField
                                    id="date-1"
                                    type="date"
                                    value={startDate == null ? '' : startDate}
                                    onChange={handleChangeStartDate}
                                    className={classes.textField1}
                                />
                            </FormControl>
                            <FormControl required className={classes.formControl} style={{ width: '45%' }}>
                                <FormHelperText>Rule End Date</FormHelperText>
                                <TextField
                                    id="date-2"
                                    type="date"
                                    value={endDate == null ? '' : endDate}
                                    onChange={handleChangeEndDate}
                                    className={classes.textField1}
                                />
                            </FormControl>
                        </Grid>

                        <div style={{ marginLeft: '20px' }}>
                            <ChooseBadgeColor
                                badgeColor={nBadgeColor || ''}
                                badgeTextHe={nBadgeTextHe || ''}
                                badgeTextEn={nBadgeTextEn || ''}
                                badgeTextRu={nBadgeTextRu || ''}
                                onChangeBadgeInfo={handleBadgeInfo} />
                        </div>

                        <AddDscPcntByAgency agencies={props.agencies} agencyDiscountList={discountListByAgency}
                            onChangeDiscountListByAgency={(list) => setDiscountListByAgency(list)} />

                        <FormControlLabel
                            style={{ width: '40%' }}
                            control={
                                <Checkbox
                                    checked={hasSpecial}
                                    onChange={handleChangeHasSpecial}
                                    name='checkedA'
                                    color='primary'
                                />
                            }
                            label='Have Special Discount?'
                            className={classes.checkboxform}
                        />
                        <Grid container justify='space-around' style={{ margin: '5px 10px' }}>
                            <FormControl required className={classes.formControl} style={{ width: '95%' }}>
                                <FormHelperText>Special Discount(1 ~ 20%)</FormHelperText>
                                <TextField
                                    id='standard-number'
                                    type='number'
                                    min='0'
                                    max='20'
                                    defaultValue={specialDiscountValue || ''}
                                    onChange={handleChangeSpecialDiscountValue}
                                    disabled={!hasSpecial}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    InputProps={{
                                        inputProps: {
                                            min: 0,
                                            max: 20
                                        }
                                    }}
                                />
                            </FormControl>
                        </Grid>

                        <Grid container justify='space-around' style={{ margin: '5px 10px' }}>
                            <FormControl required className={classes.formControl} style={{ width: '45%' }}>
                                <FormHelperText>Special Start Date</FormHelperText>
                                <DateTimePicker
                                    className={classes.textField1}
                                    onChange={handleChangeSpecialStartDate}
                                    disabled={!hasSpecial}
                                    value={specialStartDate ? new Date(specialStartDate) : new Date(startDate)}
                                />
                            </FormControl>
                            <FormControl required className={classes.formControl} style={{ width: '45%' }}>
                                <FormHelperText>Special End Date</FormHelperText>
                                <DateTimePicker
                                    className={classes.textField1}
                                    onChange={handleChangeSpecialEndDate}
                                    disabled={!hasSpecial}
                                    value={specialEndDate ? new Date(specialEndDate) : new Date(endDate)}
                                />
                            </FormControl>
                        </Grid>
                        <div style={{ display: 'flex', padding: '5px' }}>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        checked={immediateDebit}
                                        onChange={handleChangeCheckbox1}
                                        name='checkedA'
                                        color='primary'
                                    />
                                }
                                label='ImmediateDebit'
                                className={classes.checkboxform}
                            />
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        checked={autoUpdatePrice}
                                        onChange={handleChangeCheckbox2}
                                        name='checkedB'
                                        color='primary'
                                    />
                                }
                                label='AutoUpdatePrice'
                                className={classes.checkboxform}
                            />
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        checked={promotion}
                                        onChange={handleChangeCheckbox3}
                                        name='checkedB'
                                        color='primary'
                                    />
                                }
                                label='Promotion'
                                className={classes.checkboxform}
                            />
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        checked={active}
                                        onChange={handleChangeCheckbox}
                                        name='checkedC'
                                        color='primary'
                                    />
                                }
                                label='Active'
                                className={classes.checkboxform}
                            />
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        checked={isShowOnHome}
                                        onChange={handleChangeIsShowOnHome}
                                        name='checkedB'
                                        color='primary'
                                    />
                                }
                                label='ShowOnHomePage'
                                className={classes.checkboxform}
                            />
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        checked={isShowOnLP}
                                        onChange={handleChangeIsShowOnLP}
                                        name='checkedB'
                                        color='primary'
                                    />
                                }
                                label='ShowOnLandingPage'
                                className={classes.checkboxform}
                            />
                        </div>
                        <div className={classes.button_group}>
                            <Button className={classes.buttons} variant='contained' onClick={onInsertDeal} color='secondary'>
                                ADD DEAL
                            </Button>
                            <Button className={classes.buttons} variant='contained' color='primary' onClick={handleClose}>
                                Cancel
                            </Button>
                        </div>
                    </div>
                </Fade>
            </Modal>
            <Modal
                open={warningOpen}
                onClose={handleCloseWarning}
                className={classes.modal}
                aria-labelledby='simple-modal-title'
                aria-describedby='simple-modal-description'
            >
                <div className={classes.paper}>
                    <h2 id='server-modal-title' >{responseStateText}</h2>
                    <p id='server-modal-description'>{warningText}</p>
                    <Button className='whitespace-no-wrap normal-case'
                        variant='contained'
                        color='secondary'
                        onClick={handleCloseWarning}>Close
                    </Button>
                </div>
            </Modal>
        </Card>
    );
}
export default CamingoHotelResult;