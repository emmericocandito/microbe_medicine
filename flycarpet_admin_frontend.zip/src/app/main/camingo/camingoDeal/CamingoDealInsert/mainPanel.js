import FuseScrollbars from '@fuse/core/FuseScrollbars';
import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import FormHelperText from '@material-ui/core/FormHelperText';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import ButtonGroup from '@material-ui/core/ButtonGroup';
import AddIcon from '@material-ui/icons/Add';
import RemoveIcon from '@material-ui/icons/Remove';
import FuseLoading from '@fuse/core/FuseLoading';
import SearchResultPanel from './searchResultPanel';
import PersonPinIcon from '@material-ui/icons/PersonPin';
import DateRangePicker from 'react-bootstrap-daterangepicker';
import CircularProgress from '@material-ui/core/CircularProgress';
import { ReactNotifications ,  Store } from 'react-notifications-component';
import 'react-notifications-component/dist/theme.css';
import 'react-tabs/style/react-tabs.css';
import 'bootstrap-daterangepicker/daterangepicker.css';
import { useBasicAgencyInfo } from 'app/main/store/hooks';
import { baseURL } from './../../../utils';

function CamingoDealTable(props) {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			margin: theme.spacing(1),
			minWidth: '15%',
			borderRadius: '5px'
		},
		searchButton: {
			background: 'rgb(0,96,160)',
			border: '1px solid rgb(255, 255, 255)',
			borderRadius: '5px',
			marginTop: '15px',
			color: 'white',
			'&:hover': {
				backgroundColor: '#0069d9',
				borderColor: '#0062cc',
				boxShadow: 'none',
			},
			'&:active': {
				boxShadow: 'none',
				backgroundColor: '#0062cc',
				borderColor: '#005cbf',
			},
			'&:focus': {
				boxShadow: '0 0 0 0.2rem rgba(0,123,255,.5)',
			},
		},
		timeInput: {
			width: '200px',
			textAlign: 'center',
			height: '31px',
			borderBottom: '1px solid gray',
			background: 'transparent',
			'&:hover': {
				borderBottom: '2px solid black',
			},
			'&:active': {
				borderBottom: '2px solid gray',
			},
			'&:focus': {
				borderBottom: '2px solid gray',
			},
		},
		circular: {
			textAlign: 'center',
			position: 'absolute',
			width: '100%',
			marginTop: '50px'
		},
		Notificaiton: {
			position: 'absolute !important',
			top: '0px !important'
		},
		menuItem: {
			paddingTop: '0px',
			paddingBottom: '0px'
		},
		menubutton_group: {
			height: '25px'
		}
	}));
	const [destinations, setDestination] = useState('');
	const [destinationsList, setDestinationList] = useState([]);

	const [nHotelList, setHotelList] = useState([]);
	const [nHotel, setHotel] = useState(null);
	const [hotelCode, setHotelCode] = useState(null);
	const [hotelExCode, setHotelExCode] = useState(null)

	const [source, setSupply] = useState(null);

	const [adultcount, setAdultCount] = useState(2);
	const [childcount, setChildCount] = useState(0);
	const [infantcount, setInfantCount] = useState(0);
	let defaultToDate = new Date();
	defaultToDate.setDate(defaultToDate.getDate() + 14);
	const [fromdate, setFromDate] = useState(new Date());
	const [todate, setToDate] = useState(defaultToDate);

	const [people, setPeople] = useState(2);
	const [dealData, setDealData] = useState([])
	const [loading, setLoading] = useState(true);

	const classes = useStyles();

	const [anchorEl, setAnchorEl] = useState(null);
	const [loadingCircle, setLoadingCircle] = useState(false);

	const {
		basicNoAtnmAgencyInfo,
		fetchNoAtnmBasicAgencyInfo,
	} = useBasicAgencyInfo();

	useEffect(() => {
		fetchNoAtnmBasicAgencyInfo({ operation: 2 });
		getDestinationList();
		// getHotelList();
	}, [])

	async function getDestinationList(index) {
		const response = await axios.get(`${baseURL}camingo/api/destination/forAdmin?from=1&to=1000`);
		const data = response.data;
		await setDestinationList(data);
		setLoading(false);
	}
	async function getHotelList(destination) {
		await axios({
			method: 'post',
			url: `${baseURL}camingo/api/hotelConversion/search?from=1&to=1000`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"mainCityCode": destination
			}
		}).then(response => {
			const data = response.data['data'].sort((a, b) => ((a.hotelName < b.hotelName) ? -1 : 1));
			setHotelList(data);
		}).catch(error => {
			console.log(error)
			return;
		});
	}
	const handleChangeDestination = (event) => {
		var temp = event.target.value;
		setDestination(temp);
		setHotel(null);
		getHotelList(temp);
	};
	const handleChangeHotel = (event) => {

		if (event.target.value === '') {
			setHotel(null)
		}
		else {
			setHotel(event.target.value)
		}
		setSupply(event.target.options[event.target.selectedIndex].dataset.rc)
		setHotelCode(event.target.options[event.target.selectedIndex].dataset.mc)
		setHotelExCode(event.target.options[event.target.selectedIndex].dataset.nc)
	};


	const handleClick = (event) => {
		setAnchorEl(event.currentTarget);
	};

	const handleMenuClose = () => {
		setAnchorEl(null);
	};

	function handleEvent(event, picker) {
		setFromDate(picker.startDate._d);
		setToDate(picker.endDate._d);
	}
	function notification(type, title, message) {
		return Store.addNotification({
			title: title,
			message: message,
			type: type,
			insert: "top",
			container: "top-right",
			animationIn: ["animate__animated", "animate__fadeIn"],
			animationOut: ["animate__animated", "animate__fadeOut"],
			dismiss: {
				duration: 1000,
				onScreen: true
			}
		});
	}
	async function searchPackageFromApi() {
		setLoadingCircle(true);
		if (destinations === null || destinations === '') {
			notification('warning', 'warning', 'Please select Destination');
			setLoadingCircle(false);
		} else if (adultcount === 0 && childcount === 0 && infantcount === 0) {
			notification('warning', 'warning', 'Please select person');
			setLoadingCircle(false);
		} else {
			setDealData(null);
			const from = getDateFormat(fromdate);
			const to = getDateFormat(todate);
			var temp = [];
			var temp1 = [];
			var temp2 = [];
			if (!hotelCode && !hotelExCode) {
				// console.log("The search for all hotels-->", hotelCode, hotelExCode);
				await axios({
					method: 'post',
					url: `${baseURL}camingo/api/operation/search`,
					headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
					data: {
						"city": destinations,
						"hotelCode": hotelCode,
						"checkIn": from,
						"checkOut": to,
						"adult": adultcount,
						"child": childcount,
						"infant": infantcount,
						"lang": "he",
						"includeFlight": null,
						"suppliers": ["GOC", "MINI", "DAN", "ISRO", "ATLANTIS"], //GOC,MINI,DAN,ISRO,ATLANTIS
						"returnLog": null
					}
				}).then(response => {
					temp1 = response.data
				})
					.catch(error => {
						setLoadingCircle(false);
						return;
					});
			} else {
				// console.log("The search for one hotel-->", hotelCode, hotelExCode);
				if (hotelCode !== null) {
					await axios({
						method: 'post',
						url: `${baseURL}camingo/api/operation/search`,
						headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
						data: {
							"city": destinations,
							"hotelCode": hotelCode,
							"checkIn": from,
							"checkOut": to,
							"adult": adultcount,
							"child": childcount,
							"infant": infantcount,
							"lang": "he",
							"includeFlight": null,
							"suppliers": [],
							"returnLog": null
						}
					}).then(response => {
						temp1 = response.data
					}).catch(error => {
						setLoadingCircle(false);
						return;
					});
				}
				if (hotelExCode !== null) {
					await axios({
						method: 'post',
						url: `${baseURL}camingo/api/operation/search`,
						headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
						data: {
							"city": destinations,
							"hotelCode": hotelExCode,
							"checkIn": from,
							"checkOut": to,
							"adult": adultcount,
							"child": childcount,
							"infant": infantcount,
							"lang": "he",
							"includeFlight": null,
							"suppliers": [],
							"returnLog": null
						}
					}).then(response => {
						temp2 = response.data
					}).catch(error => {
						setLoadingCircle(false);
						return;
					});
				}
			}

			temp = temp1.concat(temp2);
			temp.sort((a, b) => {
				return (a.supplierCode === 'ATLANTIS' && b.supplierCode !== 'ATLANTIS') ? -1 : 1;
			})
			setDealData(temp);
			// console.log(temp)
			setLoadingCircle(false);
		}

	}
	if (loading) {
		return <FuseLoading />;
	}
	const getDateFormat = (date) => {
		var year = date.getFullYear();
		var month = date.getMonth() + 1;
		var mdate = date.getDate();
		if (month < 10) {
			month = '0' + month;
		}
		if (mdate < 10) {
			mdate = '0' + mdate;
		}
		return year + '-' + month + '-' + mdate;
	}
	const getDateMMFormat = (date) => {
		var year = date.getFullYear();
		var month = date.getMonth() + 1;
		var mdate = date.getDate();
		if (month < 10) {
			month = '0' + month;
		}
		if (mdate < 10) {
			mdate = '0' + mdate;
		}
		return month + '/' + mdate + '/' + year;
	}
	const initilaFromdate = getDateMMFormat(fromdate);
	const initilaTodate = getDateMMFormat(todate);
	return (
		<FuseScrollbars className='flex-grow overflow-x-auto'>
			<ReactNotifications isMobile={true} className={classes.Notificaiton} style={{ position: "absolute", top: "10px" }} />
			<div className='searchBox' style={{ textAlign: 'center' }}>
				<FormControl required className={classes.formControl}>
					<FormHelperText>Destination</FormHelperText>
					<Select native label='Destinations' value={destinations === null ? '' : destinations} onChange={handleChangeDestination} inputProps={{ id: 'age-native-required' }}>
						<option value=''>Select...</option>
						{destinationsList == null ? '' : destinationsList.map((n, i) =>
							<option key={i} value={n.code}>{n.name}</option>
						)}
					</Select>
				</FormControl>
				<FormControl required className={classes.formControl}>
					<FormHelperText>Hotel</FormHelperText>
					<Select native label='Hotel' value={nHotel === null ? '' : nHotel} onChange={handleChangeHotel} inputProps={{ id: 'hotel-native-required' }}>
						<option value='' >ALL</option>
						{nHotelList == null ? '' : nHotelList.map((n, i) =>
							<option key={i} value={n.id} data-rc={n.source} data-mc={n.hotelAtlantisCode} data-nc={n.hotelExternalCode}>{n.hotelName}</option>
						)}
					</Select>
				</FormControl>
				<FormControl>
					<FormHelperText style={{ marginTop: '10px' }}>From - To</FormHelperText>
					<DateRangePicker onEvent={handleEvent} initialSettings={{ startDate: initilaFromdate, endDate: initilaTodate }}>
						<input format='yyyy/MM/dd' className={classes.timeInput} />
					</DateRangePicker>
				</FormControl>

				<FormControl className={classes.formControl}>
					<Menu id='simple-menu' anchorEl={anchorEl} keepMounted open={Boolean(anchorEl)} onClose={handleMenuClose} style={{ top: '50px' }}>
						<MenuItem className={classes.menuItem}>
							<ButtonGroup className={classes.menubutton_group}>
								<Button aria-label='reduce'
									onClick={() => {
										const temp = Math.max(adultcount - 1, 0);
										setAdultCount(temp);
										setPeople(Math.max(temp + childcount + infantcount));
									}}
								>
									<RemoveIcon fontSize='small' />
								</Button>
								<Button style={{ width: '20px', border: '1px solid', textAlign: 'center' }}>{adultcount}</Button>
								<Button aria-label='increase'
									onClick={() => {
										const temp = Math.min(adultcount + 1, 5);
										setAdultCount(temp);
										setPeople(temp + childcount + infantcount);
									}}
								>
									<AddIcon fontSize='small' />
								</Button>
							</ButtonGroup>
							<Button>Adult</Button>
						</MenuItem>
						<MenuItem className={classes.menuItem}>
							<ButtonGroup className={classes.menubutton_group}>
								<Button aria-label='reduce'
									onClick={() => {
										const temp = Math.max(childcount - 1, 0);
										setChildCount(temp);
										setPeople(temp + adultcount + infantcount);
									}}
								>
									<RemoveIcon fontSize='small' />
								</Button>
								<Button style={{ width: '20px', border: '1px solid', textAlign: 'center' }}>{childcount}</Button>
								<Button aria-label='increase'
									onClick={() => {
										const temp = Math.min(childcount + 1, 5);
										setChildCount(temp);
										setPeople(adultcount + temp + infantcount);
									}}
								>
									<AddIcon fontSize='small' />
								</Button>
							</ButtonGroup>
							<Button>Child</Button>
						</MenuItem>
						<MenuItem className={classes.menuItem}>
							<ButtonGroup className={classes.menubutton_group}>
								<Button aria-label='reduce'
									onClick={() => {
										const temp = Math.max(infantcount - 1, 0);
										setInfantCount(temp);
										setPeople(adultcount + childcount + temp);
									}}
								>
									<RemoveIcon fontSize='small' />
								</Button>
								<Button style={{ width: '20px', border: '1px solid', textAlign: 'center' }}>{infantcount}</Button>
								<Button aria-label='increase'
									onClick={() => {
										const temp = Math.min(infantcount + 1, 5);
										setInfantCount(temp);
										setPeople(adultcount + childcount + temp);
									}}
								>
									<AddIcon fontSize='small' />
								</Button>
							</ButtonGroup>
							<Button>Infant</Button>
						</MenuItem>
					</Menu>
					<Button startIcon={<PersonPinIcon />} aria-controls='simple-menu' aria-haspopup='true' onClick={handleClick} style={{ border: '1px solid gray', marginTop: '15px' }}>
						{people === 0 ? 'WHO IS TRAVELING' : 'Person SELECTED(' + people + ')'}
					</Button>
				</FormControl>
				<FormControl className={classes.formControl}>
					<Button className={classes.searchButton} onClick={() => searchPackageFromApi()}  > Search </Button>
				</FormControl>
			</div>
			<div className={classes.circular}>
				{loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
			</div>
			{dealData === null ? null :
				dealData.map((n, i) =>
					<SearchResultPanel key={i} data={n.data.data} cityName={destinationsList.find((d) => d.code === destinations).name}
						group={n.supplierCode} hotelInfo={n.hotelInfo} agencies={basicNoAtnmAgencyInfo} />
				)}
		</FuseScrollbars>
	);
}
export default withRouter(CamingoDealTable);
