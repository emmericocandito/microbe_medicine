
import { lte } from 'lodash';
import React, { useEffect, useState } from 'react';
import 'react-tabs/style/react-tabs.css';
import HotelResult from './component/HotelResult';

function SearchResultPanel(props) {
	const basisNameList = ['RO', 'BB', 'HB', 'FB', 'AI'];
  const [dataList, setDataList] = useState(null);
	const [arrayShowMoreItem, setArrayShowMoreItem] = useState([]);

	useEffect(() => {
		const filteredData = filterCheapestItem(props.data, props.group, props.hotelInfo);
    setDataList(filteredData);
    setArrayShowMoreItem(filteredData.map(() => false));
	}, [])

	const filterCheapestItem = (data, supplierCode, hotelInfo) => {
		let oneData = [];

		if(supplierCode !== 'ATLANTIS'){
			for (const [key] of Object.entries(hotelInfo)) {
				let cheapestDataListByBasis = [];
				const dataListForOneHotel = data.filter((item) => (item.exCode === key));

				const dataWithCreditCardRemark = dataListForOneHotel.filter((item) => (item.matchingDiscInfo.creditCardRemark));
				// if (dataWithCreditCardRemark.length) oneData.push(getCheapestItem(dataWithCreditCardRemark, 'total'));
				if (dataWithCreditCardRemark.length) {
					basisNameList.forEach((code) => {
						const one = dataWithCreditCardRemark.filter((item) => (item.basis.toUpperCase() === code));
						if(one.length) cheapestDataListByBasis.push(getCheapestItem(one, 'total'));
					});
					if(cheapestDataListByBasis.length) {
						const item = cheapestDataListByBasis[0];
						item.moreItemByBasis = cheapestDataListByBasis.slice(1);
						oneData.push(item);
					}
				}

				cheapestDataListByBasis = [];
				const restData = dataListForOneHotel.filter((item) => (item.matchingDiscInfo.creditCardRemark === null));
				// if (restData.length) oneData.push(getCheapestItem(restData, 'total'));
				if(restData.length){
					basisNameList.forEach((code) => {
						const one = restData.filter((item) => (item.basis.toUpperCase() === code));
						if(one.length) cheapestDataListByBasis.push(getCheapestItem(one, 'total'));
					});
					if(cheapestDataListByBasis.length) {
						const item = cheapestDataListByBasis[0];
						item.moreItemByBasis = cheapestDataListByBasis.slice(1);
						oneData.push(item);
					}
				}
				
			}
		}else{
			oneData = [...data];
		}
    return oneData;
	}
	const getCheapestItem = ([...arr], field) => {
		return arr.reduce((prev,next) => prev[field] > next[field] ? next : prev);
	}
	const updateIsMoreState = (show, index) => {
		const arr = [...arrayShowMoreItem];
		arr[index] = !show;
		setArrayShowMoreItem(arr);
	}
	const renderMoreItems = (n) => {
		return (n.moreItemByBasis && n.moreItemByBasis.length) ? n.moreItemByBasis.map((m, j) => 
		<HotelResult key={j} checkIn={m.checkIn} checkOut={m.checkOut} adults={m.adults} children={m.children}
		infant={m.infant} priceList={m.priceList} avail={m.avail} basis={m.basis} basisName={m.basisName} 
		city={m.city} cityName={props.cityName} exCode={m.exCode} imageSrc={m.imgUrl} price={m.total} 
		group={props.group} name={m.name} discountPercent={m.discountPercent} roomAlloc={m.roomAlloc} agencies={props.agencies}
		roomClass={m.roomClass} roomCode={m.roomCode} roomName={m.roomName} totalAfterDiscounted ={m.totalAfterDiscounted}
		remark={m.matchingDiscInfo?.creditCardRemark || m.remark} isMore={true} />): '';
	}

	return(
		<>
		{ dataList === null ? "" : dataList.map((n, i) => 
			(
				[<HotelResult key={i} checkIn={n.checkIn} checkOut={n.checkOut} adults={n.adults} children={n.children}
				infant={n.infant} priceList={n.priceList} avail={n.avail} basis={n.basis} basisName={n.basisName} 
				city={n.city} cityName={props.cityName} exCode={n.exCode} imageSrc={n.imgUrl} price={n.total} 
				group={props.group} name={n.name} discountPercent={n.discountPercent} roomAlloc={n.roomAlloc}
					roomClass={n.roomClass} roomCode={n.roomCode} roomName={n.roomName} roomRemark={n.remark}
				totalAfterDiscounted={n.totalAfterDiscounted}
				category={n.category} agencies={props.agencies}
				remark={n.matchingDiscInfo?.creditCardRemark || n.remark} index={i}
				hasMore={n.moreItemByBasis && n.moreItemByBasis.length} isShowMoreItem={arrayShowMoreItem[i]} updateIsMoreState={updateIsMoreState}
				/>,
				arrayShowMoreItem[i] ? renderMoreItems(n) : '']
			)
		)}
		</>
	);
}
export default SearchResultPanel;