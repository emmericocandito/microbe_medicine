import React from 'react';
import Login from '../login/Login';
const token = window.localStorage.getItem('jwt_access_token');
const CamingoConfig = {
	settings: {
		layout: token == null ? {
			config: {
				navbar: {
					display: false
				},
				toolbar: {
					display: false
				},
				footer: {
					display: false
				},
				leftSidePanel: {
					display: false
				},
				rightSidePanel: {
					display: false
				}
			}
		} : {
				config: {}
			}
	},
	routes: token == null ? [
		{
			path: '/',
			component: Login
		}
	] : [
		{
			path: '/camingoDestination',
			component: React.lazy(() => import('./destination/CamingoDestination'))
		},
		{
			path: '/camingo/camingoBookingInfoAll',
			component: React.lazy(() => import('./analysis/bookingInfoAll/BookingInfoAll')),
		}
	]
};

export default CamingoConfig;
