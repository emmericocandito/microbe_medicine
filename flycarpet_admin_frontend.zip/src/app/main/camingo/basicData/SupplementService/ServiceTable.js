import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import axios from 'axios';
import _ from '@lodash';
import {
	Table, TableBody, TableCell, TablePagination, TableRow, Checkbox, Modal,
	Backdrop, Fade, TextField, Button, CircularProgress, FormControl, FormControlLabel,
	FormHelperText, Grid
} from '@material-ui/core';
import FuseScrollbars from '@fuse/core/FuseScrollbars';
import FuseLoading from '@fuse/core/FuseLoading';
import { baseURL } from './../../../utils';

import { makeStyles } from '@material-ui/core/styles';
import clsx from 'clsx';
import ServiceTableHead from './ServiceTableHead';

function ServiceTable(props) {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			margin: theme.spacing(0),
			minWidth: 60,
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
			minWidth: 120
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
		},
		discountboxform: {
			display: 'grid',
		},
		checkboxform: {
			display: 'block',
		},
		button_group: {
			padding: 30,
			textAlign: 'center',
		},
		buttons: {
			marginLeft: '10px'
		},
		fo_circular: {
			textAlign: 'center',
			position: 'absolute',
			left: '50%',
			transform: 'translatex(-50%)'
		},
		textFiled: {
			width: '100%'
		},
		chip: {
			height: '15px'
		},
		chips: {
			display: 'flex',
			flexWrap: 'wrap',
		},
		chipStyle1: {
			height: '20px',
			margin: '1px',
			color: 'white',
			fontSize: '12px',
			background: '#4CAF50'
		},
	}));

	const classes = useStyles();

	const [loading, setLoading] = useState(true);
	const [loadingCircle, setLoadingCircle] = useState(false);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [pageCount, setPageCount] = useState(10);
	const [warningOpen, setWarningOpen] = useState(false);
	const [warningText, setWarningText] = useState(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});
	const [open, setOpen] = useState(false);

	const [mNameEn, setNameEn] = useState('');
	const [mNameRu, setNameRu] = useState('');
	const [mNameHe, setNameHe] = useState('');
	const [mDescription, setDescription] = useState('');
	const [mPriceUsd, setPriceUsd] = useState(null);
	// const [mIsActive, setIsActive] = useState(false);
	const [currentServiceId, setCurrentServiceId] = useState(null);

	const [nButtonText, setButtonText] = useState(null);
	const [nButtonState, setButtonState] = useState(null);
	const [selected] = useState([]);
	const [data, setData] = useState();
	const [page, setPage] = useState(0);

	useEffect(() => {
		reopen(1, 10);
	}, [])

	async function reopen(from, to) {
		setLoading(true);
		await axios({
			method: 'get',
			url: `${baseURL}camingo/api/supplementService/flatten?from=${from}&to=${to}`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {}
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				const data = response.data;
				setPageCount(data.total);
				setData(data.data);
			}
		}).catch(error => {
			console.log(error);
		});
		setLoading(false);
		setOpen(false);

	};
	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}
	async function deleteService(index) {
		setCurrentServiceId(data[index].id);
		setConfirmOpen(true);
	}
	async function deleteProcess() {
		setLoading(true);
		await axios.delete(`${baseURL}camingo/api/supplementService/${currentServiceId}`, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		})
		reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
		setCurrentServiceId(null)
		setLoading(false);
		setOpen(false);
		setConfirmOpen(false);
	};
	const editService = async (i) => {
		setButtonText('Edit');
		setButtonState('Service Edit');
		setCurrentServiceId(data[i].id);
		setNameEn(data[i].nameEn);
		setNameRu(data[i].nameRu);
		setNameHe(data[i].nameHe);
		setDescription(data[i].description);
		setPriceUsd(data[i].priceUsd);
		// setIsActive(data[i].isActive);
		setOpen(true);
	}
	const handleClose = () => {
		setCurrentServiceId(null);
		initialValue();
		setOpen(false);
	}
	function initialValue() {
		setNameEn(null);
		setNameRu(null);
		setNameHe(null);
		setDescription(null);
		setPriceUsd(null);
		// setIsActive(false);
	}
	async function editProcess() {
		setLoadingCircle(true);
		var request_url = null;
		if (nButtonState == 'Service Edit') {
			request_url = `${baseURL}camingo/api/supplementService/${currentServiceId}`;
		} else {
			request_url = `${baseURL}camingo/api/supplementService`;
		}
		await axios({
			method: 'post',
			url: request_url,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"nameEn": mNameEn || '',
				"nameRu": mNameRu || '',
				"nameHe": mNameHe || '',
				"description": mDescription || '',
				"priceUsd": mPriceUsd === null ? null : Number(mPriceUsd),
				// "isActive": mIsActive,
			}
		}).then(response => {
			setLoadingCircle(false);
			if (response.data.error != null && (Number(response.data.error.code) === 1 || Number(response.data.error.code) === 3)) {
				setWarningText(response.data.error.message);
				setWarningOpen(true);
			} else {
				reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}
		}).catch(error => {
			setLoadingCircle(false);
			setWarningText(error.response.data);
			setWarningOpen(true);
			return;
		});
	};
	const addService = async () => {
		setButtonText('Add');
		setButtonState('Add Service');
		setCurrentServiceId(null);
		initialValue();
		setOpen(true);
	}
	function handleChangePage(event, value) {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage
		reopen(from, to);
	}
	function handleChangeRowsPerPage(event) {
		setRowsPerPage(event.target.value);
		setPage(0)
		const temp = Number(event.target.value)
		const from = 1;
		const to = temp
		reopen(from, to);
	}
	const handleCloseWarning = () => {
		setWarningOpen(false);
	}
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}

	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className='w-full flex flex-col'>
			<div>
				<div className='spinner-border text-primary' role='status'>
					<span className='sr-only'>Loading...</span>
				</div>
				<Modal
					open={warningOpen}
					onClose={handleCloseWarning}
					className={classes.modal}
					aria-labelledby='simple-modal-title'
					aria-describedby='simple-modal-description'
				>
					<div className={classes.paper}>
						<h2 id='server-modal-title' >Warning</h2>
						<p id='server-modal-description'>{warningText}</p>
						<Button className='whitespace-no-wrap normal-case'
							variant='contained'
							color='secondary'
							onClick={handleCloseWarning}>Close
						</Button>
					</div>
				</Modal>
				<Modal
					open={confirmOpen}
					onClose={handleCloseConfirm}
					className={classes.modal}
					aria-labelledby='simple-modal-title'
					aria-describedby='simple-modal-description'
				>
					<div className={classes.paper}>
						<h2 id='server-modal-title' style={{ textAlign: 'center' }} >Confirm</h2>
						<p id='server-modal-description'>Do you want to drop this Service</p>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained'
								color='secondary'
								onClick={deleteProcess}>Yes
							</Button>
							<Button className={classes.buttons} variant='contained'
								color='primary'
								onClick={handleCloseConfirm}>No
							</Button>
						</div>
					</div>
				</Modal>
				<Modal
					aria-labelledby='transition-modal-title'
					aria-describedby='transition-modal-description'
					className={classes.modal}
					open={open}
					onClose={handleClose}
					closeAfterTransition
					BackdropComponent={Backdrop}
					BackdropProps={{
						timeout: 500,
					}}
				>
					<Fade in={open}>
						<div className={classes.paper}>
							<div className={classes.fo_circular}>
								{loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
							</div>
							<div style={{ textAlign: 'center' }}>
								<h2 id='transition-modal-title' >{nButtonState}</h2>
							</div>
							<div>
								<FormControl required className={classes.formControl} style={{ width: '100%' }}>
									<FormHelperText>NameEn</FormHelperText>
									<TextField
										id='name-en'
										type='text'
										value={mNameEn || ''}
										onChange={e => { setNameEn(e.target.value) }}
										InputLabelProps={{
											shrink: true,
										}}
									/>
								</FormControl>

								<Grid container justify='space-between' style={{ margin: '10px 0px', display: 'flex', justifyContent: 'space-between' }}>
									<FormControl required className={classes.formControl} style={{ width: '100%' }}>
										<FormHelperText>NameRu</FormHelperText>
										<TextField
											id='name-ru-comm'
											type='text'
											value={mNameRu || ''}
											onChange={e => { setNameRu(e.target.value) }}
											InputLabelProps={{
												shrink: true,
											}}
										/>
									</FormControl>
								</Grid>
								<FormControl required className={classes.formControl} style={{ width: '100%' }}>
									<FormHelperText>NameHe</FormHelperText>
									<TextField
										id='name-he-comm'
										type='text'
										value={mNameHe || ''}
										onChange={e => { setNameHe(e.target.value) }}
										InputLabelProps={{
											shrink: true,
										}}
									/>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '100%' }}>
									<FormHelperText>Description</FormHelperText>
									<TextField
										id='description-comm'
										type='text'
										value={mDescription || ''}
										onChange={e => { setDescription(e.target.value) }}
										InputLabelProps={{
											shrink: true,
										}}
									/>
								</FormControl>
								<Grid container justify='space-between' style={{ margin: '10px 0px', display: 'flex', justifyContent: 'space-between' }}>
									<FormControl required className={classes.formControl} style={{ width: '100%' }}>
										<FormHelperText>PriceUSD</FormHelperText>
										<TextField
											id='price-comm'
											type='number'
											value={mPriceUsd || ''}
											onChange={e => { setPriceUsd(e.target.value === '' ? null : e.target.value) }}
											InputLabelProps={{
												shrink: true,
											}}
										/>
									</FormControl>
								</Grid>
								{/* <FormControlLabel style={{ width: '100%' }}
									control={
										<Checkbox
											checked={mIsActive}
											onChange={e => { setIsActive(e.target.checked) }}
											name='active'
											color='primary'
										/>
									}
									label='Is Active?'
									className={classes.checkboxform}
								/> */}
							</div>
							<div className={classes.button_group}>
								<Button className={classes.buttons} variant='contained' onClick={editProcess} color='secondary'>
									{nButtonText}
								</Button>
								<Button className={classes.buttons} variant='contained' color='primary' onClick={handleClose}>
									Cancel
								</Button>
							</div>
						</div>

					</Fade>
				</Modal>
			</div>
			<div>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px' }}
					onClick={() => addService()}
				>
					<span className='hidden sm:flex'>Add Service</span>
					<span className='flex sm:hidden'>Add</span>
				</Button>
			</div>
			<FuseScrollbars className='flex-grow overflow-x-auto'>
				<Table stickyHeader className='min-w-xl' aria-labelledby='tableTitle'>
					<ServiceTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={data.length}
					/>
					<TableBody>
						{_.orderBy(
							data,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className='h-64 cursor-pointer'
									hover
									tabIndex={-1}
									key={i}
								>
									<TableCell padding="none" className="w-40 md:w-64 text-center z-99">
										{page * rowsPerPage + 1 + i}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editService(i)}>
										{n.nameEn}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editService(i)}>
										{n.nameRu}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editService(i)}>
										{n.nameHe}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editService(i)}>
										{n.description}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editService(i)}>
										{n.priceUsd}
									</TableCell>
									{/* <TableCell className='p-4 md:p-16' component='th' scope='row' align='left' onClick={() => editService(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.isActive && 'bg-red',
												n.isActive && 'bg-green',
											)}
										/>
									</TableCell> */}
									<TableCell className="w-40 md:w-64 text-center z-99" component='th' scope='row' align='left'>
										<button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
											onClick={() => editService(i)}
											tabIndex='0' type='button' title='Edit'>
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>edit</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => deleteService(i)} tabIndex="0" type="button" title="Edit">
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className='flex-shrink-0 border-t-1'
				component='div'
				count={pageCount}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}
export default withRouter(ServiceTable);
