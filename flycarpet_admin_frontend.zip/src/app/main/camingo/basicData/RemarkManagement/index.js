import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../../store';
import RemarkManageHeader from '../../../domestic/basicdata/RemarkManage/RemarkManageHeader';
import RemarkManageTable from '../../../domestic/basicdata/RemarkManage/RemarkManageTable';

function RemarkManage() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<RemarkManageHeader pageName={'camingo'}/>}
			content={<RemarkManageTable pageName={'camingo'}/>}
			innerScroll
		/>
	);
}

export default withReducer('BasicData', reducer)(RemarkManage);
