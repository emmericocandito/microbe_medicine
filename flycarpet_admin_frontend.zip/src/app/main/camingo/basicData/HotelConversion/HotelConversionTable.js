import FuseScrollbars from '@fuse/core/FuseScrollbars';
import axios from 'axios';
import _ from '@lodash';
import Checkbox from '@material-ui/core/Checkbox';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import FuseLoading from '@fuse/core/FuseLoading';
import HotelConversionTableHead from './HotelConversionTableHead';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import Backdrop from '@material-ui/core/Backdrop';
import Fade from '@material-ui/core/Fade';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import Rating from '@material-ui/lab/Rating';
import Select from '@material-ui/core/Select';
import FormControl from '@material-ui/core/FormControl';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import { Autocomplete } from '@material-ui/lab';
import CircularProgress from '@material-ui/core/CircularProgress'
import Grid from '@material-ui/core/Grid';
import SearchIcon from '@material-ui/icons/Search';
import { baseURL } from './../../../utils';

var suppliers = ["...", "GOC", "ISRO", "DAN", "MINI"];
function HotelConversionTable(props) {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			margin: theme.spacing(0, 0.8),
			minWidth: 120,
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			textAlign: "center"
		},
		button_group:
		{
			padding: 30,
			textAlign: 'center',
		},
		buttons:
		{
			marginRight: '10px'
		},
		fo_circular: {
			textAlign: 'center',
			position: 'absolute',
			left: '50%',
			transform: 'translatex(-50%)'
		},
	}));
	const classes = useStyles();
	const [dealLength, setDealLength] = useState(0);
	const [warningOpen, setWarningOpen] = useState(false);
	const [openFilter, setOpenFilter] = useState(false);
	const [nButtonText, setButtonText] = useState(null);
	const [warningText, setWarningText] = useState(null);
	const [loading, setLoading] = useState(true);
	const [loadingCircle, setLoadingCircle] = useState(false);
	const [selected] = useState([]);
	const [data, setData] = useState([]);
	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [confirmText, setConfirmText] = useState(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});

	// const [referState, setReferState] = useState(false);

	const [hotelConversionID, setHotelConversionID] = useState();
	// const [domesticConversionList, setDomesticConversionList] = useState(null);
	const [hotelChainList, setHotelChainList] = useState(null);
	const [destList, setDestList] = useState(null);

	const [mainCityCode, setMainCityCode] = useState(null);
	const [secondCityCode, setSecondCityCode] = useState(null);

	const [hotelNameEn, setHotelNameEn] = useState(null);
	const [hotelNameRu, setHotelNameRu] = useState(null);
	const [hotelNameHe, setHotelNameHe] = useState(null);

	const [atlantisSupplierCode, setAtlantisSupplierCode] = useState(null);
	const [hotelCamingoCode, setHotelCamingoCode] = useState(null);

	const [hotelChainID, setHotelChainID] = useState(null);
	const [hotelExternalCode, setHotelExternalCode] = useState(null);
	const [source, setSource] = useState(null);

	const [priority, setPriority] = useState(null);
	const [commission, setCommission] = useState(null);
	const [discount, setDiscount] = useState(null);
	const [promoterPhone, setPromoterPhone] = useState(null)
	const [promoterName, setPromoterName] = useState(null);
	const [isActive, setIsActive] = useState(null);

	const [nFilterHotelCamingoCode, setFilterHotelCamingoCode] = useState(null);
	const [nFilterHotelName, setFilterHotelName] = useState(null);
	const [nFilterHotelChainID, setFilterHotelChainID] = useState(null);
	const [nFilterMainCityCode, setFilterMainCityCode] = useState(null);
	const [nFilterSecondCityCode, setFilterSecondCityCode] = useState(null);
	const [nFilterAtlantisSupplierCode, setFilterAtlantisSupplierCode] = useState(null);
	const [nFilterHotelExternalCode, setFilterHotelExternalCode] = useState(null);
	const [nFilterPriority, setFilterPriority] = useState(null);
	const [nFilterCommission, setFilterCommission] = useState(null);
	const [nFilterDiscount, setFilterDiscount] = useState(null);
	const [nFilterPromoterPhone, setFilterPromoterPhone] = useState(null)
	const [nFilterPromoterName, setFilterPromoterName] = useState(null);
	const [nFilterActive, setFilterActive] = useState(null);

	const [nFiltersource, setFilterSource] = useState(null);
	const [nFilterMissingHotelInfo, setFilterMissingHotelInfo] = useState(null);


	const [open, setOpen] = React.useState(false);
	useEffect(() => {
		reopen(1, 10);
		getHotelChainData();
		getDestList();
		// getDomesticChainList();
	}, [])
	// useEffect(() => {
	// 	const matchedConversion = domesticConversionList ? domesticConversionList.find((conversion) => (conversion.id === hotelConversionID)) : null;
	// 	if(!referState) return;
	// 	setMainCityCode(matchedConversion?.mainCityCode || null);
	// 	setSecondCityCode(matchedConversion?.secondCityCode || null);
	// 	setAtlantisSupplierCode(matchedConversion?.atlantisSupplierCode || null);
	// 	setHotelChainID(matchedConversion?.hotelChainId || null);
	// 	setHotelExternalCode(matchedConversion?.hotelExternalCode || null);
	// 	setSource(matchedConversion?.source || null);

	// }, [hotelConversionID])

	useEffect(() => {
		const orderedData = _.orderBy(
			data,
			[
				o => {
					switch (order.id) {
						case 'categories': {
							return o.categories[0];
						}
						default: {
							return o[order.id];
						}
					}
				}
			],
			[order.direction]
		);
		setData(orderedData);

	}, [order]);
	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}

	async function getHotelChainData() {
		const response = await axios.get(`${baseURL}camingo/api/hotelChain/flatten`)
		const data = response.data;
		setHotelChainList(data['data']);
	}
	async function getDestList() {
		const response = await axios.get(`${baseURL}camingo/api/destination/forAdmin?from=1&to=1000`)
		const data = response.data;
		setDestList(data);
	}
	// async function getDomesticChainList(){
	// 	const response = await axios.get(`${baseURL}domestic/api/hotelConversion?from=1&to=1000`);
	// 	const data = response.data.data;
	// 	setDomesticConversionList(data);
	// }

	async function reopen(from, to) {
		await axios({
			method: 'post',
			url: `${baseURL}camingo/api/hotelConversion/search?from=${from}&to=${to}`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"hotelCamingoCode": nFilterHotelCamingoCode,
				"hotelName": nFilterHotelName,

				"mainCityCode": nFilterMainCityCode,
				"secondCityCode": nFilterSecondCityCode,
				"atlantisSupplierCode": nFilterAtlantisSupplierCode,
				"hotelExternalCode": nFilterHotelExternalCode,
				"hotelChainId": nFilterHotelChainID,
				"priority": nFilterPriority === null ? null : Number(nFilterPriority),
				"commission": nFilterCommission === null ? null : Number(nFilterCommission),
				"discount": nFilterDiscount === null ? null : Number(nFilterDiscount),
				"promoterPhone": nFilterPromoterPhone,
				"promoterMame": nFilterPromoterName,
				"imageUrl": null,
				"active": nFilterActive ? nFilterActive === 'true' : null,
				"source": Number(nFiltersource) ? Number(nFiltersource) : null,
				"ignoreSource": nFiltersource === null,
				"missingHotelInfo": (nFilterMissingHotelInfo == '' || nFilterMissingHotelInfo == null) ? null : nFilterMissingHotelInfo == "true"
			}
		}).then(response => {
			setLoading(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningText(response.data.error.message);
				setWarningOpen(true);
			}
			else {
				setDealLength(response.data['total']);
				setData(response.data['data']);
			}
			setOpen(false);
		}).catch(error => {
			setLoading(false);
			setWarningOpen(true);
			setWarningText("Error");
		});
	}

	async function confirmProcess() {
		setLoading(true);
		await axios.delete(`${baseURL}camingo/api/hotelConversion/${hotelConversionID}`, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		}).then(response => {
			setLoading(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}
			setOpen(false);
			setConfirmOpen(false);
		}).catch(error => {
			setLoading(false);
			setConfirmOpen(false);
			setWarningOpen(true);
			setWarningText(error.response.data);
		});
		setConfirmOpen(false);
	}

	async function handleUpdate() {
		// if(nButtonText === 'Edit' && hotelConversionID == null){
		// 	setWarningText("Please choose Domestic Hotel Conversion ID");
		// 	setWarningOpen(true);
		// } else
		if (hotelNameEn == null && hotelNameRu == null && hotelNameHe == null) {
			setWarningText("Please enter HotelName");
			setWarningOpen(true);
		} else if (priority == null) {
			setWarningText("Please set Priority");
			setWarningOpen(true);
		} else {
			setLoadingCircle(true);
			var url;
			if (nButtonText === 'Edit') {
				url = `${baseURL}camingo/api/hotelConversion/${hotelConversionID}`;
			} else {
				url = `${baseURL}camingo/api/hotelConversion`;
			}
			await axios({
				method: 'post',
				url: url,
				headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token') },
				data: {
					"id": hotelConversionID,
					"hotelCamingoCode": hotelCamingoCode,

					"hotelChainId": hotelChainID,
					"hotelExternalCode": hotelExternalCode,
					"source": Number(source) ? Number(source) : null,
					"nameTranslations": {
						"en": hotelNameEn,
						"ru": hotelNameRu,
						"he": hotelNameHe,
					},
					"mainCityCode": mainCityCode,
					"secondCityCode": secondCityCode,
					"atlantisSupplierCode": atlantisSupplierCode,
					"priority": Number(priority) || null,
					"commission": Number(commission) || null,
					"discount": Number(discount) || null,
					"promoterPhone": promoterPhone,
					"promoterMame": promoterName,
					"active": isActive,

				}
			}).then(response => {
				setLoadingCircle(false);
				if (response.data.error != null && response.data.error.message != null) {
					setWarningText(response.data.error.message);
					setWarningOpen(true);
				}
				else {
					setOpen(false);
					reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
					inputInitial();
				}
			}).catch(error => {
				setLoadingCircle(false);
				setWarningText("HTTP REQUEST ERROR");
				setWarningOpen(true);
				return;
			});
		}

	};


	////////////////////////////////////////
	function onChangeHotelNameEn(event) {
		setHotelNameEn(event.target.value || null);
	}
	function onChangeHotelNameRu(event) {
		setHotelNameRu(event.target.value || null);
	}
	function onChangeHotelNameHe(event) {
		setHotelNameHe(event.target.value || null);
	}
	function onChangeAtlantisSupplier(event) {
		setAtlantisSupplierCode(event.target.value || null);
	}
	function onChangePriority(event) {
		setPriority(event.target.value || null);
	}
	function onChangeDiscountValue(event) {
		setDiscount(event.target.value || null);
	}
	function onChangeCommission(event) {
		setCommission(event.target.value || null);
	}
	function onChangeMainCity(event) {
		setMainCityCode(event.target.value || null);
	}
	function onChangeSecondCity(event) {
		setSecondCityCode(event.target.value || null);
	}
	function onChangeHotelCamingoCode(event) {
		setHotelCamingoCode(event.target.value || null);
	}
	function onChangePromoterPhone(event) {
		setPromoterPhone(event.target.value || null);
	}
	function onChangePromotionName(event) {
		setPromoterName(event.target.value || null);
	}
	function onSelectHotelChain(event) {
		setHotelChainID(event.target.value || null);
	}
	function onChangeHotelExternalCode(event) {
		setHotelExternalCode(event.target.value || null);
	}
	function onChangeSource(event) {
		setSource(event.target.value || null);
	}
	/////////////////////////////////

	function onFilterChangeHotelNameEn(event) {
		setFilterHotelName(event.target.value || null);
	}
	function onFilterSelectHotelChain(event) {
		setFilterHotelChainID(event.target.value || null);
	}
	function onFilterChangeMainCity(event) {
		setFilterMainCityCode(event.target.value || null);
	}
	function onFilterChangeSecondCity(event) {
		setFilterSecondCityCode(event.target.value || null);
	}
	function onFilterChangeAtlantisSupplier(event) {
		setFilterAtlantisSupplierCode(event.target.value || null);
	}
	function onFilterChangePriority(event) {
		setFilterPriority(event.target.value || null);
	}
	function onFilterChangeDiscountValue(event) {
		setFilterDiscount(event.target.value || null);
	}
	function onFilterChangeCommission(event) {
		setFilterCommission(event.target.value || null);
	}
	function onFilterChangeHotelCamingoCode(event) {
		setFilterHotelCamingoCode(event.target.value || null);
	}
	function onFilterChangeHotelExternalCode(event) {
		setFilterHotelExternalCode(event.target.value || null);
	}
	function onFilterChangePromoterPhone(event) {
		setFilterPromoterPhone(event.target.value || null);
	}
	function onFilterChangePromoterName(event) {
		setFilterPromoterName(event.target.value || null);
	}

	function onChangeFilterActive(e) {
		setFilterActive(e.target.value);
	}
	function onFilterChangeSource(event) {
		setFilterSource(event.target.value || null);
	}
	function onChangeFilterMissingHotelInfo(e) {
		setFilterMissingHotelInfo(e.target.value);
	}



	const addConversion = async () => {
		setButtonText('Add');
		inputInitial();
		setOpen(true);
	};

	const editConversion = (index) => {
		setButtonText('Edit');
		setHotelConversionID(data[index].id);
		setHotelCamingoCode(data[index].hotelCamingoCode);

		setMainCityCode(data[index].mainCityCode);
		setSecondCityCode(data[index].secondCityCode);

		setHotelChainID(data[index].hotelChainId);
		setHotelExternalCode(data[index].hotelExternalCode);
		setSource(data[index].source);

		setHotelNameEn(data[index].nameTranslations.en);
		setHotelNameRu(data[index].nameTranslations.ru);
		setHotelNameHe(data[index].nameTranslations.he);

		setAtlantisSupplierCode(data[index].atlantisSupplierCode);
		setPriority(data[index].priority);
		setCommission(data[index].commission);
		setDiscount(data[index].discount);
		setPromoterPhone(data[index].promoterPhone);
		setPromoterName(data[index].promoterMame);
		setIsActive(data[index].active);
		setOpen(true);
	};

	const deleteConversion = async (index) => {
		setHotelConversionID(data[index].id);
		setConfirmText("Do you want to drop this HotelConversion?");
		setConfirmOpen(true);
	}
	const handleClose = () => {
		inputInitial();
		setOpen(false);
	};
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}
	const handleCloseWarning = () => {
		setWarningOpen(false);
	}
	function inputInitial() {
		// setReferState(false);
		setHotelConversionID(null);
		setHotelCamingoCode(null);

		setMainCityCode(null);
		setSecondCityCode(null);

		setHotelChainID(null);
		setHotelExternalCode(null);
		setSource(null);

		setHotelNameEn(null);
		setHotelNameRu(null);
		setHotelNameHe(null);
		setAtlantisSupplierCode(null);
		setPriority(null);
		setCommission(null);
		setDiscount(null);
		setPromoterPhone(null);
		setPromoterName(null);
		setIsActive(false);
	}
	function handleChangePage(event, value) {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage;
		reopen(from, to)
	}
	function handleChangeRowsPerPage(event) {
		setRowsPerPage(event.target.value);
		setPage(0);
		const temp = Number(event.target.value)
		const from = 1;
		const to = temp;
		reopen(from, to)

	}
	function onChangeIsActive() {
		setIsActive(!isActive);
	}
	function searchConversion() {
		setPage(0);
		reopen(1, rowsPerPage);
		setOpenFilter(false);
	}

	const handleFilterClose = () => {
		setOpenFilter(false);
	};

	const openSearchModel = () => {
		setOpenFilter(true);
	};

	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className="w-full flex flex-col">
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={openFilter}
				onClose={handleFilterClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={openFilter}>
					<div className={classes.paper}>
						<div className={classes.fo_circular}>
							{loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
						</div>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title' >HotelConversion Filter</h2>
						</div>
						<div className={classes.formControl} style={{ display: 'grid' }}>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>HotelCamingoCode</FormHelperText>
									<TextField value={nFilterHotelCamingoCode == null ? '' : nFilterHotelCamingoCode} onChange={onFilterChangeHotelCamingoCode} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>HotelExternalCode</FormHelperText>
									<TextField value={nFilterHotelExternalCode == null ? '' : nFilterHotelExternalCode} onChange={onFilterChangeHotelExternalCode} />
								</FormControl>
							</Grid>

							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>HotelChain</FormHelperText>
									<Select
										native
										onChange={onFilterSelectHotelChain}
										defaultValue={nFilterHotelChainID || ''}
										name='ChainID'
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option value=''>...</option>
										{hotelChainList == null ? '' : hotelChainList.map((n, i) =>
											<option key={i} value={n.id}>{n.nameEn || n.nameHe || n.nameRu}</option>
										)}
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>MainCity</FormHelperText>
									<Select
										native
										onChange={onFilterChangeMainCity}
										defaultValue={nFilterMainCityCode || ''}
										name='CityCode'
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option value=''>...</option>
										{destList == null ? '' : destList.map((n, i) =>
											<option key={i} value={n.code}>{n.name}</option>
										)}
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>External Source</FormHelperText>
									<Select
										native
										onChange={onFilterChangeSource}
										defaultValue={nFiltersource === null ? '' : nFiltersource}
										name='Code'
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option value=''>All</option>
										{suppliers == null ? '' : suppliers.map((n, i) =>
											<option key={i} value={i}>{n}</option>
										)}
									</Select>
								</FormControl>
							</Grid>

							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Hotel Name</FormHelperText>
									<TextField value={nFilterHotelName || ''} onChange={onFilterChangeHotelNameEn} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>SecondCity</FormHelperText>
									<TextField value={nFilterSecondCityCode == null ? '' : nFilterSecondCityCode} onChange={onFilterChangeSecondCity} />
								</FormControl>
							</Grid>

							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl}>
									<FormHelperText>AtlantisSupplierCode</FormHelperText>
									<TextField onChange={onFilterChangeAtlantisSupplier} defaultValue={nFilterAtlantisSupplierCode == null ? '' : nFilterAtlantisSupplierCode} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Priority(1~10)</FormHelperText>
									<TextField
										id='standard-number'
										type='number'
										min='0'
										max='10'
										defaultValue={nFilterPriority == null ? 0 : Number(nFilterPriority)}
										onChange={onFilterChangePriority}
										InputProps={{
											inputProps: {
												min: 0,
												max: 10
											}
										}}
									/>
								</FormControl>
							</Grid>

							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between', flexWrap: 'nowrap' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>discount(1~20%)</FormHelperText>
									<TextField
										id='standard-number'
										type='number'
										min='0'
										max='20'
										defaultValue={nFilterDiscount == null ? 0 : nFilterDiscount}
										onChange={onFilterChangeDiscountValue}
										InputProps={{
											inputProps: {
												min: 0,
												max: 20
											}
										}}
									/>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Commission</FormHelperText>
									<TextField
										id='standard-number'
										type='number'
										min='0'
										max='20'
										defaultValue={nFilterCommission == null ? 0 : nFilterCommission}
										onChange={onFilterChangeCommission}
										InputProps={{
											inputProps: {
												min: 0,
												max: 20
											}
										}}
									/>
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between', flexWrap: 'nowrap' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>PromoterPhone</FormHelperText>
									<TextField value={nFilterPromoterPhone == null ? '' : nFilterPromoterPhone} onChange={onFilterChangePromoterPhone} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>promoterName</FormHelperText>
									<TextField value={nFilterPromoterName || ''} onChange={onFilterChangePromoterName} />
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between', flexWrap: 'nowrap' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Active</FormHelperText>
									<Select
										native
										onChange={onChangeFilterActive}
										value={nFilterActive || ''}
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option aria-label='None' value=''>All</option>
										<option value='true'>True</option>
										<option value='false'>False</option>
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>MissingHotelInfo</FormHelperText>
									<Select
										native
										onChange={onChangeFilterMissingHotelInfo}
										value={nFilterMissingHotelInfo || ''}
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option aria-label='None' value=''>All</option>
										<option value='true'>True</option>
										<option value='false'>False</option>
									</Select>
								</FormControl>
							</Grid>

						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' onClick={searchConversion} color='secondary'>
								Search
							</Button>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleFilterClose}>
								Cancel
							</Button>
						</div>
					</div>

				</Fade>
			</Modal>
			<Modal
				open={confirmOpen}
				onClose={handleCloseConfirm}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Confirm</h2>
					<p id='server-modal-description'>{confirmText}</p>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={confirmProcess}>Confirm
					</Button>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={handleCloseConfirm}>Cancel
					</Button>
				</div>
			</Modal>
			<Modal
				open={warningOpen}
				onClose={handleCloseWarning}
				className={classes.modal}
				aria-labelledby="simple-modal-title"
				aria-describedby="simple-modal-description"
			>
				<div className={classes.paper}>
					<h2 id="server-modal-title" >Warning</h2>
					<p id="server-modal-description">{warningText}</p>
					<Button className="whitespace-no-wrap normal-case"
						variant="contained"
						color="secondary"
						onClick={handleCloseWarning}>Close
					</Button>
				</div>
			</Modal>
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={open}
				onClose={handleClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={open}>
					<div className={classes.paper}>
						<div className={classes.fo_circular}>
							{loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
						</div>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title' >HotelConversion</h2>
						</div>
						<div className={classes.formControl} style={{ display: 'grid' }}>
							{/* <Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '100%' }}>
									<FormHelperText>Domestic Hotel Conversion</FormHelperText>
									<Autocomplete
										id="controlled-demo"
										onChange={(event, newValue) => {
											setReferState(true);
											setHotelConversionID(newValue?.id || null);
										}}
										defaultValue={domesticConversionList ? domesticConversionList.find((conv) => conv.id === hotelConversionID) || null : ''}
										options={domesticConversionList}
										getOptionLabel={(option) => (`${option.hotelName}`)}
										renderInput={(params) => (
											<TextField {...params} variant="standard" />
										)}
									/>
								</FormControl>
							</Grid> */}
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>HotelChain</FormHelperText>
									<Select
										native
										onChange={onSelectHotelChain}
										value={hotelChainID || ''}
										name='HotelChain'
										inputProps={{
											id: 'HotelChain-native-required',
										}}
									>
										<option value=''>...</option>
										{hotelChainList == null ? '' : hotelChainList.map((n, i) =>
											<option key={i} value={n.id}>{n.nameEn || n.nameHe || n.nameRu}</option>
										)}
									</Select>
								</FormControl>

								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>HotelExternalCode</FormHelperText>
									<TextField value={hotelExternalCode || ''} onChange={onChangeHotelExternalCode} />
								</FormControl>

								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>External Source</FormHelperText>
									<Select
										native
										onChange={onChangeSource}
										value={source || 0}
										name='SourceCode'
										inputProps={{
											id: 'Source-native-required',
										}}
									>
										{/* <option value=''>...</option> */}
										{suppliers == null ? '' : suppliers.map((n, i) =>
											<option key={i} value={i}>{n}</option>
										)}
									</Select>
								</FormControl>

							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>HotelCamingoCode</FormHelperText>
									<TextField value={hotelCamingoCode || ''} onChange={onChangeHotelCamingoCode} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>CamingoSupplierCode</FormHelperText>
									<TextField onChange={onChangeAtlantisSupplier} value={atlantisSupplierCode || ''} />
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>MainCity</FormHelperText>
									<Select
										native
										onChange={onChangeMainCity}
										value={mainCityCode || ''}
										name='mainCityCode'
										inputProps={{
											id: 'mainCityCode-native-required',
										}}
									>
										<option value=''>...</option>
										{destList == null ? '' : destList.map((n, i) =>
											<option key={i} value={n.code}>{n.name}</option>
										)}
									</Select>
									{/* <TextField value={destList ? destList.find((dest) => (dest.code === mainCityCode))?.name || '' : ''} onChange={onChangeMainCity}/> */}
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>SecondCity</FormHelperText>
									<TextField value={secondCityCode || ''} onChange={onChangeSecondCity} />
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Hotel English Name</FormHelperText>
									<TextField value={hotelNameEn || ''} onChange={onChangeHotelNameEn} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Hotel Russian Name</FormHelperText>
									<TextField value={hotelNameRu || ''} onChange={onChangeHotelNameRu} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Hotel Hebrew Name</FormHelperText>
									<TextField value={hotelNameHe || ''} onChange={onChangeHotelNameHe} />
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between', flexWrap: 'nowrap' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>discount(1~20%)</FormHelperText>
									<TextField
										id='standard-number'
										type='number'
										min='0'
										max='20'
										defaultValue={discount == null ? 0 : discount}
										onChange={onChangeDiscountValue}
										InputProps={{
											inputProps: {
												min: 0,
												max: 20
											}
										}}
									/>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Commission</FormHelperText>
									<TextField
										id='standard-number'
										type='number'
										min='0'
										max='20'
										defaultValue={commission == null ? 0 : commission}
										onChange={onChangeCommission}
										InputProps={{
											inputProps: {
												min: 0,
												max: 20
											}
										}}
									/>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Priority(1~10)</FormHelperText>
									<TextField
										id='standard-number'
										type='number'
										min='0'
										max='10'
										defaultValue={priority == null ? 0 : Number(priority)}
										onChange={onChangePriority}
										InputProps={{
											inputProps: {
												min: 0,
												max: 10
											}
										}}
									/>
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>PromoterPhone</FormHelperText>
									<TextField value={promoterPhone == null ? '' : promoterPhone} onChange={onChangePromoterPhone} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>promoterName</FormHelperText>
									<TextField value={promoterName == null ? '' : promoterName} onChange={onChangePromotionName} />
								</FormControl>
								<FormControlLabel
									control={
										<Checkbox
											checked={isActive}
											onChange={onChangeIsActive}
											name='checkedC'
											color='primary'
										/>
									}
									label='Active'
									className={classes.checkboxform}
									style={{ width: '30%' }}
								/>
							</Grid>
						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' onClick={handleUpdate} color='secondary'>
								{nButtonText}
							</Button>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleClose}>
								Cancel
							</Button>
						</div>
					</div>
				</Fade>
			</Modal>
			<div>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => addConversion()}
				>
					<span className='hidden sm:flex'>Add Conversion</span>
					<span className='flex sm:hidden'>Add</span>
				</Button>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => openSearchModel()}
				>

					<span className='hidden sm:flex'><SearchIcon />Filter</span>
					<span className='flex sm:hidden'><SearchIcon /></span>
				</Button>
			</div>
			<FuseScrollbars className="flex-grow overflow-x-auto">
				<Table stickyHeader className="min-w-xl" aria-labelledby="tableTitle">
					<HotelConversionTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={data.length}
					/>
					<TableBody>
						{_.orderBy(
							data,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className="h-64 cursor-pointer"
									hover
									tabIndex={-1}
									key={n.id}
								>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										<img alt='' style={{ height: '50px', width: '50px' }} src={n.imageUrl} />
									</TableCell>
									<TableCell className="p-4 md:p-16 truncate" component="th" scope="row" onClick={() => editConversion(i)}>
										{n.nameTranslations.en}
									</TableCell>
									<TableCell className="p-4 md:p-16 truncate" component="th" scope="row" onClick={() => editConversion(i)}>
										{n.nameTranslations.ru}
									</TableCell>
									<TableCell className="p-4 md:p-16 truncate" component="th" scope="row" onClick={() => editConversion(i)}>
										{n.nameTranslations.he}
									</TableCell>
									<TableCell className="p-4 md:p-16 truncate" component="th" scope="row" onClick={() => editConversion(i)}>
										{n.hotelChainName}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{n.hotelCamingoCode}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{n.hotelExternalCode}
									</TableCell>
									<TableCell className="p-4 md:p-16 truncate" component="th" scope="row" onClick={() => editConversion(i)}>
										{n.mainCityCode}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{n.secondCityCode}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{n.atlantisSupplierCode}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{suppliers[n.source || 0]}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{n.commission}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="center" onClick={() => editConversion(i)}>
										{n.discount == null ? null : n.discount + '%'}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{n.priority}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{n.promoterPhone}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{n.promoterMame}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left' onClick={() => editConversion(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.active && 'bg-red',
												n.active && 'bg-green',
											)}
										/>
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => editConversion(i)} tabIndex="0" type="button" title="Edit"><span className="MuiIconButton-label"><span className="material-icons MuiIcon-root" aria-hidden="true">edit</span></span><span className="MuiTouchRipple-root"></span></button>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component='th' scope='row' align='left'>
										<button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
											onClick={() => deleteConversion(i)}
											tabIndex='0' type='button' title='Edit'>
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className="flex-shrink-0 border-t-1"
				component="div"
				count={dealLength}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}

export default withRouter(HotelConversionTable);
