import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Tooltip from '@material-ui/core/Tooltip';
import React from 'react';

const rows = [
    
    {
        id: 'Hotel',
        align: 'left',
        disablePadding: false,
        label: 'Hotel Image',
        sort: false
    },
    {
        id: 'hotelNameEn',
        align: 'left',
        disablePadding: false,
        label: 'English Hotel Name',
        sort: true
    },
    {
        id: 'hotelNameRu',
        align: 'left',
        disablePadding: false,
        label: 'Russian Hotel Name',
        sort: true
    },
    {
        id: 'hotelNameHe',
        align: 'left',
        disablePadding: false,
        label: 'Hebrew Hotel Name',
        sort: true
    },
    {
        id: 'hotelChainName',
        align: 'left',
        disablePadding: false,
        label: 'Hotel Chain Name',
        sort: true
    },
    {
        id: 'hotelCamingoCode',
        align: 'left',
        disablePadding: false,
        label: 'Camingo Code',
        sort: true
    },
    {
        id: 'hotelExternalCode',
        align: 'left',
        disablePadding: false,
        label: 'External Code',
        sort: true
    },
    {
        id: 'mainCityCode',
        align: 'left',
        disablePadding: false,
        label: 'Main City',
        sort: true
    },
    {
        id: 'secondCityCode',
        align: 'left',
        disablePadding: false,
        label: 'Second City Code',
        sort: true
    },
    {
        id: 'atlantisSupplierCode',
        align: 'left',
        disablePadding: false,
        label: 'Atlantic Supplier Code',
        sort: true
    },
    {
        id: 'source',
        align: 'left',
        disablePadding: false,
        label: 'Supplier',
        sort: true
    },
    {
        id: 'commission',
        align: 'left',
        disablePadding: false,
        label: 'Commission',
        sort: true
    },
    {
        id: 'discount',
        align: 'left',
        disablePadding: false,
        label: 'Discount',
        sort: true
    },
    {
        id: 'priority',
        align: 'center',
        disablePadding: false,
        label: 'Priority',
        sort: true
    },
    {
        id: 'promoterPhone',
        align: 'left',
        disablePadding: false,
        label: 'Promoter Phone',
        sort: true
    },
    {
        id: 'promoterName',
        align: 'left',
        disablePadding: false,
        label: 'Promoter Name',
        sort: true
    },
    {
        id: 'active',
        align: 'left',
        disablePadding: false,
        label: 'Active',
        sort: true
    },
    {
        id: 'edit',
        align: 'center',
        disablePadding: false,
        label: 'Edit',
        sort: true
    },
    {
        id: 'delete',
        align: 'center',
        disablePadding: false,
        label: 'Delete',
        sort: true
    }
    
];

function ProductsTableHead(props) {

    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };

    return (
        <TableHead>
            <TableRow className="h-64">
                {rows.map(row => {
                    return (
                        <TableCell
                            className="p-4 md:p-16"
                            key={row.id}
                            align={row.align}
                            padding={row.disablePadding ? 'none' : 'default'}
                            sortDirection={props.order.id === row.id ? props.order.direction : false}
                        >
                            {row.sort && (
                                <Tooltip
                                    title="Sort"
                                    placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                    enterDelay={300}
                                >
                                    <TableSortLabel
                                        active={props.order.id === row.id}
                                        direction={props.order.direction}
                                        onClick={createSortHandler(row.id)}
                                    >
                                        {row.label}
                                    </TableSortLabel>
                                </Tooltip>
                            )}
                        </TableCell>
                    );
                }, this)}
            </TableRow>
        </TableHead>
    );
}

export default ProductsTableHead;
