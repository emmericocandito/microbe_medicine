import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Tooltip from '@material-ui/core/Tooltip';
import React from 'react';

const rows = [
  {
    id: 'code',
    translate: 'Code',
    align: 'left',
    disablePadding: false,
    label: 'Nation Code',
    sort: true
  },
  {
    id: 'name',
    translate: 'Name',
    align: 'left',
    disablePadding: false,
    label: 'Nation Name',
    sort: true
  },
  {
    id: 'nameInNationalLanguage',
    translate: 'Name In National Language',
    align: 'left',
    disablePadding: false,
    label: 'Name In National Language',
    sort: true
  },
  {
    id: 'edit',
    translate: 'edit',
    align: 'left',
    disablePadding: false,
    label: 'Edit',
    sort: false
  },
  {
    id: 'delete',
    translate: 'delete',
    align: 'left',
    disablePadding: false,
    label: 'Delete',
    sort: false
  }    
];

function BasisTableHead(props) {
  const createSortHandler = property => event => {
      props.onRequestSort(event, property);
  };
  return (
    <TableHead>
      <TableRow className="h-64">
        <TableCell padding="none" className="w-40 md:w-64 text-center z-99">
        </TableCell>
        {rows.map(row => {
          return (
            <TableCell
              className="p-4 md:p-16"
              key={row.id}
              align={row.align}
              padding={row.disablePadding ? 'none' : 'default'}
              sortDirection={props.order.id === row.id ? props.order.direction : false}
            >
              {row.sort ? (
                <Tooltip
                  title="Sort"
                  placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                  enterDelay={300}
                >
                  <TableSortLabel
                    active={props.order.id === row.id}
                    direction={props.order.direction}
                    onClick={createSortHandler(row.id)}
                  >
                    {row.label}
                  </TableSortLabel>
                </Tooltip>
              ) : row.label}
            </TableCell>
          );
        }, this)}
      </TableRow>
    </TableHead>
  );
}

export default BasisTableHead;
