import React, { useState } from 'react';
import { withRouter } from 'react-router-dom';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import Button from '@material-ui/core/Button';
import FormControl from '@material-ui/core/FormControl';
import FormHelperText from '@material-ui/core/FormHelperText';
import TextField from '@material-ui/core/TextField';
import IconButton from '@material-ui/core/IconButton';
import DeleteIcon from '@material-ui/icons/DeleteOutline';
import AddIcon from '@material-ui/icons/AddRounded';

function AddImageLink(props) {
  
	const useStyles = makeStyles((theme) => ({
		modal1: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
			margin: 'auto',
			minWidth: 200,
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 2, 3),
			textAlign: "center",
			maxHeight: '600px',
			maxWidth: '800px',
			overflow: 'auto'
		},
		button_group: {
			padding: 25,
			textAlign: 'center',
		},
		buttons: {
			marginLeft: '10px'
		},
	}));
	const classes = useStyles();

	const [addImageLinkModalOpen, setAddImageLinkModalOpen] = useState(false);
	const [multipleLinks, setMultipleLinks] = useState(['']);

	const openAddImageLinkModal = () => {
		setAddImageLinkModalOpen(true);
	}
	const handleCloseImageLinkModal = () => {
		setMultipleLinks(['']);
		setAddImageLinkModalOpen(false)
	}
	const onChangeImageLink = (event, inx) => {
		const link = event.target.value;
		const arr = [...multipleLinks];
		arr[inx] = link;

		setMultipleLinks(arr);
	}
	const deleteMultipleLink = (inx) => {
		const arr = [...multipleLinks];
		arr.splice(inx, 1);
		setMultipleLinks(arr);
	}
	const addMultipleLink = () => {
		const arr = [...multipleLinks];
		arr.push('');
		setMultipleLinks(arr);
	}
	const addImageLink = () => {
    props.setPictureLink(multipleLinks);
		setMultipleLinks(['']);
		handleCloseImageLinkModal();
	}

  return (
		<div>
			<Modal
				open={addImageLinkModalOpen}
				onClose={handleCloseImageLinkModal}
				className={classes.modal1}
				aria-labelledby="simple-modal-title"
				aria-describedby="simple-modal-description"
			>
				<div className={classes.paper}>
					<h2 id="server-modal-title" >Add {props.addingImageType} Image Link From External URL</h2>
					<div style={{ display: 'grid' }}>
						<FormControl required>
							<FormHelperText>External Image Link</FormHelperText>
							{multipleLinks ? multipleLinks.map((k, i) =>
								<div style={{ display: 'flex' }} key={i}>
									<TextField className={classes.textfield} onChange={event => onChangeImageLink(event, i)} defaultValue={k} style={{width: '90%'}}/>
									<IconButton onClick={(e) => deleteMultipleLink(i)}><DeleteIcon /></IconButton>
								</div>
							): null}
							<div style={{ width: '100%', margin: 'auto'}}>
								<IconButton onClick={(e)=>addMultipleLink()} style={{width: '48px'}}><AddIcon/></IconButton>
							</div>
							
						</FormControl>
					</div>
					<div className={classes.button_group}>
						<Button className={classes.buttons} variant='contained' color='secondary' onClick={addImageLink}>
							Add
						</Button>
						<Button className={classes.buttons} variant='contained' color='primary' onClick={handleCloseImageLinkModal}>
							Cancel
						</Button>
					</div>
				</div>
			</Modal>
      
      <Button className={classes.buttons} variant='contained' onClick={(e) => openAddImageLinkModal()} disabled={props.disabled}>
        Add {props.addingImageType} Image Link
      </Button>
    </div>

  );
}

export default withRouter(AddImageLink);