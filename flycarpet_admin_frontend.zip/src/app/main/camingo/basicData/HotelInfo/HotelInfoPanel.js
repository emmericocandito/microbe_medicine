import FuseScrollbars from '@fuse/core/FuseScrollbars';
import axios from 'axios';
import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import { makeStyles } from '@material-ui/core/styles';
import {
	Modal, Backdrop, Fade, Button, FormControl, Select, FormHelperText, TablePagination, CircularProgress,
	Card, CardActions, Collapse, Chip, IconButton, TextField, TextareaAutosize
} from '@material-ui/core';
import SearchIcon from '@material-ui/icons/Search';
import PlusOne from '@material-ui/icons/AddRounded';
import FuseLoading from '@fuse/core/FuseLoading';
import { ReactNotifications } from 'react-notifications-component';
import 'react-notifications-component/dist/theme.css';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import ShowMoreText from 'react-show-more-text';
import ReactHtmlParser from 'react-html-parser';
import { Carousel } from 'react-responsive-carousel';
import "react-responsive-carousel/lib/styles/carousel.css";
import EditIcon from '@material-ui/icons/Edit';
import DeleteIcon from '@material-ui/icons/DeleteOutline';
import ImageUploader from "react-images-upload";
import DoneIcon from '@material-ui/icons/Done';
import jwt from 'jwt-decode';

import AddImageMultipleLink from './AddImageMultipleLink';
import { baseURL } from './../../../utils';

function HotelInfoPanel(props) {
	const useStyles = makeStyles((theme) => ({
		root: {
			maxWidth: '100%',
			margin: '20px 10px',
			boxShadow: '0 0px 4px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
		},
		formControl: {
			margin: theme.spacing(0),
			// minWidth: 60,
			width: '100%',
			margin: '0px 10px'
		},
		formControl1: {
			margin: theme.spacing(0),
			width: '100%',
			border: '1px solid #d8d8d8',
			margin: '10px',
			borderRadius: '5px'
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
			margin: 'auto',
		},
		modal1: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
			margin: 'auto',
			minWidth: 200,
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 2, 3),
			textAlign: "center",
			maxHeight: '600px',
			maxWidth: '800px',
			overflow: 'auto'
		},
		avatar: {
			width: 72,
			height: 72,
			padding: 8,
			marginLeft: '20px',
			background: theme.palette.background.default,
			boxSizing: 'content-box',
			'& > img': {
				borderRadius: '50%'
			}
		},
		actionExtend: {
			alignItems: 'flex-start',
		},
		expandOpen: {
			transform: 'rotate(180deg)',
		},
		chipStyle: {
			margin: '5px',
			color: '#6f6e6e',
			fontSize: '10px',
			height: '25px',
			'&:hover': {
				backgroundColor: 'green !important',
				color: 'white !important'
			},
			'&:active': {
				backgroundColor: 'green !important',
				color: 'white !important'
			},
			'&:focus': {
				backgroundColor: 'green !important',
				color: 'white !important'
			},
		},
		button_group: {
			padding: 25,
			textAlign: 'center',
		},
		buttons: {
			marginLeft: '10px'
		},
		ntextArea: {
			width: '100%',
			border: '1px solid gray',
			minHeight: '35px !important',
			'&:hover': {
				outlineColor: '#000000cf',
				borderRadius: '0'
			},
			'&:active': {
				outlineColor: '#000000cf',
				borderRadius: '0'
			},
			'&:focus': {
				outlineColor: '#000000cf !important',
				borderRadius: '0'
			},
		},
		deleteImage: {
			position: 'absolute',
			top: '1px',
			right: '7px',
			color: '#fff',
			background: '#ff4081',
			borderRadius: '50%',
			textAign: 'center',
			cursor: 'pointer',
			fontSize: '17px',
			fontWeight: 'bold',
			lineHeight: '20px',
			width: '20px',
			height: '20px'
		},
		border_style: {
			border: '1px solid #d8d8d8',
			margin: '10px',
			borderRadius: '5px'
		},
		add_but: {
			padding: '6px 23px',
			background: '#3f4257',
			borderRadius: '30px',
			color: 'white',
			fontWeight: '300',
			fontSize: '12px',
			margin: '10px auto',
			transition: 'all 0.2s ease-in',
			cursor: 'pointer',
			outline: 'none',
			width: '180px',
			border: 'none',
			'&:hover': {
				background: '#545972',
			},

		}
	}));

	const token = window.localStorage.getItem('jwt_access_token');
	const userRole = token === null ? '' : jwt(token).role;
	const [filterOpen, setFilterOpen] = useState(false);
	const [page, setPage] = React.useState(0);
	const [rowsPerPage, setRowsPerPage] = React.useState(10);
	const [hotelInfoData, setHotelInfoData] = useState([]);
	const [dataLength, setDataLength] = useState(0);

	const [loading, setLoading] = useState(true);
	const classes = useStyles();
	const [loadingCircle, setLoadingCircle] = useState(false);

	const [actionState, setActionState] = useState(null);

	const [nButtonText, setButtonText] = useState(null);
	const [nButtonText1, setButtonText1] = useState(null);
	const [nButtonText2, setButtonText2] = useState(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [confirmText, setConfirmText] = useState(null);
	const [warningOpen, setWarningOpen] = useState(false);
	const [warningText, setWarningText] = useState(null);

	const [missingHotelList, setMissingHotelList] = useState([]);
	const [addedHotelList, setAddedHotelList] = useState([]);

	const [facilityList, setFacilityList] = useState([]);
	const [roomClassList, setRoomClassList] = useState([]);

	const [openEdit, setModalOpen] = useState(false);
	const [expanded, setExpanded] = useState(null);
	const [index, setIndex] = useState();

	const [hotel, setHotel] = useState(null);
	const [roomClasses, setRoomClasses] = useState([]);
	const [facilities, setFacilities] = useState([]);
	const [hotelInfoID, setHotelInfoID] = useState(null);
	const [descriptionEn, setDescriptionEn] = useState(null);
	const [descriptionRu, setDescriptionRu] = useState(null);
	const [descriptionHe, setDescriptionHe] = useState(null);

	const [mainImageUrls, setMainImageUrls] = useState(null);
	const [galleryImageUrls, setGalleryImageUrls] = useState(null);
	const [mainImage, setMainImage] = useState(null);
	const [galleryImage, setGalleryImage] = useState(null);

	const [existRoomClassImage, setExistRoomClassImage] = useState(null);
	const [roomClassImage, setRoomClassImage] = useState(null);

	const [roomId, setRoomID] = useState(null);
	const [roomDes, setRoomDes] = useState(null);
	const [roomName, setRoomName] = useState(null);
	const [roomClassModalOpen, setRoomClassModalOpen] = useState(false);

	const [facilityCode, setFacilityCode] = useState(null);
	const [facilityName, setFacilityName] = useState(null);
	const [facilityModalOpen, setFacilityModalOpen] = useState(false);

	const [nFilterHotelID, setFilterHotelID] = useState(null);
	const [nFilterHotelDescription, setFilterHotelDescription] = useState(null);
	const [nFIlterRoomClassID, setFilterRoomClassID] = useState(null);
	const [nFilterRoomClassName, setFilterRoomClassName] = useState(null);
	const [nFilterRoomClassDes, setFilterRoomClassDes] = useState(null);
	const [nFilterFacilityCode, setFilterFacilityCode] = useState(null);
	const [nFilterFacilityName, setFilterFacilityName] = useState(null);
	const [nFilterImageURL, setFilterImageURL] = useState(null);
	const [nFilterGalleryURL, setFilterGalleryURL] = useState(null);
	const [nFilterRoomImageURL, setFilterRoomImageURL] = useState(null);
	const [nFilterMissingCode, setFilterMissingCode] = useState(null);

	useEffect(() => {
		reopen(1, 10, '', '', '');
		getMissingHotelList('missing');
		getMissingHotelList('added');
	}, [])
	async function getMissingHotelList(kind) {
		// kind === all, missing, added.
		await axios({
			method: 'post',
			url: `${baseURL}camingo/api/hotelConversion/search?from=1&to=1000`,
			headers: {
				'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			},
			data: {
				"missingHotelInfo": kind === 'added' ? false : kind === 'missing' ? true : null,
			}
		}).then(response => {
			const data = response.data['data'].sort((a, b) => { return (a.hotelName < b.hotelName) ? -1 : 1 });
			if (kind === 'missing') {
				setMissingHotelList(data);
			} else {
				setAddedHotelList(data);
			}
		})
			.catch(error => {
				console.log(error)
				return;
			});
	}

	async function getRoomClassList() {
		await axios({
			method: 'get',
			url: `${baseURL}camingo/api/hotelInfo/roomClassName`,
			headers: {
				'Access-Control-Allow-Origin': '*',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		}).then(response => {
			const data = response.data;
			setRoomClassList(data);
		})
			.catch(error => {
				console.log(error)
				return;
			});
	}
	async function getFacilityList() {
		await axios({
			method: 'get',
			url: `${baseURL}camingo/api/hotelInfo/facility`,
			headers: {
				'Access-Control-Allow-Origin': '*',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		}).then(response => {
			const data = response.data;
			setFacilityList(data);
		})
			.catch(error => {
				console.log(error)
				return;
			});
	}

	const handleClose = () => {
		setFilterOpen(false);
	};

	function handleChangePage(event, newPage) {
		setPage(newPage);
		const from = newPage * rowsPerPage + 1;
		const to = newPage * rowsPerPage + rowsPerPage
		reopen(from, to);
	}

	function handleChangeRowsPerPage(event) {
		setPage(0);
		setRowsPerPage(event.target.value);
		reopen(1, event.target.value);
	}

	async function reopen(from, to) {
		const temp = (nFilterMissingCode == '' || nFilterMissingCode == null) ? null : nFilterMissingCode == "true";
		await axios({
			method: 'post',
			url: `${baseURL}camingo/api/hotelInfo/search?from=${from}&to=${to}`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"hotelId": nFilterHotelID,
				"hotelDescription": nFilterHotelDescription,
				"roomClassId": nFIlterRoomClassID,
				"roomClassName": nFilterRoomClassName,
				"roomClassDescription": nFilterRoomClassDes,
				"facilityCode": nFilterFacilityCode,
				"facilityName": nFilterFacilityName,
				"mainImageUrl": nFilterImageURL,
				"galleryImageUrl": nFilterGalleryURL,
				"roomImageUrl": nFilterRoomImageURL,
				"missingCode": temp
			}
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			} else {
				const data = response.data;
				setDataLength(data.total);
				setHotelInfoData(data.data);
			}
		}).catch(error => {
			console.log(error);
		});
		await getFacilityList();
		await getRoomClassList();
		setLoading(false);
	}

	const openSearchModel = () => {
		setFilterOpen(true);
	};

	const handleSetMainPictureUrl = (links) => {
		const arr = mainImageUrls ? [...mainImageUrls] : [];
		links.forEach((item) => {
			arr.push(item);
		})
		setMainImageUrls(arr);
	}
	const handleSetGalleryPictureUrl = (links) => {
		const arr = galleryImageUrls ? [...galleryImageUrls] : [];
		links.forEach((item) => {
			arr.push(item);
		})
		setGalleryImageUrls(arr);
	}
	const handleSetRoomClassPictureUrl = (links) => {
		const arr = existRoomClassImage ? [...existRoomClassImage] : [];
		links.forEach((item) => {
			arr.push(item);
		})
		setExistRoomClassImage(arr)
	}
	function searchPackageFromApi() {
		setLoading(true);
		const from = 0 * rowsPerPage + 1;
		const to = 0 * rowsPerPage + rowsPerPage;
		reopen(from, to);
		setFilterOpen(false);
	}
	//////////////////////////////////////////////////////////
	async function editProcess() {
		setLoading(true);
		var requestURL = '';
		if (actionState == 'Add') {
			requestURL = `${baseURL}camingo/api/hotelInfo`;
		} else {
			requestURL = `${baseURL}camingo/api/hotelInfo/${hotelInfoID}`;
		}
		let data = new FormData();
		data.append('hotelId', hotel);
		if (descriptionEn != null) {
			data.append('hotelDescTrans.en', descriptionEn);
		}
		if (descriptionRu != null) {
			data.append('hotelDescTrans.ru', descriptionRu);
		}
		if (descriptionHe != null) {
			data.append('hotelDescTrans.he', descriptionHe);
		}
		for (var i = 0; i < roomClasses.length; i++) {
			if (roomClasses[i].id != null) {
				data.append('roomClasses[' + i + '].id', roomClasses[i].id);
			}
			if (roomClasses[i].name != null) {
				data.append('roomClasses[' + i + '].name', roomClasses[i].name);
			}
			if (roomClasses[i].description != null) {
				data.append('roomClasses[' + i + '].description', roomClasses[i].description);
			}
			if (roomClasses[i].imageUrls != null) {
				roomClasses[i].imageUrls.forEach(file => {
					data.append('roomClasses[' + i + '].imageUrls', file);
				});
			}
			if (roomClasses[i].imageFiles != null) {
				roomClasses[i].imageFiles.forEach(file => {
					data.append('roomClasses[' + i + '].imageFiles', file);
				});
			}
		}
		for (var i = 0; i < facilities.length; i++) {
			if (facilities[i].code != null) {
				data.append('facilities[' + i + '].code', facilities[i].code);
			}
			if (facilities[i].name != null) {
				data.append('facilities[' + i + '].name', facilities[i].name);
			}
		}
		if (mainImage != null) {
			mainImage.forEach(file => {
				data.append('MainImageFiles', file);
			});
		}
		if (galleryImage != null) {
			galleryImage.forEach(file => {
				data.append('GalleryImageFiles', file);
			});
		}
		if (mainImageUrls != null) {
			mainImageUrls.forEach(file => {
				data.append('MainImageUrls', file);
			});
		}
		if (galleryImageUrls != null) {
			galleryImageUrls.forEach(file => {
				data.append('GalleryImageUrls', file);
			});
		}
		await axios({
			method: 'post',
			url: requestURL,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: data
		}).then(response => {
			setLoading(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
				setModalOpen(false);
				initialValue()
			}

		}).catch(error => {
			setLoading(false);
			setWarningOpen(true);
			setWarningText(error.response.data);
			setModalOpen(false);
			initialValue()
		});
	}

	const handleExpandClick = (i) => {
		if (index == i) {
			setExpanded(!expanded);
		}
		else {
			setExpanded(true);
		}
		setIndex(i);

	};
	const handleCloseModal = () => {
		setModalOpen(false);
	}
	const handleCloseWarning = () => {
		setWarningOpen(false);
	}
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}
	const handleCloseRoomClassModal = () => {
		setRoomClassModalOpen(false)
	}
	const handleCloseFacilitiesModal = () => {
		setFacilityModalOpen(false)
	}
	const openEditRoomClassModal = (i) => {
		setIndex(i);
		setRoomID(roomClasses[i].id)
		setRoomDes(roomClasses[i].description);
		setRoomName(roomClasses[i].name);
		setExistRoomClassImage(roomClasses[i].imageUrls);
		setButtonText1('Edit');
		setRoomClassModalOpen(true);
	}
	const openEditFacilitiesModal = (i) => {
		setIndex(i);
		setFacilityCode(facilities[i].code)
		setFacilityName(facilities[i].name);
		setButtonText2('Edit');
		setFacilityModalOpen(true);
	}
	const openDetail = (index) => {
		setActionState('Edit');
		setButtonText('Edit');
		setRoomClasses(hotelInfoData[index].roomClasses || []);
		setFacilities(hotelInfoData[index].facilities || []);
		setMainImageUrls(hotelInfoData[index].mainImageUrls || []);
		setGalleryImageUrls(hotelInfoData[index].galleryImageUrls || []);
		setDescriptionEn(hotelInfoData[index].hotelDescTrans?.en || null);
		setDescriptionHe(hotelInfoData[index].hotelDescTrans?.he || null);
		setDescriptionRu(hotelInfoData[index].hotelDescTrans?.ru || null);
		setHotelInfoID(hotelInfoData[index].id);
		setHotel(hotelInfoData[index].hotelId);
		setModalOpen(true);
	}
	const openAdd = () => {
		setActionState('Add');
		setButtonText('Add')
		initialValue()
		setModalOpen(true);
	}
	function initialValue() {
		setRoomClasses([]);
		setFacilities([]);
		setMainImageUrls(null);
		setMainImage(null);
		setGalleryImage(null);
		setGalleryImageUrls(null);
		setDescriptionEn(null);
		setDescriptionHe(null);
		setDescriptionRu(null);
		setHotelInfoID(null);
		setHotel(null);
		setRoomClassImage(null);
		setExistRoomClassImage(null);
	}
	async function confirmProcess() {
		setLoading(true);
		await axios.delete(`${baseURL}camingo/api/hotelInfo/${hotelInfoID}`, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		}).then(response => {
			setLoading(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningText(response.data.error.message);
				setWarningOpen(true);
			} else {
				reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}
			initialValue();
			setConfirmOpen(false);
		}).catch(error => {
			setLoading(false);
			setConfirmOpen(false);
			setWarningOpen(true);
			setWarningText(error.response.data);
		});
	}
	function executeOnClick(isExpanded) {
	}
	///////////////////////////////////////////////////////////////////////////////////////////
	// const handleChangeDestination = (event) => {
	//     var temp = event.target.value;
	//     if (temp == '') {
	//         temp = null
	//     }
	//     setDestination(temp);
	//     setHotel(null)
	//     getMissingHotelList(temp)
	// };

	const handleChangeHotel = (event) => {
		setHotel(event.target.value)
	};
	function deleteRoomClass(index) {
		setRoomClasses(roomClasses.filter((e, n) => n !== index));
	}
	function deleteFacilites(index) {
		setFacilities(facilities.filter((e, n) => n !== index));
	}
	function deleteHotelInfo(index) {
		setHotelInfoID(hotelInfoData[index]['id'])
		setConfirmText("Do you want to drop this HotelInfo?");
		setConfirmOpen(true);
	}
	function openAddRoomClassModal() {
		setRoomID(null);
		setRoomDes(null);
		setRoomName(null);
		setExistRoomClassImage(null);
		setRoomClassImage(null);
		setButtonText1('Add');
		setRoomClassModalOpen(true);
	}
	function openAddFacilitiesModal() {
		setFacilityCode(null);
		setFacilityName(null);
		setButtonText2('Add');
		setFacilityModalOpen(true);
	}
	const onImageDrop = (picture) => {
		setRoomClassImage(picture)
	};
	const onMainImageDrop = (picture) => {
		setMainImage(picture)
	};
	const onGalleryImageDrop = (picture) => {
		setGalleryImage(picture)
	};
	function deleteMainImage(index) {
		setMainImage(mainImage.filter((e, n) => n !== index));
	}
	function deleteGalleryImage(index) {
		setGalleryImage(galleryImage.filter((e, n) => n !== index));
	}
	function deleteExistingMainImage(index) {
		setMainImageUrls(mainImageUrls.filter((e, n) => n !== index));
	}
	function deleteExistingGalleryImage(index) {
		setGalleryImageUrls(galleryImageUrls.filter((e, n) => n !== index));
	}
	function deleteExistingImage(index) {
		setExistRoomClassImage(existRoomClassImage.filter((e, n) => n !== index));
	}
	function deleteImage(index) {
		setRoomClassImage(roomClassImage.filter((e, n) => n !== index));
	}
	function updateRoomClass() {
		if (nButtonText1 == 'Add') {
			const obj = { 'id': roomId, 'name': roomName, 'description': roomDes, 'imageUrls': existRoomClassImage || null, 'imageFiles': roomClassImage };
			let myArr = [...roomClasses]
			myArr.push(obj)
			setRoomClasses(myArr)
		}
		else {
			roomClasses[index].description = roomDes;
			roomClasses[index].name = roomName;
			roomClasses[index].imageUrls = existRoomClassImage;
			roomClasses[index].imageFiles = roomClassImage;
			var temp = roomClasses
			setRoomClasses(temp);
		}

		setRoomClassModalOpen(false);
	}
	function updateFacilites() {
		if (nButtonText2 == 'Add') {
			const obj = { 'code': facilityCode, 'name': facilityName };
			let myArr = [...facilities]
			myArr.push(obj)
			setFacilities(myArr)
		}
		else {
			facilities[index].code = facilityCode;
			facilities[index].name = facilityName;
			var temp = facilities
			setFacilities(temp);
		}

		setFacilityModalOpen(false);
	}
	function onChangeRoomID(e) {
		if (e.target.value == '') {
			setRoomID(null);
		}
		else {
			setRoomID(Number(e.target.value));
		}
	}
	function onChangeRoomDes(e) {
		if (e.target.value == '') {
			setRoomDes(null);
		}
		else {
			setRoomDes(e.target.value);
		}
	}
	function onChangeRoomName(e) {
		if (e.target.value == '') {
			setRoomName(null);
		}
		else {
			setRoomName(e.target.value);
		}
	}
	function onChangeFacilityCode(e) {
		if (e.target.value == '') {
			setFacilityCode(null);
		}
		else {
			setFacilityCode(e.target.value);
		}
	}
	function onChangeFacilityName(e) {
		if (e.target.value == '') {
			setFacilityName(null);
		}
		else {
			setFacilityName(e.target.value);
		}
	}
	function onChangeDescriptionEn(e) {
		setDescriptionEn(e.target.value || null);
	}
	function onChangeDescriptionHe(e) {
		setDescriptionHe(e.target.value || null);
	}
	function onChangeDescriptionRu(e) {
		setDescriptionRu(e.target.value || null);
	}
	////////////////////////////////
	function onChangeFilterHotelID(e) {
		if (e.target.value == '') {
			setFilterHotelID(null);
		}
		else {
			setFilterHotelID(e.target.value);
		}
	}
	function onChangeFilterRoomClassID(e) {
		if (e.target.value == '') {
			setFilterRoomClassID(null);
		}
		else {
			setFilterRoomClassID(Number(e.target.value));
		}
	}
	function onChangeFilterRoomClassDes(e) {
		if (e.target.value == '') {
			setFilterRoomClassDes(null);
		}
		else {
			setFilterRoomClassDes(e.target.value);
		}
	}
	function onChangeFilterRoomClassName(e) {
		if (e.target.value == '') {
			setFilterRoomClassName(null);
		}
		else {
			setFilterRoomClassName(e.target.value);
		}
	}
	function onChangeFilterFacilityCode(e) {
		if (e.target.value == '') {
			setFilterFacilityCode(null);
		}
		else {
			setFilterFacilityCode(e.target.value);
		}
	}
	function onChangeFilterFacilityName(e) {
		if (e.target.value == '') {
			setFilterFacilityName(null);
		}
		else {
			setFilterFacilityName(e.target.value);
		}
	}
	function onChangeFilterHotelDescription(e) {
		if (e.target.value == '') {
			setFilterHotelDescription(null);
		}
		else {
			setFilterHotelDescription(e.target.value);
		}
	}
	function onChangeFilterImageURL(e) {
		if (e.target.value == '') {
			setFilterImageURL(null);
		}
		else {
			setFilterImageURL(e.target.value);
		}
	}
	function onChangeFilterGallery(e) {
		if (e.target.value == '') {
			setFilterGalleryURL(null);
		}
		else {
			setFilterGalleryURL(e.target.value);
		}
	}
	function onChangeFilterRoomImage(e) {
		if (e.target.value == '') {
			setFilterRoomImageURL(null);
		}
		else {
			setFilterRoomImageURL(e.target.value);
		}
	}
	function onChangeFilterMissingCode(e) {
		setFilterMissingCode(e.target.value);
	}

	//////////////////////////


	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className='w-full flex flex-col'>
			<Modal
				open={confirmOpen}
				onClose={handleCloseConfirm}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Confirm</h2>
					<p id='server-modal-description'>{confirmText}</p>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={confirmProcess}>Confirm
					</Button>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={handleCloseConfirm}>Cancel
					</Button>
				</div>
			</Modal>
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={filterOpen}
				onClose={handleClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={filterOpen}>
					<div className={classes.paper}>
						<div className={classes.fo_circular}>
							{loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
						</div>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title' >Filter Setting</h2>
						</div>
						<div style={{ display: 'grid' }}>
							<div style={{ display: 'flex' }}>
								<FormControl required className={classes.formControl}>
									<FormHelperText>Hotel</FormHelperText>
									<Select
										native
										value={nFilterHotelID || ''}
										onChange={onChangeFilterHotelID}
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option aria-label='None' value='' />
										{addedHotelList.map((n, i) => (
											<option key={i} value={n.id}>
												{`${n.nameTranslations.en || n.hotelName} - ${n.destinationName}`}
											</option>
										))}
									</Select>
								</FormControl>
							</div>
							<FormControl required style={{ width: '95%', margin: 'auto' }}>
								<FormHelperText>Hotel Description</FormHelperText>
								<TextareaAutosize
									rowsMax={3}
									aria-label="maximum height"
									placeholder=".........."
									onChange={onChangeFilterHotelDescription}
									className={classes.ntextArea}
									defaultValue={nFilterHotelDescription == null ? '' : nFilterHotelDescription}
								/>
							</FormControl>

							{(userRole === 'agency') ? null :
								<div style={{ display: 'flex' }}>
									<FormControl required className={classes.formControl} style={{ width: '45%' }}>
										<FormHelperText>RoomClassID</FormHelperText>
										<TextField className={classes.textfield} defaultValue={nFIlterRoomClassID == null ? '' : nFIlterRoomClassID} onChange={onChangeFilterRoomClassID} />
									</FormControl>
									<FormControl required className={classes.formControl} style={{ width: '45%' }}>
										<FormHelperText>RoomClassName</FormHelperText>
										<TextField className={classes.textfield} defaultValue={nFilterRoomClassName == null ? '' : nFilterRoomClassName} onChange={onChangeFilterRoomClassName} />
									</FormControl>
								</div>
							}
							{(userRole === 'agency') ? null :
								<FormControl required style={{ width: '95%', margin: 'auto' }}>
									<FormHelperText>RoomClass Description</FormHelperText>
									<TextareaAutosize
										rowsMax={3}
										aria-label="maximum height"
										placeholder=".........."
										onChange={onChangeFilterRoomClassDes}
										className={classes.ntextArea}
										defaultValue={nFilterRoomClassDes == null ? '' : nFilterRoomClassDes}
									/>
								</FormControl>
							}

							{(userRole === 'agency') ? null :
								<div style={{ display: 'flex' }}>
									<FormControl required className={classes.formControl}>
										<FormHelperText>FacilityCode</FormHelperText>
										<TextField className={classes.textfield} defaultValue={nFilterFacilityCode == null ? '' : nFilterFacilityCode} onChange={onChangeFilterFacilityCode} />
									</FormControl>
									<FormControl required className={classes.formControl}>
										<FormHelperText>FacilityName</FormHelperText>
										<TextField className={classes.textfield} defaultValue={nFilterFacilityName == null ? '' : nFilterFacilityName} onChange={onChangeFilterFacilityName} />
									</FormControl>
								</div>
							}
							<FormControl required className={classes.formControl}>
								<FormHelperText>MainImageURL</FormHelperText>
								<TextField className={classes.textfield} defaultValue={nFilterImageURL == null ? '' : nFilterImageURL} onChange={onChangeFilterImageURL} />
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>GalleryImageURL</FormHelperText>
								<TextField className={classes.textfield} defaultValue={nFilterGalleryURL == null ? '' : nFilterGalleryURL} onChange={onChangeFilterGallery} />
							</FormControl>
							{(userRole === 'agency') ? null :
								<FormControl required className={classes.formControl}>
									<FormHelperText>RoomImageURL</FormHelperText>
									<TextField className={classes.textfield} defaultValue={nFilterRoomImageURL == null ? '' : nFilterRoomImageURL} onChange={onChangeFilterRoomImage} />
								</FormControl>
							}
							<FormControl required className={classes.formControl} style={{ width: '30%' }}>
								<FormHelperText>MissingHotelCode</FormHelperText>
								<Select
									native
									onChange={onChangeFilterMissingCode}
									value={nFilterMissingCode || ''}
									inputProps={{
										id: 'age-native-required',
									}}
								>
									<option aria-label='None' value=''>All</option>
									<option value='true'>True</option>
									<option value='false'>False</option>
								</Select>
							</FormControl>
						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' color='secondary' onClick={searchPackageFromApi}>
								Filter
							</Button>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleClose}>
								Cancel
							</Button>

						</div>
					</div>

				</Fade>
			</Modal>
			<div>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '10px' }}
					onClick={() => openAdd()}
				>
					<span className='hidden sm:flex'><PlusOne />Add HotelInfo</span>
					<span className='flex sm:hidden'><PlusOne /></span>
				</Button>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '10px 5px' }}
					onClick={() => openSearchModel()}
				>
					<span className='hidden sm:flex'><SearchIcon />Filter</span>
					<span className='flex sm:hidden'><SearchIcon /></span>
				</Button>

			</div>
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={openEdit}
				onClose={handleCloseModal}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={openEdit}>
					<div className={classes.paper}>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title' >Hotel Information {nButtonText}</h2>
						</div>
						<div style={{ display: 'flex' }}>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Hotel</FormHelperText>
								<Select
									native
									value={hotel || ''}
									onChange={handleChangeHotel}
									inputProps={{
										id: 'age-native-required',
									}}
								>
									<option aria-label='None' value='' />
									{missingHotelList.map((n, i) => (
										<option key={i} value={n.id}>
											{`${n.nameTranslations.en || n.hotelName} - ${n.destinationName}`}
										</option>
									))}
								</Select>
							</FormControl>
						</div>
						<FormControl required style={{ width: '97%' }}>
							<FormHelperText>Hebrew Hotel Description</FormHelperText>
							<TextareaAutosize
								rowsMax={3}
								aria-label="maximum height"
								placeholder=".........."
								onChange={onChangeDescriptionHe}
								className={classes.ntextArea}
								defaultValue={descriptionHe == null ? '' : descriptionHe}
							/>
						</FormControl>
						<FormControl required style={{ width: '97%' }}>
							<FormHelperText>English Hotel Description</FormHelperText>
							<TextareaAutosize
								rowsMax={3}
								aria-label="maximum height"
								placeholder=".........."
								onChange={onChangeDescriptionEn}
								className={classes.ntextArea}
								defaultValue={descriptionEn == null ? '' : descriptionEn}
							/>
						</FormControl>
						<FormControl required style={{ width: '97%' }}>
							<FormHelperText>Russian Hotel Description</FormHelperText>
							<TextareaAutosize
								rowsMax={3}
								aria-label="maximum height"
								placeholder=".........."
								onChange={onChangeDescriptionRu}
								className={classes.ntextArea}
								defaultValue={descriptionRu == null ? '' : descriptionRu}
							/>
						</FormControl>
						<div>
							<div className={classes.border_style}>
								<div style={{ display: 'flex', width: '500px', flexWrap: 'wrap', overflow: 'auto' }}>
									{mainImageUrls == null ? "" : mainImageUrls.map((k, i) =>
										<div style={{ position: 'relative' }} key={i}>
											<button className={classes.deleteImage} onClick={(e) => deleteExistingMainImage(i)}>X</button>
											<img alt='' style={{ width: '80px', height: '50px', margin: '10px' }} src={k} />
										</div>
									)}
									{mainImage == null ? "" : mainImage.map((n, j) =>
										<div style={{ position: 'relative' }} key={j}>
											<button className={classes.deleteImage} onClick={(e) => deleteMainImage(j)}>X</button>
											<img alt='' style={{ width: '80px', height: '50px', margin: '10px' }} src={URL.createObjectURL(n)} />
										</div>
									)}
								</div>
								<ImageUploader
									className={classes.imageUploader}
									withIcon={false}
									buttonStyles={{ fontSize: '12px' }}
									fileContainerStyle={{ padding: '0px', boxShadow: 'none' }}
									buttonText="Add MainImage"
									withLabel={false}
									withPreview={false}
									onChange={onMainImageDrop}
									imgExtension={[".jpg", ".gif", ".png", ".gif", ".jpeg", ".jfif"]}
									maxFileSize={524288000}
								/>
								<AddImageMultipleLink addingImageType={'Main'} setPictureLink={handleSetMainPictureUrl} />
							</div>
							<div className={classes.border_style}>
								<div style={{ display: 'flex', width: '500px', flexWrap: 'wrap', overflow: 'auto' }}>
									{galleryImageUrls == null ? "" : galleryImageUrls.map((k, i) =>
										<div style={{ position: 'relative' }} key={i}>
											<button className={classes.deleteImage} onClick={(e) => deleteExistingGalleryImage(i)}>X</button>
											<img alt='' style={{ width: '80px', height: '50px', margin: '10px' }} src={k} />
										</div>
									)}
									{galleryImage == null ? "" : galleryImage.map((n, j) =>
										<div style={{ position: 'relative' }} key={j}>
											<button className={classes.deleteImage} onClick={(e) => deleteGalleryImage(j)}>X</button>
											<img alt='' style={{ width: '80px', height: '50px', margin: '10px' }} src={URL.createObjectURL(n)} />
										</div>
									)}
								</div>
								<ImageUploader
									className={classes.imageUploader}
									withIcon={false}
									buttonStyles={{ fontSize: '12px' }}
									fileContainerStyle={{ padding: '0px', boxShadow: 'none' }}
									buttonText="Add Gallery Images"
									withLabel={false}
									withPreview={false}
									onChange={onGalleryImageDrop}
									imgExtension={[".jpg", ".gif", ".png", ".gif", ".jpeg", ".jfif"]}
									maxFileSize={524288000}
								/>
								<AddImageMultipleLink addingImageType={'Gallery'} setPictureLink={handleSetGalleryPictureUrl} />
							</div>
						</div>
						{(userRole === 'agency') ? null :
							<FormControl required className={classes.formControl1}>
								<div style={{ display: 'flex', margin: '10px 0px', flexWrap: 'wrap' }}>
									{roomClasses.map((n, i) =>
										<div key={i} style={{ textAlign: 'center', margin: '2px', position: 'relative', padding: '15px' }}>
											<button className={classes.deleteImage} onClick={(e) => deleteRoomClass(i)}>X</button>
											<div style={{ height: '50px', border: '1px solid #d8d8d8' }}>
												{n.imageFiles == null || n.imageFiles.length == 0 ?
													n.imageUrls == null || n.imageUrls == [] ? null :
														<Carousel autoPlay={false} transitionTime="2000" showThumbs={false} width="100px">
															{n.imageUrls.map((k, j) =>
																<div key={j}>
																	<img alt={k.name} style={{ width: '80px', height: '50px', margin: 'auto', padding: '2px' }} src={k} />
																</div>
															)}
														</Carousel>
													:
													n.imageUrls == null || n.imageUrls == [] ?
														<Carousel autoPlay={false} transitionTime="2000" showThumbs={false} width="100px">
															{n.imageFiles == null || n.imageFiles.length == 0 ? null : n.imageFiles.map((m, t) =>
																<div key={t}>
																	<img alt={m.name} style={{ width: '80px', height: '50px', margin: 'auto', padding: '2px' }} src={URL.createObjectURL(m)} />
																</div>
															)}
														</Carousel> :
														<Carousel autoPlay={false} transitionTime="2000" showThumbs={false} width="100px">
															{n.imageUrls == null || n.imageUrls == [] ? null : n.imageUrls.map((k, j) =>
																<div key={j}>
																	<img alt={k.name} style={{ width: '80px', height: '50px', margin: 'auto', padding: '2px' }} src={k} />
																</div>
															)}
															{n.imageFiles == null || n.imageFiles.length == 0 ? null : n.imageFiles.map((m, t) =>
																<div key={t}>
																	<img alt={m.name} style={{ width: '80px', height: '50px', margin: 'auto', padding: '2px' }} src={URL.createObjectURL(m)} />
																</div>
															)}
														</Carousel>
												}
											</div>
											<Chip
												className={classes.chipStyle}
												label={n.name}
												variant='outlined'
												onClick={(e) => openEditRoomClassModal(i)}
											/>
										</div>
									)}
								</div>
								<button className={classes.add_but} onClick={(e) => openAddRoomClassModal()}>Add New RoomClass</button>
							</FormControl>
						}
						{(userRole === 'agency') ? null :
							<FormControl required className={classes.formControl1}>
								<div style={{ display: 'flex', margin: '10px 0px', flexWrap: 'wrap' }}>
									{facilities.map((n, i) =>
										<div key={i} style={{ textAlign: 'center', margin: '2px', position: 'relative', padding: '15px' }}>
											<button className={classes.deleteImage} onClick={(e) => deleteFacilites(i)}>X</button>
											<Chip
												className={classes.chipStyle}
												label={n.name}
												variant='outlined'
												onClick={(e) => openEditFacilitiesModal(i)}
												// onDelete={handleDelete}
												deleteIcon={<DoneIcon />}
											/>
										</div>
									)}
								</div>
								<button className={classes.add_but} onClick={(e) => openAddFacilitiesModal()}>Add New Facility</button>
							</FormControl>
						}
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' color='secondary' onClick={(e) => editProcess()}>
								{nButtonText}
							</Button>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleCloseModal}>
								Cancel
							</Button>
						</div>
					</div>

				</Fade>
			</Modal>
			<Modal
				open={roomClassModalOpen}
				onClose={handleCloseRoomClassModal}
				className={classes.modal1}
				aria-labelledby="simple-modal-title"
				aria-describedby="simple-modal-description"
			>
				<div className={classes.paper}>
					<h2 id="server-modal-title" >RoomClass {nButtonText1}</h2>
					<div style={{ display: 'grid' }}>
						<FormControl required className={classes.formControl}>
							<FormHelperText>ID</FormHelperText>
							<TextField className={classes.textfield} defaultValue={roomId == null ? '' : roomId} onChange={onChangeRoomID} />
						</FormControl>
						<FormControl required className={classes.formControl}>
							<FormHelperText>Name</FormHelperText>
							<TextField className={classes.textfield} defaultValue={roomName == null ? '' : roomName} onChange={onChangeRoomName}
								InputProps={{
									endAdornment: (
										<datalist id="roomClassList">
											{roomClassList.map((n, i) => (
												<option key={i} value={n}></option>
											))}
										</datalist>
									),
									inputProps: {
										list: "roomClassList"
									}
								}}
							/>
						</FormControl>
						<FormControl required className={classes.formControl}>
							<FormHelperText>Description</FormHelperText>
							<TextareaAutosize
								rowsMax={3}
								aria-label="maximum height"
								placeholder=".........."
								onChange={onChangeRoomDes}
								className={classes.ntextArea}
								defaultValue={roomDes == null ? '' : roomDes}
							/>
							{/* <TextField className={classes.textfield} defaultValue={roomDes == null ? '' : roomDes} onChange={onChangeRoomDes} /> */}
						</FormControl>

					</div>
					<div style={{ display: 'flex', width: '500px', flexWrap: 'wrap', overflow: 'auto' }}>
						{existRoomClassImage == null ? "" : existRoomClassImage.map((k, i) =>
							<div style={{ position: 'relative' }} key={i}>
								<button className={classes.deleteImage} onClick={(e) => deleteExistingImage(i)}>X</button>
								<img alt='' style={{ width: '80px', height: '50px', margin: '10px' }} src={k} />
							</div>
						)}
						{roomClassImage == null ? "" : roomClassImage.map((n, j) =>
							<div style={{ position: 'relative' }} key={j}>
								<button className={classes.deleteImage} onClick={(e) => deleteImage(j)}>X</button>
								<img alt='' style={{ width: '80px', height: '50px', margin: '10px' }} src={URL.createObjectURL(n)} />
							</div>
						)}
					</div>

					<ImageUploader
						className={classes.imageUploader}
						withIcon={false}
						buttonStyles={{ fontSize: '12px' }}
						fileContainerStyle={{ padding: '0px', boxShadow: 'none' }}
						buttonText="Add Images"
						withLabel={false}
						withPreview={false}
						onChange={onImageDrop}
						imgExtension={[".jpg", ".gif", ".png", ".gif", ".jpeg", ".jfif"]}
						maxFileSize={524288000}
					/>
					<AddImageMultipleLink addingImageType={'RoomClass'} setPictureLink={handleSetRoomClassPictureUrl} />
					<div className={classes.button_group}>
						<Button className={classes.buttons} variant='contained' color='secondary' onClick={updateRoomClass}>
							{nButtonText1}
						</Button>
						<Button className={classes.buttons} variant='contained' color='primary' onClick={handleCloseRoomClassModal}>
							Cancel
						</Button>
					</div>
				</div>
			</Modal>
			<Modal
				open={facilityModalOpen}
				onClose={handleCloseFacilitiesModal}
				className={classes.modal1}
				aria-labelledby="simple-modal-title"
				aria-describedby="simple-modal-description"
			>
				<div className={classes.paper}>
					<h2 id="server-modal-title" >Facilities {nButtonText2}</h2>
					<div style={{ display: 'grid' }}>
						<FormControl required className={classes.formControl}>
							<FormHelperText>Code</FormHelperText>
							<TextField className={classes.textfield} defaultValue={facilityCode == null ? '' : facilityCode} onChange={onChangeFacilityCode} />
						</FormControl>
						<FormControl required className={classes.formControl}>
							<FormHelperText>Name</FormHelperText>
							<TextField className={classes.textfield} defaultValue={facilityName == null ? '' : facilityName} onChange={onChangeFacilityName}
								InputProps={{
									endAdornment: (
										<datalist id="facilityList">
											{facilityList.map((n, i) => (
												<option key={i} value={n}></option>
											))}
										</datalist>
									),
									inputProps: {
										list: "facilityList"
									}
								}}
							/>
						</FormControl>
					</div>
					<div className={classes.button_group}>
						<Button className={classes.buttons} variant='contained' color='secondary' onClick={updateFacilites}>
							{nButtonText2}
						</Button>
						<Button className={classes.buttons} variant='contained' color='primary' onClick={handleCloseFacilitiesModal}>
							Cancel
						</Button>
					</div>
				</div>
			</Modal>
			<Modal
				open={warningOpen}
				onClose={handleCloseWarning}
				className={classes.modal}
				aria-labelledby="simple-modal-title"
				aria-describedby="simple-modal-description"
			>
				<div className={classes.paper}>
					<h2 id="server-modal-title" >Warning</h2>
					<p id="server-modal-description">{warningText}</p>
					<Button className="whitespace-no-wrap normal-case"
						variant="contained"
						color="secondary"
						onClick={handleCloseWarning}>Close
					</Button>
				</div>
			</Modal>
			<FuseScrollbars className='flex-grow overflow-x-auto'>
				<ReactNotifications isMobile={true} className={classes.Notificaiton} style={{ position: "absolute", top: "10px" }} />
				<div>
					{hotelInfoData === null || dataLength === 0 ? <p className={classes.dataDiv}>Empty Result</p> :
						hotelInfoData.map((n, i) =>
							<Card className={classes.root} key={i} >
								<div style={{ display: 'flex' }}>
									<div style={{ width: '100%', display: 'flex' }} >
										{n.mainImageUrls == null || n.mainImageUrls.length == 0 ? <img alt='' style={{ width: '120px', height: '80px', padding: '2px' }} src=' ' /> :
											<Carousel autoPlay={false} transitionTime="2000" showThumbs={false} width="100px">
												{n.mainImageUrls.map((k, i) =>
													<div key={i}>
														<img alt='' style={{ width: '100px', height: '80px', margin: 'auto', padding: '2px' }} src={k} />
													</div>
												)}
											</Carousel>
										}
										{n.galleryImageUrls == null || n.galleryImageUrls.length == 0 ? <img alt='' style={{ width: '120px', height: '80px', padding: '2px' }} src=' ' /> :
											<Carousel autoPlay={false} transitionTime="2000" showThumbs={false} width="100px">
												{n.galleryImageUrls.map((k, i) =>
													<div key={i}>
														<img alt='' style={{ width: '100px', height: '80px', margin: 'auto', padding: '2px' }} src={k} />
													</div>
												)}
											</Carousel>
										}
										<div style={{ margin: 'auto 20px', display: 'grid', width: '100%' }}>
											<div style={{ fontWeight: '600' }}>
												{n.hotelConversion?.hotelName || ''} {n.hotelConversion?.nameTranslations?.he ? `(${n.hotelConversion?.nameTranslations?.he})` : ''}
											</div>
											<ShowMoreText
												lines={3}
												more='Show more'
												less='Show less'
												className='content-css'
												anchorClass='my-anchor-css-class'
												onClick={executeOnClick}
												expanded={false}
												style={{ marginBottom: '20px' }}
											>
												{ReactHtmlParser(n.hotelDescTrans?.he || null)}
											</ShowMoreText>
										</div>
									</div>
									<CardActions disableSpacing className={classes.actionExtend}>
										{
											(userRole === 'agency') ? null :
												<IconButton
													className={clsx(classes.expand, {
														[classes.expandOpen]: expanded,
													})}
													onClick={(e) => handleExpandClick(i)}
													aria-expanded={expanded}
													aria-label='show more'
												>
													<ExpandMoreIcon />
												</IconButton>
										}
										<IconButton
											onClick={(e) => openDetail(i)}
											aria-expanded={expanded}
											aria-label='show more'
										>
											<EditIcon />
										</IconButton>
										<IconButton
											onClick={(e) => deleteHotelInfo(i)}
											aria-expanded={expanded}
											aria-label='show more'
										>
											<DeleteIcon />
										</IconButton>
									</CardActions>
								</div>
								{
									(userRole === 'agency') ? null :
										<Collapse in={expanded && i == index} timeout='auto' unmountOnExit>
											{n.facilities == null ? null :
												<div style={{ border: '1px solid #d8d8d8', borderRadius: '3px', margin: '5px' }}>
													{/* <span style={{ paddingLeft: '10px', fontWeight: '600' }}>Facilities</span> */}
													<div>
														{n.facilities.map((n, i) =>
															<Chip
																key={i}
																className={classes.chipStyle}
																label={n.name}
																variant='outlined'
															/>
														)}
													</div>
												</div>
											}
											{n.roomClasses == null ? null :
												<div style={{ border: '1px solid #d8d8d8', borderRadius: '3px', margin: '5px' }}>
													{/* <span style={{ paddingLeft: '10px', fontWeight: '600' }}>RoomClass</span> */}
													<div style={{ display: 'flex' }}>
														{n.roomClasses.map((n, i) =>
															<div key={i} style={{ textAlign: 'center', margin: '2px' }}>
																<Carousel autoPlay={false} transitionTime="2000" showThumbs={false} width="100px">
																	{n.imageUrls == null ? "" : n.imageUrls.map((k, j) =>
																		<div key={j}>
																			<img alt={k.name} style={{ width: '80px', height: '50px', margin: 'auto', padding: '2px' }} src={k} />
																		</div>
																	)}
																</Carousel>
																<Chip
																	className={classes.chipStyle}
																	label={n.name}
																	variant='outlined'
																/>
															</div>
														)}
													</div>
												</div>
											}
										</Collapse>
								}
							</Card>
						)}
				</div>

				{dataLength > 0 ?
					<TablePagination
						component="div"
						count={dataLength}
						page={page}
						onChangePage={handleChangePage}
						rowsPerPage={rowsPerPage}
						onChangeRowsPerPage={handleChangeRowsPerPage}
						className={classes.pagination}
					/>
					: null
				}

			</FuseScrollbars>
		</div>

	);
}
export default withRouter(HotelInfoPanel);
