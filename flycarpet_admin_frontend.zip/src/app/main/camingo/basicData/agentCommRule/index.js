import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../../store';
import AgentHeader from 'app/main/domestic/basicdata/agentCommissionRule/AgentCommRuleHeader';
import AgentTable from 'app/main/domestic/basicdata/agentCommissionRule/AgentCommRuleTable';

function AgentCommRule() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<AgentHeader operation="camingo"/>}
			content={<AgentTable operation="camingo"/>}
			innerScroll
		/>
	);
}
 
export default withReducer('BasicData', reducer)(AgentCommRule);
