import { makeStyles } from '@material-ui/core/styles';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Tooltip from '@material-ui/core/Tooltip';
import React from 'react';

const rows = [

    {
        id: 'nameEn',
        align: 'left',
        disablePadding: false,
        label: 'English Name',
        sort: true
    },
    {
        id: 'nameRu',
        align: 'left',
        disablePadding: false,
        label: 'Russian Name',
        sort: true
    },
    {
        id: 'nameHe',
        align: 'left',
        disablePadding: false,
        label: 'Hebrew Name',
        sort: true
    },
    {
        id: 'agencyName',
        align: 'left',
        disablePadding: false,
        label: 'Agency Name',
        sort: true
    },
    {
        id: 'createdTime',
        align: 'left',
        disablePadding: false,
        label: 'CreatedTime',
        sort: true
    },
    {
        id: 'sortOrder',
        align: 'left',
        disablePadding: false,
        label: 'Sort Order',
        sort: true
    },
    {
        id: 'active',
        align: 'left',
        disablePadding: false,
        label: 'active',
        sort: true
    },
    {
        id: 'action',
        align: 'center',
        disablePadding: false,
        label: 'Edit',
        sort: true
    },
     {
        id: 'delete',
        align: 'center',
        disablePadding: false,
        label: 'Delete',
        sort: true
    }

];

function ProductsTableHead(props) {

    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };

    return (
        <TableHead>
            <TableRow className="h-64">
                <TableCell padding="none" className="w-20 md:w-20 text-center z-99">
                </TableCell>
                {rows.map(row => {
                    return (
                        <TableCell
                            className="p-4 md:p-16"
                            key={row.id}
                            align={row.align}
                            padding={row.disablePadding ? 'none' : 'default'}
                            sortDirection={props.order.id === row.id ? props.order.direction : false}
                        >
                            {row.sort && (
                                <Tooltip
                                    title="Sort"
                                    placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                    enterDelay={300}
                                >
                                    <TableSortLabel
                                        active={props.order.id === row.id}
                                        direction={props.order.direction}
                                        onClick={createSortHandler(row.id)}
                                    >
                                        {row.label}
                                    </TableSortLabel>
                                </Tooltip>
                            )}
                        </TableCell>
                    );
                }, this)}
            </TableRow>
        </TableHead>
    );
}

export default ProductsTableHead;
