import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../../store';
import AgentHeader from './InternalAgentHeader';
import AgentTable from './InternalAgentTable';

function AgentManage() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<AgentHeader />}
			content={<AgentTable />}
			innerScroll
		/>
	);
}
 
export default withReducer('BasicData', reducer)(AgentManage);
