import React from 'react';
import Login from '../../login/Login';
const token = window.localStorage.getItem('jwt_access_token');
const DealType = {
	settings: {
		layout: token == null ? {
			config: {
				navbar: {
					display: false
				},
				toolbar: {
					display: false
				},
				footer: {
					display: false
				},
				leftSidePanel: {
					display: false
				},
				rightSidePanel: {
					display: false
				}
			}
		} : {
				config: {}
			}
	},
	routes: token == null ? [
		{
			path: '/',
			component: Login
		}
	] : [
		{
			path: '/camingo/camingoChain',
			component: React.lazy(() => import('./HotelChain/HotelChain'))
		},
		{
			path: '/camingo/camingoCategory',
			component: React.lazy(() => import('./deal_category/Category'))
		},
		{
			path: '/camingo/camingoHotelConversion',
			component: React.lazy(() => import('./HotelConversion/index'))
		},
		{
			path: '/camingo/camingoHotelInfo',
			component: React.lazy(() => import('./HotelInfo/HotelInfo.js'))
		},
		{
			path: '/camingo/remarkManagement',
			component: React.lazy(() => import('./RemarkManagement/index'))
		},
		{
			path: '/camingo/staticPage/camingoFooter',
			component: React.lazy(() => import('../../EditStaticPage/footer/index'))
		},
		{
			path: '/camingo/camingoInternalAgent',
			component: React.lazy(() => import('./internalAgentManage/index'))
		},
		{
			path: '/camingo/agentCommRule',
			component: React.lazy(() => import('./agentCommRule/index')),
		},
		{
			path: '/camingo/supplementService',
			component: React.lazy(() => import('./SupplementService/index')),
		},
		{
			path: '/camingo/nationality',
			component: React.lazy(() => import('./nationality/index')),
		}
	]
};
export default DealType;
