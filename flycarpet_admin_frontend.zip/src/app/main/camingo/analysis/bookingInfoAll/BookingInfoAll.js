import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../../store';
import DestinationHeader from './BookingInfoAllHeader';
import DestinationTable from './BookingInfoAllTable';

function Destination() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<DestinationHeader />}
			content={<DestinationTable />}
			innerScroll
		/>
	);
}

export default withReducer('BasicData', reducer)(Destination);
