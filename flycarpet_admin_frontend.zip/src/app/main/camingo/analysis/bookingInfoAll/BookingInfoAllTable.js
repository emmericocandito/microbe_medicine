import FuseScrollbars from '@fuse/core/FuseScrollbars';
import axios from 'axios';
import _ from '@lodash';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import FuseLoading from '@fuse/core/FuseLoading';
import DestinationTableHead from './BookingInfoAllTableHead';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import Backdrop from '@material-ui/core/Backdrop';
import Fade from '@material-ui/core/Fade';
import Button from '@material-ui/core/Button';
import FormControl from '@material-ui/core/FormControl';
import FormHelperText from '@material-ui/core/FormHelperText';
import SearchIcon from '@material-ui/icons/Search';
import Select from '@material-ui/core/Select';
import Grid from '@material-ui/core/Grid';
import CircularProgress from '@material-ui/core/CircularProgress';
import Chip from '@material-ui/core/Chip';
import 'react-tabs/style/react-tabs.css';
import 'bootstrap-daterangepicker/daterangepicker.css';
import IconButton from '@material-ui/core/IconButton';
import OpenInNew from '@material-ui/icons/OpenInNew';
import TextField from '@material-ui/core/TextField';
import {
	MuiPickersUtilsProvider,
	KeyboardDatePicker,
} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import { baseURL } from 'app/main/utils';

function DestinationTable(props) {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			margin: theme.spacing(1),
			minWidth: 120,
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			minWidth: 100,
			minHeight: 200
		},
		button_group:
		{
			padding: 30,
			textAlign: 'center',
		},
		buttons: {
			marginRight: '10px'
		},
		textfield: {
			width: '100%'
		},
		chipStyle: {
			height: '20px',
			margin: '1px',
			color: 'white',
			fontSize: '12px',
			background: '#32606b'
		},
	}));
	const [open, setOpen] = useState(false);
	const [page, setPage] = React.useState(0);
	const [rowsPerPage, setRowsPerPage] = React.useState(10);
	const [upaidCustomers, setUpaidCustomers] = useState([])
	const [dataLength, setDataLength] = useState(0);
	const [selected] = useState([]);
	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});

	const [nFilterBookingId, setFilterBookingId] = useState(null);
	const [nFilterHotelName, setFilterHotelName] = useState(null);
	const [nFilterGroup, setFilterGroup] = useState(null);
	const [nFilterPayerName, setFilterPayerName] = useState(null);
	const [nFilterPaxName, setFilterPaxName] = useState(null);
	const [nFilterHotelOrderNum, setFilterHotelOrderNum] = useState(null);
	const [nFilterPNR, setFilterPNR] = useState(null);
	const [nFilterCheckIn, setFilterCheckIn] = useState(null);
	const [nFilterCheckOut, setFilterCheckOut] = useState(null);
	const [nFilterBookingStart, setFilterBookingStart] = useState(null);
	const [nFilterBookingEnd, setFilterBookingEnd] = useState(null);
	const [nFilterPayed, setFilterPayed] = useState(null);
	const [nFilterBooked, setFilterBooked] = useState(null);


	const [loading, setLoading] = useState(true);
	const classes = useStyles();
	const [value, setValue] = useState(0);
	const [loadingCircle, setLoadingCircle] = useState(false);

	useEffect(() => {
		reopen(1, 10, '', '', '');
	}, [])

	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}

	const handleClose = () => {
		setOpen(false);
	};

	function handleChangePage(event, newPage) {
		setPage(newPage);
		const from = newPage * rowsPerPage + 1;
		const to = newPage * rowsPerPage + rowsPerPage
		reopen(from, to);
	}

	function handleChangeRowsPerPage(event) {
		setPage(0);
		setRowsPerPage(event.target.value);
		reopen(1, event.target.value);
	}

	async function reopen(from, to) {
		setLoading(true);
		await axios({
			method: 'post',
			url: baseURL + 'camingo/api/analysis/bookings/search?' + 'from=' + from + '&to=' + to,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"BookingTransId": nFilterBookingId,
				"Source": nFilterGroup,
				"HotelName": nFilterHotelName,
				"CheckinDate": nFilterCheckIn,
				"CheckoutDate": nFilterCheckOut,
				"BookDateFrom": nFilterBookingStart,
				"BookDateTo": nFilterBookingEnd,
				"PaxName": nFilterPaxName,
				"PayerName": nFilterPayerName,
				"BookSucceeded": (nFilterBooked === null) ? null : nFilterBooked === 'true',
				"Payed": (nFilterPayed === null) ? null : nFilterPayed === 'true',
				"Pnr": nFilterPNR,
				"HotelOrderNumber": nFilterHotelOrderNum
			}
		}).then(response => {
			setLoading(false);
			setDataLength(response.data.total);
			setUpaidCustomers(response.data.data);
			setOpen(false);
		}).catch(error => {
			setLoading(false);
			setOpen(false);
		});
	}

	const openSearchModel = () => {
		setOpen(true);
	};

	function searchPackageFromApi() {
		const from = 0 * rowsPerPage + 1;
		const to = 0 * rowsPerPage + rowsPerPage;
		reopen(from, to);
	}
	function onChangeFilterBookingID(event) {
		if (event.target.value == '') {
			setFilterBookingId(null);
		}
		else {
			setFilterBookingId(event.target.value);
		}
	}
	function onChangeFilterHotelName(event) {
		if (event.target.value == '') {
			setFilterHotelName(null);
		}
		else {
			setFilterHotelName(event.target.value);
		}
	}
	function onChangeFilterGroup(event) {
		if (event.target.value == '') {
			setFilterGroup(null);
		}
		else {
			setFilterGroup(event.target.value);
		}
	}
	function onChangeFilterPayerName(event) {
		if (event.target.value == '') {
			setFilterPayerName(null);
		}
		else {
			setFilterPayerName(event.target.value);
		}
	}
	function onChangeFilterPaxName(event) {
		if (event.target.value == '') {
			setFilterPaxName(null);
		}
		else {
			setFilterPaxName(event.target.value);
		}
	}
	function onChangeFilterHotelOrderNum(event) {
		if (event.target.value == '') {
			setFilterHotelOrderNum(null);
		}
		else {
			setFilterHotelOrderNum(event.target.value);
		}
	}
	function onChangeFilterPNR(event) {
		if (event.target.value == '') {
			setFilterPNR(null);
		}
		else {
			setFilterPNR(event.target.value);
		}
	}
	function onChangeFilterCheckIn(event) {
		if (event.target.value == '') {
			setFilterCheckIn(null);
		} else {
			setFilterCheckIn(event.target.value);
		}
	}
	function onChangeFilterCheckOut(event) {
		if (event.target.value == '') {
			setFilterCheckOut(null);
		} else {
			setFilterCheckOut(event.target.value);
		}
	}
	function onChangeFilterCheckIn(event) {
		if (event.target.value == '') {
			setFilterCheckIn(null);
		} else {
			setFilterCheckIn(event.target.value);
		}
	}
	function onChangeFilterBookingFrom(event) {
		if (event.target.value == '') {
			setFilterBookingStart(null);
		} else {
			setFilterBookingStart(event.target.value);
		}
	}
	function onChangeFilterBookingTo(event) {
		if (event.target.value == '') {
			setFilterBookingEnd(null);
		} else {
			setFilterBookingEnd(event.target.value);
		}
	}
	function onChangeFilterBookingFrom(event) {
		if (event.target.value == '') {
			setFilterBookingStart(null);
		} else {
			setFilterBookingStart(event.target.value);
		}
	}
	function onChangeFilterPayed(event) {
		if (event.target.value == '') {
			setFilterPayed(null);
		} else {
			setFilterPayed(event.target.value);
		}
	}
	function onChangeFilterBooked(event) {
		if (event.target.value == '') {
			setFilterBooked(null);
		} else {
			setFilterBooked(event.target.value);
		}
	}
	if (loading) {
		return <FuseLoading />;
	}
	const getDateFormat = (date) => {
		if (date === null) {
			return '';
		}
		else {
			var year = date.getFullYear();
			var month = date.getMonth() + 1;
			var mdate = date.getDate();
			if (month < 10) {
				month = '0' + month;
			}
			if (mdate < 10) {
				mdate = '0' + mdate;
			}
			return year + '-' + month + '-' + mdate;
		}

	}

	return (
		<div className="w-full flex flex-col">
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={open}
				onClose={handleClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={open}>
					<div className={classes.paper}>
						<div className={classes.fo_circular}>
							{loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
						</div>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title' >Filter Setting</h2>
						</div>

						<FormControl required className={classes.formControl} style={{ width: '100%' }}>
							<FormHelperText>BookingTransId</FormHelperText>
							<TextField className={classes.textfield}
								defaultValue={nFilterBookingId == null ? '' : nFilterBookingId}
								onChange={onChangeFilterBookingID}
							/>
						</FormControl>

						<div style={{ display: 'flex', width: '100%' }}>
							<FormControl required className={classes.formControl} style={{ width: '50%' }}>
								<FormHelperText>HotelName</FormHelperText>
								<TextField className={classes.textfield}
									defaultValue={nFilterHotelName == null ? '' : nFilterHotelName}
									onChange={onChangeFilterHotelName}
								/>
							</FormControl>
							<FormControl required className={classes.formControl} style={{ width: '50%' }}>
								<FormHelperText>Group</FormHelperText>
								<TextField className={classes.textfield}
									defaultValue={nFilterGroup == null ? '' : nFilterGroup}
									onChange={onChangeFilterGroup}
								/>
							</FormControl>
						</div>

						<div style={{ display: 'flex', width: '100%' }}>
							<FormControl required className={classes.formControl} style={{ width: '50%' }}>
								<FormHelperText>PayerName</FormHelperText>
								<TextField className={classes.textfield}
									defaultValue={nFilterPayerName == null ? '' : nFilterPayerName}
									onChange={onChangeFilterPayerName}
								/>
							</FormControl>
							<FormControl required className={classes.formControl} style={{ width: '50%' }}>
								<FormHelperText>PaxName</FormHelperText>
								<TextField className={classes.textfield}
									defaultValue={nFilterPaxName == null ? '' : nFilterPaxName}
									onChange={onChangeFilterPaxName}
								/>
							</FormControl>
						</div>

						<div style={{ display: 'flex', width: '100%' }}>
							<FormControl required className={classes.formControl} style={{ width: '50%' }}>
								<FormHelperText>HotelOrderNumber</FormHelperText>
								<TextField className={classes.textfield}
									defaultValue={nFilterHotelOrderNum == null ? '' : nFilterHotelOrderNum}
									onChange={onChangeFilterHotelOrderNum}
								/>
							</FormControl>
							<FormControl required className={classes.formControl} style={{ width: '50%' }}>
								<FormHelperText>PNR</FormHelperText>
								<TextField className={classes.textfield}
									defaultValue={nFilterPNR == null ? '' : nFilterPNR}
									onChange={onChangeFilterPNR}
								/>
							</FormControl>
						</div>
						<Grid container justify='space-around' style={{ margin: '5px 0px' }}>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>CheckIn</FormHelperText>
								<TextField
									id="filterdate-1"
									type="date"
									value={nFilterCheckIn == null ? '' : nFilterCheckIn}
									onChange={onChangeFilterCheckIn}
									className={classes.textField1}
								/>
							</FormControl>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>CheckOut</FormHelperText>
								<TextField
									id="filterdate-2"
									type="date"
									value={nFilterCheckOut == null ? '' : nFilterCheckOut}
									onChange={onChangeFilterCheckOut}
									className={classes.textField1}
								/>
							</FormControl>
						</Grid>
						<Grid container justify='space-around' style={{ margin: '5px 0px' }}>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>BookingFrom</FormHelperText>
								<TextField
									id="filterdate-1"
									type="date"
									value={nFilterBookingStart == null ? '' : nFilterBookingStart}
									onChange={onChangeFilterBookingFrom}
									className={classes.textField1}
								/>
							</FormControl>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>BookingTo</FormHelperText>
								<TextField
									id="filterdate-2"
									type="date"
									value={nFilterBookingEnd == null ? '' : nFilterBookingEnd}
									onChange={onChangeFilterBookingTo}
									className={classes.textField1}
								/>
							</FormControl>
						</Grid>
						<div style={{ display: 'flex', padding: '5px', justifyContent: 'space-between' }}>
							<FormControl required className={classes.formControl}>
								<FormHelperText>BookSucceeded</FormHelperText>
								<Select
									native
									onChange={onChangeFilterBooked}
									value={nFilterBooked == null ? '' : nFilterBooked}
									inputProps={{
										id: 'age-native-required',
									}}
								>
									<option aria-label='None' value=''>All</option>
									<option value='true'>Active</option>
									<option value='false'>Unactive</option>
								</Select>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Payed</FormHelperText>
								<Select
									native
									onChange={onChangeFilterPayed}
									value={nFilterPayed == null ? '' : nFilterPayed}
									inputProps={{
										id: 'age-native-required',
									}}
								>
									<option aria-label='None' value=''>All</option>
									<option value='true'>Active</option>
									<option value='false'>Unactive</option>
								</Select>
							</FormControl>
						</div>

						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' color='secondary' onClick={searchPackageFromApi}>
								Search
							</Button>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleClose}>
								Cancel
							</Button>

						</div>
					</div>

				</Fade>
			</Modal>
			<div>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px' }}
					onClick={() => openSearchModel()}
				>
					<span className='hidden sm:flex'><SearchIcon />Filter</span>
					<span className='flex sm:hidden'><SearchIcon /></span>
				</Button>
			</div>
			<FuseScrollbars className="flex-grow overflow-x-auto">
				<Table stickyHeader className="min-w-xl" aria-labelledby="tableTitle">
					<DestinationTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={upaidCustomers.length}
					/>
					<TableBody>
						{_.orderBy(
							upaidCustomers,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className="h-64 cursor-pointer"
									hover
									tabIndex={-1}
									key={i}
								>
									<TableCell padding="none" className="w-20 md:w-20 text-center z-99">
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.payerName}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.hotelName}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.source}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.bookDate == null ? null : new Date(n.bookDate).toString().substring(0, 16)}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left">
										{n.paxName == null ? null : n.paxName.map((n, i) =>
											n != null && <Chip key={i} className={classes.chipStyle} label={n} variant='outlined' />
										)}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.pnr == null ? 'N/A' : n.pnr}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left'>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.bookSucceeded && 'bg-red',
												n.bookSucceeded && 'bg-green',
											)}
										/>
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left'>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.payed && 'bg-red',
												n.payed && 'bg-green',
											)}
										/>
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.hotelOrderNumber}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.checkinDate == null ? null : new Date(n.checkinDate).toString().substring(0, 16)}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.checkoutDate == null ? null : new Date(n.checkoutDate).toString().substring(0, 16)}
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component='th' scope='row' align='left'>
										<IconButton aria-label="delete" target="_blank" href={'/camingo/bookingInfo/' + n.bookingTransId}>
											<OpenInNew />
										</IconButton>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className="flex-shrink-0 border-t-1"
				component="div"
				count={dataLength}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}

export default withRouter(DestinationTable);
