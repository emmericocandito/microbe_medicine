import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../store';
import DiscountHeader from './CamingoDiscountHeader';
import DiscountTable from './CamingoDiscountTable';

function Discount() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<DiscountHeader />}
			content={<DiscountTable />}
			innerScroll
		/>
	);
}
 
export default withReducer('BasicData', reducer)(Discount);
