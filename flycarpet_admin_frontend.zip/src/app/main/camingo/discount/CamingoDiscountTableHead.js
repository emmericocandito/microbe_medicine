import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Tooltip from '@material-ui/core/Tooltip';
import React from 'react';
import i18next from 'i18next';

const rows = [
    {
        id: 'city',
        translate: 'city',
        align: 'center',
        disablePadding: false,
        label: 'City',
        sort: true
    },
    {
        id: 'hotelName',
        translate: 'hotelName',
        align: 'left',
        disablePadding: false,
        label: 'Hotel',
        sort: true
    },
    {
        id: 'chain',
        translate: 'chain',
        align: 'left',
        disablePadding: false,
        label: 'Chain',
        sort: true
    },
    {
        id: 'category',
        translate: 'Category',
        align: 'left',
        disablePadding: false,
        label: 'Category',
        sort: true
    },
    {
        id: 'agency',
        translate: 'agency',
        align: 'left',
        disablePadding: false,
        label: 'Agency',
        sort: true
    },
    {
        id: 'discount_Homepage',
        translate: 'discount_Homepage',
        align: 'left',
        disablePadding: false,
        label: 'Discount',
        sort: true
    },

    {
        id: 'H_remark',
        translate: 'hotel',
        align: 'left',
        disablePadding: false,
        label: 'Discount Remark',
        sort: true
    },
    {
        id: 'startDate',
        translate: 'startDate',
        align: 'left',
        disablePadding: false,
        label: 'Check-In From',
        sort: true
    },
    {
        id: 'endDate',
        translate: 'endDate',
        align: 'left',
        disablePadding: false,
        label: 'Check-Out To',
        sort: true
    },
    {
        id: 'latest',
        translate: 'latest',
        align: 'left',
        disablePadding: false,
        label: 'Latest',
        sort: true
    },
    {
        id: 'action',
        translate: 'action',
        align: 'left',
        disablePadding: false,
        label: 'Edit',
        sort: true
    },
    {
        id: 'delete',
        translate: 'delete',
        align: 'left',
        disablePadding: false,
        label: 'Delete',
        sort: true
    }

];

function ProductsTableHead(props) {
    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };
    return (
        <TableHead>
            <TableRow className="h-64">
                {rows.map(row => {
                    return (
                        <TableCell
                            className="p-4 md:p-16"
                            key={row.id}
                            align={row.align}
                            padding={row.disablePadding ? 'none' : 'default'}
                            sortDirection={props.order.id === row.id ? props.order.direction : false}
                        >
                            {row.sort && (
                                <Tooltip
                                    title="Sort"
                                    placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                    enterDelay={300}
                                >
                                    <TableSortLabel
                                        active={props.order.id === row.id}
                                        direction={props.order.direction}
                                        onClick={createSortHandler(row.id)}
                                    >
                                        {row.label}
                                    </TableSortLabel>
                                </Tooltip>
                            )}
                        </TableCell>
                    );
                }, this)}
            </TableRow>
        </TableHead>
    );
}

export default ProductsTableHead;
