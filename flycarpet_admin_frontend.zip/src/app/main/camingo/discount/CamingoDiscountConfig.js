import React from 'react';
import Login from '../../login/Login';
const token = window.localStorage.getItem('jwt_access_token');

const Discount = {
	settings: {
		layout: token == null ? {
			config: {
				navbar: {
					display: false
				},
				toolbar: {
					display: false
				},
				footer: {
					display: false
				},
				leftSidePanel: {
					display: false
				},
				rightSidePanel: {
					display: false
				}
			}
		} : {
			config: {}
		}
	},
	routes: token == null ? [
		{
			path: '/',
			component: Login
		}
	] : [
		{
			path: '/camingo/camingoDiscountBuilder',
			component: React.lazy(() => import('./CamingoDiscount'))
		}
	]
};

export default Discount;
