import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../store';
import CamingoDestinationHeader from './CamingoDestinationHeader';
import CamingoDestinationTable from './CamingoDestinationTable';

function CamingoDestination() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<CamingoDestinationHeader />}
			content={<CamingoDestinationTable />}
			innerScroll
		/>
	);
}

export default withReducer('BasicData', reducer)(CamingoDestination);
