
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Tooltip from '@material-ui/core/Tooltip';
import React from 'react';

const rows = [
    
    {
        id: 'code',
        align: 'left',
        disablePadding: false,
        label: 'Code',
        sort: true
    },
    {
        id: 'nameTranslations.en',
        align: 'left',
        disablePadding: false,
        label: 'Name EN',
        sort: true
    },
    {
        id: 'nameTranslations.he',
        align: 'right',
        disablePadding: false,
        label: 'Name HE',
        sort: true
    },
    {
        id: 'nameTranslations.ru',
        align: 'left',
        disablePadding: false,
        label: 'Name RU',
        sort: true
    },
    {
        id: 'area',
        align: 'right',
        disablePadding: false,
        label: 'Area',
        sort: true
    },
    {
        id: 'order',
        align: 'left',
        disablePadding: false,
        label: 'Order',
        sort: true
    },
    {
        id: 'isActive',
        align: 'right',
        disablePadding: false,
        label: 'Active',
        sort: true
    },
    {
        id: 'edit',
        align: 'left',
        disablePadding: false,
        label: 'Edit',
        sort: true
    },
    {
        id: 'delete',
        align: 'left',
        disablePadding: false,
        label: 'Delete',
        sort: true
    }
];

function ProductsTableHead(props) {

    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };

    return (
        <TableHead>
            <TableRow className="h-64">
                <TableCell padding="none" className="w-20 md:w-20 text-center z-99">
                </TableCell>
                {rows.map(row => {
                    return (
                        <TableCell
                            className="p-4 md:p-16"
                            key={row.id}
                            align={row.align}
                            padding={row.disablePadding ? 'none' : 'default'}
                            sortDirection={props.order.id === row.id ? props.order.direction : false}
                        >
                            {row.sort && (
                                <Tooltip
                                    title="Sort"
                                    placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                    enterDelay={300}
                                >
                                    <TableSortLabel
                                        active={props.order.id === row.id}
                                        direction={props.order.direction}
                                        onClick={createSortHandler(row.id)}
                                    >
                                        {row.label}
                                    </TableSortLabel>
                                </Tooltip>
                            )}
                        </TableCell>
                    );
                }, this)}
                <TableCell padding="none" className="w-20 md:w-20 text-center z-99">
                </TableCell>
            </TableRow>
        </TableHead>
    );
}

export default ProductsTableHead;
