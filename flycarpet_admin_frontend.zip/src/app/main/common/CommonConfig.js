import React from 'react';
import Login from '../login/Login';
const token = window.localStorage.getItem('jwt_access_token');
const CommonConfig = {
	settings: {
		layout: token == null ? {
			config: {
				navbar: {
					display: false
				},
				toolbar: {
					display: false
				},
				footer: {
					display: false
				},
				leftSidePanel: {
					display: false
				},
				rightSidePanel: {
					display: false
				}
			}
		} : {
				config: {}
			}
	},
	routes: token == null ? [
		{
			path: '/',
			component: Login
		}
	] : [
		{
			path: '/user_management',
			component: React.lazy(() => import('./usermanagement/UserManagement'))
		},
		{
			path: '/partner_commission',
			component: React.lazy(() => import('./Partner/Commission'))
		},
		{
			path: '/mailing_list',
			component: React.lazy(() => import('./MailingList/MailingList'))
		},
		{
			path: '/agency',
			component: React.lazy(() => import('./agency/Agency'))
		},
		{
			path: '/google_audience',
			component: React.lazy(() => import('./GoogleAudience'))
		},
		{
			path: '/content_landing',
			component: React.lazy(() => import('./ImageBuilder/Index'))
		},
		{
			path: '/coupon_management',
			component: React.lazy(() => import('./CouponManagement/CouponManagement'))
		},
		{
			path: '/maintenance_message_management',
			component: React.lazy(() => import('./MaintenanceMessages/index'))
		},
	]
};

export default CommonConfig;
