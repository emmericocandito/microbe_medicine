import React, { useEffect, useState, memo, useCallback } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  Modal, Backdrop, Button, TextField, TextareaAutosize,
  Grid, FormHelperText, FormControl, FormControlLabel, Select, Checkbox,
} from '@material-ui/core';
import { Autocomplete } from '@material-ui/lab';

import './custom.css';

const EditorModal = (props) => {
  const { open, extraData, onMessage: sendMessage } = props;

  const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: '2px 5px',
      minWidth: 60,
    },
    modal: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      textAlign: "center",
      maxHeight: "100vh",
      overflowY: "auto",
    },
    checkboxform: {
      display: 'block',
    },
  }));
  const classes = useStyles();

  const [openEdit, setOpenEdit] = useState(false);
  const handleCloseModal = () => {
    setOpenEdit(false);
    sendMessage({
      type: 'action',
      action: 'close',
    });
  }

  const [action, setAction] = useState('Add');
  const [partnerCommPercent, setPartnerCommPercent] = useState(0);
  const [active, setActive] = useState(false);

  const initialize = () => {
    initialState();
  }
  const initialState = () => {
    setPartnerCommPercent(0);
    setActive(false);
  }

  const setPickedState = (pData) => {
    const { extProps, active } = pData;
    const partnerCommPercent = extProps?.partnerSpecificProps?.commissionPct || 0;
    setAction('Update');
    setPartnerCommPercent(partnerCommPercent);
    setActive(active);
  }

  const handleSave = () => {
    sendMessage({
      type: 'action',
      action: action === 'Update' ? 'update' : 'save',
      extraData: {
        commissionPct: partnerCommPercent,
        active,
      }
    })
  }


  useEffect(() => {
    const data = extraData?.editData ?? null;
    if (data) {
      setPickedState(data);
    } else {
      initialState();
    }
    setOpenEdit(open);
  }, [open, extraData]);

  useEffect(() => {
    initialize();
  }, []);

  return (
    <div className="w-full flex flex-col">
      <Modal
        open={openEdit}
        onClose={handleCloseModal}
        className={classes.modal}
        closeAfterTransition
        aria-labelledby='transition-modal-title'
        aria-describedby='transition-modal-description'
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <div className={classes.paper}>
          <h2 id="server-modal-title" >{`${action} Commission Rule`}</h2>
          <Grid container justify='center' style={{ margin: '20px 5px', display: 'grid' }}>
            <FormControl required className='classes.formControl'>
              <TextField className={classes.textField} label="Commission Percent" defaultValue={partnerCommPercent} onChange={e => setPartnerCommPercent(Number(e.target.value))} />
            </FormControl>
          </Grid>
          <Grid container justify='space-around' style={{ margin: '10px 5px' }}>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="primary"
              onClick={handleSave}>{action}
            </Button>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="secondary"
              onClick={handleCloseModal}>Close
            </Button>
          </Grid>
        </div>
      </Modal>
    </div>
  );
}

export default memo(EditorModal);