import React, { memo, useEffect, useState } from 'react'

import { useAgency } from 'app/main/store/hooks'
import ActionTable from 'app/main/BasicComponents/ActionTable'

function CommissionPartnerTable(props) {

  const { getAgencyNameByCode } = useAgency();

  const { rowsData, onMessage: sendMessage } = props;
  const propColumns = [
    {
      id: 'idx',
      align: 'left',
      disablePadding: false,
      label: 'Index',
      sort: false,
      type: 'text'
    },
    {
      id: 'id',
      align: 'left',
      disablePadding: false,
      label: 'code',
      sort: true,
      type: 'text',
      show: 'hide'
    },
    {
      id: 'userName',
      align: 'left',
      disablePadding: false,
      label: 'User Name',
      sort: true,
      type: 'text'
    },
    {
      id: 'fullName',
      align: 'left',
      disablePadding: false,
      label: 'Full Name',
      sort: true,
      type: 'text'
    },
    {
      id: 'email',
      align: 'left',
      disablePadding: false,
      label: 'Email',
      sort: true,
      type: 'text'
    },
    {
      id: 'phoneNumber',
      align: 'left',
      disablePadding: false,
      label: 'Phone Number',
      sort: true,
      type: 'text'
    },
    {
      id: 'commissionPct',
      align: 'left',
      disablePadding: false,
      label: 'Commission',
      sort: true,
      type: 'text'
    },
    {
      id: 'active',
      align: 'left',
      disablePadding: false,
      label: 'Active',
      sort: false,
      type: 'boolean'
    },
    {
      id: 'edit',
      align: 'center',
      disablePadding: false,
      label: 'Edit',
      sort: false,
      type: 'button',
    },
    // {
    //   id: 'delete',
    //   align: 'center',
    //   disablePadding: false,
    //   label: 'Delete',
    //   sort: false,
    //   type: 'button'
    // },
  ];

  const [bodyRows, setBodyRows] = useState([]);

  useEffect(() => {
    if (!rowsData  || rowsData.length===0) return;
    const rows = rowsData.map((row, idx) => {
      const { id, userName, fullName, email, phoneNumber, extProps, enabled } = row;
      const commissionPct = extProps?.partnerSpecificProps?.commissionPct ?? '';
      return {
        idx: idx + 1, id, userName, fullName, email, phoneNumber, commissionPct, active: enabled,
      }
    })
    setBodyRows(rows);
  }, [rowsData]);

  const onMessage = (pMsg) => {
    if (pMsg.evtType === 'button') {
      switch (pMsg.kind) {
        case 'edit': case 'delete':
          sendMessage({
            action: pMsg.kind,
            type: pMsg.evtType,
            id: pMsg.id,
          });
          break;
        default:
      }
    } else if (pMsg.evtType === 'column') {
      sendMessage({
        action: 'edit',
        type: pMsg.evtType,
        id: pMsg.id,
      })
    }
  }

  return (
    <ActionTable
      propColumns={propColumns}
      bodyRows={bodyRows}
      onMessage={onMessage}
    />
  )
}

export default memo(CommissionPartnerTable);