import React, { useEffect, useState, memo } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  Modal, Backdrop, Button, TextField, TextareaAutosize,
  Grid, FormHelperText, FormControl, FormControlLabel, Select, Checkbox,
} from '@material-ui/core';
import { Autocomplete } from '@material-ui/lab';

import './custom.css';

import { usePackages, useAgency } from 'app/main/store/hooks';
import { useConstantValue } from 'app/main/utils/constantValue';

const FilterModal = (props) => {
  const { open, extraData, onMessage: sendMessage, isAbsolute } = props;
  // const { pageKind } = extraData;

  const { packagesData } = usePackages();
  const [packagesType, setPackagesType] = useState([]);
  useEffect(() => {
    if (packagesData.length) {
      let packagesCategories = [{ label: '', value: '' }];
      packagesData.forEach(pack => {
        packagesCategories.push({
          label: pack.name,
          value: pack.code,
        })
      });
      setPackagesType(packagesCategories);
    }
  }, [packagesData]);

  const { getAgencyBySite } = useAgency();
  const [listAgencies, setListAgencies] = useState([]);
  useEffect(async () => {
    let agencies = getAgencyBySite('Package');
    if (agencies.length) {
      let listAgency = [{ label: '', value: '' }];
      agencies.forEach(item => {
        listAgency.push({
          label: item.uniqueName,
          value: item.code,
        })
      });
      setListAgencies(listAgency);
    }
  }, [getAgencyBySite])

  const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: '2px 5px',
      minWidth: 60,
    },
    modal: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      textAlign: "center",
      maxHeight: "100vh",
      overflowY: "auto",
    },
    checkboxform: {
      display: 'block',
    },
  }));
  const classes = useStyles();

  const [openFilter, setOpenFilter] = useState(false);
  const handleCloseModal = () => {
    setOpenFilter(false);
    sendMessage({
      type: 'action',
      action: 'close',
    });
  }

  const [packageId, setPackageId] = useState('');
  const [packCategCode, setPackCategCode] = useState('');
  const [agencyCode, setAgencyCode] = useState(null);
  const [absoluteComm, setAbsoluteComm] = useState(isAbsolute);
  const [active, setActive] = useState(false);

  const { constantCategoryTypes, getLabelCategoryTypesFromItem, getValueCategoryTypesFromItem, constPageKinds } = useConstantValue();
  const optionsCateogryTypes = {
    options: constantCategoryTypes,
    getOptionLabel: (option) => getLabelCategoryTypesFromItem(option)
  }
  const [categoryType, setCategoryType] = useState(null);

  const initialize = () => {
    initialState();
  }
  const initialState = () => {
    setPackCategCode('');
    setAgencyCode(null);
    setAbsoluteComm(isAbsolute);
    setActive('null');
  }

  const handleFilter = () => {
    const action = 'filter';
    sendMessage({
      type: 'action',
      action,
      extraData: {
        packCategCode,
        agencyCode,
        absoluteComm,
        active,
      }
    })
  }

  function handleChangePackage(event) {
    if (event.target.value !== '') {
      setPackCategCode(event.target.value);
    }
    else {
      setPackCategCode(null);
    }
  }

  function handleChangeAgency(event) {
    if (event.target.value !== '') {
      setAgencyCode(event.target.value);
    }
    else {
      setAgencyCode(null);
    }
  }

  useEffect(() => {
    // initialState();
    setOpenFilter(open);
  }, [open]);

  useEffect(() => {
    initialize();
  }, []);

  return (
    <div className="w-full flex flex-col">
      <Modal
        open={openFilter}
        onClose={handleCloseModal}
        className={classes.modal}
        closeAfterTransition
        aria-labelledby='transition-modal-title'
        aria-describedby='transition-modal-description'
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Grid className={classes.paper}>
          <h2 id="server-modal-title" >{`Filter Commission Rule`}</h2>
          <Grid container justify='space-between' style={{ margin: '20px 5px', display: 'grid' }}>
            <FormControl required className={classes.formControl}>
              <FormHelperText>Package Type</FormHelperText>
              <Select
                native
                onChange={handleChangePackage}
                value={packCategCode === null ? '' : packCategCode}
                inputProps={{
                  id: 'age-native-required',
                }}
              >
                {
                  packagesType.map((type, i) =>
                    <option key={i} value={type.value}>{type.label}</option>
                  )
                }
              </Select>
            </FormControl>
            <FormControl required className={classes.formControl}>
              <FormHelperText>Agency Code</FormHelperText>
              <Select
                native
                onChange={handleChangeAgency}
                value={agencyCode === null ? '' : agencyCode}
                inputProps={{
                  id: 'age-native-required',
                }}
              >
                {
                  listAgencies.map((type, i) =>
                    <option key={i} value={type.value}>{type.label}</option>
                  )
                }
              </Select>
            </FormControl>
            <FormControl required className={classes.formControl}>
              <FormHelperText>Active State</FormHelperText>
              <Select
                native
                onChange={ev => setActive(ev.target.value)}
                value={active}
                inputProps={{
                  id: 'age-native-required',
                }}
              >
                <option aria-label='None' value={'null'}>All</option>
                <option value={true}>Active</option>
                <option value={false}>Unactive</option>
              </Select>
            </FormControl>
          </Grid>
          <Grid container justify='space-around' style={{ margin: '10px 5px' }}>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="primary"
              onClick={handleFilter}>Filter
            </Button>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="secondary"
              onClick={handleCloseModal}>Close
            </Button>
          </Grid>
        </Grid>
      </Modal>
    </div>
  );
}

export default memo(FilterModal);