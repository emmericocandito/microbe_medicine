import React, { memo, useEffect, useState } from 'react'
import ActionTable from 'app/main/BasicComponents/ActionTable'

function GoogleAudienceTable(props) {
  const { rowsData, onMessage: sendMessage } = props;
  const propColumns = [
    {
      id: 'idx',
      align: 'left',
      disablePadding: false,
      label: 'Index',
      sort: false,
      type: 'text'
    },
    {
      id: 'id',
      align: 'left',
      disablePadding: false,
      label: 'Audience Code',
      sort: true,
      type: 'text',
      show: 'text',
    },
    {
      id: 'name',
      align: 'center',
      disablePadding: false,
      label: 'Name',
      sort: true,
      type: 'text'
    },
    {
      id: 'add',
      align: 'center',
      disablePadding: false,
      label: 'Add',
      sort: false,
      type: 'button',
    },
    // {
    //   id: 'edit',
    //   align: 'center',
    //   disablePadding: false,
    //   label: 'Edit',
    //   sort: false,
    //   type: 'button',
    // },
    // {
    //   id: 'delete',
    //   align: 'center',
    //   disablePadding: false,
    //   label: 'Delete',
    //   sort: false,
    //   type: 'button'
    // },
  ]

  const [bodyRows, setBodyRows] = useState([]);

  const initialize = () => {
    setBodyRows([]);
  }

  useEffect(() => {
    initialize();
  }, [])

  const formatRowData = (pOrignData) => {
    return pOrignData.map((row, idx) => {
      const { id, name, description } = row;
      return { idx: idx + 1, id, name, description }
    })
  }
  useEffect(() => {
    if (!rowsData) return;    
    setBodyRows(formatRowData(rowsData));
  }, [rowsData]);

  const onMessage = (pMsg) => {
    if (pMsg.evtType === 'button') {
      switch (pMsg.kind) {
        case 'edit': case 'delete': case 'add':
          sendMessage({
            action: pMsg.kind,
            id: pMsg.id,
          });
          break;
        default:
      }
    } else if (pMsg.evtType === 'column') {
      sendMessage({
        action: 'edit',
        id: pMsg.id,
      })
    } else if (pMsg.evtType === 'loadMore') {
      sendMessage({
        action: pMsg.evtType,
        extraData: pMsg.extraData
      })
    }
  }

  return (
    <ActionTable
      propColumns={propColumns}
      bodyRows={bodyRows}
      onMessage={onMessage}
    />
  )
}

export default memo(GoogleAudienceTable);