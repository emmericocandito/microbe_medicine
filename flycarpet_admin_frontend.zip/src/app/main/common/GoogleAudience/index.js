import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from 'app/main/store';
import AudiencePageContent from './GoogleAudiencePageContent';
import AudienceHeader from './GoogleAudiencePageHeader';
import { TableStatusContextProvider } from 'app/main/Context/tableStatusContext';

function Audience() {
  return (
    <TableStatusContextProvider>
      <FusePageCarded
        classes={{
          content: 'flex',
          contentCard: 'overflow-hidden',
          header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
        }}
        header={<AudienceHeader />}
        content={<AudiencePageContent />}
        innerScroll
      />
    </TableStatusContextProvider>
  );
}

export default withReducer('BasicData', reducer)(Audience);