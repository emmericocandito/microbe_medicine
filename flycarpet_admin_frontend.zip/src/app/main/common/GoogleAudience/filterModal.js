import React, { useEffect, useState, memo } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  Modal, Backdrop, Button, TextField, TextareaAutosize,
  Grid, FormHelperText, FormControl, FormControlLabel, Select, Checkbox,
} from '@material-ui/core';


const FilterModal = (props) => {
  const { open, extraData, onMessage: sendMessage } = props;

  const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: '2px 5px',
      minWidth: 60,
    },
    modal: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      textAlign: "center",
      maxHeight: "100vh",
      overflowY: "auto",
    },
    checkboxform: {
      display: 'block',
    },
  }));
  const classes = useStyles();

  const [openFilter, setOpenFilter] = useState(false);
  const handleCloseModal = () => {
    setOpenFilter(false);
    sendMessage({
      type: 'action',
      action: 'close',
    });
  }

  const [title, setTitle] = useState('');
  // const [active, setActive] = useState(null);

  const initialize = () => {
    initialState();
  }
  const initialState = () => {
    setTitle('');
    // setActive(null);
  }

  const handleFilter = () => {
    const action = 'filter';
    sendMessage({
      type: 'action',
      action,
      extraData: {
        title,
        // active,
      }
    })
  }

  useEffect(() => {
    initialState();
    setOpenFilter(open);
  }, [open]);

  useEffect(() => {
    initialize();
  }, []);

  return (
    <div className="w-full flex flex-col">
      <Modal
        open={openFilter}
        onClose={handleCloseModal}
        className={classes.modal}
        closeAfterTransition
        aria-labelledby='transition-modal-title'
        aria-describedby='transition-modal-description'
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <div className={classes.paper}>
          <h2 id="server-modal-title" >Airport Name Filter</h2>
          <Grid container justify='space-between' style={{ margin: '20px 5px', display: 'grid' }}>
            {/* <FormControl >
              <TextField className='min-w-256' label='Code' defaultValue={code} onChange={ev => setCode(ev.target.value)} />
            </FormControl> */}
            <FormControl className='mt-10'>
              <TextField className='min-w-256' label='Title' defaultValue={title} onChange={ev => setTitle(ev.target.value)} />
            </FormControl>
            {/* <FormControlLabel
              control={
                <Checkbox
                  checked={active}
                  onChange={e => { setActive(e.target.checked) }}
                  name='checkedB'
                  color='primary'
                />
              }
              label='Active'
              className={classes.checkboxform}
            /> */}
          </Grid>
          <Grid container justify='space-around' style={{ margin: '10px 5px' }}>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="primary"
              onClick={handleFilter}>Filter
            </Button>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="secondary"
              onClick={handleCloseModal}>Close
            </Button>
          </Grid>
        </div>
      </Modal>
    </div>
  );
}

export default memo(FilterModal);