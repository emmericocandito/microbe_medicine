import React, { useEffect, useState, memo } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  Modal, Backdrop, Button, TextField, TextareaAutosize,
  Grid, FormHelperText, FormControl, FormControlLabel, Select, Checkbox,
} from '@material-ui/core';
import { Autocomplete } from '@material-ui/lab';

const AddExtraModal = (props) => {
  const { open, extraData, onMessage: sendMessage } = props;

  const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: '2px 5px',
      minWidth: 60,
    },
    modal: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      textAlign: "center",
      maxHeight: "100vh",
      overflowY: "auto",
    },
    checkboxform: {
      display: 'block',
    },
  }));
  const classes = useStyles();

  const [kind, setKind] = useState('add');
  const [openEdit, setOpenEdit] = useState(false);
  const handleCloseModal = () => {
    setOpenEdit(false);
    sendMessage({
      type: 'action',
      action: 'close',
    });
  }

  const [id, setId] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');

  const initialize = () => {
    initialState();
  }
  const initialState = () => {
    setKind('add');
    setId('');
    setEmail('');
    setPhone('');
    // setActive(false);
  }

  const handleSave = () => {
    const action = 'addExtraInfo';
    sendMessage({
      type: 'action',
      action,
      extraData: {
        id,
        email,
        phone,
        // active,
      }
    })
  }

  // const handleChangeCode = (ev) => {
  //   const code = ev.target.value.replace(/ /g,'');
  //   setId(code);
  // }

  useEffect(() => {
    const data = extraData?.editData ?? null;
    if (data) {
      setKind('update');
      setId(data.id);
      // setEmail(data.name);
      // setPhone(data.phone);
      // setActive(data.active);
    } else {
      initialState();
    }
    setOpenEdit(open);
  }, [open, extraData]);

  useEffect(() => {
    initialize();
  }, []);

  return (
    <div className="w-full flex flex-col">
      <Modal
        open={openEdit}
        onClose={handleCloseModal}
        className={classes.modal}
        closeAfterTransition
        aria-labelledby='transition-modal-title'
        aria-describedby='transition-modal-description'
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <div className={classes.paper}>
          <h2 id="server-modal-title" >Audience Editor</h2>
          <Grid container justify='space-between' style={{ margin: '20px 5px', display: 'grid' }}>
            {/* <FormControl >
              <TextField className='min-w-256' label='Code' defaultValue={id} inputProps={{ readOnly: kind === 'update' }} onChange={ev => handleChangeCode(ev)} />
            </FormControl> */}
            <FormControl className='mt-10'>
              <TextField className='min-w-256' label='Email' defaultValue={email} onChange={ev => setEmail(ev.target.value)} />
            </FormControl>
            <FormControl className='mt-10'>
              <TextField className='min-w-256' label='Phone' defaultValue={phone} onChange={ev => setPhone(ev.target.value)} />
            </FormControl>
            {/* <FormControlLabel
              control={
                <Checkbox
                  checked={active}
                  onChange={e => { setActive(e.target.checked) }}
                  name='checkedB'
                  color='primary'
                />
              }
              label='Active'
              className={classes.checkboxform}
            /> */}
          </Grid>
          <Grid container justify='space-around' style={{ margin: '10px 5px' }}>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="primary"
              onClick={handleSave}>SAVE
            </Button>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="secondary"
              onClick={handleCloseModal}>Close
            </Button>
          </Grid>
        </div>
      </Modal>
    </div>
  );
}

export default memo(AddExtraModal);