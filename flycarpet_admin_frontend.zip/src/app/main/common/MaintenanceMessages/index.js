import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from 'app/main/store';
import MaintenanceMessagePageContent from './MaintenanceMessagePageContent';
import MaintenanceMessagePageHeader from './MaintenanceMessagePageHeader';
import { TableStatusContextProvider } from 'app/main/Context/tableStatusContext';

function AppDealSubcategory() {
  return (
    <TableStatusContextProvider>
      <FusePageCarded
        classes={{
          content: 'flex',
          contentCard: 'overflow-hidden',
          header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
        }}
        header={<MaintenanceMessagePageHeader />}
        content={<MaintenanceMessagePageContent />}
        innerScroll
      />
    </TableStatusContextProvider>
  );
}

export default withReducer('BasicData', reducer)(AppDealSubcategory);