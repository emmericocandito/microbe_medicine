import React, { useEffect, useState, memo, useCallback } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  Modal, Backdrop, Button, TextField, TextareaAutosize,
  Grid, FormHelperText, FormGroup, FormControl, FormControlLabel, Select, Checkbox,
} from '@material-ui/core';
import { Autocomplete } from '@material-ui/lab';
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicExtended from "ckeditor5-build-classic-extended";
import { MultiOperations, MultiRoutes } from "app/main/BasicComponents/MultiSelection";
import { useConstantValue } from 'app/main/utils/constantValue';

import "./editor.css";

const EditorModal = (props) => {
  const { open, extraData, onMessage: sendMessage } = props;

  const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: '2px 5px',
      minWidth: 60,
    },
    modal: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      textAlign: "center",
      maxHeight: "100vh",
      overflowY: "auto",
    },
    checkboxform: {
      display: 'block',
    },
    groupLabel: {
      width: '200px',
    },
  }));
  const classes = useStyles();

  const {constantKindsSites, getSiteNameFromID} = useConstantValue();

  const [kind, setKind] = useState('create');
  const [openEdit, setOpenEdit] = useState(false);
  const handleCloseModal = () => {
    setOpenEdit(false);
    sendMessage({
      type: 'action',
      action: 'close',
    });
  }

  const defaultRoute = 'allPages';
  const [operations, setOperations] = useState([]);
  const [allTargets, setAllTargets] = useState([]);
  const [target, setTarget] = useState({});
  const [title, setTitle] = useState('');
  const [body, setBody] = useState(null);
  const [active, setActive] = useState(false);

  const initialize = () => {
    initialState();
  }
  const initialState = () => {
    setKind('create');
    setTarget({});
    setTitle('');
    setBody('');
    setActive(false);
  }

  const handleSave = () => {
    const action = extraData?.editData ? 'update' : 'create';
    sendMessage({
      type: 'action',
      action,
      extraData: {
        target,
        message: {title, body},
        active,
      }
    })
  }

  const checkedListTarget = (pGroup) => {
    return operations.indexOf(item => item === pGroup);
  }

  const getCheckedRoutes = (pGroup) => {
    let checkedRoutes = [];
    if(checkedListTarget(pGroup)) {
      checkedRoutes = target[pGroup] || [defaultRoute];
    }
    return checkedRoutes;
  }

  const getListRouteGroup = (pGroup) => {    
    const allRoutes = extraData?.allRoutes;
    let listRoutes = [];
    if(allRoutes.hasOwnProperty(pGroup)) {
      listRoutes = allRoutes[pGroup];
    }
    return listRoutes?.map((route) => ({code: route, name: route})) ?? [];
  }

  const receiveMessageFromMultiRoute = (pType, pMsg) => {
    switch (pType) {
      case 'changedCheckedItems':
        if(pMsg.items && pMsg.id) {
          let oldTargets = {...target};
          oldTargets[pMsg.id] = pMsg.items;
          setTarget(oldTargets);
        }
				break;
			default:
				setTarget({});
		}
  };

  const receiveMessageFromMultiOperations = useCallback((pType, pMsg) => {
    switch(pType) {
      case 'changedCheckedItems':
        setOperations(pMsg.items);
        break;
      default:
        setOperations([]);
    }
  }, [])

  useEffect(() => {
    const listTargets = Object.entries(target).filter(([key]) => operations.includes(key));
    operations.forEach(site => {
      let isExist = false;
      if(listTargets.some(target => target[0] === site)) isExist = true;
      if(!isExist) listTargets.push([site, [defaultRoute]]);
    })
    if(listTargets.length>0) {
      const newTargets = Object.fromEntries(listTargets);
      setTarget(newTargets);
    } else {
      setTarget({});
    }
  }, [operations])

  useEffect(() => {
    const allRoutes = extraData?.allRoutes;
    setAllTargets(Object.entries(allRoutes));
    const data = extraData?.editData ?? null;
    if (data) {
      setOperations(Object.entries(data.target ?? {}).map(([key, routes]) => key));
      setKind('update');
      setTarget(data.target ?? '');
      setTitle(data.message?.title ?? '');
      setBody(data.message?.body ?? "");
      setActive(data.active);
    } else {
      initialState();
    }
    setOpenEdit(open);
  }, [open, extraData]);

  useEffect(() => {
    initialize();
  }, []);

  return (
    <div className="w-full flex flex-col">
      <Modal
        open={openEdit}
        onClose={handleCloseModal}
        className={classes.modal}
        closeAfterTransition
        aria-labelledby='transition-modal-title'
        aria-describedby='transition-modal-description'
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <div className={classes.paper}>
          <h2 id="server-modal-title" >Maintenance Message Editor</h2>
          <Grid container justify='space-between' style={{ margin: '20px 5px', display: 'grid' }}>
            <MultiOperations 
              loading={false}
              title="operations"
              checkedItems={operations}
              sourceList={constantKindsSites}
              onMessage={receiveMessageFromMultiOperations}
            />
            {operations.map(code => {
              return <Grid container justify='flex-start' style={{ margin: '5px 5px', display: 'flex' }}  key={code}>
                <FormHelperText className={classes.groupLabel}>{code}</FormHelperText>
                <FormGroup >
                  <MultiRoutes
                    id={code}
                    loading={false}
                    title={`page lists on ${code}`}
                    checkedItems={getCheckedRoutes(code)}
                    sourceList={getListRouteGroup(code)}
                    onMessage={receiveMessageFromMultiRoute}
                  />
                </FormGroup>
              </Grid>
            })}
            
            <FormControl className='my-10'>
              <TextField className='min-w-256' label='Title' defaultValue={title} onChange={ev => setTitle(ev.target.value)} />
            </FormControl>
            <FormControl required className={classes.formControl}>
              <FormHelperText>Content</FormHelperText>
              <div className='static-text-modal'>
                <CKEditor
                  editor={ClassicExtended}
                  data={body || ''}
                  config={
                    {
                      mediaEmbed: {
                        previewsInData: true
                      },
                    }
                  }
                  onChange={(event, editor) => {
                    const data = editor.getData();
                    setBody(data);
                  }}
                />
              </div>
            </FormControl>
            <FormControlLabel
              control={
                <Checkbox
                  checked={active}
                  onChange={e => { setActive(e.target.checked) }}
                  name='checkedB'
                  color='primary'
                />
              }
              label='Active'
              className={classes.checkboxform}
            />
          </Grid>
          <Grid container justify='space-around' style={{ margin: '10px 5px' }}>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="primary"
              onClick={handleSave}>SAVE
            </Button>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="secondary"
              onClick={handleCloseModal}>Close
            </Button>
          </Grid>
        </div>
      </Modal>
    </div>
  );
}

export default memo(EditorModal);