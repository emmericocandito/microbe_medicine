import React, { useEffect, useState, memo, useContext } from 'react';
import FuseLoading from '@fuse/core/FuseLoading';

import {
  Button
} from '@material-ui/core'
import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import SearchIcon from '@material-ui/icons/Search';

import { MultiActionModal } from 'app/main/BasicComponents/customModal';
import MaintenanceMessageTable from './MaintenanceMessageTable';
import EditorModal from './editorModal';
import FilterModal from './filterModal';

import { useMaintenaceMessage, useRoutePage } from 'app/main/store/hooks'

import { TableStatusContext } from 'app/main/Context/tableStatusContext';
const numberLoadingItems = 100;

function MaintenanceMessagePageContent(props) {

  const {
    allItems: allItemsRoutePage,

    fetchAllItems: fetchAllItemsRoutePage,
  } = useRoutePage();

  const {
    loading,
    total,
    allItems,

    getItemByKey,

    fetchAllItems,
    searchItems,
    createItem,
    saveItem,
    deleteItem,
  } = useMaintenaceMessage();

  const { initTableStatus, setStatusTotal, statusRowsPerPage } = useContext(TableStatusContext);

  const [showingRows, setShowingRows] = useState([]);
  const [activeItemId, setActiveItemId] = useState('');
  const [editData, setEditData] = useState(null);

  const [titleActionModal, setTitleActionModal] = useState('WARNING !');
  const [wordActionModal, setWordActionModal] = useState('');
  const [openActionModal, setOpenActionModal] = useState(false);
  const [actionsModal, setActionsModal] = useState([
    { label: 'Close', code: 'close' }
  ])
  const showActionModal = (pOption) => {
    setTitleActionModal(pOption.title);
    setWordActionModal(pOption.word);
    setActionsModal(pOption.actions);
    setOpenActionModal(true);
  };
  const onMessageActionModal = (pType, pMsg) => {
    if (pType === 'selectAction') {
      switch (pMsg.code) {
        case 'agreeDelete':
          deleteRowInstance(activeItemId);
          break;
        case 'close':
          break;
        default:
          console.log(`missed the handle of ${pType}`);
      }
      setOpenActionModal(false);
    } else if (pType === 'closeModal') {
      setOpenActionModal(false);
    }
  }
  const deleteRowInstance = async (pID) => {
    const data = { id: pID };
    const response = await deleteItem(data);
    if (response.payload.status !== 'success') {
      const options = {
        ...response.payload.data,
        actions: [
          { label: 'Close', code: 'close' }
        ]
      }
      showActionModal(options);
    }
  }

  const [openEditModal, setOpenEditModal] = useState(false);
  const onMessageEditModal = (pMsg) => {
    if (pMsg.type === 'action') {
      switch (pMsg.action) {
        case 'create': case 'update':
          saveRowInstance(pMsg.extraData);
          break;
        case 'confirmDelete':
          confirmDelete({ id: pMsg.id });
          break;
        case 'close':
          break;
        default:
          console.log(`missed the handle of ${pMsg.type}`)
      }

      setOpenEditModal(false);
    }
  }
  const saveRowInstance = async (pData) => {
    const data = { ...pData };
    if (activeItemId === '') { // create
      const response = await createItem(data);
      if (response.payload.status !== 'success') {
        const options = {
          ...response.payload.data,
          actions: [
            { label: 'Close', code: 'close' }
          ]
        }
        showActionModal(options);
      }
    } else { //update
      const response = await saveItem({ id: activeItemId, data });
      if (response.payload.status !== 'success') {
        const options = {
          ...response.payload.data,
          actions: [
            { label: 'Close', code: 'close' }
          ]
        }
        showActionModal(options);
      }
      setActiveItemId('');
    }
  }

  const [searchOption, setSearchOption] = useState(null);
  const [openFilterModal, setOpenFilterModal] = useState(false);
  const onMessageFilterModal = (pMsg) => {
    if (pMsg.type === 'action') {
      switch (pMsg.action) {
        case 'filter':
          searchByOption({ data: pMsg.extraData });
          break;
        case 'close':
          break;
        default:
          console.log(`missed the handle of ${pMsg.type}`)
      }
      setOpenFilterModal(false);
    }
  }
  const searchRowInstance = async (pOption) => {
    const response = await searchItems(pOption);
    if (response.payload.status !== 'success') {
      const options = {
        ...response.payload.data,
        actions: [
          { label: 'Close', code: 'close' }
        ]
      }
      showActionModal(options);
    }
  }
  const searchByOption = (pData) => {
    initTableStatus();
    let option = {
      ...pData,
      from: 1,
      to: numberLoadingItems,
    };
    setSearchOption(option);
    searchRowInstance(option);
  }

  const addItem = () => {
    setActiveItemId('');
    setEditData(null);
    setOpenEditModal(true);
  }
  const editItem = (pID) => {
    setActiveItemId(pID);
    // const activeItem = getItemByKey('id', pID);
    const activeItem = allItems[0];
    setEditData(activeItem);
    setOpenEditModal(true);
  }
  const confirmDelete = (pData) => {
    if (pData.id !== '' && pData.id !== null) {
      setActiveItemId(pData.id);
      showActionModal({
        title: 'NOTICE !',
        word: 'Do you want to drop the airport ?',
        actions: [
          { label: 'Ok', code: 'agreeDelete' },
          { label: 'Cancel', code: 'close' }
        ]
      });
    }
  }
  const onMessageTable = (pMsg) => {
    if (pMsg.action === 'edit') {
      editItem(pMsg.id);
    } else if (pMsg.action === 'delete') {
      confirmDelete(pMsg);
    } else if (pMsg.action === 'loadMore') {
      if (searchOption === null) {
        fetchInstances({
          from: allItems.length,
          to: allItems.length + Math.max(numberLoadingItems, statusRowsPerPage) - 1,
        });
      } else {
        searchRowInstance({
          ...searchOption,
          from: searchOption.to,
          to: searchOption.to + Math.max(numberLoadingItems, statusRowsPerPage) - 1,
        })
      }
    } else {
      console.log(`please add the handler for ${pMsg.action} action`);
    }
  }

  useEffect(() => {
    setShowingRows(allItems);
    setStatusTotal(total);
  }, [allItems])


  const fetchInstances = async (pOption) => {
    const response = await fetchAllItems(pOption);
    if (response.payload.status !== 'success') {
      const options = {
        ...response.payload.data,
        actions: [
          { label: 'Close', code: 'close' }
        ]
      }
      showActionModal(options);
    }
  }
  const initialize = () => {
    fetchAllItemsRoutePage();
    fetchInstances({
      from: 0,
      to: numberLoadingItems
    });
  }
  useEffect(() => {
    initialize();
  }, []);

  if (loading) {
    return <FuseLoading />
  }

  return (
    <div className='w-full flex flex-col'>
      <div>
        {/* <Button
          className="whitespace-no-wrap normal-case"
          variant="contained"
          color="secondary"
          style={{ float: 'right', margin: '15px 5px' }}
          onClick={() => setOpenFilterModal(true)}
        >
          <span className="hidden sm:flex">
            <SearchIcon />
            Filter
          </span>
          <span className="flex sm:hidden">
            <SearchIcon />
          </span>
        </Button> */}
        {/* <Button
          className='whitespace-no-wrape normal-case'
          variant='contained'
          color='secondary'
          style={{ float: 'right', margin: '15px 5px' }}
          onClick={() => addItem()}
        >
          <span className="hidden sm:flex">
            <AddCircleOutlineIcon />
            New
          </span>
          <span className="flex sm:hidden">
            <AddCircleOutlineIcon />
          </span>
        </Button> */}
      </div>
      <MaintenanceMessageTable
        rowsData={showingRows}
        onMessage={onMessageTable}
      />
      <MultiActionModal
        open={openActionModal}
        title={titleActionModal}
        description={wordActionModal}
        actionList={actionsModal}
        onMessage={onMessageActionModal}
      />
      <EditorModal
        open={openEditModal}
        extraData={{ editData, allRoutes: allItemsRoutePage }}
        onMessage={onMessageEditModal}
      />
      <FilterModal
        open={openFilterModal}
        extraData={null}
        onMessage={onMessageFilterModal}
      />
    </div>
  )
}

export default memo(MaintenanceMessagePageContent);