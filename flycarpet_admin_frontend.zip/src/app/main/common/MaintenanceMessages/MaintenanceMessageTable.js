import React, { memo, useEffect, useState } from 'react'
import ActionTable from 'app/main/BasicComponents/ActionTable'
import {Chip} from '@material-ui/core';

function MaintenanceMessageTable(props) {
  const { rowsData, onMessage: sendMessage } = props;
  const propColumns = [
    {
      id: 'idx',
      align: 'left',
      disablePadding: false,
      label: 'Index',
      sort: false,
      type: 'text'
    },
    {
      id: 'id',
      align: 'left',
      disablePadding: false,
      label: 'Airport Code',
      sort: true,
      type: 'text',
      show: 'hide',
    },
    {
      id: 'target',
      align: 'center',
      disablePadding: false,
      label: 'Target',
      sort: false,
      type: 'component'
    },
    {
      id: 'title',
      align: 'center',
      disablePadding: false,
      label: 'Title',
      sort: false,
      type: 'text'
    },
    {
      id: 'body',
      align: 'center',
      disablePadding: false,
      label: 'Content',
      sort: false,
      type: 'component'
    },
    {
      id: 'active',
      align: 'center',
      disablePadding: false,
      label: 'Active',
      sort: false,
      type: 'boolean',
    },
    {
      id: 'edit',
      align: 'center',
      disablePadding: false,
      label: 'Edit',
      sort: false,
      type: 'button',
    },
    // {
    //   id: 'delete',
    //   align: 'center',
    //   disablePadding: false,
    //   label: 'Delete',
    //   sort: false,
    //   type: 'button'
    // },
  ]

  const [bodyRows, setBodyRows] = useState([]);

  const initialize = () => {
    setBodyRows([]);
  }

  useEffect(() => {
    initialize();
  }, [])

  const domTarget = (pData) => {
    const targetList = Object.entries(pData ?? {}).map(([site, pages]) => {
      return pages.map(page => {
        const label = `${site} > ${page}`;
        return <Chip
                className='mb-1 m-auto'
                variant="outlined"
                label={label} 
                key={label} 
                style={{
                  display: 'block',
                  width: 'fit-content',
                  height: '20px',
                  margin: '1px',
                  color: 'white',
			            background: '#4CAF50'
                }}
              />
      });
    })
    return targetList;
  }
  const domContent = (pData) => {
    return <div 
            className='ellipsisDiv' 
            dangerouslySetInnerHTML={{ __html: pData ?? '' }}
          />
  }

  const formatRowData = (pOrignData) => {
    return pOrignData.map((row, idx) => {
      const { target, message, active } = row;
      const {title, body} = message ?? {title: '', body: ''};
      return { idx: idx + 1, id: idx + 1, target: domTarget(target), title, body: domContent(body), active }
    })
  }
  useEffect(() => {
    if (!rowsData) return;    
    setBodyRows(formatRowData(rowsData));
  }, [rowsData]);

  const onMessage = (pMsg) => {
    if (pMsg.evtType === 'button') {
      switch (pMsg.kind) {
        case 'edit': case 'delete':
          sendMessage({
            action: pMsg.kind,
            id: pMsg.id,
          });
          break;
        default:
      }
    } else if (pMsg.evtType === 'column') {
      sendMessage({
        action: 'edit',
        id: pMsg.id,
      })
    } else if (pMsg.evtType === 'loadMore') {
      sendMessage({
        action: pMsg.evtType,
        extraData: pMsg.extraData
      })
    }
  }

  return (
    <ActionTable
      propColumns={propColumns}
      bodyRows={bodyRows}
      onMessage={onMessage}
    />
  )
}

export default memo(MaintenanceMessageTable);