import { makeStyles } from '@material-ui/core/styles';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Tooltip from '@material-ui/core/Tooltip';
import React from 'react';

const rows = [
    {
        id: 'agency',
        align: 'left',
        disablePadding: false,
        label: 'AgencyKey',
        sort: true,
    },
    {
        id: 'logoUrls',
        align: 'center',
        disablePadding: false,
        label: 'Logo',
        sort: true,
    },
    {
        id: 'topSlider',
        align: 'center',
        disablePadding: false,
        label: 'Top Slider',
        sort: true,
    },
    {
        id: 'topBanner',
        align: 'center',
        disablePadding: false,
        label: 'Top Banner',
        sort: true,
    },
    {
        id: 'middleBanner',
        align: 'center',
        disablePadding: false,
        label: 'Middle Banner',
        sort: true,
    },
    {
        id: 'nameTranslationEng',
        align: 'left',
        disablePadding: false,
        label: 'nameTranslationEng',
        sort: true
    },
    {
        id: 'nameTranslationRus',
        align: 'left',
        disablePadding: false,
        label: 'nameTranslationRus',
        sort: true
    },
    {
        id: 'nameTranslationHeb',
        align: 'right',
        disablePadding: false,
        label: 'nameTranslationHeb',
        sort: true
    },
    {
        id: 'nameTranslationArb',
        align: 'right',
        disablePadding: false,
        label: 'nameTranslationArb',
        sort: true
    },
    {
        id: 'phoneNumber',
        align: 'left',
        disablePadding: false,
        label: 'phoneNumber',
        sort: true
    },
    {
        id: 'whatsappAddress',
        align: 'left',
        disablePadding: false,
        label: 'whatsappAddress',
        sort: true
    },
    {
        id: 'emailAddress',
        align: 'left',
        disablePadding: false,
        label: 'emailAddress',
        sort: true
    },
    {
        id: 'active',
        align: 'left',
        disablePadding: false,
        label: 'Active',
        sort: true
    },
    {
        id: 'action',
        align: 'center',
        disablePadding: false,
        label: 'Edit',
        sort: true
    },
    {
        id: 'action',
        align: 'center',
        disablePadding: false,
        label: 'Delete',
        sort: true
    }

];

function ProductsTableHead(props) {

    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };

    return (
        <TableHead>
            <TableRow className="h-64">
                <TableCell padding="none" className="w-20 md:w-20 text-center z-99">
                </TableCell>
                {rows.map((row, i) => {
                    return (
                        <TableCell
                            className="p-4 md:p-16 w-224"
                            key={i}
                            align={row.align}
                            padding={row.disablePadding ? 'none' : 'default'}
                            sortDirection={props.order.id === row.id ? props.order.direction : false}
                        >
                            {row.sort && (
                                <Tooltip
                                    title="Sort"
                                    placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                    enterDelay={300}
                                >
                                    <TableSortLabel
                                        active={props.order.id === row.id}
                                        direction={props.order.direction}
                                        onClick={createSortHandler(row.id)}
                                    >
                                        {row.label}
                                    </TableSortLabel>
                                </Tooltip>
                            )}
                        </TableCell>
                    );
                }, this)}
            </TableRow>
        </TableHead>
    );
}

export default ProductsTableHead;
