import FuseScrollbars from '@fuse/core/FuseScrollbars';
import _ from '@lodash';
import axios from 'axios';
import { Radio, RadioGroup, FormLabel, Checkbox, Table, TableBody, TableCell, TablePagination, TableRow,
	Modal, Backdrop, Fade, Grid, TextField, TextareaAutosize, Button, FormControl, FormHelperText,
	FormControlLabel, Select, Switch } from '@material-ui/core';
import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import FuseLoading from '@fuse/core/FuseLoading';
import AgencyTableHead from './AgencyContentTableHead';
import { makeStyles } from '@material-ui/core/styles';
import SearchIcon from '@material-ui/icons/Search';
import ImageUploader from "react-images-upload";
import "react-responsive-carousel/lib/styles/carousel.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';
// import ColorPicker from 'material-ui-color-picker'
import { ColorPicker, createColor, getCssColor } from 'material-ui-color';
import { LEFT } from 'react-swipeable';
import AddMultiImages from 'app/main/BasicComponents/AddMultiImages';
import SubjectsCustomFooter from './subjectsCustomFooter';
import { MultiDealTypesDomestic, MultiDealTypesPackage } from 'app/main/BasicComponents/MultiSelection';

import { useDomesticDealCategory, useDealTypesPackage } from 'app/main/store/hooks';
import { baseURL } from '../../utils';

function AgencyContentTable(props) {
	const operationKey = ['package', 'domestic', 'camingo'];
	const useStyles = makeStyles((theme) => ({
		formControl: {
			// margin: theme.spacing(1),
			minWidth: 120,
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			minWidth: 200,
			maxHeight: "100vh",
			overflowY: "auto",
			maxWidth: '800px',
		},
		button_group: {
			textAlign: 'center',
			padding: 30,
		},
		buttons: {
			marginRight: '10px'
		},
		checkboxform: {
			marginLeft: '-10px'
		},
		textfield: {
			width: '100%',
			padding: '5px'
		},
		deleteImage: {
			position: 'absolute',
			top: '1px',
			right: '7px',
			color: '#fff',
			background: '#ff4081',
			borderRadius: '50%',
			textAign: 'center',
			cursor: 'pointer',
			fontSize: '17px',
			fontWeight: 'bold',
			lineHeight: '20px',
			width: '20px',
			height: '20px'
		},
		bgColor: {
			color: '#000',
			width: '150px'
		},
		shadowBorder: {
			border: '2px solid #00000008',
			boxShadow: '0 0 15px #00000014',
			borderRadius: '15px',
			marginTop: '5px',
		}
	}));
	const classes = useStyles();

	const {
		loading: loadingDealCatetoryDomestic,
		allItems: allDealCategoriesDomestic,

		fetchAllItems: fetchDealCategoryDomestic,
	} = useDomesticDealCategory();

	const {
		loading: loadingDealTypesPackage,
		allItems: allDealTypesPackage,

		fetchAllItems: fetchDealCategoryPackage,
	} = useDealTypesPackage();

	useEffect(() => {
		getAgencyData(1, 10);
		getAgencyUserList();
		fetchDealCategoryDomestic();
		fetchDealCategoryPackage();
	}, [])
	const [nAgencyUserList, setAgencyUserList] = useState([]);


	const [nCode, setCode] = useState(null)
	const [nNameEN, setNameEN] = useState(null)
	const [nNameRU, setNameRU] = useState(null)
	const [nNameHE, setNameHE] = useState(null)
	const [nNameAR, setNameAR] = useState(null)
	const [nPhone, setPhone] = useState(null)
	const [nWhatsApp, setWhatsApp] = useState(null)
	const [nFacebook, setFacebook] = useState(null)
	const [nTwitter, setTwitter] = useState(null)
	const [nInstagram, setInstagram] = useState(null)
	const [nEmail, setEmail] = useState(null)
	const [metaTitle, setMetaTitle] = useState(null)
	const [metaDesc, setMetaDesc] = useState('')
	const [bgColor, setBgColor] = useState(createColor('#fff'));
	const [showDomesticTourismLink, setShowDomesticTourismLink] = useState(true);
	const [marketerSpecificContents, setMarketerSpecificContents] = useState({ hideFooter: false, footerVisibility: 1, footerItems: [], homeUrl: '', fellowSiteUrl: '', images: null, showMainDeals: true, dealCategoriesToShow: [] });

	const [hideHomeTopBanner, setHideHomeTopBanner] = useState(false);
	const [homeTopBanner, setHomeTopBanner] = useState([]);
	const [hideHomeSecondBanner, setHideHomeSecondBanner] = useState(false);
	const [homeSecondBanner, setHomeSecondBanner] = useState([]);
	const [hideHomeTopSlider, setHideHomeTopSlider] = useState(false);
	const [homeTopSlider, setHomeTopSlider] = useState([]);
	const [footerItems, setFooterItems] = useState([]);
	const [showOptionDeal, setShowOptionDeal] = useState(0);
	const [useAlternateTemplate, setUseAlterateTemplate] = useState(false);
	const [kindThemeHome, setKindThemeHome] = useState(0);
	const [kindThemeSearch, setKindThemeSearch] = useState(0);
	const [kindThemeProduct, setKindThemeProduct] = useState(0);

	const [nAgencyCode, setAgencyCode] = useState('');
	const [kindOperation, setKindOperation] = useState('');
	const [nLogo, setLogo] = useState([])
	const [existingLogo, setExistingLogo] = useState([]);
	const [nIsActiveState, setIsActive] = useState(false);

	const [nFilterNameEN, setFilterNameEN] = useState(null);
	const [nFilterNameRU, setFilterNameRU] = useState(null);
	const [nFilterNameHE, setFilterNameHE] = useState(null);
	const [nFilterNameAR, setFilterNameAR] = useState(null);
	const [nFilterPhone, setFilterPhone] = useState(null);
	const [nFilterWhatsApp, setFilterWhatsApp] = useState(null);
	const [nFilterEmail, setFilterEmail] = useState(null);
	const [nFilterLogo, setFilterLogo] = useState(null);
	const [nFilterActive, setFilterActive] = useState(null);
	const [nFilterAgencyCode, setFilterAgencyCode] = useState(null);

	const [nButtonText, setButtonText] = useState(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [confirmText, setConfirmText] = useState(null);
	const [warningOpen, setWarningOpen] = useState(false);
	const [warningText, setWarningText] = useState(null);


	const [loading, setLoading] = useState(true);
	const [selected] = useState([]);
	const [data, setData] = useState([]);
	const [agencyData, setAgencyData] = useState([]);
	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});
	const [open, setOpen] = React.useState(false);
	const [openFilter, setOpenFilter] = useState(false);
	const addAgency = () => {
		setButtonText('Add');
		initialValue();
		setOpen(true);
	};
	const formatDefaultImageData = (pImgGroup) => {
		let listFormatedImg = [];
		if (pImgGroup) {
			pImgGroup.forEach(img => {
				const formatedImg = {
					kind: 'image',
					id: img?.id ?? '',
					Url: img?.image ?? '',
					Blob: '',
					file: null,
					caption: img?.caption ?? '',
					href: img?.href ?? '',
				};
				listFormatedImg.push(formatedImg);
			})
		}
		return listFormatedImg;
	}
	const handleOpen = (index) => {
		setButtonText('Edit');
		setCode(agencyData[index]['code']);

		setAgencyCode(agencyData[index]['agencyCode']);
		const itemAgency = nAgencyUserList.find(item => item.code === agencyData[index]['agencyCode']);
		setKindOperation(itemAgency?.operation ?? 0);

		setNameEN(agencyData[index]['nameTranslationEng']);
		setNameRU(agencyData[index]['nameTranslationRus']);
		setNameHE(agencyData[index]['nameTranslationHeb']);
		setNameAR(agencyData[index]['nameTranslationArb']);
		setPhone(agencyData[index]['phoneNumber']);
		setWhatsApp(agencyData[index]['whatsappAddress']);
		setEmail(agencyData[index]['emailAddress']);
		setFacebook(agencyData[index]['facebookLink']);
		setTwitter(agencyData[index]['twitterLink']);
		setInstagram(agencyData[index]['instagramLink']);
		setMetaTitle(agencyData[index]['metaTitle']);

		setMetaDesc(agencyData[index]['metaDescription'] || '');

		setShowDomesticTourismLink(agencyData[index]['showDomesticTourismLink']);

		let dmstcData = agencyData[index]['marketerSpecificContents'];
		let optShowDeal = agencyData[index]?.marketerSpecificContents?.showMainDeals ? 0 : 1;
		if (dmstcData?.showMainDeals === null || dmstcData?.showMainDeals === undefined) optShowDeal = 0;
		if (optShowDeal === 0) {
			setShowOptionDeal(0);
			if (dmstcData) dmstcData.dealCategoriesToShow = [];
		} else if (optShowDeal === 1) {
			setShowOptionDeal(1);
			if (!dmstcData || (dmstcData && !Array.isArray(dmstcData.dealCategoriesToShow))) {
				if (dmstcData) dmstcData.dealCategoriesToShow = [];
			}
		}
		if (dmstcData?.useAlternateTemplate === undefined || dmstcData?.useAlternateTemplate === null) {
			setUseAlterateTemplate(false);
		} else {
			setUseAlterateTemplate(dmstcData?.useAlternateTemplate);
			if (dmstcData?.useAlternateTemplate && dmstcData.pageTemplates.length > 0) {
				dmstcData.pageTemplates.forEach(temp => {
					switch (temp.page) {
						case 0:
							setKindThemeHome(temp.selectedTemplate);
							break;
						case 1:
							setKindThemeSearch(temp.selectedTemplate);
							break;
						case 2:
							setKindThemeProduct(temp.selectedTemplate);
							break;
						default:
							console.log(temp);
					}
				});
			}
		}

		setMarketerSpecificContents({ hideFooter: false, footerVisibility: 1, homeUrl: '', fellowSiteUrl: '', images: null, showMainDeals: true, dealCategoriesToShow: [], ...dmstcData });

		setHideHomeTopBanner(agencyData[index]?.marketerSpecificContents?.images?.homeTopBanner?.hide ?? false);
		setHomeTopBanner(formatDefaultImageData(agencyData[index]?.marketerSpecificContents?.images?.homeTopBanner?.imageWithHrefList));

		setHideHomeSecondBanner(agencyData[index]?.marketerSpecificContents?.images?.homeSecondBanner?.hide ?? false);
		setHomeSecondBanner(formatDefaultImageData(agencyData[index]?.marketerSpecificContents?.images?.homeSecondBanner?.imageWithHrefList));

		setHideHomeTopSlider(agencyData[index]?.marketerSpecificContents?.images?.homeTopSlider?.hide ?? false);
		setHomeTopSlider(formatDefaultImageData(agencyData[index]?.marketerSpecificContents?.images?.homeTopSlider?.imageWithHrefList));

		setFooterItems(agencyData[index]?.marketerSpecificContents?.footerItems ?? []);

		let color = agencyData[index]['backgroundColorCss'] || '#fff';
		setBgColor(createColor(color));

		setExistingLogo(agencyData[index]['logoUrls']);
		if (agencyData[index]['active']) {
			setIsActive(true);
		}
		else {
			setIsActive(false);
		}
		setOpen(true);
	};

	const availableSpecificContent = (pOperation) => {
		return pOperation === 0 || pOperation === 1;
	}

	const deleteHandle = async (index) => {
		setCode(agencyData[index]['code'])
		setConfirmText("Do you want to drop the content of this Agency?");
		setConfirmOpen(true);
	}

	const openSearchModel = () => {
		setOpenFilter(true);
	};
	const handleClose = () => {
		initialValue();
		setOpen(false);
	};
	const handleFilterClose = () => {
		setOpenFilter(false);
	};
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}
	const handleCloseWarning = () => {
		setWarningOpen(false);
	};
	function searchAgencyList() {
		setPage(0);
		getAgencyData(1, rowsPerPage);
		setOpenFilter(false);
	}
	function convertModelToFormData(model, form = null, namespace = '') {
		let formData = form || new FormData();
		let formKey;

		for (let propertyName in model) {
			if (!model.hasOwnProperty(propertyName) || !model[propertyName]) continue;
			let formKey = namespace ? `${namespace}[${propertyName}]` : propertyName;
			if (model[propertyName] instanceof Date)
				formData.append(formKey, model[propertyName].toISOString());
			else if (model[propertyName] instanceof Array) {
				model[propertyName].forEach((element, index) => {
					const tempFormKey = `${formKey}[${index}]`;
					convertModelToFormData(element, formData, tempFormKey);
				});
			}
			else if (typeof model[propertyName] === 'object' && !(model[propertyName] instanceof File))
				convertModelToFormData(model[propertyName], formData, formKey);
			else
				formData.append(formKey, model[propertyName].toString());
		}
		return formData;
	}
	async function editProcess() {
		setLoading(true);
		var post_url;
		if (nButtonText === 'Edit') {
			post_url = baseURL + 'api/agencyContents/' + nCode;
		}
		else {
			post_url = baseURL + 'api/agencyContents';
		}
		let data = new FormData();
		data.append('active', nIsActiveState);
		if (nNameEN != null) {
			data.append('nameTranslationEng', nNameEN);
		}
		if (nNameRU != null) {
			data.append('nameTranslationRus', nNameRU);
		}
		if (nNameHE != null) {
			data.append('nameTranslationHeb', nNameHE);
		}
		if (nNameAR != null) {
			data.append('nameTranslationArb', nNameAR);
		}
		if (nEmail != null) {
			data.append('emailAddress', nEmail);
		}
		if (nPhone != null) {
			data.append('phoneNumber', nPhone);
		}
		if (nWhatsApp != null) {
			data.append('whatsappAddress', nWhatsApp);
		}
		if (nFacebook != null) {
			data.append('facebookLink', nFacebook);
		}
		if (nTwitter != null) {
			data.append('twitterLink', nTwitter);
		}
		if (nInstagram != null) {
			data.append('instagramLink', nInstagram);
		}
		if (metaTitle != null) {
			data.append('metaTitle', metaTitle);
		}
		if (metaDesc != null || metaDesc !== '') {
			data.append('metaDescription', metaDesc);
		}
		data.append('showDomesticTourismLink', showDomesticTourismLink);

		if (availableSpecificContent(kindOperation)) {
			data.append('marketerSpecificContents.hideFooter', marketerSpecificContents.hideFooter);
			data.append('marketerSpecificContents.footerVisibility', marketerSpecificContents.footerVisibility);
			data.append('marketerSpecificContents.homeUrl', marketerSpecificContents.homeUrl || '');
			data.append('marketerSpecificContents.fellowSiteUrl', marketerSpecificContents.fellowSiteUrl || '');

			data.append(`marketerSpecificContents.images.homeTopBanner.hide`, hideHomeTopBanner);
			homeTopBanner.forEach((img, i) => {
				if (img.Url === '' && img.file) {
					data.append(`marketerSpecificContents.images.homeTopBanner.imageWithHrefList[${i}].imageFile`, img.file);
				} else if (img.Url !== '' && img.file === null) {
					data.append(`marketerSpecificContents.images.homeTopBanner.imageWithHrefList[${i}].image`, img.Url);
				}
				data.append(`marketerSpecificContents.images.homeTopBanner.imageWithHrefList[${i}].caption`, img.caption || '');
				data.append(`marketerSpecificContents.images.homeTopBanner.imageWithHrefList[${i}].href`, img.href || '');
			});

			data.append(`marketerSpecificContents.images.homeSecondBanner.hide`, hideHomeSecondBanner);
			homeSecondBanner.forEach((img, i) => {
				if (img.Url === '' && img.file) {
					data.append(`marketerSpecificContents.images.homeSecondBanner.ImageWithHrefList[${i}].imageFile`, img.file);
				} else if (img.Url !== '' && img.file === null) {
					data.append(`marketerSpecificContents.images.homeSecondBanner.ImageWithHrefList[${i}].image`, img.Url);
				}
				data.append(`marketerSpecificContents.images.homeSecondBanner.ImageWithHrefList[${i}].caption`, img.caption || '');
				data.append(`marketerSpecificContents.images.homeSecondBanner.ImageWithHrefList[${i}].href`, img.href || '');
			});

			data.append(`marketerSpecificContents.images.homeTopSlider.hide`, hideHomeTopSlider);
			homeTopSlider.forEach((img, i) => {
				if (img.Url === '' && img.file) {
					data.append(`marketerSpecificContents.images.homeTopSlider.ImageWithHrefList[${i}].imageFile`, img.file);
				} else if (img.Url !== '' && img.file === null) {
					data.append(`marketerSpecificContents.images.homeTopSlider.ImageWithHrefList[${i}].image`, img.Url);
				}
				data.append(`marketerSpecificContents.images.homeTopSlider.ImageWithHrefList[${i}].caption`, img.caption || '');
				data.append(`marketerSpecificContents.images.homeTopSlider.ImageWithHrefList[${i}].href`, img.href || '');
			});

			footerItems.forEach((footer, i) => {
				data.append(`marketerSpecificContents.footerItems[${i}].subject`, footer.subject);
				footer.hrefList.forEach((href, j) => {
					data.append(`marketerSpecificContents.footerItems[${i}].hrefList[${j}].text`, href.text);
					data.append(`marketerSpecificContents.footerItems[${i}].hrefList[${j}].url`, href.url);
				})
			})

			data.append('marketerSpecificContents.useAlternateTemplate', useAlternateTemplate);
			if (useAlternateTemplate) {
				data.append('marketerSpecificContents.pageTemplates[0].page', 0);
				data.append('marketerSpecificContents.pageTemplates[0].selectedTemplate', kindThemeHome);

				data.append('marketerSpecificContents.pageTemplates[1].page', 1);
				data.append('marketerSpecificContents.pageTemplates[1].selectedTemplate', kindThemeSearch);

				data.append('marketerSpecificContents.pageTemplates[2].page', 2);
				data.append('marketerSpecificContents.pageTemplates[2].selectedTemplate', kindThemeProduct);
			}

			if (showOptionDeal === 1) {
				data.append('marketerSpecificContents.showMainDeals', false);
				marketerSpecificContents.dealCategoriesToShow.forEach((opt, i) => {
					data.append(`marketerSpecificContents.dealCategoriesToShow[]`, opt);
				})
			} else {
				data.append('marketerSpecificContents.showMainDeals', true);
			}
		}

		if (bgColor != null) {
			data.append('backgroundColorCss', `#${bgColor.hex}`);
		}
		if (nAgencyCode != null) {
			data.append('agencyCode', nAgencyCode);
		}
		if (existingLogo != null && nButtonText === 'Edit') {
			existingLogo.forEach(file => {
				data.append("logoUrls", file);
			});
		}
		nLogo.forEach(file => {
			data.append("logoFile", file);
		});
		await axios({
			method: 'post',
			url: post_url,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: data
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			} else {
				getAgencyData(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}
			initialValue();
			setLoading(false);
			setOpen(false);
		}).catch(error => {
			setLoading(false);
			setWarningOpen(true);
			setWarningText(error.response.data);
		});
	};
	async function confirmProcess() {
		setLoading(true);
		await axios.delete(baseURL + 'api/agencyContents/' + nCode, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		}).then(response => {
			if (response.data.error !== null && response.data.error.message !== null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			} else {
				getAgencyData(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}
			initialValue();
			setLoading(false);
			setOpen(false);
			setConfirmOpen(false);
		}).catch(error => {
			setLoading(false);
			setConfirmOpen(false);
			setWarningOpen(true);
			setWarningText(error.response.data);
		});

	};

	async function getAgencyUserList() {
		// const active = nFilterActive === null || nFilterActive === '' ? null : (nFilterActive === 'true' ? true : false);
		await axios({
			method: 'post',
			url: baseURL + 'api/agency/search?',
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				'allocatedHostFqdn': null,
				'authorizedUsername': null,
				'odyAgentCode': null,
				'active': true,
			}
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				const data = response.data;
				setAgencyUserList(data['data']);
			}
		}).catch(error => {
			console.log(error);
		});
	}

	async function getAgencyData(from, to) {
		const active = nFilterActive === null || nFilterActive === '' ? null : (nFilterActive === 'true' ? true : false);
		await axios({
			method: 'post',
			url: `${baseURL}api/agencyContents/flatten/search?from=${from}&to=${to}`,
			headers: {
				'Content-Type': 'application/json',
				'Access-Control-Allow-Origin': '*'
			},
			data: {
				"code": null,
				"phoneNumber": nFilterPhone,
				"whatsappAddress": nFilterWhatsApp,
				"emailAddress": nFilterEmail,
				"active": active,
				"nameTranslationEng": nFilterNameEN === '' ? null : nFilterNameEN,
				"nameTranslationHeb": nFilterNameHE === '' ? null : nFilterNameHE,
				"nameTranslationRus": nFilterNameRU === '' ? null : nFilterNameRU,
				"nameTranslationArb": nFilterNameAR === '' ? null : nFilterNameAR,
				"logoUrls": nFilterLogo === null || nFilterLogo === '' ? [] : new Array(nFilterLogo),
				"agencyCode": nFilterAgencyCode === '' ? null : nFilterAgencyCode,
			}
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				const data = response.data;
				setData(data);
				setAgencyData(data['data'])
			}
		}).catch(error => {
			console.log(error);
		});
		setLoading(false);
	}
	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}
	function onChangeNameEN(event) {
		setNameEN(event.target.value)
	}
	function onChangeNameRU(event) {
		setNameRU(event.target.value)
	}
	function onChangeNameHE(event) {
		setNameHE(event.target.value)
	}
	function onChangeNameAR(event) {
		setNameAR(event.target.value)
	}
	function onChangePhone(event) {
		setPhone(event.target.value)
	}
	function onChangeWhatsApp(event) {
		setWhatsApp(event.target.value)
	}
	function onChangeFacebookLink(event) {
		setFacebook(event.target.value);
	}
	function onChangeTwitterLink(event) {
		setTwitter(event.target.value);
	}
	function onChangeInstagramLink(event) {
		setInstagram(event.target.value);
	}
	function onChangeEmail(event) {
		setEmail(event.target.value)
	}
	function onChangeMetaTitle(event) {
		setMetaTitle(event.target.value)
	}
	function onChangeMetaDescription(event) {
		setMetaDesc(event.target.value);
	}
	function handleShowFellowSiteLink(event) {
		setShowDomesticTourismLink(!showDomesticTourismLink);
	}
	const handleShowFooter = (event) => {
		setMarketerSpecificContents({
			...marketerSpecificContents,
			"hideFooter": !marketerSpecificContents.hideFooter
		});
	}
	const switchingFooterVisibility = (event) => {
		setMarketerSpecificContents({
			...marketerSpecificContents,
			"footerVisibility": Number(event.target.value),
		});
	}
	const handleHomeUrl = (event) => {
		if (event.target.value) {
			setMarketerSpecificContents({
				...marketerSpecificContents,
				"homeUrl": event.target.value,
			});
		} else {
			setMarketerSpecificContents({
				...marketerSpecificContents,
				"homeUrl": '',
			})
		}
	}
	const handleFellowSiteUrl = (event) => {
		if (event.target.value) {
			setMarketerSpecificContents({
				...marketerSpecificContents,
				"fellowSiteUrl": event.target.value,
			});
		} else {
			setMarketerSpecificContents({
				...marketerSpecificContents,
				"fellowSiteUrl": '',
			})
		}
	}
	function onChangeColor(color) {
		setBgColor(color);
	}
	function handleChangeCheckbox() {
		setIsActive(!nIsActiveState);
	}
	function onChangeAgency(event) {
		setAgencyCode(event.target.value);

		const itemAgency = nAgencyUserList.find(item => item.code === event.target.value);
		setKindOperation(itemAgency?.operation ?? 0);
	}

	const receiveMessageFromTopBanner = (pMsg) => {
		setHomeTopBanner(pMsg.images);
	}
	const changeHideTopBanner = (ev) => {
		setHideHomeTopBanner(!hideHomeTopBanner);
		let tmpSpecificContent = marketerSpecificContents;
		tmpSpecificContent.images.homeTopBanner.hide = !tmpSpecificContent.images.homeTopBanner.hide
		setMarketerSpecificContents(tmpSpecificContent);
	}
	const receiveMessageFromSecondBanner = (pMsg) => {
		setHomeSecondBanner(pMsg.images);
	}
	const changeHideSecondBanner = (ev) => {
		setHideHomeSecondBanner(!hideHomeSecondBanner);
		let tmpSpecificContent = marketerSpecificContents;
		tmpSpecificContent.images.homeSecondBanner.hide = !tmpSpecificContent.images.homeSecondBanner.hide
		setMarketerSpecificContents(tmpSpecificContent);
	}
	const receiveMessageFromTopSlider = (pMsg) => {
		setHomeTopSlider(pMsg.images);
	}
	const changeHideTopSlider = (ev) => {
		setHideHomeTopSlider(!hideHomeTopSlider);
		let tmpSpecificContent = marketerSpecificContents;
		tmpSpecificContent.images.homeSecondBanner.hide = !tmpSpecificContent.images.homeSecondBanner.hide
		setMarketerSpecificContents(tmpSpecificContent);
	}
	const changeShowDeals = (ev) => {
		console.log('pending : changeShowDeals')
	}
	const receiveMessageFromSubjectsFooter = (pMsg) => {
		if (pMsg.action === 'Update') {
			setFooterItems(pMsg.extraData);
		}
	}

	/////////////////////////////////////////////////
	function onChangeFilterNameEN(event) {
		setFilterNameEN(event.target.value)
	}
	function onChangeFilterNameRU(event) {
		setFilterNameRU(event.target.value)
	}
	function onChangeFilterNameHE(event) {
		setFilterNameHE(event.target.value)
	}
	function onChangeFilterNameAR(event) {
		setFilterNameAR(event.target.value)
	}
	function onChangeFiltePhone(event) {
		setFilterPhone(event.target.value)
	}
	function onChangeFilterWhatsApp(event) {
		setFilterWhatsApp(event.target.value)
	}
	function onChangeFilterEmail(event) {
		setFilterEmail(event.target.value)
	}
	function onChangeFilterLogo(event) {
		setFilterLogo(event.target.value)
	}
	function onChangeFilterActive(event) {
		setFilterActive(event.target.value)
	}
	function onChangeFilteAgncy(event) {
		setFilterAgencyCode(event.target.value)
	}
	function onChangeAlterateTemplate(event) {
		setUseAlterateTemplate(!useAlternateTemplate);
	}
	function onChangeThemeHome(event) {
		setKindThemeHome(event.target.value);
	}
	function onChangeThemeSearch(event) {
		setKindThemeSearch(event.target.value);
	}
	function onChangeThemeProduct(event) {
		setKindThemeProduct(event.target.value);
	}

	//////////////////////////////////////////////
	function handleChangePage(event, value) {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage
		getAgencyData(from, to);
	}
	function handleChangeRowsPerPage(event) {
		setRowsPerPage(event.target.value);
		setPage(0)
		const temp = Number(event.target.value)
		const from = 1;
		const to = temp
		getAgencyData(from, to);
	}
	const onLogoDrop = (picture) => {
		setExistingLogo([])
		setLogo(picture)
	};
	function deleteExistingLogo(index) {
		setExistingLogo(existingLogo.filter((e, n) => n !== index));
	}
	function deleteLogo(index) {
		setLogo(nLogo.filter((e, n) => n !== index));
	}
	function getAgencyKeyFromCode(pAgencyData) {
		if (nAgencyUserList.length == 0) return pAgencyData.agencyCode;
		const agency = nAgencyUserList.find(item => item?.code === pAgencyData.agencyCode);
		return getAgencyKey(agency);
	}
	function getAgencyKey(pItem) {
		let key = '';
		if (pItem) {
			const forInternalAgentSite = pItem.forInternalAgentSite ? '/ agentSite' : '';
			key = `${operationKey[pItem.operation]} / ${pItem.odyAgentCode} ${forInternalAgentSite}`;
		}
		return key;
	}
	const makeCarousel = (pImgUrls) => {
		return (
			<Carousel autoPlay={false} transitionTime="2000" showThumbs={false} width="250px">
				{pImgUrls == null ? "" : pImgUrls.map((img, i) =>
					<div key={i}>
						<img alt='' style={{ width: '100px', maxWidth: '100px', margin: 'auto' }} src={img} />
					</div>
				)}
			</Carousel>
		);
	}
	const imgUrlsTopSlider = (pData) => {
		return pData.marketerSpecificContents?.images?.homeTopSlider?.imageWithHrefList?.map(el => el.image) || [];
	}
	const imgUrlsTopBanner = (pData) => {
		return pData.marketerSpecificContents?.images?.homeTopBanner?.imageWithHrefList?.map(el => el.image) || [];
	}
	const imgUrlsMiddleBanner = (pData) => {
		return pData.marketerSpecificContents?.images?.homeSecondBanner?.imageWithHrefList?.map(el => el.image) || [];
	}
	const makeListFooterSubjects = (pData) => {
		let items = pData?.marketerSpecificContents?.footerItems ?? [];
		return (
			items.length === 0 ? "" :
				<Grid container>
					{
						items.map(el => <Grid item xs={12} md={12} lg={12}>{el.subject}</Grid>)
					}
				</Grid>
		)
	}
	const getCheckedStateDomesticDealTypes = () => {
		let keyState = '';
		if (marketerSpecificContents?.dealCategoriesToShow?.length > 0) {
			if (marketerSpecificContents?.dealCategoriesToShow?.length === allDealCategoriesDomestic.length) {
				keyState = 'all';
			}
		} else {
			keyState = 'empty';
		}
		return keyState;
	}
	const getCheckedStatePackageDealTypes = () => {
		let keyState = '';
		if (marketerSpecificContents?.dealCategoriesToShow?.length > 0) {
			if (marketerSpecificContents?.dealCategoriesToShow?.length === allDealTypesPackage.length) {
				keyState = 'all';
			}
		} else {
			keyState = 'empty';
		}
		return keyState;
	}
	const handleChangeOptionDeal = (event) => {
		setShowOptionDeal(Number(event.target.value));
	}
	const receiveMessageFromMultiSelectDealCatetory = (pType, pMsg) => {
		switch (pType) {
			case 'changedCheckedItems':
				setMarketerSpecificContents({
					...marketerSpecificContents,
					"dealCategoriesToShow": pMsg.items
				});
				break;
		}
	}

	function initialValue() {
		setCode(null)
		setNameEN(null)
		setNameRU(null)
		setNameHE(null)
		setNameAR(null)
		setPhone(null)
		setWhatsApp(null)
		setEmail(null)
		setLogo([]);
		setExistingLogo([]);
		setIsActive(false);
		setAgencyCode('');
		setMarketerSpecificContents({ hideFooter: false, footerVisibility: 1, footerItems: [], homeUrl: '', fellowSiteUrl: '', images: null, showMainDeals: true, dealCategoriesToShow: [] });
		setShowOptionDeal(0);
	}
	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className="w-full flex flex-col">
			<Modal
				open={warningOpen}
				onClose={handleCloseWarning}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Warning</h2>
					<p id='server-modal-description'>{warningText}</p>
					<Button className='whitespace-no-wrap normal-case'
						variant='contained'
						color='secondary'
						style={{ marginTop: '10px' }}
						onClick={handleCloseWarning}>Close
					</Button>
				</div>
			</Modal>
			<Modal
				open={confirmOpen}
				onClose={handleCloseConfirm}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Confirm</h2>
					<p id='server-modal-description'>{confirmText}</p>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={confirmProcess}>Confirm
					</Button>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={handleCloseConfirm}>Cancel
					</Button>
				</div>
			</Modal>
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={openFilter}
				onClose={handleFilterClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={openFilter}>
					<div className={classes.paper}>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title' >Filter Setting</h2>
						</div>
						<div style={{ display: 'grid' }}>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Agency</FormHelperText>
								<Select
									native
									onChange={onChangeFilteAgncy}
									value={nFilterAgencyCode}
									name='Code'
									inputProps={{
										id: 'age-native-required',
									}}
								>
									<option value=''></option>
									{nAgencyUserList == null ? '' : nAgencyUserList.map((n, i) =>
										<option key={i} value={n?.code ?? ''}>{n?.odyAgentCode ?? ''}</option>
									)}
								</Select>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>NameEN</FormHelperText>
								<TextField defaultValue={nFilterNameEN} className={classes.textfield} onChange={onChangeFilterNameEN} />
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>NameRu</FormHelperText>
								<TextField defaultValue={nFilterNameRU} className={classes.textfield} onChange={onChangeFilterNameRU} />
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>NameHE</FormHelperText>
								<div dir='rtl'>
									<TextField defaultValue={nFilterNameHE} className={classes.textfield} onChange={onChangeFilterNameHE} />
								</div>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>NameAR</FormHelperText>
								<div dir='rtl'>
									<TextField defaultValue={nFilterNameAR} className={classes.textfield} onChange={onChangeFilterNameAR} />
								</div>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>PhoneNumber</FormHelperText>
								<TextField defaultValue={nFilterPhone} className={classes.textfield} onChange={onChangeFiltePhone} />
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>WhatsApp</FormHelperText>
								<TextField defaultValue={nFilterWhatsApp} className={classes.textfield} onChange={onChangeFilterWhatsApp} />
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Email</FormHelperText>
								<TextField defaultValue={nFilterEmail} className={classes.textfield} onChange={onChangeFilterEmail} />
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Logo</FormHelperText>
								<TextField defaultValue={nFilterLogo} className={classes.textfield} onChange={onChangeFilterLogo} />
							</FormControl>

							<FormControl required className={classes.formControl}>
								<FormHelperText>Active State</FormHelperText>
								<Select
									native
									onChange={onChangeFilterActive}
									value={nFilterActive}
									inputProps={{
										id: 'age-native-required',
									}}
								>
									<option aria-label='None' value=''>All</option>
									<option value='true'>Active</option>
									<option value='false'>Unactive</option>
								</Select>
							</FormControl>

						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' color='secondary' onClick={searchAgencyList}>
								Filter
							</Button>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleFilterClose}>
								Cancel
							</Button>

						</div>
					</div>

				</Fade>
			</Modal>
			<Modal
				aria-labelledby="transition-modal-title"
				aria-describedby="transition-modal-description"
				className={classes.modal}
				open={open}
				onClose={handleClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={open}>
					<div className={classes.paper}>
						<h2 id="transition-modal-title" style={{ textAlign: 'center' }}>{nButtonText}</h2>
						<div style={{ textAlign: 'center', display: 'grid' }}>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Agency</FormHelperText>
								<Select
									native
									onChange={onChangeAgency}
									value={nAgencyCode}
									name='Code'
									inputProps={{
										id: 'age-native-required',
									}}
								>
									<option value=''></option>
									{nAgencyUserList == null ? '' : nAgencyUserList.map((n, i) =>
										<option key={i} value={n?.code ?? ''}>{getAgencyKey(n)}</option>
									)}
								</Select>
							</FormControl>
							<Grid container justify='space-around' style={{ textAlign: 'center', display: 'flex' }}>
								<FormControl required className={classes.formControl}>
									<FormHelperText>NameEN</FormHelperText>
									<TextField defaultValue={nNameEN} className={classes.textfield} onChange={onChangeNameEN} />
								</FormControl>
								<FormControl required className={classes.formControl}>
									<FormHelperText>NameRU</FormHelperText>
									<TextField defaultValue={nNameRU} className={classes.textfield} onChange={onChangeNameRU} />
								</FormControl>
								<FormControl required className={classes.formControl}>
									<FormHelperText>NameHE</FormHelperText>
									<div dir='rtl'>
										<TextField defaultValue={nNameHE} className={classes.textfield} onChange={onChangeNameHE} />
									</div>
								</FormControl>
								<FormControl required className={classes.formControl}>
									<FormHelperText>NameAR</FormHelperText>
									<div dir='rtl'>
										<TextField defaultValue={nNameAR} className={classes.textfield} onChange={onChangeNameAR} />
									</div>
								</FormControl>
							</Grid>
							<Grid container justify='space-around' style={{ textAlign: 'center', display: 'flex' }}>
								<FormControl required className={classes.formControl}>
									<FormHelperText>PhoneNumber</FormHelperText>
									<TextField defaultValue={nPhone} className={classes.textfield} onChange={onChangePhone} />
								</FormControl>
								<FormControl required className={classes.formControl}>
									<FormHelperText>WhatsApp</FormHelperText>
									<TextField defaultValue={nWhatsApp} className={classes.textfield} onChange={onChangeWhatsApp} />
								</FormControl>
								<FormControl required className={classes.formControl}>
									<FormHelperText>Email</FormHelperText>
									<TextField defaultValue={nEmail} className={classes.textfield} onChange={onChangeEmail} />
								</FormControl>
							</Grid>
							<Grid container justify='space-around' style={{ textAlign: 'center', display: 'flex' }}>
								<FormControl required className={classes.formControl}>
									<FormHelperText>Facebook</FormHelperText>
									<TextField defaultValue={nFacebook} className={classes.textfield} onChange={onChangeFacebookLink} />
								</FormControl>
								<FormControl required className={classes.formControl}>
									<FormHelperText>Twitter</FormHelperText>
									<TextField defaultValue={nTwitter} className={classes.textfield} onChange={onChangeTwitterLink} />
								</FormControl>
								<FormControl required className={classes.formControl}>
									<FormHelperText>Instagram</FormHelperText>
									<TextField defaultValue={nInstagram} className={classes.textfield} onChange={onChangeInstagramLink} />
								</FormControl>
							</Grid>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Meta Title</FormHelperText>
								<TextField defaultValue={metaTitle} className={classes.textfield} onChange={onChangeMetaTitle} />
							</FormControl>
							<FormControl fullWidth sx={{ m: 1 }}>
								<FormHelperText>Meta Description</FormHelperText>
								<TextareaAutosize
									className="border-2"
									style={{ height: "100px" }}
									value={metaDesc}
									onChange={onChangeMetaDescription}
								/>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Background Color</FormHelperText>
								<ColorPicker
									name="bgColor"
									defaultValue={'#000'}
									value={bgColor}
									onChange={onChangeColor}
									className={classes.bgColor}
								/>
							</FormControl>
							{!availableSpecificContent(kindOperation) ?
								(<Grid container justify='space-around' style={{ textAlign: 'center', display: 'flex' }}>
									<FormControlLabel
										control={
											<Checkbox
												checked={showDomesticTourismLink}
												onChange={handleShowFellowSiteLink}
												name='checkedC'
												color='primary'
											/>
										}
										label='show Fellow Site Link'
										className={classes.checkboxform}
									/>
								</Grid>)
								:
								(<Grid className={classes.shadowBorder}>
									<Grid container justify='space-around' style={{ textAlign: 'center', display: 'flex' }}>
										<FormControlLabel
											control={
												<Checkbox
													checked={showDomesticTourismLink}
													onChange={handleShowFellowSiteLink}
													name='checkedC'
													color='primary'
												/>
											}
											label='show Fellow Site Link'
											className={classes.checkboxform}
										/>
									</Grid>
									<Grid container justify='space-around' style={{ textAlign: 'center', display: 'flex', marginTop: '10px' }}>
										<FormControl required className={classes.formControl}>
											<FormHelperText>Home URL</FormHelperText>
											<TextField defaultValue={marketerSpecificContents.homeUrl} className={classes.textfield} onChange={handleHomeUrl} />
										</FormControl>
										<FormControl required className={classes.formControl}>
											<FormHelperText>Fellow Stie URL</FormHelperText>
											<TextField defaultValue={marketerSpecificContents.fellowSiteUrl} className={classes.textfield} onChange={handleFellowSiteUrl} />
										</FormControl>
									</Grid>
								</Grid>
								)
							}
							<div className={classes.shadowBorder}>
								<div style={{ display: 'flex', overflow: 'auto' }}>
									{existingLogo == null ? "" : existingLogo.map((k, i) =>
										<div style={{ position: 'relative', margin: 'auto' }} key={i}>
											<button className={classes.deleteImage} onClick={(e) => deleteExistingLogo(i)}>X</button>
											<img alt='' style={{ height: '70px', margin: '10px' }} src={k} />
										</div>
									)}
									{nLogo == null ? "" : nLogo.map((n, j) =>
										<div style={{ position: 'relative', margin: 'auto' }} key={j}>
											<button className={classes.deleteImage} onClick={(e) => deleteLogo(j)}>X</button>
											<img alt='' style={{ height: '70px', margin: '10px' }} src={URL.createObjectURL(n)} />
										</div>
									)}
								</div>

								<ImageUploader
									className={classes.imageUploader}
									withIcon={false}
									buttonStyles={{ fontSize: '12px' }}
									fileContainerStyle={{ padding: '0px', boxShadow: 'none' }}
									buttonText="Add Images"
									withLabel={false}
									withPreview={false}
									onChange={onLogoDrop}
									singleImage={false}
									imgExtension={[".jpg", ".gif", ".png", ".gif", ".jpeg", ".jfif"]}
									maxFileSize={524288000}
								/>
							</div>
						</div>
						{!availableSpecificContent(kindOperation) ? '' :
							<Grid container justify='center'>
								<Grid container justify='center' className={classes.shadowBorder}>
									<Grid item xs={12} md={12} lg={12} className="m-14">
										<FormControlLabel
											control={
												<Checkbox
													checked={hideHomeTopSlider}
													onChange={changeHideTopSlider}
													name='checkSecondBanner'
													color='primary'
												/>
											}
											label='Hide Home Top Slider'
											className={classes.checkboxform}
										/>
									</Grid>
									{hideHomeTopSlider ? "" :
										<Grid item>
											<FormControl className='mt-20'>
												<AddMultiImages
													imageData={{ imageData: homeTopSlider, title: 'Top Slider Images' }}
													extraData={{ showCaption: true, showHref: true, enableArrange: true }}
													onMessage={receiveMessageFromTopSlider}
												/>
											</FormControl>
										</Grid>
									}
								</Grid>
								<Grid container justify='center' className={classes.shadowBorder}>
									<Grid item xs={12} md={12} lg={12} className="m-14">
										<FormControlLabel
											control={
												<Checkbox
													checked={hideHomeTopBanner}
													onChange={changeHideTopBanner}
													name='checkTopBanner'
													color='primary'
												/>
											}
											label='Hide Home Top Banner'
											className={classes.checkboxform}
										/>
									</Grid>
									{hideHomeTopBanner ? "" :
										<Grid>
											<FormControl className='mt-20'>
												<AddMultiImages
													imageData={{ imageData: homeTopBanner, title: 'Top Banner Images' }}
													extraData={{ showCaption: true, showHref: true, enableArrange: true }}
													onMessage={receiveMessageFromTopBanner}
												/>
											</FormControl>
										</Grid>
									}
								</Grid>
								<Grid container justify='center' className={classes.shadowBorder}>
									<Grid item xs={12} md={12} lg={12} className="m-14">
										<FormControlLabel
											control={
												<Checkbox
													checked={hideHomeSecondBanner}
													onChange={changeHideSecondBanner}
													name='checkSecondBanner'
													color='primary'
												/>
											}
											label='Hide Home Second Banner'
											className={classes.checkboxform}
										/>
									</Grid>
									{hideHomeSecondBanner ? "" :
										<Grid>
											<FormControl className='mt-20'>
												<AddMultiImages
													imageData={{ imageData: homeSecondBanner, title: 'Second Banner Images' }}
													extraData={{ showCaption: true, showHref: true, enableArrange: true }}
													onMessage={receiveMessageFromSecondBanner}
												/>
											</FormControl>
										</Grid>
									}
								</Grid>
								<Grid container justify='center' className={classes.shadowBorder}>
									<Grid item xs={12} md={12} lg={12} className="m-14">
										<FormControl className="flex">
											<FormLabel id="row-radio-buttons-group-label">Footer visibility</FormLabel>
											<RadioGroup
												className="m-auto"
												row
												aria-labelledby="row-radio-buttons-group-label"
												name="row-radio-buttons-group"
												value={marketerSpecificContents?.footerVisibility ?? 1}
												onChange={switchingFooterVisibility}
											>
												<FormControlLabel value={0} control={<Radio />} label="Hide Footer" />
												<FormControlLabel value={1} control={<Radio />} label="Show Main Footer" />
												<FormControlLabel value={2} control={<Radio />} label="Show Subject Footer" />
											</RadioGroup>
										</FormControl>
									</Grid>
									{marketerSpecificContents.hideFooter ? "" :
										<Grid item xs={12} md={12} lg={12}>
											<FormControl className='mt-2 w-full' >
												<SubjectsCustomFooter
													subjectsData={footerItems}
													onMessage={receiveMessageFromSubjectsFooter}
												/>
											</FormControl>
										</Grid>
									}
								</Grid>
								<Grid container justify='center' className={classes.shadowBorder}>
									<Grid item xs={12} md={12} lg={12} className="m-14">
										<FormControl className="flex m-auto">
											<FormLabel id="row-radio-buttons-group-label">Categories To Show</FormLabel>
											<Grid container justify='center'>
												<Grid item xs={6} md={6} lg={6}>
													<RadioGroup
														className='m-auto'
														row
														aria-labelledby="row-radio-buttons-group-label"
														name="row-radio-buttons-group"
														value={showOptionDeal}
														onChange={handleChangeOptionDeal}
													>
														<FormControlLabel value={0} control={<Radio />} label="Main Site" />
														<FormControlLabel value={1} control={<Radio />} label="Selected Deals" />
													</RadioGroup>
												</Grid>
												{showOptionDeal === 0 ? "" :
													kindOperation === 0 ?
														<MultiDealTypesPackage
															loading={loadingDealTypesPackage}
															title="Deal Types To Show"
															checkedItems={marketerSpecificContents.dealCategoriesToShow}
															sourceList={allDealTypesPackage}
															extraData={{ checked: getCheckedStatePackageDealTypes() }}
															onMessage={receiveMessageFromMultiSelectDealCatetory}
														/>
														:
														<MultiDealTypesDomestic
															loading={loadingDealCatetoryDomestic}
															title="Deal Types To Show"
															checkedItems={marketerSpecificContents.dealCategoriesToShow}
															sourceList={allDealCategoriesDomestic}
															extraData={{ checked: getCheckedStateDomesticDealTypes() }}
															onMessage={receiveMessageFromMultiSelectDealCatetory}
														/>
												}
											</Grid>
										</FormControl>
									</Grid>
								</Grid>
								<Grid container justify='center' className={classes.shadowBorder}>
									<Grid item xs={12} md={12} lg={12} className='m-14'>
										<Grid container justify='center' className='m-14'>
											<FormLabel id="row-radio-buttons-group-label" className="mr-20 mt-12">Select Design Per Page</FormLabel>
											<FormControlLabel
												control={
													<Switch
														checked={useAlternateTemplate}
														onChange={onChangeAlterateTemplate}
														name="alterateTheme"
														color="primary"
													/>
												}
												label="Alternate Template"
											/>
										</Grid>
										{useAlternateTemplate ?
											(<Grid container>
												<Grid container justify='center' className='m-14'>
													<Grid item xs={12} md={2} lg={3} className='m-14'>
														<FormLabel id="row-radio-buttons-group-label">Home Page</FormLabel>
													</Grid>
													<Grid item xs={12} md={6} lg={6} className='m-14'>
														<FormHelperText>Kind of Theme for Home page</FormHelperText>
														<Select
															native
															onChange={onChangeThemeHome}
															value={kindThemeHome}
															name='Code'
															inputProps={{
																id: 'age-native-required',
															}}
														>
															<option value={0}>Original</option>
															<option value={1}>Theme 1</option>
														</Select>
													</Grid>
												</Grid>
												{kindOperation === 1 ?
													(<>
														<Grid container justify='center' className='m-14'>
															<Grid item xs={12} md={2} lg={3} className='m-14'>
																<FormLabel id="row-radio-buttons-group-label">Search Page</FormLabel>
															</Grid>
															<Grid item xs={12} md={6} lg={6} className='m-14'>
																<FormHelperText>Kind of Theme for Search page</FormHelperText>
																<Select
																	native
																	onChange={onChangeThemeSearch}
																	value={kindThemeSearch}
																	name='Code'
																	inputProps={{
																		id: 'age-native-required',
																	}}
																>
																	<option value={0}>Original</option>
																	<option value={1}>Theme 1</option>
																</Select>
															</Grid>
														</Grid>
														<Grid container justify='center' className='m-14'>
															<Grid item xs={12} md={2} lg={3} className='m-14'>
																<FormLabel id="row-radio-buttons-group-label">Product Page</FormLabel>
															</Grid>
															<Grid item xs={12} md={6} lg={6} className='m-14'>
																<FormHelperText>Kind of Theme for Product page</FormHelperText>
																<Select
																	native
																	onChange={onChangeThemeProduct}
																	value={kindThemeProduct}
																	name='Code'
																	inputProps={{
																		id: 'age-native-required',
																	}}
																>
																	<option value={0}>Original</option>
																	<option value={1}>Theme 1</option>
																</Select>
															</Grid>
														</Grid>
													</>)
													: null
												}
											</Grid>) : null
										}
									</Grid>
								</Grid>
							</Grid>
						}
						<FormControlLabel
							control={
								<Checkbox
									checked={nIsActiveState}
									onChange={handleChangeCheckbox}
									name='checkedC'
									color='primary'
								/>
							}
							label='Active'
							className={classes.checkboxform}
						/>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant="contained" onClick={editProcess} color="secondary">
								{nButtonText}
							</Button>
							<Button className={classes.buttons} variant="contained" color="primary" onClick={handleClose}>
								Cancel
							</Button>
						</div>
					</div>
				</Fade>
			</Modal>
			<div>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => addAgency()}
				>
					<span className='hidden sm:flex'>Add Content</span>
					<span className='flex sm:hidden'>Add</span>
				</Button>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => openSearchModel()}
				>
					<span className='hidden sm:flex'><SearchIcon />Filter</span>
					<span className='flex sm:hidden'><SearchIcon /></span>
				</Button>
			</div>
			<FuseScrollbars className="flex-grow overflow-x-auto">
				<Table stickyHeader className="min-w-xl" aria-labelledby="tableTitle">
					<AgencyTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={agencyData.length}
					/>
					<TableBody>
						{_.orderBy(
							agencyData,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className="h-64 cursor-pointer"
									hover
									tabIndex={-1}
									key={i}
								>
									<TableCell padding="none" className="w-20 md:w-20 text-center z-99">
									</TableCell>
									<TableCell className="p-4 md:p-16 min-w-256" component="th" scope="row" onClick={() => handleOpen(i)}>
										{(getAgencyKeyFromCode(n))}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.logoUrls === null ? "" : n.logoUrls.map((k, j) =>
											<div key={j}>
												<img style={{ width: '100px', maxWidth: '100px', margin: 'auto' }} alt="" src={k} />
											</div>
										)}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.logoUrls === null ? "" : makeCarousel(imgUrlsTopSlider(n))}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.logoUrls === null ? "" : makeCarousel(imgUrlsTopBanner(n))}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.logoUrls === null ? "" : makeCarousel(imgUrlsMiddleBanner(n))}
									</TableCell>
									{/* <TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{makeListFooterSubjects(n)}
									</TableCell> */}
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.nameTranslationEng}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.nameTranslationRus}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="right" onClick={() => handleOpen(i)}>
										{n.nameTranslationHeb}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="right" onClick={() => handleOpen(i)}>
										{n.nameTranslationArb}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.phoneNumber}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.whatsappAddress}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.emailAddress}
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left">
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.active && 'bg-red',
												n.active && 'bg-green',

											)}
										/>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => handleOpen(i)} tabIndex="0" type="button" title="Edit"><span className="MuiIconButton-label"><span className="material-icons MuiIcon-root" aria-hidden="true">edit</span></span><span className="MuiTouchRipple-root"></span></button>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => deleteHandle(i)} tabIndex="0" type="button" title="Edit">
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className="flex-shrink-0 border-t-1"
				component="div"
				count={data.total}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div >
	);
}

export default withRouter(AgencyContentTable);
