import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../store';
import AgencyContentHeader from './AgencyContentHeader';
import AgencyContentTable from './AgencyContentTable';
// import jwt from 'jwt-decode'
// var userRole = jwt(window.localStorage.getItem('jwt_access_token')).role;

function AgencyContent() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<AgencyContentHeader />}
			content={<AgencyContentTable />}
			innerScroll
		/>
	);
}

export default withReducer('BasicData', reducer)(AgencyContent);
