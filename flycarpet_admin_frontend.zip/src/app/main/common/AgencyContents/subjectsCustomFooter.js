import React, { useEffect, useState, memo, useContext } from 'react';

import { Button, Grid } from '@material-ui/core'
import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';

import ActionTable from 'app/main/BasicComponents/ActionTable'
import PropertiesModal from './propertiesModal'


function SubjectsCustomFooter(props) {
  const { subjectsData, onMessage: sendMessage } = props;

  const [propSubjects, setPropSubjects] = useState([]);
  const [bodyRows, setBodyRows] = useState([]);
  const [subjects, setSubjects] = useState([]);

  const [openPropertiesModal, setOpenPropertiesModal] = useState(false);
  const [pickedData, setPickedData] = useState(null);
  const receiveMessageFromPropertiesModal = (pMsg) => {
    if (pMsg.type === 'action') {
      switch (pMsg.action) {
        case 'Add':
          console.log('pending', pMsg);
          break;
        case 'Update':
          setOpenPropertiesModal(false);
          updateTable(pMsg.data);
          break;
        case 'close':
        default:
          setOpenPropertiesModal(false);
      }
    }
  }

  const generateTableData = (pSubjects) => {
    if (!pSubjects) return;
    let listProps = [
      {
        id: 'idx',
        align: 'left',
        disablePadding: false,
        label: 'Index',
        sort: true,
        type: 'text'
      },
      {
        id: 'id',
        align: 'left',
        disablePadding: false,
        label: 'code',
        sort: false,
        type: 'text',
        show: 'hide'
      },
      {
        id: 'subject',
        align: 'center',
        disablePadding: false,
        label: 'Subjects',
        sort: true,
        type: 'text'
      },
    ],
      max = 0;

    let rows = [];
    pSubjects.forEach((subject, idx) => {
      if (subject.hrefList === undefined || subject.hrefList === null) subject.hrefList = [];
      if (max < subject.hrefList.length) max = subject.hrefList.length;
      let row = { idx: idx + 1, id: subject.id, subject: subject.subject };
      subject.hrefList.forEach((link, i) => {
        row[`link${i + 1}`] = renderLink(link);
      })
      // row[`link${subject.HrefList.length + 1}`] = renderMoreButton();
      rows.push(row);
    })
    setBodyRows(rows);

    for (let i = 0; i < max; i++) {
      listProps.push({
        id: `link${i + 1}`,
        align: 'center',
        disablePadding: false,
        label: `Link${i + 1}`,
        sort: true,
        type: 'component'
      })
    }
    listProps.push({
      id: 'edit',
      align: 'center',
      disablePadding: false,
      label: 'Edit',
      sort: false,
      type: 'button'
    });
    listProps.push({
      id: 'delete',
      align: 'center',
      disablePadding: false,
      label: 'Delete',
      sort: false,
      type: 'button'
    });
    setPropSubjects(listProps);
  }
  const updateTable = (pData) => {
    let tmpSubjects = subjects, idx = subjects.findIndex(subject => subject.id === pData.id);

    tmpSubjects[idx] = pData;
    setSubjects(tmpSubjects);
    generateTableData(tmpSubjects);
    sendMessage({
      type: 'action',
      action: 'Update',
      extraData: tmpSubjects,
    })
  }
  const editRow = (pOpt) => {
    const { action, type, id } = pOpt;
    let data = subjects.find(subject => subject.id === id);
    setPickedData(JSON.parse(JSON.stringify(data)));
    setOpenPropertiesModal(true);
  }
  const deleteRow = (pOpt) => {
    const { action, type, id } = pOpt;
    let tmpSubjects = subjects, idx = tmpSubjects.findIndex(el => el.id === id);
    tmpSubjects.splice(idx, 1);
    setSubjects(tmpSubjects);
    generateTableData(tmpSubjects);
    sendMessage({
      type: 'action',
      action: 'Update',
      extraData: tmpSubjects,
    })
  }
  const receiveMessageFromSubjectTable = (pMsg) => {
    if (pMsg.evtType === 'button') {
      switch (pMsg.kind) {
        case 'edit':
          editRow({
            action: pMsg.kind,
            type: pMsg.evtType,
            id: pMsg.id,
          })
          break;
        case 'delete':
          deleteRow({
            action: pMsg.kind,
            type: pMsg.evtType,
            id: pMsg.id,
          })
          break;
        default:
      }
    } else if (pMsg.evtType === 'column') {
      editRow({
        action: 'edit',
        type: pMsg.evtType,
        id: pMsg.id,
      })
    }
  }

  const addSubejct = () => {
    let tmpSubjects = subjects;
    let subjectItem = { idx: bodyRows.length + 1, id: Date.now(), subject: `subject ${bodyRows.length + 1}`, hrefList: [] };
    // row[`link${1}`] = renderMoreButton();
    tmpSubjects.push(subjectItem);
    setSubjects(tmpSubjects);
    generateTableData(tmpSubjects);
    sendMessage({
      type: 'action',
      action: 'Update',
      extraData: tmpSubjects,
    })
  }

  const renderLink = (pLink) => {
    return (
      <Grid container>
        <a href={pLink.Url}>{pLink.text}</a>
      </Grid>
    )
  }
  const renderMoreButton = () => {
    return (
      <Grid container >
        <Button
          className='whitespace-no-wrape normal-case'
          variant='contained'
          color='secondary'
          style={{ float: 'right', margin: '15px 5px' }}
        // onClick={() => addItem()}
        >
          <span className="hidden sm:flex">
            <AddCircleOutlineIcon />
            New
          </span>
          <span className="flex sm:hidden">
            <AddCircleOutlineIcon />
          </span>
        </Button>
      </Grid>
    )
  }

  const generatingSubjectRows = () => {
    let newRows = [...bodyRows];

  }
  useEffect(() => {
    subjectsData.forEach((subject, i) => {
      subject.id = Date.now() + i;
    })
    setSubjects(subjectsData);
    generateTableData(subjectsData);
  }, [subjectsData])

  return (
    <Grid container justify='center'>
      <Grid item xs={12} md={12} lg={12}>
        <Button
          className='whitespace-no-wrape normal-case'
          variant='contained'
          color='secondary'
          style={{ float: 'right', margin: '5px' }}
          onClick={() => addSubejct()}
        >
          <span className="hidden sm:flex">
            <AddCircleOutlineIcon />
            New Subject
          </span>
          <span className="flex sm:hidden">
            <AddCircleOutlineIcon />
          </span>
        </Button>
      </Grid>
      <Grid item style={{ maxWidth: '98%' }}>
        <ActionTable
          propColumns={propSubjects}
          bodyRows={bodyRows}
          onMessage={receiveMessageFromSubjectTable}
          extraData={{ showPagination: false }}
        />
      </Grid>
      <PropertiesModal
        open={openPropertiesModal}
        extraData={{ editData: pickedData }}
        onMessage={receiveMessageFromPropertiesModal}
      />
    </Grid>
  )
}

export default memo(SubjectsCustomFooter)