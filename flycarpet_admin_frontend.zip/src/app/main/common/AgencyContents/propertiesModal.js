import React, { useEffect, useState, memo, useCallback } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  Modal, Backdrop, Button, TextField, TextareaAutosize,
  Grid, FormHelperText, FormControl, FormControlLabel, Select, Checkbox,
} from '@material-ui/core';
import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import { Autocomplete } from '@material-ui/lab';

const PropertiesModal = (props) => {
  const { open, extraData, onMessage: sendMessage } = props;

  const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: '2px 5px',
      minWidth: 60,
    },
    modal: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      textAlign: "center",
      maxHeight: "100vh",
      overflowY: "auto",
    },
    checkboxform: {
      display: 'block',
    },
    buttons: {
      padding: '5px',
    }
  }));
  const classes = useStyles();

  const [action, setAction] = useState('Add');
  const [subjectData, setSubjectData] = useState(null);
  const [newText, setNewText] = useState('');
  const [newUrl, setNewUrl] = useState('');

  const changeProperty = (ev, kind, idx) => {
    let data = subjectData, val = ev.target.value;
    if (kind === 'subject') {
      data.subject = val;
    } else if (kind === 'label') {
      data.hrefList[idx].text = val;
    } else if (kind === 'href') {
      data.hrefList[idx].url = val;
    }
    setSubjectData(JSON.parse(JSON.stringify(data)));
  }
  const disabledAdd = useCallback(() => {
    return newText === '' || newUrl === '';
  }, [newText, newUrl]);
  const addLink = () => {
    let data = subjectData;
    if (!data.hrefList || data.hrefList === undefined) data.hrefList = [];
    data.hrefList.push({ text: newText, url: newUrl });
    initialize();
    setSubjectData(data);
  }
  const deleteLink = (idx) => {
    let data = subjectData, list = data.hrefList;
    list.splice(idx, 1);
    data.hrefList = list;
    setSubjectData(JSON.parse(JSON.stringify(data)));
  }
  const editProcess = () => {
    initialize();
    sendMessage({
      type: 'action',
      action: action,
      data: subjectData,
    })
  }
  const handleCloseModal = () => {
    initialize();
    sendMessage({
      type: 'action',
      action: 'close',
    });
  }

  useEffect(() => {
  }, [subjectData])


  const setPickedState = (pData) => {
    setSubjectData(pData);
    setAction('Update');
  }
  const initialize = () => {
    // setPickedState(null);
    setNewText('');
    setNewUrl('');
  }
  useEffect(() => {
    const data = extraData?.editData ?? null;
    if (data) {
      setPickedState(data);
    } else {
      initialize();
    }
  }, [extraData]);
  useEffect(() => {
    initialize();
  }, [])


  return (
    <Modal
      open={open}
      onClose={handleCloseModal}
      className={classes.modal}
      closeAfterTransition
      aria-labelledby='transition-modal-title'
      aria-describedby='transition-modal-description'
      BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 500,
      }}
    >
      <div className={classes.paper}>
        <h2 id="server-modal-title" >{`${action} properties of subjects`}</h2>
        <Grid container justify='center' style={{ margin: '20px 5px', display: 'grid' }}>
          <Grid item>
            <FormControl required className={classes.formControl}>
              <FormHelperText>Subject Name</FormHelperText>
              <TextField defaultValue={subjectData?.subject} className={classes.textfield} onChange={ev => changeProperty(ev, 'subject')} />
            </FormControl>
          </Grid>
          <Grid container>
            <Grid item>
              {subjectData?.hrefList?.map((href, i) => {
                return (
                  <Grid item className='mt-2' key={i}>
                    <FormControl required className={classes.formControl}>
                      <FormHelperText>Text</FormHelperText>
                      <TextField value={href.text} className={classes.textfield} onChange={ev => changeProperty(ev, 'label', i)} />
                    </FormControl>
                    <FormControl required className={classes.formControl}>
                      <FormHelperText>Url</FormHelperText>
                      <TextField value={href.url} className={classes.textfield} onChange={ev => changeProperty(ev, 'href', i)} />
                    </FormControl>
                    <Button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit mt-20'
                      onClick={ev => deleteLink(i)}
                      tabIndex='0' type='button' title='Delete'>
                      <span className='MuiIconButton-label'>
                        <span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
                      </span>
                      <span className='MuiTouchRipple-root'></span>
                    </Button>
                  </Grid>
                )
              })}
              <Grid item className='mt-5'>
                <FormControl required className={classes.formControl}>
                  <FormHelperText>Text</FormHelperText>
                  <TextField value={newText} className={classes.textfield} onChange={ev => setNewText(ev.target.value)} />
                </FormControl>
                <FormControl required className={classes.formControl}>
                  <FormHelperText>Url</FormHelperText>
                  <TextField value={newUrl} className={classes.textfield} onChange={ev => setNewUrl(ev.target.value)} />
                </FormControl>
                <Button
                  className='whitespace-no-wrape normal-case'
                  variant='contained'
                  color='secondary'
                  style={{ float: 'right', margin: '15px 5px' }}
                  disabled={disabledAdd()}
                  onClick={() => addLink()}
                >
                  <span className="hidden sm:flex">
                    <AddCircleOutlineIcon />
                  </span>
                </Button>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        <Grid container justify='space-evenly'>
          <Button className={classes.buttons} variant="contained" onClick={editProcess} color="secondary">
            {action}
          </Button>
          <Button className={classes.buttons} variant="contained" color="primary" onClick={handleCloseModal}>
            Cancel
          </Button>
        </Grid>
      </div>
    </Modal >
  )
}

export default memo(PropertiesModal);