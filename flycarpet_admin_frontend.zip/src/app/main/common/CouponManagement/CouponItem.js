import React, { useState, useRef, useEffect } from 'react';
import './custom.css';

function CouponItem(props) {
	const [pnr, setPnr] = useState(props.data.pnr);
	const [usedCount, setUsedCount] = useState(props.data.usedCount);

	const paxNumRef = useRef(null);
	const maxCountRef = useRef(null);

	useEffect(() => {
		paxNumRef.current.checked = (props.data.multiplyByPaxNum);
		maxCountRef.current.value = (props.data.usesMaxCount);
	})

	const handleChangePnr = (event) => {
		setPnr(event.target.value);
	}

	const handleChangeUsed = (event) => {
		let _usedCount = event.target.checked ? 1 : 0;
		setUsedCount(_usedCount);

		props.handleChangeUsed({
			code: props.data.code,
			used: event.target.checked,
			pnr: pnr,
			usedCount: _usedCount,
			codeIndex: props.index
		});
	}

	const handleChangeState = (event) => {
		props.updateCodeState({
			code: props.data.code,
			isMultiByPaxNum: paxNumRef.current.checked,
			maxCount: parseInt(maxCountRef.current.value),
			codeIndex: props.index
		});
	}

	const handleClickDelete = (event) => {
		props.handleClickDelete({
			codeIndex: props.index,
		});
	}

	return (
		<tr className="coupon-item">
			<td>{props.index + 1}</td>
			<td>
				<input type="checkbox" defaultChecked={props.data.usedCount > 0} onChange={handleChangeUsed} readOnly />
			</td>
			<td>{props.data.code}</td>
			<td>
				<input className="input-box pnr-box" defaultValue={pnr ? pnr : ''} onChange={handleChangePnr} />
			</td>
			<td><input className="input-box maxcount-box" onBlur={handleChangeState} ref={maxCountRef} /></td>
			<td>{usedCount}</td>
			<td><input type="checkbox" onChange={handleChangeState} ref={paxNumRef}/></td>
			<td><span className='material-icons MuiIcon-root' aria-hidden='true' onClick={handleClickDelete} >delete</span></td>
		</tr>
	);
}

export default CouponItem;