import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Tooltip from '@material-ui/core/Tooltip';
import React from 'react';
import i18next from 'i18next';
import jwt from 'jwt-decode'
import ar from '../../../fuse-configs/navigation-i18n/ar';
import en from '../../../fuse-configs/navigation-i18n/en';
import tr from '../../../fuse-configs/navigation-i18n/tr';

i18next.addResourceBundle('en', 'navigation', en);
i18next.addResourceBundle('tr', 'navigation', tr);
i18next.addResourceBundle('ar', 'navigation', ar);
var token = window.localStorage.getItem('jwt_access_token');
var userRole = (token == null ? 'superadmin' : jwt(window.localStorage.getItem('jwt_access_token')).role)
const rows = (userRole === 'superadmin' || userRole === 'admin') ? [
    {
        id: 'series',
        translate: 'Series',
        align: 'left',
        disablePadding: false,
        label: 'Series',
        sort: true
    },
    {
        id: 'name',
        translate: 'Name',
        align: 'left',
        disablePadding: false,
        label: 'Name',
        sort: true
    },
    {
        id: 'numOfCoupons',
        translate: 'Num of Coupons',
        align: 'left',
        disablePadding: false,
        label: 'Num of Coupons',
        sort: true
    },
    {
        id: 'used',
        translate: 'Total Used',
        align: 'left',
        disablePadding: false,
        label: 'Total Used',
        sort: true
    },
    {
        id: 'discount',
        translate: 'Discount',
        align: 'left',
        disablePadding: false,
        label: 'Discount',
        sort: true
    },
    {
        id: 'oneTime',
        translate: 'One-Time',
        align: 'left',
        disablePadding: false,
        label: 'One-Time',
        sort: true
    },
    {
        id: 'from',
        translate: 'From',
        align: 'left',
        disablePadding: false,
        label: 'From',
        sort: true
    },
    {
        id: 'until',
        translate: 'Until',
        align: 'left',
        disablePadding: false,
        label: 'Until',
        sort: true
    },
    {
        id: 'create_data',
        translate: 'CreatedDate',
        align: 'left',
        disablePadding: false,
        label: 'CreatedDate',
        sort: true
    },
    {
        id: 'acitve',
        translate: 'Active',
        align: 'left',
        disablePadding: false,
        label: 'Active',
        sort: true
    },
    {
        id: 'delete',
        translate: 'Controls',
        align: 'left',
        disablePadding: false,
        label: '',
        sort: true
    },
] : [];

function CouponTableHead(props) {
    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };
    return (
        <TableHead>
            <TableRow className="h-64">
                <TableCell padding="none" className="w-20 md:w-20 text-center z-99">
                </TableCell>
                {rows.map(row => {
                    return (
                        <TableCell
                            className="p-4 md:p-16"
                            key={row.id}
                            align={row.align}
                            padding={row.disablePadding ? 'none' : 'default'}
                            sortDirection={props.order.id === row.id ? props.order.direction : false}
                        >
                            {row.sort && (
                                <Tooltip
                                    title="Sort"
                                    placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                    enterDelay={300}
                                >
                                    <TableSortLabel
                                        active={props.order.id === row.id}
                                        direction={props.order.direction}
                                        onClick={createSortHandler(row.id)}
                                    >
                                        {row.label}
                                    </TableSortLabel>
                                </Tooltip>
                            )}
                        </TableCell>
                    );
                }, this)}
                <TableCell padding="none" className="w-20 md:w-20 text-center z-99">
                </TableCell>
            </TableRow>
        </TableHead>
    );
}

export default CouponTableHead;
