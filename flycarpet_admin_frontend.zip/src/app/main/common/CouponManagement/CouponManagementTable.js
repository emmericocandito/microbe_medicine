import 'date-fns';
import FuseScrollbars from '@fuse/core/FuseScrollbars';
import axios from 'axios';
import _ from '@lodash';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import FuseLoading from '@fuse/core/FuseLoading';
import CouponManagementTableHead from './CouponManagementTableHead';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import Backdrop from '@material-ui/core/Backdrop';
import Fade from '@material-ui/core/Fade';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import CircularProgress from '@material-ui/core/CircularProgress';
import InputLabel from '@material-ui/core/InputLabel';
import FormControl from '@material-ui/core/FormControl';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Grid from '@material-ui/core/Grid';
import DateFnsUtils from '@date-io/date-fns';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import ListItemText from '@material-ui/core/ListItemText';
import Checkbox from '@material-ui/core/Checkbox';
import Input from '@material-ui/core/Input';
import clsx from 'clsx';
import jwt from 'jwt-decode'
import CouponItem from './CouponItem'
import {
	MuiPickersUtilsProvider,
	KeyboardDatePicker,
	KeyboardDateTimePicker,
} from '@material-ui/pickers';
import { baseURL } from '../../utils';

var userRole = jwt(window.localStorage.getItem('jwt_access_token')).role
function UserManagementTable(props) {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			margin: theme.spacing(0),
			minWidth: 60,
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
			minWidth: 120,
			overflow: 'auto'
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			width: 1000,
			maxWidth: 1000,
			overflowY: "auto",
			maxHeight: "100vh",
		},
		button_group: {
			padding: '20px 20px 0px 20px',
			textAlign: 'center',
		},
		buttons: {
			marginLeft: '10px'
		},
		fo_circular: {
			textAlign: 'center',
			position: 'absolute',
			left: '50%',
			transform: 'translatex(-50%)'
		},
		itemField: {
			marginTop: 10,
			marginRight: 10,
			width: '100%',
		},
		couponGenParamsWrapper: {
			display: 'flex',
			position: 'absolute',
			top: '15px',
			left: '10px'
		},
		genParamsOptionsWrapper: {
			border: 'solid 0.5px gray',
			padding: '8px',
			marginRight: '10px',
			width: '240px'
		},
		generateParamInput: {
			width: '45%',
			marginRight: '5px'
		},
		generateParam: {
			width: '100%',
		},
		packLabel: {
			width: '40%',
			color: 'black',
			textAlign: 'center',
			margin: 'auto',
			lineHeight: '20px',
			marginRight: 10,
		},
		w_2: {
			width: '200% !important',
		},
		checkbox: {
			verticalAlign: 'bottom',
			padding: '0px'
		},
		couponCodesWrapper: {
			height: 170,
			padding: 10,
			overflowY: 'auto',
			display: 'flex',
			flexDirection: "row",
    		justifyContent: "flex-end"
		},
		pasteBox: {
			width: '150px',
			height: '100%',
			minHeight: 150,
			padding: '3px',
			border:'solid 1px'
		},
		couponItemsWrapper: {
		},
		couponDetailTable: {
			textAlign: 'center',
			width: '495px'
		}
	}));

	const classes = useStyles();
	const [loading, setLoading] = useState(true);
	const [loadingCircle, setLoadingCircle] = useState(false);

	const [activeIndex, setActiveIndex] = useState(-1);
	const [activeCodeIndex, setActiveCodeIndex] = useState(-1);
	const [couponId, setCouponId] = useState(null);

	const [ruleCode, setRuleCode] = useState("");
	const [ruleName, setRuleName] = useState("");

	const [codeUsesMaxCount, setCodeUsesMaxCount] = useState(1);
	const [requiredNumOfCodes, setRequiredNumOfCodes] = useState(1);
	const [multiplyByPaxNum, setMultiplyByPaxNum] = useState(false);
	const [autoGeneration, setAutoGeneration] = useState(false);

	const [couponType, setCouponType] = useState("singleUse");
	const [dealId, setDealId] = useState(null);
	const [totalUsed, setTotalUsed] = useState(0);
	const [codeList, setCodeList] = useState([]);

	const [codeSubsidy, setCodeSubsidy] = useState("");
	const [codeAgent, setCodeAgent] = useState("");

	const [discByPct, setDiscByPct] = useState(true);
	const [discount, setDiscount] = useState(0);
	const [discByPctNet, setDiscByPctNet] = useState(true);
	const [discountNet, setDiscountNet] = useState(0);
	const [discByPctG, setDiscByPctG] = useState(true);
	const [discountG, setDiscountG] = useState(0);
	const [discByPctI, setDiscByPctI] = useState(true);
	const [discountI, setDiscountI] = useState(0);

	const [discByPctFH, setDiscByPctFH] = useState(true);
	const [discountFH, setDiscountFH] = useState(null);
	const [excludeDestinationsFH, setExcludeDestinationsFH] = useState([]);
	const [discByPctFO, setDiscByPctFO] = useState(true);
	const [discountFO, setDiscountFO] = useState(null);
	const [excludeDestinationsFO, setExcludeDestinationsFO] = useState([]);
	const [discByPctFD, setDiscByPctFD] = useState(true);
	const [discountFD, setDiscountFD] = useState(null);
	const [excludeDestinationsFD, setExcludeDestinationsFD] = useState([]);
	const [discByPctORG, setDiscByPctORG] = useState(true);
	const [discountORG, setDiscountORG] = useState(null);
	const [excludeDestinationsORG, setExcludeDestinationsORG] = useState([]);
	const [discByPctSPORT, setDiscByPctSPORT] = useState(true);
	const [discountSPORT, setDiscountSPORT] = useState(null);
	const [excludeDestinationsSPORT, setExcludeDestinationsSPORT] = useState([]);

	const [startDate, setStartDate] = useState(null);
	const [endDate, setEndDate] = useState(null);
	const [createDate, setCreateDate] = useState(null);
	const [active, setActive] = useState(true);

	const [packStartDateFrom, setPackStartDateFrom] = useState(null);
	const [packStartDateTo, setPackStartDateTo] = useState(null);

	const [destinationsList, setDestinationList] = useState([]);
	const [packDestinations, setPackDestinations] = useState([]);

	const [nButtonText, setButtonText] = useState(null);
	const [nButtonState, setButtonState] = useState(null);
	const [confirmText, setConfirmText] = useState(null);
	const [confirmState, setConfirmState] = useState(null);
	const [selected] = useState([]);
	const [data, setData] = useState();
	const [dataLength, setDataLength] = useState(0);
	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [warningOpen, setWarningOpen] = useState(false);
	const [warningText, setWarningText] = useState(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});
	const [open, setOpen] = useState(false);

	useEffect(() => {
		reopen(1, 10);
		getDestiationList();
		// eslint-disable-next-line
	}, [])

	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}
	function handleChangePage(event, value) {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage
		reopen(from, to);
	}
	function handleChangeRowsPerPage(event) {
		setPage(0);
		setRowsPerPage(event.target.value);
		reopen(1, event.target.value);
	}
	const editCoupon = (i) => {
		setButtonText('Update');
		setButtonState('Update Coupon');
		setCouponId(data[i].id);
		setActiveIndex(i);

		setRuleCode(data[i].ruleCode);
		setRuleName(data[i].ruleName);
		setTotalUsed(calcTotalUsed(data[i].couponCodes));

		setRequiredNumOfCodes(1);
		setCodeUsesMaxCount(1);
		setMultiplyByPaxNum(false);
		setAutoGeneration(false);

		setCouponType(data[i].couponType);
		setDealId(data[i].dealId);
		setCodeSubsidy(data[i].codeSubside);
		setCodeAgent(data[i].codeAgent);

		setDiscount(data[i].discount);
		setDiscByPct(data[i].discByPct);
		setDiscountNet(data[i].discountNet);
		setDiscByPctNet(data[i].discByPctNet);
		setDiscountG(data[i].discountG);
		setDiscByPctG(data[i].discByPctG);
		setDiscountI(data[i].discountI);
		setDiscByPctI(data[i].discByPctI);

		setDiscountFH(null);
		setDiscByPctFH(true);
		setExcludeDestinationsFH([]);
		setDiscountFO(null);
		setDiscByPctFO(true);
		setExcludeDestinationsFO([]);
		setDiscountFD(null);
		setDiscByPctFD(true);
		setExcludeDestinationsFD([]);
		setDiscountORG(null);
		setDiscByPctORG(true);
		setExcludeDestinationsORG([]);
		setDiscountSPORT(null);
		setDiscByPctSPORT(true);
		setExcludeDestinationsSPORT([]);
		if (data[i].discountsByPackCateg) {
			data[i].discountsByPackCateg.forEach(cate => {
				switch (cate.packageCategoryCode) {
					case 'vacation_pack':
						setDiscountFH(cate.discount);
						setDiscByPctFH(cate.discByPct);
						setExcludeDestinationsFH(!cate.destinationsToExclude ? [] : cate.destinationsToExclude);
						break;
					case 'Organize_tour_packages':
						setDiscountORG(cate.discount);
						setDiscByPctORG(cate.discByPct);
						setExcludeDestinationsORG(!cate.destinationsToExclude ? [] : cate.destinationsToExclude);
						break;
					case 'Flight_Only':
						setDiscountFO(cate.discount);
						setDiscByPctFO(cate.discByPct);
						setExcludeDestinationsFO(!cate.destinationsToExclude ? [] : cate.destinationsToExclude);
						break;
					case 'Flight_Drive':
						setDiscountFD(cate.discount);
						setDiscByPctFD(cate.discByPct);
						setExcludeDestinationsFD(!cate.destinationsToExclude ? [] : cate.destinationsToExclude);
						break;
					case 'sport_pack':
						setDiscountSPORT(cate.discount);
						setDiscByPctSPORT(cate.discByPct);
						setExcludeDestinationsSPORT(!cate.destinationsToExclude ? [] : cate.destinationsToExclude);
						break;
				}
			})
		}

		setStartDate(data[i].startDate);
		setEndDate(data[i].endDate);
		setCreateDate(data[i].createTime);
		setActive(data[i].active);

		setPackStartDateFrom(data[i].packStartDateFrom);
		setPackStartDateTo(data[i].packStartDateTo);

		setCodeList([]);

		setPackDestinations(!data[i].packDestinations ? [] : data[i].packDestinations);


		setOpen(true);
	}
	const createNewCoupon = () => {
		setButtonText('Create');
		setButtonState('Create a new Coupon');
		initialValue();
		setOpen(true);
	}
	const deleteCoupon = async (i) => {
		setCouponId(data[i].id);
		setConfirmText("Do you want to delete this coupon?");
		setConfirmState('deleteCoupon');
		setConfirmOpen(true);
	}
	const download = function (data, strName) {
		const blob = new Blob([data], { type: 'text/csv' });
		const url = window.URL.createObjectURL(blob)

		const a = document.createElement('a')
		a.setAttribute('href', url)
		a.setAttribute('download', `${strName}.csv`);
		a.click()
	}
	const downloadCoupon = async (i) => {
		let csvdata = `code,used,pnr\n`;
		data[i].couponCodes.forEach(n => {
			csvdata += `${n.code},${n.usedCount},${n.pnr?n.pnr:''}\n`
		})

    	download(csvdata, data[i].id);
	}
	const handleClose = () => {
		setOpen(false);
	}
	const handleCloseWarning = () => {
		setWarningOpen(false);
	}
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}
	async function confirmProcess() {
		switch (confirmState) {
			case 'deleteCoupon': {
				await axios.delete(baseURL + 'api/couponRule/' + couponId, {
					headers: {
						'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
						'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
					}
				})

				setConfirmOpen(false);
				reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
				break;
			}
			case 'deleteCouponCode': {
				await axios.delete(`${baseURL}api/couponRule/${couponId}/${data[activeIndex].couponCodes[activeCodeIndex].code}`, {
					headers: {
						'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
						'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
					},
				});

				if (activeIndex !== -1) {
					data[activeIndex].couponCodes.splice(activeCodeIndex, 1);
					setTotalUsed(calcTotalUsed(data[activeIndex].couponCodes));
				}

				setConfirmOpen(false);
				break;
			}
		}
	}
	async function editProcess(index) {
		setLoadingCircle(true);
		var request_url = baseURL + 'api/couponRule';
		if (nButtonState === 'Update Coupon') {
			request_url += '/' + couponId;
		}

		var config = {
			"RuleCode": ruleCode,
			"RuleName": ruleName,
			"DealId": dealId,
			"CouponType": couponType,

			"CodeSubside": codeSubsidy,
			"CodeAgent": codeAgent,

			"Discount": parseInt(discount),
			"DiscountNet": parseInt(discountNet),
			"DiscountG": parseInt(discountG),
			"DiscountI": parseInt(discountI),
			"DiscByPct": discByPct,
			"DiscByPctNet": discByPctNet,
			"DiscByPctG": discByPctG,
			"DiscByPctI": discByPctI,

			"DiscountsByPackCateg": [],
			"PackDestinations": packDestinations,

			"PackStartDateFrom": DateToStr(packStartDateFrom),
			"PackStartDateTo": DateToStr(packStartDateTo),
			"StartDate": startDate,
			"EndDate": endDate,
			"Active": active,

			"CodeGenerationAction": {
				"CodeList": codeList,
				"CodeUsesMaxCount": parseInt(codeUsesMaxCount),
				"RequiredNumOfCodes": parseInt(requiredNumOfCodes),
				"multiplyByPaxNum": multiplyByPaxNum,
				"AutoGeneration": (autoGeneration),
			}
		}

		if (!isNaN(parseInt(discountFH))) {
			config.DiscountsByPackCateg.push({ "PackageCategoryCode": 'vacation_pack', "Discount": parseInt(discountFH), "DiscByPct": discByPctFH, "DestinationsToExclude": excludeDestinationsFH });
		}
		if (!isNaN(parseInt(discountORG))) {
			config.DiscountsByPackCateg.push({ "PackageCategoryCode": 'Organize_tour_packages', "Discount": parseInt(discountORG), "DiscByPct": discByPctORG, "DestinationsToExclude": excludeDestinationsORG });
		}
		if (!isNaN(parseInt(discountFO))) {
			config.DiscountsByPackCateg.push({ "PackageCategoryCode": 'Flight_Only', "Discount": parseInt(discountFO), "DiscByPct": discByPctFO, "DestinationsToExclude": excludeDestinationsFO });
		}
		if (!isNaN(parseInt(discountFD))) {
			config.DiscountsByPackCateg.push({ "PackageCategoryCode": 'Flight_Drive', "Discount": parseInt(discountFD), "DiscByPct": discByPctFD, "DestinationsToExclude": excludeDestinationsFD });
		}
		if (!isNaN(parseInt(discountSPORT))) {
			config.DiscountsByPackCateg.push({ "PackageCategoryCode": 'sport_pack', "Discount": parseInt(discountSPORT), "DiscByPct": discByPctSPORT, "DestinationsToExclude": excludeDestinationsSPORT });
		}

		await axios({
			method: 'post',
			url: request_url,
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			},
			data: config
		}).then(response => {
			setLoadingCircle(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningText(response.data.error.message);
				setWarningOpen(true);
			} else {
				reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}
		})
		.catch(error => {
			setLoadingCircle(false);
			setWarningText("HTTP Error");
			setWarningOpen(true);
			return;
		});
	};
	async function reopen(from, to) {
		const response = await axios.get(`${baseURL}api/couponRule?from=${from}&to=${to}`, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		});
		const data = response.data['data'];
		setData(data);
		setDataLength(response.data['total'])
		setActiveIndex(-1);
		setLoading(false);
		setOpen(false);
	};
	async function updateCouponUsedState({ code, used, pnr, usedCount, codeIndex }) {
		setLoadingCircle(true);
		var request_url = `${baseURL}api/couponRule/${couponId}/${code}/setAsUsed?pnr=${pnr ? pnr : ''}&isSet=${used}`;
		await axios({
			method: 'post',
			url: request_url,
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			},
			data: {}
		}).then(response => {
			setLoadingCircle(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningText(response.data.error.message);
				setWarningOpen(true);
			}

			if (activeIndex !== -1) {
				data[activeIndex].couponCodes[codeIndex].usedCount = usedCount;
				data[activeIndex].couponCodes[codeIndex].pnr = pnr;
				setTotalUsed(calcTotalUsed(data[activeIndex].couponCodes));
			}
		})
		.catch(error => {
			setLoadingCircle(false);
			setWarningText("HTTP Error");
			setWarningOpen(true);
			return;
		});
	}
	async function updateCodeState({ code, isMultiByPaxNum, maxCount, codeIndex }) {
		setLoadingCircle(true);
		var request_url = `${baseURL}api/couponRule/${couponId}/${code}`;
		await axios({
			method: 'post',
			url: request_url,
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			},
			data: {
				"UsesMaxCount": maxCount,
				"MultiplyByPaxNum": isMultiByPaxNum
			}
		}).then(response => {
			setLoadingCircle(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningText(response.data.error.message);
				setWarningOpen(true);
			}

			if (activeIndex !== -1) {
				data[activeIndex].couponCodes[codeIndex].usesMaxCount = maxCount;
				data[activeIndex].couponCodes[codeIndex].multiplyByPaxNum = isMultiByPaxNum;
			}
		})
		.catch(error => {
			setLoadingCircle(false);
			setWarningText("HTTP Error");
			setWarningOpen(true);
			return;
		});
	}
	function deleteCouponCode({ codeIndex }) {
		setActiveCodeIndex(codeIndex);
		setConfirmText("Do you want to delete this coupon code?");
		setConfirmState('deleteCouponCode');
		setConfirmOpen(true);
	}
	async function getDestiationList() {
		const response = await axios.get(baseURL + 'api/destination/?from=1&to=1000');
		const _data = response.data.data;
		setDestinationList(_data);
	}
	function initialValue() {
		setActiveIndex(-1);

		setRuleName(null);
		setRuleCode(null);
		setTotalUsed(0);
		setDealId(null);
		setRequiredNumOfCodes(1);
		setCodeUsesMaxCount(1);
		setMultiplyByPaxNum(false);
		setAutoGeneration(false);
		setCodeList([]);
		setCouponType('singleUse');

		setCodeSubsidy(null);
		setCodeAgent(null);

		setDiscount(0);
		setDiscByPct(true);
		setDiscountNet(0);
		setDiscByPctNet(true);
		setDiscountG(0);
		setDiscByPctG(true);
		setDiscountI(0);
		setDiscByPctI(true);

		setDiscountFH(0);
		setDiscByPctFH(true);
		setExcludeDestinationsFH([]);
		setDiscountFO(0);
		setDiscByPctFO(true);
		setExcludeDestinationsFO([]);
		setDiscountFD(0);
		setDiscByPctFD(true);
		setExcludeDestinationsFD([]);
		setDiscountORG(0);
		setDiscByPctORG(true);
		setExcludeDestinationsORG([]);
		setDiscountSPORT(0);
		setDiscByPctSPORT(true);
		setExcludeDestinationsSPORT([]);

		setPackDestinations([]);

		let startDate = new Date();
		startDate.setHours(0, 0, 0);
		let endDate = new Date();
		endDate.setHours(12, 59, 0);
		let toDate = new Date();
		toDate.setFullYear(toDate.getFullYear() + 1);

		setStartDate(startDate);
		setEndDate(endDate);
		setPackStartDateFrom(startDate);
		setPackStartDateTo(toDate);
		setCreateDate(startDate);

		setActive(true);
	}

	function TimeToStr(date) {
		if (date == null) return null;
		if (date instanceof Date) {
			date = date.toISOString();
		}
		return `${date.substr(0, 10)} ${date.substr(11, 5)}`;
	}
	function DateToStr(date) {
		if (date == null) return null;
		if (date instanceof Date) {
			date = date.toISOString();
		}

		return date.substr(0, 10);
	}
	function calcTotalUsed(_couponCodes) {
		let _used = 0;
		_couponCodes.forEach(code => {
			_used += code.usedCount;
		})
		return _used;
	}
	function makeCodeList(_codes) {
		let _strCodes = '';
		_codes.forEach(code => {
			_strCodes += (code + "\n");
		})
		return _strCodes;
	}

	/////////// event handlers ///////////////////
	function handleChangeCode(event) {
		setRuleCode(event.target.value)
	}
	function handleChangeName(event) {
		setRuleName(event.target.value)
	}
	function handleChangeMultiplyByPaxNum(event) {
		setMultiplyByPaxNum(event.target.checked)
	}
	function handleChangeAutoGeneration(event) {
		setAutoGeneration(event.target.checked)
	}
	function handleChangeRequiredNumOfCodes(event) {
		setRequiredNumOfCodes(event.target.value)
	}
	function handleChangeCouponType(event) {
		setCouponType(event.target.value)
	}
	function handleChangeSubsidyCode(event) {
		setCodeSubsidy(event.target.value)
	}
	function handleChangeAgentCode(event) {
		setCodeAgent(event.target.value)
	}
	function handleChangeDiscountType(event) {
		setDiscByPct(event.target.value==='PERCENT')
	}
	function handleChangeDiscount(event) {
		setDiscount(event.target.value)
	}
	function handleChangeDiscountTypeNet(event) {
		setDiscByPctNet(event.target.value==='PERCENT')
	}
	function handleChangeDiscountNet(event) {
		setDiscountNet(event.target.value)
	}
	function handleChangeDiscountTypeG(event) {
		setDiscByPctG(event.target.value==='PERCENT')
	}
	function handleChangeDiscountG(event) {
		setDiscountG(event.target.value)
	}
	function handleChangeDiscountTypeI(event) {
		setDiscByPctI(event.target.value==='PERCENT')
	}
	function handleChangeDiscountI(event) {
		setDiscountI(event.target.value)
	}
	function handleChangeDiscountTypeFH(event) {
		setDiscByPctFH(event.target.value==='PERCENT')
	}
	function handleChangeDiscountFH(event) {
		setDiscountFH(event.target.value)
	}
	function handleChangeExcludeDestinationsFH(event) {
		setExcludeDestinationsFH(event.target.value);
	}
	function handleChangeDiscountTypeFO(event) {
		setDiscByPctFO(event.target.value==='PERCENT')
	}
	function handleChangeDiscountFO(event) {
		setDiscountFO(event.target.value)
	}
	function handleChangeExcludeDestinationsFO(event) {
		setExcludeDestinationsFO(event.target.value);
	}
	function handleChangeDiscountTypeFD(event) {
		setDiscByPctFD(event.target.value==='PERCENT')
	}
	function handleChangeDiscountFD(event) {
		setDiscountFD(event.target.value)
	}
	function handleChangeExcludeDestinationsFD(event) {
		setExcludeDestinationsFD(event.target.value);
	}
	function handleChangeDiscountTypeORG(event) {
		setDiscByPctORG(event.target.value==='PERCENT')
	}
	function handleChangeDiscountORG(event) {
		setDiscountORG(event.target.value)
	}
	function handleChangeExcludeDestinationsORG(event) {
		setExcludeDestinationsORG(event.target.value);
	}
	function handleChangeDiscountTypeSPORT(event) {
		setDiscByPctSPORT(event.target.value==='PERCENT')
	}
	function handleChangeDiscountSPORT(event) {
		setDiscountSPORT(event.target.value)
	}
	function handleChangeExcludeDestinationsSPORT(event) {
		setExcludeDestinationsSPORT(event.target.value);
	}
	const handleChangePackStartDateFrom = (date) => {
		setPackStartDateFrom(date);
	}
	const handleChangePackStartDateTo = (date) => {
		setPackStartDateTo(date);
	}
	const handleChangeStartDate = (date) => {
		setStartDate(date);
	};
	const handleChangeEndDate = (date) => {
		setEndDate(date);
	};
	function handleChangeDealId(event) {
		setDealId(event.target.value)
	}
	function handleCodeUsesMaxCount(event) {
		setCodeUsesMaxCount(event.target.value)
	}
	function handleChangePasteBox(event) {
		let codes = event.target.value.split('\n').filter(c => {
			return (c.replace(/\s/g, '') !== '');
		});

		setCodeList(codes);
		setRequiredNumOfCodes(Math.max(codes.length, 1));
	}
	function handleChangePackDestinations(event) {
		setPackDestinations(event.target.value);
	}

	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className='w-full flex flex-col'>
			<div>
				<div className='spinner-border text-primary' role='status'>
					<span className='sr-only'>Loading...</span>
				</div>
				<Modal
					open={warningOpen}
					onClose={handleCloseWarning}
					className={classes.modal}
					aria-labelledby='simple-modal-title'
					aria-describedby='simple-modal-description'
				>
					<div className={classes.paper} style={{ textAlign: 'center' }}>
						<h2 id='server-modal-title' >Warning</h2>
						<p id='server-modal-description'>{warningText}</p>
						<Button className='whitespace-no-wrap normal-case'
							variant='contained'
							color='secondary'
							onClick={handleCloseWarning}>Close
						</Button>
					</div>
				</Modal>
				<Modal
					open={confirmOpen}
					onClose={handleCloseConfirm}
					className={classes.modal}
					aria-labelledby='simple-modal-title'
					aria-describedby='simple-modal-description'
				>
					<div className={classes.paper} style={{ textAlign: 'center' }}>
						<h2 id='server-modal-title' >Confirm</h2>
						<p id='server-modal-description'>{confirmText}</p>
						<Button className='whitespace-no-wrap normal-case'
							style={{ margin: '10px 5px' }}
							variant='contained'
							color='secondary'
							onClick={confirmProcess}>Confirm
						</Button>
						<Button className='whitespace-no-wrap normal-case'
							style={{ margin: '10px 5px' }}
							variant='contained'
							color='secondary'
							onClick={handleCloseConfirm}>Cancel
						</Button>
					</div>
				</Modal>
				<Modal
					aria-labelledby='transition-modal-title'
					aria-describedby='transition-modal-description'
					className={classes.modal}
					open={open}
					onClose={handleClose}
					closeAfterTransition
					BackdropComponent={Backdrop}
					BackdropProps={{
						timeout: 500,
					}}
				>
					<Fade in={open}>
						<div className={classes.paper}>
							<div className={classes.fo_circular}>
								{loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
							</div>
							<div style={{ textAlign: 'center' }}>
								<h2 id='transition-modal-title' >{nButtonState}</h2>
							</div>
							<div>
								<div className='flex'>
									<TextField onChange={handleChangeCode} className={classes.itemField} label="Rule Code" defaultValue={ruleCode} inputProps={{readOnly:true}} />
									<TextField onChange={handleChangeName} className={classes.itemField} label="Name" defaultValue={ruleName} />
									<TextField className={classes.itemField} label="Total Used" value={totalUsed} />
								</div>
								<Grid className='relative'>
									<div className={classes.couponGenParamsWrapper}>
										<div className={classes.genParamsOptionsWrapper} >
											<TextField onChange={handleCodeUsesMaxCount} className={classes.generateParamInput} label="Max Count of use" defaultValue={codeUsesMaxCount} />
											<TextField onChange={handleChangeRequiredNumOfCodes} className={classes.generateParamInput} label="Required Num Of Codes" value={requiredNumOfCodes} />
											<FormControlLabel className={classes.generateParam}
												control={
													<Checkbox
														checked={multiplyByPaxNum}
														onChange={handleChangeMultiplyByPaxNum}
													/>
												}
												label="MultiplyByPaxNum"
											/>
											<FormControlLabel className={classes.generateParam}
												control={
													<Checkbox
														checked={autoGeneration}
														onChange={handleChangeAutoGeneration}
													/>
												}
												label="AutoGeneration"
											/>
										</div>
										<textarea className={classes.pasteBox} id="paste_box" onChange={handleChangePasteBox} defaultValue={makeCodeList(codeList)} ></textarea>
									</div>
									<div className={classes.couponCodesWrapper}>
										<div className={classes.couponItemsWrapper}>
											<table className={classes.couponDetailTable}>
												<tbody>
													<tr>
														<td width="10%"></td>
														<td width="5%"></td>
														<td width="25%">Code</td>
														<td width="25%">pnr</td>
														<td width="10%">MaxCount</td>
														<td width="10%">Used</td>
														<td width="10%">PaxNum?</td>
														<td width="5%"></td>
													</tr>
													{
														(activeIndex != -1) &&
														data[activeIndex].couponCodes.map((n, i) => {
															return (
																<CouponItem
																	data={n}
																	index={i}
																	key={i}
																	handleChangeUsed={updateCouponUsedState}
																	updateCodeState={updateCodeState}
																	handleClickDelete={deleteCouponCode}
																/>
															)
														})
													}
												</tbody>
											</table>
										</div>
									</div>
								</Grid>
								<div className='flex'>
									<FormControl className={classes.itemField}>
										<InputLabel id="coupon-type-select-label">Coupon Type</InputLabel>
										<Select
											labelId="coupon-type-select-label"
											id="coupon-type-select"
											value={couponType}
											onChange={handleChangeCouponType}
										>
											<MenuItem value='singleUse'>One-time code</MenuItem>
											<MenuItem value='reusable'>Multiple use code</MenuItem>
										</Select>
									</FormControl>
									<TextField onChange={handleChangeSubsidyCode} className={classes.itemField} label="Subsidy Code" defaultValue={codeSubsidy} />
									<TextField onChange={handleChangeDealId} className={classes.itemField} label="Deal Code" defaultValue={dealId} />
									<TextField onChange={handleChangeAgentCode} className={classes.itemField} label="Agent Code" defaultValue={codeAgent} />
								</div>
								<hr></hr>
								<div className='flex'>
									<FormControl className={classes.itemField}>
										<InputLabel id="discount-type-select-label">Discount Type</InputLabel>
										<Select
											labelId="discount-type-select-label"
											id="discount-type-select"
											defaultValue={discByPct ? 'PERCENT' : 'PRICE'}
											onChange={handleChangeDiscountType}
										>
											<MenuItem value='PERCENT'>Percent</MenuItem>
											<MenuItem value='PRICE'>Price</MenuItem>
										</Select>
									</FormControl>
									<TextField onChange={handleChangeDiscount} className={classes.itemField} label="discount" defaultValue={discount} />
									<FormControl className={classes.itemField}>
										<InputLabel id="discount-type-GOC-select-label">Discount Type of Bento subsidy</InputLabel>
										<Select
											labelId="discount-type-GOC-select-label"
											id="discount-type-Net-select"
											defaultValue={discByPctNet ? 'PERCENT' : 'PRICE'}
											onChange={handleChangeDiscountTypeNet}
										>
											<MenuItem value='PERCENT'>Percent</MenuItem>
											<MenuItem value='PRICE'>Price</MenuItem>
										</Select>
									</FormControl>
									<TextField onChange={handleChangeDiscountNet} className={classes.itemField} label="discount Bento Subsidy" defaultValue={discountNet} />
								</div>
								<div className='flex'>
									<FormControl className={classes.itemField}>
										<InputLabel id="discount-type-GOC-select-label">Discount Type of GOC DAN</InputLabel>
										<Select
											labelId="discount-type-GOC-select-label"
											id="discount-type-GOC-select"
											defaultValue={discByPctG ? 'PERCENT' : 'PRICE'}
											onChange={handleChangeDiscountTypeG}
										>
											<MenuItem value='PERCENT'>Percent</MenuItem>
											<MenuItem value='PRICE'>Price</MenuItem>
										</Select>
									</FormControl>
									<TextField onChange={handleChangeDiscountG} className={classes.itemField} label="discount GOC" defaultValue={discountG} />
									<FormControl className={classes.itemField}>
										<InputLabel id="discount-type-IS-select-label">Discount Type of ISROTEL</InputLabel>
										<Select
											labelId="discount-type-IS-select-label"
											id="discount-type-IS-select"
											defaultValue={discByPctI ? 'PERCENT' : 'PRICE'}
											onChange={handleChangeDiscountTypeI}
										>
											<MenuItem value='PERCENT'>Percent</MenuItem>
											<MenuItem value='PRICE'>Price</MenuItem>
										</Select>
									</FormControl>
									<TextField onChange={handleChangeDiscountI} className={classes.itemField} label="discount ISROTEL" defaultValue={discountI} />
								</div>
								<hr></hr>
								<div className='flex'>
									<MuiPickersUtilsProvider utils={DateFnsUtils}>
										<Grid container justify="space-around" className={`${classes.itemField}`}>
											<KeyboardDatePicker
												variant="inline"
												ampm={false}
												format="dd/MM/yyyy"
												id="packstart-date-from-picker-inline"
												label="Pack Start Date From"
												value={packStartDateFrom}
												onChange={handleChangePackStartDateFrom}
											/>
										</Grid>
									</MuiPickersUtilsProvider>
									<MuiPickersUtilsProvider utils={DateFnsUtils}>
										<Grid container justify="space-around" className={`${classes.itemField}`}>
											<KeyboardDatePicker
												variant="inline"
												ampm={false}
												format="dd/MM/yyyy"
												id="packstart-date-to-picker-inline"
												label="Pack Start Date To"
												value={packStartDateTo}
												onChange={handleChangePackStartDateTo}
											/>
										</Grid>
									</MuiPickersUtilsProvider>
									<FormControl className={`${classes.itemField} ${classes.w_2}`}>
										<InputLabel id="pack-destinations-label">Pack Destinations</InputLabel>
										<Select
											labelId="pack-destinations-checkbox-label"
											id="pack-destinations-checkbox"
											multiple
											value={packDestinations}
											onChange={handleChangePackDestinations}
											input={<Input />}
											renderValue={(selected) => selected.join(', ')}
										>
											{destinationsList.map((dest) => (
												<MenuItem key={dest.code} value={dest.code}>
													<Checkbox checked={packDestinations.indexOf(dest.code) > -1} />
													<ListItemText primary={dest.code} />
												</MenuItem>
											))}
										</Select>
									</FormControl>
								</div>
								<div className='flex'>
									<InputLabel className={classes.packLabel}>Vacation Pack</InputLabel>
									<FormControl className={classes.itemField}>
										<InputLabel id="discount-type-FH-select-label">Discount Type</InputLabel>
										<Select
											labelId="discount-type-FH-select-label"
											id="discount-type-FH-select"
											defaultValue={discByPctFH ? 'PERCENT' : 'PRICE'}
											onChange={handleChangeDiscountTypeFH}
										>
											<MenuItem value='PERCENT'>Percent</MenuItem>
											<MenuItem value='PRICE'>Price</MenuItem>
										</Select>
									</FormControl>
									<TextField onChange={handleChangeDiscountFH} className={classes.itemField} label="discount" defaultValue={discountFH} />
									<FormControl className={`${classes.itemField} ${classes.w_2}`}>
										<InputLabel id="exclude-destinations-FH-label">Excluded Destinations</InputLabel>
										<Select
											labelId="exclude-destinations-FH-checkbox-label"
											id="exclude-destinations-FH-checkbox"
											multiple
											value={excludeDestinationsFH}
											onChange={handleChangeExcludeDestinationsFH}
											input={<Input />}
											renderValue={(selected) => selected.join(', ')}
										>
											{destinationsList.map((dest) => (
												<MenuItem key={dest.code} value={dest.code}>
													<Checkbox checked={excludeDestinationsFH.indexOf(dest.code) > -1} />
													<ListItemText primary={dest.code} />
												</MenuItem>
											))}
										</Select>
									</FormControl>
								</div>
								<div className='flex'>
									<InputLabel className={classes.packLabel}>Flight Only</InputLabel>
									<FormControl className={classes.itemField}>
										<InputLabel id="discount-type-FO-select-label">Discount Type</InputLabel>
										<Select
											labelId="discount-type-FO-select-label"
											id="discount-type-FO-select"
											defaultValue={discByPctFO ? 'PERCENT' : 'PRICE'}
											onChange={handleChangeDiscountTypeFO}
										>
											<MenuItem value='PERCENT'>Percent</MenuItem>
											<MenuItem value='PRICE'>Price</MenuItem>
										</Select>
									</FormControl>
									<TextField onChange={handleChangeDiscountFO} className={classes.itemField} label="discount" defaultValue={discountFO} />
									<FormControl className={`${classes.itemField} ${classes.w_2}`}>
										<InputLabel id="exclude-destinations-FO-label">Excluded Destinations</InputLabel>
										<Select
											labelId="exclude-destinations-FO-checkbox-label"
											id="exclude-destinations-FO-checkbox"
											multiple
											value={excludeDestinationsFO}
											onChange={handleChangeExcludeDestinationsFO}
											input={<Input />}
											renderValue={(selected) => selected.join(', ')}
										>
											{destinationsList.map((dest) => (
												<MenuItem key={dest.code} value={dest.code}>
													<Checkbox checked={excludeDestinationsFO.indexOf(dest.code) > -1} />
													<ListItemText primary={dest.code} />
												</MenuItem>
											))}
										</Select>
									</FormControl>
								</div>
								<div className='flex'>
									<InputLabel className={classes.packLabel}>Organize Tour</InputLabel>
									<FormControl className={classes.itemField}>
										<InputLabel id="discount-type-ORG-select-label">Discount Type</InputLabel>
										<Select
											labelId="discount-type-ORG-select-label"
											id="discount-type-ORG-select"
											defaultValue={discByPctORG ? 'PERCENT' : 'PRICE'}
											onChange={handleChangeDiscountTypeORG}
										>
											<MenuItem value='PERCENT'>Percent</MenuItem>
											<MenuItem value='PRICE'>Price</MenuItem>
										</Select>
									</FormControl>
									<TextField onChange={handleChangeDiscountORG} className={classes.itemField} label="discount" defaultValue={discountORG} />
									<FormControl className={`${classes.itemField} ${classes.w_2}`}>
										<InputLabel id="exclude-destinations-ORG-label">Excluded Destinations</InputLabel>
										<Select
											labelId="exclude-destinations-ORG-checkbox-label"
											id="exclude-destinations-ORG-checkbox"
											multiple
											value={excludeDestinationsORG}
											onChange={handleChangeExcludeDestinationsORG}
											input={<Input />}
											renderValue={(selected) => selected.join(', ')}
										>
											{destinationsList.map((dest) => (
												<MenuItem key={dest.code} value={dest.code}>
													<Checkbox checked={excludeDestinationsORG.indexOf(dest.code) > -1} />
													<ListItemText primary={dest.code} />
												</MenuItem>
											))}
										</Select>
									</FormControl>
								</div>
								<div className='flex'>
									<InputLabel className={classes.packLabel}>Flight Drive</InputLabel>
									<FormControl className={classes.itemField}>
										<InputLabel id="discount-type-FD-select-label">Discount Type</InputLabel>
										<Select
											labelId="discount-type-FD-select-label"
											id="discount-type-FD-select"
											defaultValue={discByPctFD ? 'PERCENT' : 'PRICE'}
											onChange={handleChangeDiscountTypeFD}
										>
											<MenuItem value='PERCENT'>Percent</MenuItem>
											<MenuItem value='PRICE'>Price</MenuItem>
										</Select>
									</FormControl>
									<TextField onChange={handleChangeDiscountFD} className={classes.itemField} label="discount" defaultValue={discountFD} />
									<FormControl className={`${classes.itemField} ${classes.w_2}`}>
										<InputLabel id="exclude-destinations-FD-label">Excluded Destinations</InputLabel>
										<Select
											labelId="exclude-destinations-FD-checkbox-label"
											id="exclude-destinations-FD-checkbox"
											multiple
											value={excludeDestinationsFD}
											onChange={handleChangeExcludeDestinationsFD}
											input={<Input />}
											renderValue={(selected) => selected.join(', ')}
										>
											{destinationsList.map((dest) => (
												<MenuItem key={dest.code} value={dest.code}>
													<Checkbox checked={excludeDestinationsFD.indexOf(dest.code) > -1} />
													<ListItemText primary={dest.code} />
												</MenuItem>
											))}
										</Select>
									</FormControl>
								</div>
								<div className='flex'>
									<InputLabel className={classes.packLabel}>Sport Pack</InputLabel>
									<FormControl className={classes.itemField}>
										<InputLabel id="discount-type-SPORT-select-label">Discount Type</InputLabel>
										<Select
											labelId="discount-type-SPORT-select-label"
											id="discount-type-SPORT-select"
											defaultValue={discByPctSPORT ? 'PERCENT' : 'PRICE'}
											onChange={handleChangeDiscountTypeSPORT}
										>
											<MenuItem value='PERCENT'>Percent</MenuItem>
											<MenuItem value='PRICE'>Price</MenuItem>
										</Select>
									</FormControl>
									<TextField onChange={handleChangeDiscountSPORT} className={classes.itemField} label="discount" defaultValue={discountSPORT} />
									<FormControl className={`${classes.itemField} ${classes.w_2}`}>
										<InputLabel id="exclude-destinations-SPORT-label">Excluded Destinations</InputLabel>
										<Select
											labelId="exclude-destinations-SPORT-checkbox-label"
											id="exclude-destinations-SPORT-checkbox"
											multiple
											value={excludeDestinationsSPORT}
											onChange={handleChangeExcludeDestinationsSPORT}
											input={<Input />}
											renderValue={(selected) => selected.join(', ')}
										>
											{destinationsList.map((dest) => (
												<MenuItem key={dest.code} value={dest.code}>
													<Checkbox checked={excludeDestinationsSPORT.indexOf(dest.code) > -1} />
													<ListItemText primary={dest.code} />
												</MenuItem>
											))}
										</Select>
									</FormControl>
								</div>
								<hr></hr>
								<div className='flex'>
									<MuiPickersUtilsProvider utils={DateFnsUtils}>
										<Grid container justify="space-around" className={classes.itemField}>
											<KeyboardDateTimePicker
												variant="inline"
												ampm={false}
												format="dd/MM/yyyy HH:mm"
												id="start-date-picker-inline"
												label="Start Date"
												value={startDate}
												onChange={handleChangeStartDate}
											/>
										</Grid>
									</MuiPickersUtilsProvider>
									<MuiPickersUtilsProvider utils={DateFnsUtils}>
										<Grid container justify="space-around" className={classes.itemField}>
											<KeyboardDateTimePicker
												variant="inline"
												ampm={false}
												format="dd/MM/yyyy HH:mm"
												id="end-date-picker-inline"
												label="End Date"
												value={endDate}
												onChange={handleChangeEndDate}
											/>
										</Grid>
									</MuiPickersUtilsProvider>
									<div className={classes.itemField}>
										<FormControlLabel style={{ width: '50%', marginLeft: '50px' }}
											control={
												<Checkbox
													checked={active}
													onChange={e => { setActive(e.target.checked) }}
													name='active'
													color='primary'
												/>
											}
											label='Active?'
											className={classes.checkboxform}
										/>
									</div>
									<TextField className={classes.itemField} label="Create Date" defaultValue={DateToStr(createDate)} inputProps={{readOnly:true}}/>
								</div>
							</div>
							<div className={classes.button_group}>
								<Button className={classes.buttons} variant='contained' onClick={editProcess} color='secondary'>
									{nButtonText}
								</Button>
								<Button className={classes.buttons} variant='contained' color='primary' onClick={handleClose}>
									Cancel
								</Button>
							</div>
						</div>

					</Fade>
				</Modal>
			</div>
			{userRole === 'user' ? null :
				<div>
					<Button
						className='whitespace-no-wrap normal-case'
						variant='contained'
						color='secondary'
						style={{ float: 'right', margin: '15px' }}
						onClick={() => createNewCoupon()}
					>
						<span className='hidden sm:flex'>Create a new series</span>
					</Button>
				</div>
			}
			<FuseScrollbars className='flex-grow overflow-x-auto'>
				<Table stickyHeader className='min-w-xl' aria-labelledby='tableTitle'>
					<CouponManagementTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={data.length}
					/>
					<TableBody>
						{_.orderBy(
							data,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className='h-64 cursor-pointer'
									hover
									tabIndex={-1}
									key={i}
								>
									<TableCell padding="none" className="w-20 md:w-20 text-center z-99">
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editCoupon(i)}>
										{n.ruleCode}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editCoupon(i)}>
										{n.ruleName}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editCoupon(i)}>
										{n.numOfCodes}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editCoupon(i)}>
										{calcTotalUsed(n.couponCodes)}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editCoupon(i)}>
										{n.discount}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editCoupon(i)}>
										{n.couponType==='singleUse' ? 'Yes' : 'No'}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editCoupon(i)}>
										{TimeToStr(n.startDate)}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editCoupon(i)}>
										{TimeToStr(n.endDate)}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editCoupon(i)}>
										{DateToStr(n.createTime)}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editCoupon(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.active && 'bg-red',
												n.active && 'bg-green',
											)}
										/>
									</TableCell>
									<TableCell className="w-20 md:w-44 text-center z-99" component='th' scope='row' align='left'>
										<div style={{display:'flex'}}>
											<button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
												onClick={() => downloadCoupon(i)}
											>
												<span className='MuiIconButton-label'>
													<span className='material-icons MuiIcon-root' aria-hidden='true'>download</span>
												</span>
											</button>
											<button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
												onClick={() => deleteCoupon(i)}
											>
												<span className='MuiIconButton-label'>
													<span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
												</span>
												<span className='MuiTouchRipple-root'></span>
											</button>
											<button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
												onClick={() => editCoupon(i)}
											>
												<span className='MuiIconButton-label'>
													<span className='material-icons MuiIcon-root' aria-hidden='true'>edit</span>
												</span>
												<span className='MuiTouchRipple-root'></span>
											</button>
										</div>
										<span className='MuiTouchRipple-root'></span>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className='flex-shrink-0 border-t-1'
				component='div'
				count={dataLength}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}
export default withRouter(UserManagementTable);
