import 'date-fns';
import FuseScrollbars from '@fuse/core/FuseScrollbars';
import axios from 'axios';
import _ from '@lodash';
import Checkbox from '@material-ui/core/Checkbox';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import FuseLoading from '@fuse/core/FuseLoading';
import UserManagementTableHead from './UserManagementTableHead';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import Backdrop from '@material-ui/core/Backdrop';
import Fade from '@material-ui/core/Fade';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import CircularProgress from '@material-ui/core/CircularProgress';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import FormControl from '@material-ui/core/FormControl';
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import IconButton from '@material-ui/core/IconButton';
import InputAdornment from '@material-ui/core/InputAdornment';
import Grid from '@material-ui/core/Grid';
import DateFnsUtils from '@date-io/date-fns';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import generator from 'generate-password';
import jwt from 'jwt-decode'
import {
	MuiPickersUtilsProvider,
	KeyboardDatePicker,
} from '@material-ui/pickers';
import { baseURL } from '../../utils';

var userRole = jwt(window.localStorage.getItem('jwt_access_token')).role
function UserManagementTable(props) {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			margin: theme.spacing(0),
			minWidth: 60,
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
			minWidth: 120
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			maxWidth: '400px',
		},
		discountboxform: {
			display: 'grid',
		},
		checkboxform: {
			display: 'block',
		},
		button_group: {
			padding: 30,
			textAlign: 'center',
		},
		buttons: {
			marginLeft: '10px'
		},
		buttons1: {
			fontSize: '10px',
			margin: 'auto 0px',
			background: '#b4c9dc'
		},
		fo_circular: {
			textAlign: 'center',
			position: 'absolute',
			left: '50%',
			transform: 'translatex(-50%)'
		},
		textField: {
			marginTop: '10px',
			width: '100%'
		},
		checkbox: {
			verticalAlign: 'bottom',
			padding: '0px'
		},
		textField1: {
			marginTop: '10px',
			marginBottom: '0px',
			width: '100%'
		}
	}));
	const classes = useStyles();
	const [loading, setLoading] = useState(true);
	const [loadingCircle, setLoadingCircle] = useState(false);
	const [userId, setUserId] = useState(null);
	const [userName, setUserName] = useState(null);
	const [fullName, setFullName] = useState(null);
	const [birthday, setBirthday] = useState(null);
	const [role, setRole] = useState('');
	const [email, setEmail] = useState(null);
	const [phoneNumber, setPhoneNumber] = useState(null);
	const [password, setPassWord] = useState(null);
	const [nIsActiveState, setIsActive] = useState(false);
	const [nButtonText, setButtonText] = useState(null);
	const [nButtonState, setButtonState] = useState(null);
	const [confirmText, setConfirmText] = useState(null);
	const [confirmState, setConfirmState] = useState(null);
	const [selected] = useState([]);
	const [data, setData] = useState();
	const [dataLength, setDataLength] = useState(0);
	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [warningOpen, setWarningOpen] = useState(false);
	const [warningText, setWarningText] = useState(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [newPassword, setNewPassword] = useState('');
	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});
	const [open, setOpen] = useState(false);
	const [values, setValues] = React.useState({
		amount: '',
		password: '',
		weight: '',
		weightRange: '',
		showPassword: false,
	});
	const handlePasswordChange = (prop) => (event) => {
		setPassWord(event.target.value)
		setValues({ ...values, [prop]: event.target.value });
	};

	const handleClickShowPassword = () => {
		setValues({ ...values, showPassword: !values.showPassword });
	};

	const handleMouseDownPassword = (event) => {
		event.preventDefault();
	};

	useEffect(() => {
		reopen(1, 10);
		// eslint-disable-next-line
	}, [])

	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}
	function handleChangePage(event, value) {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage
		reopen(from, to);
	}
	function handleChangeRowsPerPage(event) {
		setPage(0);
		setRowsPerPage(event.target.value);
		reopen(1, event.target.value);
	}
	function handleChangeCheckbox() {
		setIsActive(!nIsActiveState);
	}
	const editUser = (i) => {
		setButtonText('Update');
		setButtonState('Update User');
		setUserId(data[i].id);
		setUserName(data[i].userName);
		setFullName(data[i].fullName);
		setBirthday(data[i].dob);
		setPhoneNumber(data[i].phoneNumber);
		setEmail(data[i].email);
		setRole(data[i].role);
		setPassWord(data[i].password);
		setIsActive(data[i].enabled);
		setOpen(true);
	}
	const createUser = () => {
		setButtonText('Create');
		setButtonState('Create User');
		initialValue();
		setOpen(true);
	}
	const dropUser = async (i) => {
		setUserId(data[i].id);
		setConfirmText("Do you want to drop this user?");
		setConfirmState('delete');
		setConfirmOpen(true);
	}
	const Reset = async (i) => {
		setUserId(data[i].id);
		setConfirmText("Password can generate or create");
		setConfirmState('reset');
		setConfirmOpen(true);
	}
	const handleClose = () => {
		initialValue();
		setOpen(false);
	}
	const handleCloseWarning = () => {
		setWarningOpen(false);
	}
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}
	async function confirmProcess() {
		if (confirmState === 'reset') {
			await axios.patch(baseURL + 'api/user/' + userId + '/resetpass',
				{ "newPassword": newPassword },
				{
					headers: {
						'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
						'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
					}
				}
			).then(response => {
				if (response.data.error !== null) {
					setWarningText(response.data.error.message);
					setWarningOpen(true);
				}
			})
			setConfirmOpen(false);
		}
		else if (confirmState === 'delete') {
			await axios.delete(baseURL + 'api/user/' + userId, {
				headers: {
					'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
					'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
				}
			})
			setConfirmOpen(false);
			reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
		}
	}
	async function editProcess(index) {
		setLoadingCircle(true);
		var request_url = null;
		var config = null
		if (nButtonState === 'Update User') {
			request_url = baseURL + 'api/user/' + userId;
			config = {
				'fullName': fullName,
				'dob': birthday,
				'phoneNumber': phoneNumber,
				'email': email,
				'enabled': nIsActiveState,
				'role': role
			}
		}
		else {
			request_url = baseURL + 'api/user';
			config = {
				'userName': userName,
				'fullName': fullName,
				'dob': birthday,
				'role': role,
				'phoneNumber': phoneNumber,
				'email': email,
				'enabled': nIsActiveState,
				'password': password
			}
		}
		await axios({
			method: 'post',
			url: request_url,
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			},
			data: config
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setLoadingCircle(false);
				setWarningText(response.data.error.message);
				setWarningOpen(true);
			}
			reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
		})
			.catch(error => {
				setLoadingCircle(false);
				setWarningText("HTTP Error");
				setWarningOpen(true);
				return;
			});
	};
	async function reopen(from, to) {
		const response = await axios.get(`${baseURL}api/user/?from=${from}&to=${to}&excludePartners=true`, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		});
		const data = response.data['data'];
		setData(data);
		setDataLength(response.data['total'])
		setLoading(false);
		setOpen(false);
	};
	function initialValue() {
		setUserName(null);
		setFullName(null);
		setBirthday(null);
		setPhoneNumber(null);
		setRole('');
		setEmail(null);
		setPassWord('');
		setIsActive(false);
	}

	const handleDateChange = (date) => {
		setBirthday(date);
	};
	const handleRoleChange = (event) => {
		setRole(event.target.value);
	};
	function handleChangeFullName(event) {
		setFullName(event.target.value)
	}
	function handleChangeUserName(event) {
		setUserName(event.target.value)
	}
	function handleChangeEmail(event) {
		setEmail(event.target.value)
	}
	function handleChangePhone(event) {
		setPhoneNumber(event.target.value)
	}
	function newGenerate() {
		var passwords = generator.generate({
			length: 10,
			numbers: true,
			uppercase: true,
			symbols: true,
			strict: true,
			exclude: '+_-=}{[]|:;"/?.><,`~'
		})
		setNewPassword(passwords)
	}
	function handleNewPasswordChange(event) {
		setNewPassword(event.target.value);
	}
	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className='w-full flex flex-col'>
			<div>
				<div className='spinner-border text-primary' role='status'>
					<span className='sr-only'>Loading...</span>
				</div>
				<Modal
					open={warningOpen}
					onClose={handleCloseWarning}
					className={classes.modal}
					aria-labelledby='simple-modal-title'
					aria-describedby='simple-modal-description'
				>
					<div className={classes.paper} style={{ textAlign: 'center' }}>
						<h2 id='server-modal-title' >Warning</h2>
						<p id='server-modal-description'>{warningText}</p>
						<Button className='whitespace-no-wrap normal-case'
							variant='contained'
							color='secondary'
							onClick={handleCloseWarning}>Close
						</Button>
					</div>
				</Modal>
				<Modal
					open={confirmOpen}
					onClose={handleCloseConfirm}
					className={classes.modal}
					aria-labelledby='simple-modal-title'
					aria-describedby='simple-modal-description'
				>
					<div className={classes.paper} style={{ textAlign: 'center' }}>
						<h2 id='server-modal-title' >Confirm</h2>
						<p id='server-modal-description'>{confirmText}</p>
						{confirmState === 'reset' ?
							<div>
								<p id='server-modal-description'>Passwords must have at least non alphanumeric character, one digit ('0'-'9'), one uppercase ('A'-'Z')"</p>
								<div style={{ display: 'flex', margin: '20px 0px' }}>
									<FormControl style={{ width: '100%' }}>
										<TextField onChange={handleNewPasswordChange} label="New Password" value={newPassword} />
									</FormControl>
									<Button className={classes.buttons1} variant='contained' onClick={newGenerate} color='secondary'>
										Generate
									</Button>
								</div>
							</div> : null}
						<Button className='whitespace-no-wrap normal-case'
							style={{ margin: '10px 5px' }}
							variant='contained'
							color='secondary'
							onClick={confirmProcess}>Confirm
						</Button>
						<Button className='whitespace-no-wrap normal-case'
							style={{ margin: '10px 5px' }}
							variant='contained'
							color='secondary'
							onClick={handleCloseConfirm}>Cancel
						</Button>
					</div>
				</Modal>
				<Modal
					aria-labelledby='transition-modal-title'
					aria-describedby='transition-modal-description'
					className={classes.modal}
					open={open}
					onClose={handleClose}
					closeAfterTransition
					BackdropComponent={Backdrop}
					BackdropProps={{
						timeout: 500,
					}}
				>
					<Fade in={open}>
						<div className={classes.paper}>
							<div className={classes.fo_circular}>
								{loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
							</div>
							<div style={{ textAlign: 'center' }}>
								<h2 id='transition-modal-title' >{nButtonState}</h2>
							</div>
							<div>
								<TextField onChange={handleChangeFullName} className={classes.textField} label="Full Name" defaultValue={fullName} />
								{nButtonState === 'Update User' ? null :
									<TextField onChange={handleChangeUserName} className={classes.textField} label="User Name" defaultValue={userName} />
								}
								<MuiPickersUtilsProvider utils={DateFnsUtils} >
									<Grid container justify="space-around" >
										<KeyboardDatePicker
											disableToolbar
											className={classes.textField1}
											variant="inline"
											format="MM/dd/yyyy"
											id="date-picker-inline"
											label="Birthday"
											value={birthday}
											onChange={handleDateChange}
											KeyboardButtonProps={{
												'aria-label': 'change date',
											}}
										/>
									</Grid>
								</MuiPickersUtilsProvider>
								<TextField onChange={handleChangeEmail} className={classes.textField} type='email' label="Email" defaultValue={email} />
								<TextField onChange={handleChangePhone} className={classes.textField} label="Phone" defaultValue={phoneNumber} />
								<FormControl className={classes.textField}>
									<InputLabel id="demo-simple-select-helper-label">Role</InputLabel>
									{
										role==='partner' ?
											<Input value={role} disabled/>
										:
										<Select
											labelId="demo-simple-select-helper-label"
											id="demo-simple-select-helper"
											value={role}
											onChange={handleRoleChange}
										>
											{userRole === 'superadmin' ? <MenuItem value='superadmin'>Super Admin</MenuItem> : null}
											{userRole === 'superadmin' ? <MenuItem value='admin'>Admin</MenuItem> : null}
											{userRole === 'superadmin' || userRole === 'admin' ? <MenuItem value='manager'>Manager</MenuItem> : null}
											{userRole === 'superadmin' || userRole === 'admin' || userRole === 'manager' ? <MenuItem value='user'>User</MenuItem> : null}
											{userRole === 'superadmin' || userRole === 'admin' || userRole === 'manager' ? <MenuItem value='agency'>Agency</MenuItem> : null}
										</Select>
									}
								</FormControl>
								{nButtonState === 'Update User' ? null :
									<FormControl className={classes.textField} margin="dense">
										<InputLabel htmlFor="filled-adornment-password">Password</InputLabel>
										<Input
											id="filled-adornment-password"
											type={values.showPassword ? 'text' : 'password'}
											value={password}
											onChange={handlePasswordChange('password')}
											endAdornment={
												<InputAdornment position="end">
													<IconButton
														aria-label="toggle password visibility"
														onClick={handleClickShowPassword}
														onMouseDown={handleMouseDownPassword}
														edge="end"
													>
														{values.showPassword ? <Visibility /> : <VisibilityOff />}
													</IconButton>
												</InputAdornment>
											}
										/>
									</FormControl>
								}
								<FormControlLabel
									control={
										<Checkbox
											checked={nIsActiveState}
											onChange={handleChangeCheckbox}
											name='checkedC'
											color='primary'
										/>
									}
									label='Active'
									className={classes.checkboxform}
								/>
							</div>
							<div className={classes.button_group}>
								<Button className={classes.buttons} variant='contained' onClick={editProcess} color='secondary' disabled={loadingCircle}>
									{nButtonText}
								</Button>
								<Button className={classes.buttons} variant='contained' color='primary' onClick={handleClose}>
									Cancel
								</Button>
							</div>
						</div>

					</Fade>
				</Modal>
			</div>
			{userRole === 'user' ? null :
				<div>
					<Button
						className='whitespace-no-wrap normal-case'
						variant='contained'
						color='secondary'
						style={{ float: 'right', margin: '15px' }}
						onClick={() => createUser()}
					>
						<span className='hidden sm:flex'>Create User</span>
						<span className='flex sm:hidden'>Create</span>
					</Button>
				</div>
			}
			<FuseScrollbars className='flex-grow overflow-x-auto'>
				<Table stickyHeader className='min-w-xl' aria-labelledby='tableTitle'>
					<UserManagementTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={data.length}
					/>
					<TableBody>
						{_.orderBy(
							data,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className='h-64 cursor-pointer'
									hover
									tabIndex={-1}
									key={i}
								>
									<TableCell padding="none" className="w-20 md:w-20 text-center z-99">
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editUser(i)}>
										{n.fullName}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editUser(i)}>
										{n.userName}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editUser(i)}>
										{(new Date(n.dob)).toString().substring(0, 16)}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editUser(i)}>
										{n.email}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editUser(i)}>
										{n.phoneNumber}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editUser(i)}>
										{n.role}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left' onClick={() => editUser(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.enabled && 'bg-red',
												n.enabled && 'bg-green',
											)}
										/>
									</TableCell>
									<TableCell className="w-20 md:w-44 text-center z-99" component='th' scope='row' align='left'>
										<button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
											onClick={() => editUser(i)}
										>
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>edit</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
									<TableCell className="w-20 md:w-44 text-center z-99" component='th' scope='row' align='left'>
										<button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
											onClick={() => dropUser(i)}
										>
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
									{userRole === 'superadmin' || userRole === 'admin' ?
										<TableCell className="w-20 md:w-44 text-center z-99" component='th' scope='row' align='left'>
											<button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
												onClick={() => Reset(i)}
											>
												<span className='MuiIconButton-label'>
													<span className='material-icons MuiIcon-root' aria-hidden='true'>replay</span>
												</span>
												<span className='MuiTouchRipple-root'></span>
											</button>
										</TableCell> : null
									}
									<TableCell padding="none" className="w-20 md:w-20 text-center z-99">
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className='flex-shrink-0 border-t-1'
				component='div'
				count={dataLength}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}
export default withRouter(UserManagementTable);
