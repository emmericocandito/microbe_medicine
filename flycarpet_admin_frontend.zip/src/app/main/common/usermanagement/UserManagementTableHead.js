import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Tooltip from '@material-ui/core/Tooltip';
import React from 'react';
import i18next from 'i18next';
import jwt from 'jwt-decode'
import ar from '../../../fuse-configs/navigation-i18n/ar';
import en from '../../../fuse-configs/navigation-i18n/en';
import tr from '../../../fuse-configs/navigation-i18n/tr';

i18next.addResourceBundle('en', 'navigation', en);
i18next.addResourceBundle('tr', 'navigation', tr);
i18next.addResourceBundle('ar', 'navigation', ar);
var token = window.localStorage.getItem('jwt_access_token');
var userRole = (token == null ? 'superadmin' : jwt(window.localStorage.getItem('jwt_access_token')).role)
const rows = (userRole === 'superadmin' || userRole === 'admin') ? [
    {
        id: 'user_fullname',
        translate: 'FullName',
        align: 'left',
        disablePadding: false,
        label: 'FullName',
        sort: true
    },
    {
        id: 'user_name',
        translate: 'UserName',
        align: 'left',
        disablePadding: false,
        label: 'UserName',
        sort: true
    },
    {
        id: 'birthday',
        translate: 'BirthDay',
        align: 'left',
        disablePadding: false,
        label: 'BirthDay',
        sort: true
    },
    {
        id: 'email',
        translate: 'Email',
        align: 'left',
        disablePadding: false,
        label: 'Email',
        sort: true
    },
    {
        id: 'phone',
        translate: 'Phone',
        align: 'left',
        disablePadding: false,
        label: 'PhoneNumber',
        sort: true
    },
    {
        id: 'role',
        translate: 'Role',
        align: 'left',
        disablePadding: false,
        label: 'Role',
        sort: true
    },
    {
        id: 'active',
        translate: 'active',
        align: 'left',
        disablePadding: false,
        label: 'isActive',
        sort: true
    },
    {
        id: 'edit',
        translate: 'Edit',
        align: 'left',
        disablePadding: false,
        label: '',
        sort: true
    },
    {
        id: 'delete',
        translate: 'delete',
        align: 'left',
        disablePadding: false,
        label: '',
        sort: true
    },
    {
        id: 'reset',
        translate: 'Reset',
        align: 'left',
        disablePadding: false,
        label: '',
        sort: true
    }

] : [
    {
        id: 'user_fullname',
        translate: 'FullName',
        align: 'left',
        disablePadding: false,
        label: 'FullName',
        sort: true
    },
    {
        id: 'user_name',
        translate: 'UserName',
        align: 'left',
        disablePadding: false,
        label: 'UserName',
        sort: true
    },
    {
        id: 'birthday',
        translate: 'BirthDay',
        align: 'left',
        disablePadding: false,
        label: 'BirthDay',
        sort: true
    },
    {
        id: 'email',
        translate: 'Email',
        align: 'left',
        disablePadding: false,
        label: 'Email',
        sort: true
    },
    {
        id: 'phone',
        translate: 'Phone',
        align: 'left',
        disablePadding: false,
        label: 'PhoneNumber',
        sort: true
    },
    {
        id: 'role',
        translate: 'Role',
        align: 'left',
        disablePadding: false,
        label: 'Role',
        sort: true
    },
    {
        id: 'active',
        translate: 'active',
        align: 'left',
        disablePadding: false,
        label: 'isActive',
        sort: true
    },
    {
        id: 'edit',
        translate: 'Edit',
        align: 'left',
        disablePadding: false,
        label: '',
        sort: true
    },
    {
        id: 'delete',
        translate: 'delete',
        align: 'left',
        disablePadding: false,
        label: '',
        sort: true
    }

];

function ProductsTableHead(props) {
    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };
    return (
        <TableHead>
            <TableRow className="h-64">
                <TableCell padding="none" className="w-20 md:w-20 text-center z-99">
                </TableCell>
                {rows.map(row => {
                    return (
                        <TableCell
                            className="p-4 md:p-16"
                            key={row.id}
                            align={row.align}
                            padding={row.disablePadding ? 'none' : 'default'}
                            sortDirection={props.order.id === row.id ? props.order.direction : false}
                        >
                            {row.sort && (
                                <Tooltip
                                    title="Sort"
                                    placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                    enterDelay={300}
                                >
                                    <TableSortLabel
                                        active={props.order.id === row.id}
                                        direction={props.order.direction}
                                        onClick={createSortHandler(row.id)}
                                    >
                                        {row.label}
                                    </TableSortLabel>
                                </Tooltip>
                            )}
                        </TableCell>
                    );
                }, this)}
                <TableCell padding="none" className="w-20 md:w-20 text-center z-99">
                </TableCell>
            </TableRow>
        </TableHead>
    );
}

export default ProductsTableHead;
