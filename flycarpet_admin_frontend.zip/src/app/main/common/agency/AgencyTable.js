import FuseScrollbars from '@fuse/core/FuseScrollbars';
import _ from '@lodash';
import axios from 'axios';
import {
	Checkbox, Table, TableHead, TableBody, TableCell, TablePagination, TableRow, Modal, Backdrop, Fade, Grid, TextField,
	Button, FormControl, FormHelperText, FormControlLabel, Select, Chip, IconButton, Input, InputLabel,
	CircularProgress
} from '@material-ui/core';
import Visibility from '@material-ui/icons/Visibility';
import VisibilityOff from '@material-ui/icons/VisibilityOff';
import InputAdornment from '@material-ui/core/InputAdornment';
import { MuiPickersUtilsProvider, KeyboardDatePicker, } from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import clsx from 'clsx';
import React, { useEffect, useState, useMemo } from 'react';
import { withRouter } from 'react-router-dom';
import FuseLoading from '@fuse/core/FuseLoading';
import AgencyTableHead from './AgencyTableHead';
import { makeStyles } from '@material-ui/core/styles';
import SearchIcon from '@material-ui/icons/Search';
import OpenInNew from '@material-ui/icons/OpenInNew';
import FileCopyOutlined from '@material-ui/icons/FileCopyOutlined';
import { RadioGroupKind } from 'app/main/BasicComponents/CustomOptions';
import { Autocomplete } from '@material-ui/lab';
import { useAgencyInfo, useAgencyUser } from 'app/main/store/hooks';
import { baseURL } from './../../utils';

function AgencyTable(props) {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			// margin: theme.spacing(1),
			minWidth: 120,
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			minWidth: 200,
			maxHeight: "100vh",
			overflowY: "auto",
		},
		button_group: {
			padding: 30,
		},
		buttons: {
			float: 'right',
			marginRight: '10px'
		},
		linkGroup: {
			width: '230px',
		},
		checkboxform: {
			marginLeft: '-10px'
		},
		textfield: {
			width: '100%'
		},
		chipStyle: {
			height: '20px',
			margin: '1px',
			color: 'white',
			fontSize: '12px',
			background: '#32606b'
		},
		chipStyle1: {
			height: '20px',
			margin: '1px',
			color: 'white',
			fontSize: '12px',
			background: '#4CAF50'
		},
	}));
	const classes = useStyles();
	const operationsArray = ['Pack OP', 'Domestic OP', 'Camingo OP'];

	const [nAgentCode, setAgentCode] = useState(null);
	const [assignedClerk, setAssignedClerk] = useState('');
	const [nHostFqdn, setHostFqdn] = useState([]);
	const [nSubAgencyCodes, setSubAgencyCodes] = useState([]);
	const [nDefaultDiscountPercent, setDefaultDiscountPercent] = useState(null);
	const [nCode, setCode] = useState(null);
	const [nIsActiveState, setIsActive] = useState(false);
	const [nOperations, setOperations] = useState(0);
	const defaultKindAgency = {
		"forMainSite": false,
		"forWhiteLabelSite": false,
		"forMarketer": false,
		"forOnewayFlightApiOnly": false,
		"forInternalAgentSite": false,
	};
	const optionsKindAgency = useMemo(() => {
		return [
			{ label: 'For Main Site', value: 'forMainSite' },
			{ label: 'For White Label Site', value: 'forWhiteLabelSite' },
			{ label: 'For Marketer', value: 'forMarketer' },
			{ label: 'For Oneway Flight API Only', value: 'forOnewayFlightApiOnly' },
			{ label: 'Agent Site', value: 'forInternalAgentSite' },
		]
	}, []);
	const [kindAgency, setKindAgency] = useState('forMarketer');
	const [forPOS, setPOS] = useState('');
	const [odyAgentProperties, setOdyAgentProperties] = useState([]);
	const [odyAgentForPos, setOdyAgentForPos] = useState('');
	const [odyAgentPosCode, setOdyAgentPosCode] = useState('');
	const [addtionalAgencyList, setAddtionalAgencyList] = useState(null);
	const [odyAgentGroup, setOdyAgentGroup] = useState([]);
	useEffect(() => {
		updateOdyAgentGroup();
	}, [odyAgentProperties]);

	const defaultLabelsCoupon = useMemo(() => {
		return {
			title: '',
			codeLabel: '',
			statusLabel: '',
		}
	}, []);
	const [labelsCoupon, setLabelsCoupon] = useState(defaultLabelsCoupon);

	const {
		allItems: authorizedUsers,
		fetchAllItems: fetchAutheredAllUsers,
		getAgencyUserName,
		getAgencyFromName,
	} = useAgencyUser();
	const [authorizedUsername, setAuthorizedUsername] = useState(null);
	const [listAuthorizedUser, setListAuthorizedUser] = useState({
		options: authorizedUsers,
		getOptionLabel: (option) => getAgencyUserName(option),
	})
	useEffect(() => {
		setListAuthorizedUser({
			options: authorizedUsers,
			getOptionLabel: (option) => getAgencyUserName(option),
		})
		setAuthorizedUsername(authorizedUsers.find(user => user.email === email));
	}, [authorizedUsers]);

	const [nMobileToAuthen, setMobileToAuthen] = useState(null);
	const [nIsAutonomous, setIsAutonomous] = useState(false);
	const [nIsLoginMarketer, setIsLoginMarketer] = useState(false);
	const [nBypassPayment, setBypassPayment] = useState(false);
	const [nLimitToSpecificDeals, setLimitToSpecificDeals] = useState(false);

	const [nPreferSmsToPassword, setPreferSmsToPassword] = useState(false);
	const [nIsForPricePlanOnly, setIsForPricePlanOnly] = useState(false);
	const [nSimplifiedDiscRuleAgency, setSimplifiedDiscRuleAgency] = useState(false);
	const [nEnableSearchAgent, setEnableSearchAgent] = useState(false);
	const [nProtectDiscount, setProtectDiscount] = useState(false);
	const [nPasswordForMarketer, setPasswordForMarketer] = useState('');
	const [nPasswordForClerk, setPasswordForClerk] = useState('');

	const [currentEditingContent, setCurrentEditingContent] = useState(null);

	const [nFilterAgentCode, setFilterAgentCode] = useState(null);
	const [nFilterHostFqdn, setFilterHostFqdn] = useState(null);
	const [nFilterSubAgencyCodes, setFilterSubAgencyCodes] = useState(null);
	const [nFilterActive, setFilterActive] = useState('');

	const [nFilterMobileToAuthen, setFilterMobileToAuthen] = useState('');
	const [nFilterAutonomous, setFilterAutonomous] = useState('');
	const [nFilterLoginMarketer, setFilterLoginMarketer] = useState('');
	const [nFilterBypassPayment, setFilterBypassPayment] = useState('');
	const [filterKindAgency, setFilterKindAgency] = useState('');
	const [filterPOS, setFilterPOS] = useState('');
	const [nFilterLimitDeals, setFilterLimitDeals] = useState(null);
	const [nFilterOperation, setFilterOperation] = useState(null);

	const [nFilterPreferSmsToPassword, setFilterPreferSmsToPassword] = useState('');
	const [nFilterForPricePlanOnly, setFilterForPricePlanOnly] = useState('');
	const [nFilterSimplifiedDiscRuleAgency, setFilterSimplifiedDiscRuleAgency] = useState('');
	const [nFilterEnableSearchAgent, setFilterEnableSearchAgent] = useState('');
	const [nFilterProtectDiscount, setFilterProtectDiscount] = useState('');

	const [saveNewAgency, setSaveNewAgency] = useState(false);
	const [userName, setUserName] = useState(null);
	const [fullName, setFullName] = useState(null);
	const [birthday, setBirthday] = useState(null);
	const [email, setEmail] = useState(null);
	const [phoneNumber, setPhoneNumber] = useState(null);
	const [password, setPassWord] = useState(null);
	const [values, setValues] = React.useState({
		password: '',
		showPassword: false,
	});

	const [nButtonText, setButtonText] = useState(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [confirmText, setConfirmText] = useState(null);
	const [warningOpen, setWarningOpen] = useState(false);
	const [warningText, setWarningText] = useState(null);

	const [loading, setLoading] = useState(true);
	const [selected] = useState([]);
	const [data, setData] = useState();
	const [agencyData, setAgencyData] = useState();
	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});
	const [open, setOpen] = React.useState(false);
	const [openFilter, setOpenFilter] = useState(false);
	const [openAddAgency, setOpenAddAgency] = useState(false);

	const [dabAgencyList, setDabAgencyList] = useState(null);
	// const [ddaAgencyList, setDdaAgencyList] = useState(null);
	const [specialAgencyList, setSpecialAgencyList] = useState(null);
	const {
		agencyInfoInternal,
		fetchAgencyInfoInternal,
		getAgencyNameInternal,
		getAgencyCodeInternal,
		getAgencyListFromCodeList,
	} = useAgencyInfo();
	const agencyInfoProps = {
		options: agencyInfoInternal,
		getOptionLabel: (option) => getAgencyNameInternal(option),
	};

	useEffect(() => {
		getAgencyData(1, 10);
		fetchAgencyInfoInternal({ operation: nOperations });
		fetchAutheredAllUsers();
	}, []);

	useEffect(() => {
		fetchAgencyInfoInternal({ operation: nOperations });
	}, [nOperations]);

	useEffect(() => {
		if (currentEditingContent) {
			setDabAgencyList(getAgencyListFromCodeList(currentEditingContent['dabAllowedOdyAgentCodes']));
			// setDdaAgencyList(getAgencyListFromCodeList(currentEditingContent['ddaAllowedOdyAgentCodes']));
			setSpecialAgencyList(getAgencyListFromCodeList(currentEditingContent['agentSiteSpecificProps']?.visitorLikeExtAgents));
		}
	}, [agencyInfoInternal]);

	const addAgency = () => {
		setAuthorizedUsername(null);
		setButtonText('Add');
		setOpen(true);
	};
	const deleteHandle = async (index) => {
		setCode(agencyData[index]['code'])
		setConfirmText("Do you want to drop this Agency?");
		setConfirmOpen(true);
	}
	const handleOpen = (index) => {
		setCurrentEditingContent(agencyData[index]);

		setButtonText('Edit');
		setAgentCode(agencyData[index]['odyAgentCode']);
		setHostFqdn(agencyData[index]['allocatedHostFqdn']);
		setSubAgencyCodes(agencyData[index]['subAgencyCodes']);
		setDefaultDiscountPercent(agencyData[index]['defaultDiscountPercent']);
		setCode(agencyData[index]['code']);
		if (agencyData[index]['active']) {
			setIsActive(true);
		} else {
			setIsActive(false);
		}

		setOperations(agencyData[index]['operation']);
		setAssignedClerk(agencyData[index]['assignedClerk']);
		setAuthorizedUsername(getAgencyFromName(agencyData[index]['authorizedUsername']));

		setMobileToAuthen(agencyData[index]['mobileToAuthen']);
		setIsAutonomous(agencyData[index]['isAutonomous'] ?? false);
		setLimitToSpecificDeals(agencyData[index]['limitToSpecificDeals']);
		setPOS(agencyData[index]['Pos']);
		setLabelsCoupon(agencyData[index]['couponLblForMarketer'] || defaultLabelsCoupon);
		setKindAgency('ForMarketer');
		optionsKindAgency.forEach(item => {
			if (agencyData[index][item.value]) setKindAgency(item.value);
		})
		setIsLoginMarketer(agencyData[index]['isLoginMarketer']);
		setBypassPayment(agencyData[index]['bypassPayment']);
		setLimitToSpecificDeals(agencyData[index]['limitToSpecificDeals']);

		setPreferSmsToPassword(agencyData[index]['preferSmsToPassword']);
		setIsForPricePlanOnly(agencyData[index]['forPricePlanOnly']);
		setSimplifiedDiscRuleAgency(agencyData[index]['simplifiedDiscRuleAgency']);
		setEnableSearchAgent(agencyData[index]['enableSearchAgent']);
		setProtectDiscount(agencyData[index]['protectDiscount']);
		setPasswordForMarketer(agencyData[index]['passwordForMarketer']);
		setPasswordForClerk(agencyData[index]['passwordForClerk']);

		setDabAgencyList(getAgencyListFromCodeList(agencyData[index]['dabAllowedOdyAgentCodes']));
		// setDdaAgencyList(getAgencyListFromCodeList(agencyData[index]['ddaAllowedOdyAgentCodes']));
		setSpecialAgencyList(getAgencyListFromCodeList(agencyData[index]['agentSiteSpecificProps']?.visitorLikeExtAgents));
		setOdyAgentProperties(agencyData[index]['agentSiteSpecificProps']?.odyAgentProperties || []);
		setOpen(true);
	};

	const openSearchModel = () => {
		setOpenFilter(true);
	};
	const handleClose = () => {
		initialValue();
		setOpen(false);
	};
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}
	const handleCloseWarning = () => {
		setWarningOpen(false);
	};
	const handleFilterClose = () => {
		setOpenFilter(false);
	};
	function searchHotelList() {
		setPage(0);
		getAgencyData(1, rowsPerPage);
		setOpenFilter(false);
	}
	async function editProcess() {
		setLoading(true);
		var post_url;
		if (nButtonText === 'Edit') {
			post_url = baseURL + 'api/agency/' + nCode;
		} else {
			post_url = baseURL + 'api/agency';
		}
		await axios({
			method: 'post',
			url: post_url,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"odyAgentCode": nAgentCode,
				"allocatedHostFqdn": nHostFqdn,
				"subAgencyCodes": nSubAgencyCodes,
				"defaultDiscountPercent": nDefaultDiscountPercent ? Number(nDefaultDiscountPercent) : null,
				'active': nIsActiveState,
				'operation': Number(nOperations),
				'mobileToAuthen': nMobileToAuthen || null,
				'isAutonomous': nIsAutonomous,
				'isLoginMarketer': nIsLoginMarketer,
				'bypassPayment': nBypassPayment,
				'limitToSpecificDeals': nLimitToSpecificDeals,
				'Pos': forPOS,
				'assignedClerk': assignedClerk,
				...{ ...defaultKindAgency, [kindAgency]: true },
				'dabAllowedOdyAgentCodes': kindAgency === 'forInternalAgentSite' && dabAgencyList ? dabAgencyList.map((agency) => getAgencyCodeInternal(agency)) : null,
				'agentSiteSpecificProps': kindAgency === 'forInternalAgentSite' && specialAgencyList ?  {
						'visitorLikeExtAgents': specialAgencyList.map((agency) => getAgencyCodeInternal(agency)),
						'internalAgents': [],
						'odyAgentProperties': odyAgentProperties
					} : null,
				'authorizedUsername': authorizedUsername?.userName ?? '',
				// 'ddaAllowedOdyAgentCodes': ddaAgencyList ? ddaAgencyList.map((agency) => getAgencyCodeInternal(agency)) : null,
				"couponLblForMarketer": kindAgency === 'forMarketer' ? labelsCoupon : null,
				'PreferSmsToPassword': nPreferSmsToPassword,
				"forPricePlanOnly": nIsForPricePlanOnly,
				"simplifiedDiscRuleAgency": nSimplifiedDiscRuleAgency,
				"enableSearchAgent": nEnableSearchAgent,
				"protectDiscount": nProtectDiscount,
				"passwordForMarketer": nPasswordForMarketer,
				"PasswordForClerk": nPasswordForClerk,
			}
		}).then(response => {
			if (response.data.error) {
				setLoading(false);
				setConfirmOpen(false);
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
		}).catch(error => {
			setLoading(false);
			setWarningOpen(true);
			setWarningText("Error");
		});
		getAgencyData(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
		initialValue();
		setLoading(false);
		setOpen(false);
	};
	async function confirmProcess() {
		setLoading(true);
		await axios.delete(baseURL + 'api/agency/' + nCode, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		}).then(response => {
			if (response.data.error !== null && response.data.error.message !== null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			} else {
				getAgencyData(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}
			initialValue();
			setLoading(false);
			setOpen(false);
			setConfirmOpen(false);
		}).catch(error => {
			setLoading(false);
			setConfirmOpen(false);
			setWarningOpen(true);
			setWarningText(error.response.data);
		});

	};
	async function getAgencyData(from, to) {
		const active = nFilterActive === null || nFilterActive === '' ? null : nFilterActive === 'true';
		await axios({
			method: 'post',
			url: `${baseURL}api/agency/search?from=${from}&to=${to}`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				'allocatedHostFqdn': nFilterHostFqdn || null,
				'odyAgentCode': nFilterAgentCode || null,
				"subAgencyCodes": nFilterSubAgencyCodes || null,
				'active': active,
				'mobileToAuthen': nFilterMobileToAuthen || null,
				'isAutonomous': nFilterAutonomous === null || nFilterAutonomous === '' ? null : nFilterAutonomous === 'true',
				'isLoginMarketer': (nFilterLoginMarketer === null) || nFilterLoginMarketer === '' ? null : nFilterLoginMarketer === 'true',
				'preferSmsToPassword': (nFilterPreferSmsToPassword === null) || nFilterPreferSmsToPassword === '' ? null : nFilterPreferSmsToPassword === 'true',
				'forPricePlanOnly': (nFilterForPricePlanOnly === null) || nFilterForPricePlanOnly === '' ? null : nFilterForPricePlanOnly === 'true',
				'simplifiedDiscRuleAgency': (nFilterSimplifiedDiscRuleAgency === null) || nFilterSimplifiedDiscRuleAgency === '' ? null : nFilterSimplifiedDiscRuleAgency === 'true',
				'enableSearchAgent': (nFilterEnableSearchAgent === null) || nFilterEnableSearchAgent === '' ? null : nFilterEnableSearchAgent === 'true',
				'protectDiscount': (nFilterProtectDiscount === null) || nFilterProtectDiscount === '' ? null : nFilterProtectDiscount === 'true',
				'bypassPayment': (nFilterBypassPayment === null) || nFilterBypassPayment === '' ? null : nFilterBypassPayment === 'true',
				'limitToSpecificDeals': (nFilterLimitDeals === null) || nFilterLimitDeals === '' ? null : nFilterLimitDeals === 'true',
				'operation': nFilterOperation === null || nFilterOperation === '' ? null : Number(nFilterOperation),
				"principalType": filterKindAgency === null || filterKindAgency === '' ? null : filterKindAgency,
				"Pos": filterPOS === null || filterPOS === '' ? null : filterPOS,
			}
		}).then(response => {
			const data = response.data;
			setData(data);
			setAgencyData(data['data'])
		}).catch(error => {
			console.log(error);
		});
		setLoading(false);
	}
	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}

	function onChangeAgentCode(event) {
		setAgentCode(event.target.value)
	}
	function onChangeHostFqdn(event) {
		const sContent = event.target.value.replace(/\s/g, "");
		const aContent = (sContent === '') ? [] : sContent.split(',');
		setHostFqdn(aContent);
	}
	function onChangeSubAgencyCode(event) {
		const sContent = event.target.value.replace(/\s/g, "");
		const aContent = (sContent === '') ? [] : sContent.split(',');
		setSubAgencyCodes(aContent)
	}
	function onChangeDefaultDiscountPercent(event) {
		setDefaultDiscountPercent(event.target.value)
	}
	function handleChangeCheckbox() {
		setIsActive(!nIsActiveState);
	}
	function handleChangeOperations(event) {
		setOperations(event.target.value);
	}
	const onChangePOS = (ev) => {
		setPOS(ev.target.value);
	}
	const onMessageFromRadioKindAgency = (pMsg) => {
		switch (pMsg.kind) {
			case 'changeValue':
				setKindAgency(pMsg.value);
				break;
			default:
		}
	}
	const handleChangeOdyAgentForPos = event => {
		setOdyAgentForPos(event.target.value || '');
		setOdyAgentPosCode('');
	};
	const handleChangeOdyAgentPosCode = event => {
		setOdyAgentPosCode(event.target.value);
	};
	const addOdyAgentProperty = () => {
		if(odyAgentForPos === '' || odyAgentPosCode === '') return;

		// find editing row
		let agentInGroup = odyAgentGroup.find(e => e.main_agent === odyAgentForPos);
		if(!agentInGroup) {
			agentInGroup = { main_agent: odyAgentForPos };
			odyAgentGroup.push(agentInGroup);
		}

		// process duplicated agents
		agentInGroup.pos = odyAgentPosCode;
		if(addtionalAgencyList){
			agentInGroup.additional_agents = [];
			addtionalAgencyList.forEach(e => {
				let duplicatedFlag = false;
				odyAgentGroup.forEach(group => {
					if(group.main_agent == e.agt_Code) {
						duplicatedFlag = true;
					}
				})

				if(!duplicatedFlag) {  // this means if main_agent then ignore.
					odyAgentGroup.forEach(group => {
						if(group.main_agent !== odyAgentForPos && group.additional_agents) {
							const idx = group.additional_agents.findIndex(elem => elem === e.agt_Code);
							if(idx > -1){
								group.additional_agents.splice(idx, 1);
							}
						}
					})

					agentInGroup.additional_agents.push(e.agt_Code);
				}
			})
		}

		// re-construct the OdyAgentProperties
		updateOdyAgentProperties();

		setOdyAgentForPos('');
		setOdyAgentPosCode('');
		setAddtionalAgencyList([]);
	}
	const editOdyAgentForPos = (index) => {
		setOdyAgentForPos(odyAgentGroup[index].main_agent);
		setOdyAgentPosCode(odyAgentGroup[index].pos);
		setAddtionalAgencyList(getAgencyListFromCodeList(odyAgentGroup[index].additional_agents));
	}
	const deleteOdyAgentForPos = (index) => {
		odyAgentGroup.splice(index, 1);

		updateOdyAgentProperties();

		setOdyAgentForPos('');
		setOdyAgentPosCode('');
		setAddtionalAgencyList([]);
	}
	const updateOdyAgentGroup = () => {
		const groupedData = odyAgentProperties.reduce(function (result, current) {
			if (!result[current.pos]) {
				result[current.pos] = { pos: current.pos, main_agent: current.odyAgentCode, additional_agents: [] };
			} else {
			  	result[current.pos].additional_agents.push(current.odyAgentCode);
			}
			return result;
		}, {});

		setOdyAgentGroup(Object.values(groupedData));
	}
	const updateOdyAgentProperties = () => {
		const tmpList = [];
		odyAgentGroup.forEach(e => {
			tmpList.push({odyAgentCode: e.main_agent, pos: e.pos});
		})

		odyAgentGroup.forEach(e => {
			if(e.additional_agents){
				e.additional_agents.forEach(code => {
					tmpList.push({odyAgentCode: code, pos: e.pos});
				})
			}
		})

		setOdyAgentProperties(tmpList);
	}

	const addAgencyForMarketer = () => {
		setUserName('');
		setFullName('');
		setBirthday(null);
		setEmail('');
		setPhoneNumber('');
		setPassWord('');

		setOpenAddAgency(true);
	}
	const handleAddAgencyClose = () => {
		setOpenAddAgency(false);
	}
	const handleAddAgencyForMarketer = async (index) => {
		const request_url = baseURL + 'api/user';
		const dataAgency = {
			'userName': userName,
			'fullName': fullName,
			'dob': birthday,
			'role': 'agency',
			'phoneNumber': phoneNumber,
			'email': email,
			'enabled': true,
			'password': password
		}

		setSaveNewAgency(true);
		setOpenAddAgency(false);
		await axios({
			method: 'post',
			url: request_url,
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			},
			data: dataAgency
		}).then(async response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningText(response.data.error.message);
				setWarningOpen(true);
			} else {
				fetchAutheredAllUsers();
			}
			setSaveNewAgency(false);
		})
		.catch(error => {
			setSaveNewAgency(false);
			setWarningText("HTTP Error");
			setWarningOpen(true);
			return;
		});
	}

	/////////////////////////////////////////////////
	function onChangeFilterAgentCode(event) {
		setFilterAgentCode(event.target.value)
	}
	function onChangeFilterHostFqdn(event) {
		setFilterHostFqdn(event.target.value)
	}
	function onChangeFilterSubAgencyCodes(event) {
		setFilterSubAgencyCodes(event.target.value)
	}
	function onChangeFilterActive(event) {
		setFilterActive(event.target.value)
	}
	const onChangeFilterPOS = (ev) => {
		setFilterPOS(ev.target.value);
	}
	const onChangeFilterRadioKindAgency = (ev) => {
		setFilterKindAgency(ev.target.value);
	}
	function onChangeFilterOperation(event) {
		setFilterOperation(event.target.value)
	}

	///////////////// add user form //////////////
	const handleDateChange = (date) => {
		setBirthday(date);
	};
	function handleChangeFullName(event) {
		setFullName(event.target.value)
	}
	function handleChangeUserName(event) {
		setUserName(event.target.value)
	}
	function handleChangeEmail(event) {
		setEmail(event.target.value)
	}
	function handleChangePhone(event) {
		setPhoneNumber(event.target.value)
	}
	const handlePasswordChange = (prop) => (event) => {
		setPassWord(event.target.value)
		setValues({ ...values, [prop]: event.target.value });
	};
	const handleClickShowPassword = () => {
		setValues({ ...values, showPassword: !values.showPassword });
	};
	const handleMouseDownPassword = (event) => {
		event.preventDefault();
	};

	//////////////////////////////////////////////
	function handleChangePage(event, value) {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage
		getAgencyData(from, to);
	}
	function handleChangeRowsPerPage(event) {
		setRowsPerPage(event.target.value);
		setPage(0)
		const temp = Number(event.target.value)
		const from = 1;
		const to = temp
		getAgencyData(from, to);
	}
	function initialValue() {
		setCurrentEditingContent(null);

		setAgentCode(null);
		setHostFqdn([]);
		setSubAgencyCodes([]);
		setCode(null);
		setIsActive(false);
		setOperations(0);
		setMobileToAuthen(null);
		setIsAutonomous(false);
		setIsLoginMarketer(false);
		setBypassPayment(false);
		setPOS('');
		setAssignedClerk('');
		setLimitToSpecificDeals(false);
		setDabAgencyList(null);
		// setDdaAgencyList(null);
		setSpecialAgencyList(null);

		setPreferSmsToPassword(false);
		setIsForPricePlanOnly(false);
		setSimplifiedDiscRuleAgency(false);
		setEnableSearchAgent(false);
		setProtectDiscount(false);
		setPasswordForMarketer('');
		setPasswordForClerk('');
	}
	const clipboardLink = (pLink) => async (event) => {
		if (navigator && navigator.clipboard && navigator.clipboard.writeText)
			return await navigator.clipboard.writeText(pLink);
		return Promise.reject('The Clipboard API is not available.');
	}
	function getSubAgencyCode(item) {
		return (
			item.subAgencyCodes.map((code, i) =>
				<Chip key={i} className={classes.chipStyle1} label={code} variant='outlined' />
			)
		)
	}
	function getAgencyUrl(item) {
		const host = [process.env.REACT_APP_PACK_DOMAIN, process.env.REACT_APP_DOMESTIC_DOMAIN, process.env.REACT_APP_CAMINGO_DOMAIN][item.operation];
		return item.allocatedHostFqdn.length > 0 ?
			(
				''
			) :
			(
				item.subAgencyCodes.length > 0 ?
					(
						item.subAgencyCodes.map((code, i) => {
							return (
								<Grid key={i} className={classes.linkGroup}>
									<Chip className={classes.chipStyle} label={`${code}`} variant='outlined' />
									<IconButton aria-label="delete" onClick={clipboardLink(`${host}?marketerId=${item.code}&subMarketerId=${code}`)}>
										<FileCopyOutlined />
									</IconButton>
									<IconButton aria-label="delete" target="_blank" href={`${host}?marketerId=${item.code}&subMarketerId=${code}`}>
										<OpenInNew />
									</IconButton>
								</Grid>
							)
						}
						)
					) :
					(
						<Grid className={classes.linkGroup}>
							<Chip className={classes.chipStyle} label={`${item.odyAgentCode}`} variant='outlined' />
							<IconButton aria-label="copy" onClick={clipboardLink(`${host}?marketerId=${item.code}`)}>
								<FileCopyOutlined />
							</IconButton>
							<IconButton aria-label="link" target="_blank" href={`${host}?marketerId=${item.code}`}>
								<OpenInNew />
							</IconButton>
							{
								item.isLoginMarketer && item.passwordForClerk ? (
									<IconButton title="agent mode" aria-label="link" target="_blank" href={`${host}?marketerId=${item.code}&fc-agent-mode`}>
										<OpenInNew />
									</IconButton>
								) : ''
							}
						</Grid>
					)
			);
	}

	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className="w-full flex flex-col">
			<Modal
				open={warningOpen}
				onClose={handleCloseWarning}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Warning</h2>
					<p id='server-modal-description'>{warningText}</p>
					<Button className='whitespace-no-wrap normal-case'
						variant='contained'
						color='secondary'
						style={{ marginTop: '10px' }}
						onClick={handleCloseWarning}>Close
					</Button>
				</div>
			</Modal>
			<Modal
				open={confirmOpen}
				onClose={handleCloseConfirm}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Confirm</h2>
					<p id='server-modal-description'>{confirmText}</p>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={confirmProcess}>Confirm
					</Button>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={handleCloseConfirm}>Cancel
					</Button>
				</div>
			</Modal>
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={openFilter}
				onClose={handleFilterClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={openFilter}>
					<div className={classes.paper}>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title' >Filter Setting</h2>
						</div>
						<div style={{ display: 'grid' }}>
							<Grid container justify='space-between' style={{ textAlign: 'center', display: 'flex' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>AgentCode</FormHelperText>
									<TextField defaultValue={nFilterAgentCode} className={classes.textfield} onChange={onChangeFilterAgentCode} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>AllocatedHostFqdn</FormHelperText>
									<TextField defaultValue={nFilterHostFqdn} className={classes.textfield} onChange={onChangeFilterHostFqdn} />
								</FormControl>
							</Grid>

							<Grid container justify='space-between' style={{ textAlign: 'center', display: 'flex' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>SubAgencyCodes</FormHelperText>
									<TextField defaultValue={nFilterSubAgencyCodes} className={classes.textfield} onChange={onChangeFilterSubAgencyCodes} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Mobile To Authen</FormHelperText>
									<TextField type="number" inputProps={{ inputMode: 'numeric', pattern: '[0-9]*' }} defaultValue={nFilterMobileToAuthen} className={classes.textfield} onChange={(e) => { setFilterMobileToAuthen(e.target.value) }} />
								</FormControl>
							</Grid>

							<Grid container justify='space-between' style={{ textAlign: 'center', display: 'flex' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }} >
									<FormHelperText>Point of Sale</FormHelperText>
									<TextField defaultValue={filterPOS} className={classes.textfield} onChange={onChangeFilterPOS}></TextField>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Kind of Agency</FormHelperText>
									<Select
										native
										onChange={onChangeFilterRadioKindAgency}
										value={filterKindAgency}
										inputProps={{
											id: 'kind-agency-required',
										}}
									>
										<option aria-label='None' value=''></option>
										{optionsKindAgency.map((opt, i) => (
											<option aria-label='None' key={i} value={opt.value}>{opt.label}</option>
										))}
									</Select>
								</FormControl>
							</Grid>

							<Grid container justify='space-between' style={{ textAlign: 'center', display: 'flex' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Autonomous</FormHelperText>
									<Select
										native
										onChange={(e) => { setFilterAutonomous(e.target.value) }}
										value={nFilterAutonomous || ''}
										inputProps={{
											id: 'b2b-marketer-required',
										}}
									>
										<option aria-label='None' value=''>All</option>
										<option value='true'>Active</option>
										<option value='false'>Inactive</option>
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Bypass Payment</FormHelperText>
									<Select
										native
										onChange={(e) => { setFilterBypassPayment(e.target.value) }}
										value={nFilterBypassPayment || ''}
										inputProps={{
											id: 'b2b-marketer-required',
										}}
									>
										<option aria-label='None' value=''>All</option>
										<option value='true'>Active</option>
										<option value='false'>Inactive</option>
									</Select>
								</FormControl>
							</Grid>

							<Grid container justify='space-between' style={{ textAlign: 'center', display: 'flex' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Login Marketer</FormHelperText>
									<Select
										native
										onChange={(e) => { setFilterLoginMarketer(e.target.value) }}
										value={nFilterLoginMarketer || ''}
										inputProps={{
											id: 'b2b-marketer-required',
										}}
									>
										<option aria-label='None' value=''>All</option>
										<option value='true'>Active</option>
										<option value='false'>Inactive</option>
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Prefer SMS To Password</FormHelperText>
									<Select
										native
										onChange={(e) => { setFilterPreferSmsToPassword(e.target.value) }}
										value={nFilterPreferSmsToPassword || ''}
										inputProps={{
											id: 'prefer-sms-pass',
										}}
									>
										<option aria-label='None' value=''>All</option>
										<option value='true'>Active</option>
										<option value='false'>Inactive</option>
									</Select>
								</FormControl>
							</Grid>

							<Grid container justify='space-between' style={{ border: '1px solid #999', padding: '5px', margin: '5px -5px' }}>
								<Grid container justify='space-between' style={{ textAlign: 'center', display: 'flex' }}>
									<FormControl required className={classes.formControl} style={{ width: '45%' }}>
										<FormHelperText>For Price Plan Only</FormHelperText>
										<Select
											native
											onChange={(e) => { setFilterForPricePlanOnly(e.target.value) }}
											value={nFilterForPricePlanOnly || ''}
											inputProps={{
												id: 'price-plan-only',
											}}
										>
											<option aria-label='None' value=''>All</option>
											<option value='true'>Active</option>
											<option value='false'>Inactive</option>
										</Select>
									</FormControl>
									<FormControl required className={classes.formControl} style={{ width: '45%' }}>
										<FormHelperText>Simplified DiscRule Agency</FormHelperText>
										<Select
											native
											onChange={(e) => { setFilterSimplifiedDiscRuleAgency(e.target.value) }}
											value={nFilterSimplifiedDiscRuleAgency || ''}
											inputProps={{
												id: 'simplified-Disc-Rule-Agency',
											}}
										>
											<option aria-label='None' value=''>All</option>
											<option value='true'>Active</option>
											<option value='false'>Inactive</option>
										</Select>
									</FormControl>
								</Grid>

								<Grid container justify='space-between' style={{ textAlign: 'center', display: 'flex' }}>
									<FormControl required className={classes.formControl} style={{ width: '45%' }}>
										<FormHelperText>Protect Discount</FormHelperText>
										<Select
											native
											onChange={(e) => { setFilterProtectDiscount(e.target.value) }}
											value={nFilterProtectDiscount || ''}
											inputProps={{
												id: 'filter-protect-discount',
											}}
										>
											<option aria-label='None' value=''>All</option>
											<option value='true'>Active</option>
											<option value='false'>Inactive</option>
										</Select>
									</FormControl>
								</Grid>

							</Grid>

							<Grid container justify='space-between' style={{ border: '1px solid #999', padding: '5px', margin: '5px -5px' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Limit Specific Deals</FormHelperText>
									<Select
										native
										onChange={(e) => { setFilterLimitDeals(e.target.value) }}
										value={nFilterLimitDeals || ''}
										inputProps={{
											id: 'limit-marketer-required',
										}}
									>
										<option aria-label='None' value=''>All</option>
										<option value='true'>Active</option>
										<option value='false'>Inactive</option>
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Enable Search Agent</FormHelperText>
									<Select
										native
										onChange={(e) => { setFilterEnableSearchAgent(e.target.value) }}
										value={nFilterEnableSearchAgent || ''}
										inputProps={{
											id: 'filter-enable-search',
										}}
									>
										<option aria-label='None' value=''>All</option>
										<option value='true'>Active</option>
										<option value='false'>Inactive</option>
									</Select>
								</FormControl>
							</Grid>

							<Grid container justify='space-between' style={{ textAlign: 'center', display: 'flex' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Operation</FormHelperText>
									<Select
										native
										onChange={onChangeFilterOperation}
										value={nFilterOperation || ''}
										inputProps={{
											id: 'operation-filter-required',
										}}
									>
										<option aria-label='None' value=''>All</option>
										{operationsArray.map((operation, inx) => (<option aria-label='None' key={inx} value={inx}>{operation}</option>))}
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Active State</FormHelperText>
									<Select
										native
										onChange={onChangeFilterActive}
										value={nFilterActive}
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option aria-label='None' value=''>All</option>
										<option value='true'>Active</option>
										<option value='false'>Inactive</option>
									</Select>
								</FormControl>
							</Grid>
						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleFilterClose}>
								Cancel
							</Button>
							<Button className={classes.buttons} variant='contained' color='secondary' onClick={searchHotelList}>
								Filter
							</Button>
						</div>
					</div>

				</Fade>
			</Modal>
			<Modal
				aria-labelledby="transition-modal-title"
				aria-describedby="transition-modal-description"
				className={classes.modal}
				open={open}
				onClose={handleClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={open}>
					<div className={classes.paper}>
						<h2 id="transition-modal-title" style={{ textAlign: 'center' }}>Edit</h2>
						<div style={{ textAlign: 'center', display: 'grid' }}>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>Operation</FormHelperText>
								<Select
									native
									onChange={handleChangeOperations}
									value={nOperations}
									inputProps={{
										id: 'operation-native-required',
									}}
								>
									{operationsArray.map((operation, inx) => (<option aria-label='None' key={inx} value={inx}>{operation}</option>))}
								</Select>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>AgentCode</FormHelperText>
								<TextField defaultValue={nAgentCode} className={classes.textfield} onChange={onChangeAgentCode} />
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>AllocatedHostFqdn</FormHelperText>
								<TextField defaultValue={nHostFqdn} className={classes.textfield} onChange={onChangeHostFqdn} />
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>SubAgencyCode</FormHelperText>
								<TextField defaultValue={nSubAgencyCodes} className={classes.textfield} onChange={onChangeSubAgencyCode} />
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Default Discount Percent</FormHelperText>
								<TextField defaultValue={nDefaultDiscountPercent} className={classes.textfield} onChange={onChangeDefaultDiscountPercent} />
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Mobile To Authen</FormHelperText>
								<TextField type="number" inputProps={{ inputMode: 'numeric', pattern: '[0-9]*' }} defaultValue={nMobileToAuthen} className={classes.textfield} onChange={(e) => { setMobileToAuthen(e.target.value) }} />
							</FormControl>

							<Grid container justify='space-between' style={{ textAlign: 'center', display: 'flex' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Point of Sale</FormHelperText>
									<TextField defaultValue={forPOS} className={classes.textfield} onChange={onChangePOS} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Assigned Clerk</FormHelperText>
									<TextField defaultValue={assignedClerk} className={classes.textfield} onChange={(e) => setAssignedClerk(e.target.value)} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>authorized User Name</FormHelperText>
									{/* <TextField defaultValue={authorizedUsername} className={classes.textfield} onChange={(e) => setAuthorizedUsername(e.target.value)} /> */}
									{saveNewAgency ? (
										<CircularProgress className="w-xs max-w-full m-auto" color="secondary" />
									) : (
										<Autocomplete
											{...listAuthorizedUser}
											id="authorizeduser"
											value={authorizedUsername}
											onChange={(ev, newValue) => {
												setAuthorizedUsername(newValue);
											}}
											renderInput={(params) => (
												<TextField {...params} variant="standard" />
											)}
										/>
									)}									
								</FormControl>
								<Button
									color="secondary"
									variant="contained"
									style={{ margin: 'auto 0px', height: '50%' }}
									onClick={event => addAgencyForMarketer(event)}
									disabled={kindAgency!=='forMarketer'}
								>
									add
								</Button>
							</Grid>
							<Grid container justify='space-between' style={{ textAlign: 'center', display: 'flex' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Coupon Title</FormHelperText>
									<TextField defaultValue={labelsCoupon.title} className={classes.textfield} onChange={e => setLabelsCoupon({ ...labelsCoupon, title: e.target.value })} disabled={kindAgency !== 'forMarketer'} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Coupon Code Label</FormHelperText>
									<TextField defaultValue={labelsCoupon.codeLabel} className={classes.textfield} onChange={e => setLabelsCoupon({ ...labelsCoupon, codeLabel: e.target.value })} disabled={kindAgency !== 'forMarketer'} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Coupon Status Label</FormHelperText>
									<TextField defaultValue={labelsCoupon.statusLabel} className={classes.textfield} onChange={e => setLabelsCoupon({ ...labelsCoupon, statusLabel: e.target.value })} disabled={kindAgency !== 'forMarketer'} />
								</FormControl>
							</Grid>
							{
								agencyInfoInternal && agencyInfoInternal.length ?
									(
										<Grid container justify='space-between' style={{ textAlign: 'center', display: 'flex' }}>
											<FormControl required className={classes.formControl} style={{ width: '100%' }}>
												<FormHelperText style={{ wordSpacing: '-1px' }}>Choose Internal Agent</FormHelperText>
												<Autocomplete
													multiple
													{...agencyInfoProps}
													id="dab-allowed"
													value={dabAgencyList || []}
													disabled={kindAgency !== 'forInternalAgentSite'}
													onChange={(event, newValue) => {
														setDabAgencyList(newValue);
													}}
													renderInput={(params) => (
														<TextField {...params} variant="standard" />
													)}
												/>
											</FormControl>

											{
												nOperations === 1 && kindAgency === 'forInternalAgentSite' ? (
												<div style={{ padding: '10px', border: '1px solid',  borderRadius: '5px', margin: '10px 0px', width: '100%' }}>
													<div style={{ display: 'flex' }}>
														<FormControl
															required
															className={classes.formControl}
															style={{ width: '30%', marginLeft: '5px' }}
														>
															<FormHelperText>Agents</FormHelperText>
															<Select
																native
																name="Agents"
																onChange={handleChangeOdyAgentForPos}
																value={odyAgentForPos || ''}
																inputProps={{
																	id: 'select-agent-for-poscode'
																}}
															>
																<option aria-label="None" value={null} />
																{dabAgencyList === null
																	? ''
																	: dabAgencyList.map((n, i) => (
																		<option key={i} value={getAgencyCodeInternal(n)}>
																			{getAgencyNameInternal(n)}
																		</option>
																	))}
															</Select>
														</FormControl>
														<FormControl
															required
															className={classes.formControl}
															style={{ width: '15%', marginLeft: '5px' }}
														>
															<FormHelperText>POS Code</FormHelperText>
															<TextField value={odyAgentPosCode} className={classes.textfield} onChange={handleChangeOdyAgentPosCode} />
														</FormControl>
														<FormControl
															required
															className={classes.formControl}
															style={{ width: '40%', marginLeft: '5px' }}
														>
															<FormHelperText>additional Agents</FormHelperText>
															<Autocomplete
																multiple
																{...agencyInfoProps}
																id="dab-allowed"
																value={addtionalAgencyList || []}
																onChange={(event, newValue) => {
																	setAddtionalAgencyList(newValue);
																}}
																renderInput={(params) => (
																	<TextField {...params} variant="standard" />
																)}
															/>
														</FormControl>
														<Button
															className={classes.buttons}
															color="secondary"
															variant="contained"
															style={{ marginLeft: '10px' }}
															onClick={event => addOdyAgentProperty(event)}
														>
															Add / Save
														</Button>
													</div>

													<Table className={classes.table} aria-label="caption table">
														<TableHead>
															<TableRow>
																<TableCell>Agent Code</TableCell>
																<TableCell>POS Code</TableCell>
																<TableCell>Additional Agents</TableCell>
																<TableCell align="center">Edit</TableCell>
																<TableCell align="center">Delete</TableCell>
															</TableRow>
														</TableHead>
														<TableBody>
															{odyAgentGroup.map((n, index) => (
																<TableRow key={index}>
																	<TableCell className="p-4 md:p-16" component="th" scope="row" size="small">
																		{n.main_agent}
																	</TableCell>
																	<TableCell className="p-4 md:p-16" size="small">
																		{n.pos}
																	</TableCell>
																	<TableCell className="p-4 md:p-16" size="small">
																		{
																			n.additional_agents ?
																			n.additional_agents.map((key, i) => (
																				<Chip
																					key={i}
																					label={key}
																					className={classes.chipStyle}
																				/>
																			)) : ''
																		}
																	</TableCell>
																	<TableCell
																		className="w-40 md:w-64 text-center z-99"
																		component="th"
																		scope="row"
																		align="left"
																		size="small"
																	>
																		<button
																			className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit"
																			onClick={() => editOdyAgentForPos(index)}
																			tabIndex="0"
																			type="button"
																			title="Edit"
																		>
																			<span className="MuiIconButton-label">
																				<span
																					className="material-icons MuiIcon-root"
																					aria-hidden="true"
																				>
																					edit
																				</span>
																			</span>
																			<span className="MuiTouchRipple-root" />
																		</button>
																	</TableCell>
																	<TableCell
																		className="w-40 md:w-64 text-center z-99"
																		component="th"
																		scope="row"
																		align="left"
																		size="small"
																	>
																		<button
																			className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit"
																			onClick={() => deleteOdyAgentForPos(index)}
																			tabIndex="0"
																			type="button"
																			title="Delete"
																		>
																			<span className="MuiIconButton-label">
																				<span
																					className="material-icons MuiIcon-root"
																					aria-hidden="true"
																				>
																					delete
																				</span>
																			</span>
																			<span className="MuiTouchRipple-root" />
																		</button>
																	</TableCell>
																</TableRow>
															))}
														</TableBody>
													</Table>
												</div> ) : null
											}


											{/* <FormControl required className={classes.formControl} style={{ width: '48%' }}>
												<FormHelperText>Ody Agent Codes that is allowed to Decide the Debit Amount</FormHelperText>
												<Autocomplete
													multiple
													{...agencyInfoProps}
													id="dda-allowed"
													value={ddaAgencyList || []}
													disabled={kindAgency !== 'forInternalAgentSite'}
													onChange={(event, newValue) => {
														setDdaAgencyList(newValue);
													}}
													renderInput={(params) => (
														<TextField {...params} variant="standard" />
													)}
												/>
											</FormControl> */}
											<FormControl required className={classes.formControl} style={{ width: '100%' }}>
												<FormHelperText style={{ wordSpacing: '-1px' }}>Choose Special External Agent</FormHelperText>
												<Autocomplete
													multiple
													{...agencyInfoProps}
													id="dab-allowed"
													value={specialAgencyList || []}
													disabled={kindAgency !== 'forInternalAgentSite'}
													onChange={(event, newValue) => {
														setSpecialAgencyList(newValue);
													}}
													renderInput={(params) => (
														<TextField {...params} variant="standard" />
													)}
												/>
											</FormControl>
										</Grid>
									) : null
							}
							<RadioGroupKind
								title='Kind of Agency'
								options={optionsKindAgency}
								value={kindAgency}
								direction='row'
								onMessage={onMessageFromRadioKindAgency}
							/>
						</div>
						<div style={{ border: 'solid 1px #999', borderRadius: '10px', padding: '10px' }}>
							<Grid>
								<FormControlLabel
									control={
										<Checkbox
											checked={nIsAutonomous}
											onChange={(e) => setIsAutonomous(!nIsAutonomous)}
											name='isAutonomous'
											color='primary'
											disabled={kindAgency !== 'forMarketer'}
										/>
									}
									label='Autonomous'
									className={classes.checkboxform}
									style={{ width: '23%' }}
								/>
								<FormControlLabel
									control={
										<Checkbox
											checked={nBypassPayment}
											onChange={(e) => setBypassPayment(!nBypassPayment)}
											name='nBypassPayment'
											color='primary'
											disabled={kindAgency !== 'forMarketer'}
										/>
									}
									label='BypassPayment'
									className={classes.checkboxform}
									style={{ width: '23%' }}
								/>
								<FormControlLabel
									control={
										<Checkbox
											checked={nIsLoginMarketer}
											onChange={(e) => setIsLoginMarketer(!nIsLoginMarketer)}
											name='nIsLoginMarketer'
											color='primary'
											disabled={kindAgency !== 'forMarketer'}
										/>
									}
									label='LoginMarketer'
									className={classes.checkboxform}
									style={{ width: '23%' }}
								/>
								<FormControlLabel
									control={
										<Checkbox
											checked={nPreferSmsToPassword}
											onChange={(e) => setPreferSmsToPassword(!nPreferSmsToPassword)}
											name='PreferSmsToPassword'
											color='primary'
											disabled={kindAgency !== 'forMarketer' || !nIsLoginMarketer}
										/>
									}
									label='PreferSMSToPassword'
									className={classes.checkboxform}
								/>
							</Grid>

							<Grid>
								<FormControlLabel
									control={
										<Checkbox
											checked={nEnableSearchAgent}
											onChange={(e) => setEnableSearchAgent(!nEnableSearchAgent)}
											name='enableSearchAgent'
											color='primary'
											disabled={kindAgency !== 'forMarketer'}
										/>
									}
									label='Enable Search Agent'
									className={classes.checkboxform}
									style={{ width: '23%' }}
								/>
								<FormControlLabel
									control={
										<Checkbox
											checked={nLimitToSpecificDeals}
											onChange={(e) => setLimitToSpecificDeals(!nLimitToSpecificDeals)}
											name='nLimitToSpecificDeals'
											color='primary'
											disabled={kindAgency !== 'forMarketer'}
										/>
									}
									label='LimitToSpecificDeals'
									className={classes.checkboxform}
									style={{ width: '23%' }}
								/>
							</Grid>

							<Grid>
								<FormControlLabel
									control={
										<Checkbox
											checked={nIsForPricePlanOnly}
											onChange={(e) => setIsForPricePlanOnly(!nIsForPricePlanOnly)}
											name='ForPricePlanOnly'
											color='primary'
											disabled={kindAgency !== 'forMarketer'}
										/>
									}
									label='ForPricePlanOnly'
									className={classes.checkboxform}
									style={{ width: '23%' }}
								/>
								<FormControlLabel
									control={
										<Checkbox
											checked={nSimplifiedDiscRuleAgency}
											onChange={(e) => setSimplifiedDiscRuleAgency(!nSimplifiedDiscRuleAgency)}
											name='simplifiedDiscRuleAgency'
											color='primary'
											disabled={kindAgency !== 'forMarketer'}
										/>
									}
									label='Simplified DiscRule Agency'
									className={classes.checkboxform}
									style={{ width: '23%' }}
								/>
								<FormControlLabel
									control={
										<Checkbox
											checked={nProtectDiscount}
											onChange={(e) => setProtectDiscount(!nProtectDiscount)}
											name='protectDiscount'
											color='primary'
											disabled={kindAgency !== 'forMarketer'}
										/>
									}
									label='Protect Discount'
									className={classes.checkboxform}
									style={{ width: '23%' }}
								/>
							</Grid>

						</div>
						<Grid container justify='space-between' style={{ textAlign: 'center', display: 'flex' }}>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>Password For Marketer</FormHelperText>
								<TextField defaultValue={nPasswordForMarketer} className={classes.textfield} onChange={e => setPasswordForMarketer(e.target.value)} disabled={kindAgency !== 'forMarketer' || !nIsLoginMarketer} />
							</FormControl>
							<FormControl required className={classes.formControl} style={{ width: '45%' }}>
								<FormHelperText>Password For Clerk</FormHelperText>
								<TextField defaultValue={nPasswordForClerk} className={classes.textfield} onChange={e => setPasswordForClerk(e.target.value)} disabled={kindAgency !== 'forMarketer' || !nIsLoginMarketer} />
							</FormControl>
						</Grid>
						<div style={{ textAlign: 'center', display: 'flex' }}>
							<FormControlLabel
								control={
									<Checkbox
										checked={nIsActiveState}
										onChange={handleChangeCheckbox}
										name='checkedC'
										color='primary'
									/>
								}
								label='Active'
								className={classes.checkboxform}
							/>
						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant="contained" color="primary" onClick={handleClose}>
								Cancel
							</Button>
							<Button className={classes.buttons} variant="contained" onClick={editProcess} color="secondary">
								{nButtonText}
							</Button>
						</div>
					</div>
				</Fade>
			</Modal>
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={openAddAgency}
				onClose={handleAddAgencyClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={openAddAgency}>
					<div className={classes.paper}>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title' >Create User for Marketer</h2>
						</div>
						<div style={{ display: 'flex', flexDirection: 'column', width: '240px' }}>
							<TextField onChange={handleChangeFullName} className={classes.textField} label="Full Name" defaultValue={fullName} />
							<MuiPickersUtilsProvider utils={DateFnsUtils} >
								<Grid container justify="space-around" >
									<KeyboardDatePicker
										disableToolbar
										className={classes.textField1}
										variant="inline"
										format="MM/dd/yyyy"
										id="date-picker-inline"
										label="Birthday"
										value={birthday}
										onChange={handleDateChange}
										KeyboardButtonProps={{
											'aria-label': 'change date',
										}}
									/>
								</Grid>
							</MuiPickersUtilsProvider>
							<TextField onChange={handleChangeEmail} className={classes.textField} type='email' label="Email" defaultValue={email} />
							<TextField onChange={handleChangePhone} className={classes.textField} label="Phone" defaultValue={phoneNumber} />
							<TextField onChange={handleChangeUserName} className={classes.textField} label="username" defaultValue={userName} />
							<FormControl className={classes.textField} margin="dense">
								<InputLabel htmlFor="filled-adornment-password">Password</InputLabel>
								<Input
									id="filled-adornment-password"
									type={values.showPassword ? 'text' : 'password'}
									value={password}
									onChange={handlePasswordChange('password')}
									endAdornment={
										<InputAdornment position="end">
											<IconButton
												aria-label="toggle password visibility"
												onClick={handleClickShowPassword}
												onMouseDown={handleMouseDownPassword}
												edge="end"
											>
												{values.showPassword ? <Visibility /> : <VisibilityOff />}
											</IconButton>
										</InputAdornment>
									}
								/>
							</FormControl>
							<div><h5>The plain password won't be shown after saved, so please write down it safely and let the agency know it.</h5></div>
						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleAddAgencyClose}>
								Cancel
							</Button>
							<Button className={classes.buttons} variant='contained' color='secondary' onClick={handleAddAgencyForMarketer}>
								Create
							</Button>
						</div>
					</div>

				</Fade>
			</Modal>
			<div>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => addAgency()}
				>
					<span className='hidden sm:flex'>Add Agency</span>
					<span className='flex sm:hidden'>Add</span>
				</Button>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => openSearchModel()}
				>
					<span className='hidden sm:flex'><SearchIcon />Filter</span>
					<span className='flex sm:hidden'><SearchIcon /></span>
				</Button>
			</div>
			<FuseScrollbars className="flex-grow overflow-x-auto">
				<Table stickyHeader className="min-w-xl" aria-labelledby="tableTitle">
					<AgencyTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={agencyData?.length ?? 0}
					/>
					<TableBody>
						{_.orderBy(
							agencyData,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className="h-64 cursor-pointer"
									hover
									tabIndex={-1}
									key={i}
								>
									<TableCell padding="none" className="w-20 md:w-20 text-center z-99">
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.odyAgentCode}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.allocatedHostFqdn}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{getSubAgencyCode(n)}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" >
										{getAgencyUrl(n)}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.assignedClerk}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.nDefaultDiscountPercent}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.mobileToAuthen}
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										{operationsArray[n.operation]}
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.isFlyingCarpet && 'bg-red',
												n.isFlyingCarpet && 'bg-green',

											)}
										/>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.active && 'bg-red',
												n.active && 'bg-green',

											)}
										/>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.isLoginMarketer && 'bg-red',
												n.isLoginMarketer && 'bg-green',
											)}
										/>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.bypassPayment && 'bg-red',
												n.bypassPayment && 'bg-green',
											)}
										/>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.limitToSpecificDeals && 'bg-red',
												n.limitToSpecificDeals && 'bg-green',
											)}
										/>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => handleOpen(i)} tabIndex="0" type="button" title="Edit"><span className="MuiIconButton-label"><span className="material-icons MuiIcon-root" aria-hidden="true">edit</span></span><span className="MuiTouchRipple-root"></span></button>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => deleteHandle(i)} tabIndex="0" type="button" title="Edit">
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className="flex-shrink-0 border-t-1"
				component="div"
				count={data?.total ?? 0}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}

export default withRouter(AgencyTable);
