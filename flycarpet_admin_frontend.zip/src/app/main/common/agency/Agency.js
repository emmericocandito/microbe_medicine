import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../store';
import AgencyHeader from './AgencyHeader';
import AgencyTable from './AgencyTable';

function Agency() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<AgencyHeader />}
			content={<AgencyTable />}
			innerScroll
		/>
	);
}
 
export default withReducer('BasicData', reducer)(Agency);
