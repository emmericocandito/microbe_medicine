import { makeStyles } from '@material-ui/core/styles';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Tooltip from '@material-ui/core/Tooltip';
import React from 'react';

const rows = [

    {
        id: 'OdyAgentCode',
        align: 'left',
        disablePadding: false,
        label: 'odyAgentCode',
        sort: true
    },
    {
        id: 'allocatedHostFqdn',
        align: 'left',
        disablePadding: false,
        label: 'AllocatedHostFqdn',
        sort: true
    },
    {
        id: 'subAgencyCodes',
        align: 'left',
        disablePadding: false,
        label: 'SubAgencyCodes',
        sort: true
    },
    {
        id: 'agencyUrl',
        align: 'left',
        disablePadding: false,
        label: 'Links',
        sort: true
    },
    {
        id: 'assignedClerk',
        align: 'left',
        disablePadding: false,
        label: 'Assigned Clerk',
        sort: true
    },
    {
        id: 'defaultDiscountPercent',
        align: 'left',
        disablePadding: false,
        label: 'DefaultDiscountPercent',
        sort: true
    },
    {
        id: 'mobileToAuthen',
        align: 'left',
        disablePadding: false,
        label: 'MobileToAuthen',
        sort: true
    },
    {
        id: 'operation',
        align: 'left',
        disablePadding: false,
        label: 'Operations',
        sort: true
    },
    {
        id: 'isFlyingCarpet',
        align: 'left',
        disablePadding: false,
        label: 'FlyingCarpet',
        sort: true
    },
    {
        id: 'active',
        align: 'left',
        disablePadding: false,
        label: 'Active',
        sort: true
    },
    {
        id: 'isLoginMarketer',
        align: 'left',
        disablePadding: false,
        label: 'Login Marketer',
        sort: true
    },
    {
        id: 'bypassPayment',
        align: 'left',
        disablePadding: false,
        label: 'Bypass Payment',
        sort: true
    },
    {
        id: 'limitToSpecificDeals',
        align: 'left',
        disablePadding: false,
        label: 'Limit Deals',
        sort: true
    },
    {
        id: 'action',
        align: 'center',
        disablePadding: false,
        label: 'Edit',
        sort: true
    },
     {
        id: 'delete',
        align: 'center',
        disablePadding: false,
        label: 'Delete',
        sort: true
    }

];

function ProductsTableHead(props) {

    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };

    return (
        <TableHead>
            <TableRow className="h-64">
                <TableCell padding="none" className="w-20 md:w-20 text-center z-99">
                </TableCell>
                {rows.map(row => {
                    return (
                        <TableCell
                            className="p-4 md:p-16"
                            key={row.id}
                            align={row.align}
                            padding={row.disablePadding ? 'none' : 'default'}
                            sortDirection={props.order.id === row.id ? props.order.direction : false}
                        >
                            {row.sort && (
                                <Tooltip
                                    title="Sort"
                                    placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                    enterDelay={300}
                                >
                                    <TableSortLabel
                                        active={props.order.id === row.id}
                                        direction={props.order.direction}
                                        onClick={createSortHandler(row.id)}
                                    >
                                        {row.label}
                                    </TableSortLabel>
                                </Tooltip>
                            )}
                        </TableCell>
                    );
                }, this)}
            </TableRow>
        </TableHead>
    );
}

export default ProductsTableHead;
