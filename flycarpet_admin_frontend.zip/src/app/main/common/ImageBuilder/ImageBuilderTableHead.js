import { makeStyles } from '@material-ui/core/styles';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Tooltip from '@material-ui/core/Tooltip';
import React from 'react';

const rows = [
    
    {
        id: 'id',
        align: 'left',
        disablePadding: false,
        label: 'ID',
        sort: true
    },
    {
        id: 'ImageID',
        align: 'left',
        disablePadding: false,
        label: 'ImageID',
        sort: true
    },
    {
        id: 'description',
        align: 'left',
        disablePadding: false,
        label: 'Description',
        sort: true
    },
    {
        id: 'image',
        align: 'center',
        disablePadding: false,
        label: 'Image',
        sort: true
    },
    {
        id: 'href',
        align: 'left',
        disablePadding: false,
        label: 'Href',
        sort: true
    },
    {
        id: 'caption',
        align: 'left',
        disablePadding: false,
        label: 'Caption',
        sort: true
    },
    {
        id: 'active',
        align: 'center',
        disablePadding: false,
        label: 'Active',
        sort: true
    },
    {
        id: 'edit',
        align: 'left',
        disablePadding: false,
        label: 'Edit',
        sort: true
    },
    {
        id: 'delete',
        align: 'left',
        disablePadding: false,
        label: 'delete',
        sort: true
    },
  
    
];

function ProductsTableHead(props) {
    
    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };

    return (
        <TableHead>
            <TableRow className="h-64">
                <TableCell className="w-60 md:w-124 z-99" component="th" scope="row">
                </TableCell>
                {rows.map(row => {
                    return (
                        <TableCell
                            className="p-4 md:p-16"
                            key={row.id}
                            align={row.align}
                            padding={row.disablePadding ? 'none' : 'default'}
                            sortDirection={props.order.id === row.id ? props.order.direction : false}
                        >
                            {row.sort && (
                                <Tooltip
                                    title="Sort"
                                    placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                    enterDelay={300}
                                >
                                    <TableSortLabel
                                        active={props.order.id === row.id}
                                        direction={props.order.direction}
                                        onClick={createSortHandler(row.id)}
                                    >
                                        {row.label}
                                    </TableSortLabel>
                                </Tooltip>
                            )}
                        </TableCell>
                    );
                }, this)}
            </TableRow>
        </TableHead>
    );
}

export default ProductsTableHead;
