import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../store';
import ImageBuilderHeader from './ImageBuilderHeader';
import ImageBuilderTable from './ImageBuilderTable';

function ImageBuilder() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<ImageBuilderHeader />}
			content={<ImageBuilderTable />}
			innerScroll
		/>
	);
}
 
export default withReducer('ImageBuilderApp', reducer)(ImageBuilder);
