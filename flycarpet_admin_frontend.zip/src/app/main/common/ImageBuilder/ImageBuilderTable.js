import FuseScrollbars from '@fuse/core/FuseScrollbars';
import _ from '@lodash';
import axios from 'axios';
import clsx from 'clsx';
import {
	Table, TableBody, TableCell, TablePagination, TableRow, Modal, Backdrop, Fade, Button,
	TextField, FormControl, FormHelperText, FormControlLabel, Select, Checkbox, Chip, IconButton
} from '@material-ui/core';
import { ColorPicker, createColor, getCssColor } from 'material-ui-color';
import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import FuseLoading from '@fuse/core/FuseLoading';
import ImageBuilderTableHead from './ImageBuilderTableHead';
import { makeStyles } from '@material-ui/core/styles';
import SearchIcon from '@material-ui/icons/Search';
import SyncAltIcon from '@material-ui/icons/SyncAlt';
import ImageUploader from "react-images-upload";
import "react-responsive-carousel/lib/styles/carousel.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';

import { useBasicAgencyInfo } from 'app/main/store/hooks';
import { useConstantValue } from 'app/main/utils/constantValue';
import { baseURL } from 'app/main/utils';

import jwt from 'jwt-decode';

function ImageBuilderTable(props) {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			// margin: theme.spacing(1),
			minWidth: 120,
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			minWidth: 200,
			minHeight: 100,
			// textAlign: 'center'
		},
		button_group: {
			textAlign: 'center',
			padding: 30,
		},
		buttons: {
			marginRight: '10px'
		},
		checkboxform: {
			marginLeft: '-10px'
		},
		imageUploader: {
			maxWidth: '500px',

		},
		deleteImage: {
			position: 'absolute',
			top: '1px',
			right: '7px',
			color: '#fff',
			background: '#ff4081',
			borderRadius: '50%',
			textAign: 'center',
			cursor: 'pointer',
			fontSize: '17px',
			fontWeight: 'bold',
			lineHeight: '20px',
			width: '20px',
			height: '20px'
		},
		chipStyle: {
			height: '20px',
			margin: '1px',
			color: 'white',
			fontSize: '12px',
			background: '#32606b'
		},
		thumbnailStyle: {
			cursor: 'pointer',
			width: '100px',
			maxHeight: '100px',
			margin: '10px'
		},
		bgColor: {
			color: '#000',
			width: '150px'
		},
	}));
	const classes = useStyles();
	const { getPageIdListForBannerDestination, constantKindsSites, getSiteNameFromID } = useConstantValue();
	const [buttonText, setButtonText] = useState('');
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [confirmText, setConfirmText] = useState(null);
	const [warningOpen, setWarningOpen] = useState(false);
	const [warningText, setWarningText] = useState(null);

	const [pageID, setPageID] = useState(null);
	const [imageID, setImageID] = useState(null);
	const [description, setDescription] = useState('');
	const [nActive, setActive] = useState(false);
	const [siteID, setSiteID] = useState(0);

	const [imageLinksArray, setImageLinksArray] = useState([]);
	const [editingImageLinkIndex, setEditingImageLinkIndex] = useState(null);
	const [editingImageLink, setEditingImageLink] = useState(null);
	const [addEditState, setAddEditState] = useState('');

	const [nfilterPageID, setFilterPageID] = useState();
	const [nfilterImageID, setFilterImageID] = useState();
	const [nfilterImageURL, setFilterImageURL] = useState('');
	const [nfilterDescription, setFilterDescription] = useState('');
	const [nfilterActive, setFilterActive] = useState(null);

	const [loading, setLoading] = useState(true);
	const [selected] = useState([]);
	const [data, setData] = useState();
	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});
	const [open, setOpen] = React.useState(false);
	const [openFilter, setOpenFilter] = useState(false);
	const [openEditImageLinkModal, setEditImageLinkModal] = useState(false);
	const [imageData, setImageData] = useState();

	const { basicAgencyInfo, getBasicAgencyCode, fetchBasicAgencyInfo } = useBasicAgencyInfo();
	const [nEmalonAgencyCode, setEmalonAgencyCode] = useState('');

	var token = window.localStorage.getItem('jwt_access_token');
	var userRole = (token === null ? '' : jwt(token).role);

	useEffect(() => {
		if (props.pageType === 'emalon') {
			fetchBasicAgencyInfo({ operation: 1 }); // For domestic
		} else {
			getImageData(1, 10);
		}
	}, []);

	useEffect(() => {
		if (props.pageType === 'emalon') {
			setEmalonAgencyCode(getBasicAgencyCode('emalon'));
		}
	}, [basicAgencyInfo]);

	useEffect(() => {
		if (props.pageType === 'emalon' && nEmalonAgencyCode) {
			getImageData(1, 10);
		}
	}, [nEmalonAgencyCode]);

	const onImageDrop = (picture, file) => {
		const item = { ...editingImageLink };
		item.image = picture[picture.length - 1];
		item.type = 'new';
		setEditingImageLink(item);
	};
	const editHandleOpen = (index) => {
		setButtonText('Edit');
		setPageID(imageData[index].pageId);
		setImageID(imageData[index].imageId)
		setDescription(imageData[index].description);
		setImageLinksArray(imageData[index].imageWithHrefList);
		setActive(imageData[index].active);
		setSiteID(imageData[index]?.operation || 0);
		setOpen(true);
	};
	const deleteHandle = async (index) => {
		setPageID(imageData[index].pageId);
		setImageID(imageData[index].imageId)
		setConfirmText("Do you want to drop this Images?");
		setConfirmOpen(true);
	}
	const addHotelImange = () => {
		setButtonText('Add');
		initialValue();
		setOpen(true);
	}
	const openSearchModel = () => {
		setOpenFilter(true);
	};
	const handleClose = () => {
		initialValue();
		setOpen(false);
	};
	const handleFilterClose = () => {
		setOpenFilter(false);
	};
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}
	const handleCloseWarning = () => {
		setWarningOpen(false);
	};
	function searchImageList() {
		setPage(0);
		getImageData(1, rowsPerPage);
		setOpenFilter(false);
	}
	function handleChangeCheckbox() {
		setActive(!nActive);
	}
	async function confirmProcess() {
		setLoading(true);
		const headers = {
			'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
			'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
		}
		if (props.pageType === 'emalon') {
			headers.agency = nEmalonAgencyCode;
		}
		await axios.delete(`${baseURL}api/pageContentsImage/${pageID}/${imageID}`, { headers })
			.then(response => {
				if (response.data.error != null && response.data.error.message != null) {
					setWarningOpen(true);
					setWarningText(response.data.error.message);
				}
				else {
					getImageData(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
				}
				initialValue();
				setLoading(false);
				setOpen(false);
				setConfirmOpen(false);
			}).catch(error => {
				setLoading(false);
				setWarningOpen(true);
				setWarningText(error.response.data);
				initialValue();
				return;
			});
	};
	async function editProcess() {
		setLoading(true);
		var url = ''
		var data = new FormData();
		if (buttonText === 'Edit') {
			url = `api/pageContentsImage/${pageID}/${imageID}`;
		}
		else {
			url = 'api/pageContentsImage';
			data.append('pageId', pageID);
			data.append('imageId', imageID);
		}
		data.append('operation', siteID);
		data.append('description', description);
		data.append('Active', nActive);
		for (let i = 0; i < imageLinksArray.length; i++) {
			if (imageLinksArray[i].type === 'new') {
				data.append(`ImageWithHrefList[${i}].ImageFile`, imageLinksArray[i].image);
			} else {
				data.append(`ImageWithHrefList[${i}].Image`, imageLinksArray[i].image);
			}
			if (imageLinksArray[i].href) data.append(`ImageWithHrefList[${i}].Href`, imageLinksArray[i].href);
			data.append(`ImageWithHrefList[${i}].caption`, imageLinksArray[i].caption || '');

			// Camingo sub image part
			const camingoSubImages = imageLinksArray[i]?.cmgoExt?.subImages;
			if (siteID === 2 && camingoSubImages && camingoSubImages.length) {
				for ( let j = 0; j < camingoSubImages.length; j++) {
					if (typeof(camingoSubImages[j]) === 'string') {
						data.append(`ImageWithHrefList[${i}].CmgoExt.SubImages[${j}]`, camingoSubImages[j]);
					} else {
						data.append(`ImageWithHrefList[${i}].CmgoExt.ImageFiles`, camingoSubImages[j]);
					}
				}
			}
			if (siteID === 2 && imageLinksArray[i]?.cmgoExt?.description) {
				data.append(`ImageWithHrefList[${i}].CmgoExt.Description`, imageLinksArray[i].cmgoExt.description);
			}
			if (siteID === 2 && imageLinksArray[i]?.textColor) {
				data.append(`ImageWithHrefList[${i}].textColor`, imageLinksArray[i].textColor);
			}
			// Camingo sub image part
		}
		const headers = { 'Content-Type': 'multipart/form-data', 'Access-Control-Allow-Origin': '*' }
		if (props.pageType === 'emalon') {
			headers.agency = nEmalonAgencyCode;
		}
		await axios({
			method: 'post',
			url: baseURL + url,
			headers,
			data: data
		}).then(response => {
			setLoading(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				getImageData(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}
			initialValue();
			setOpen(false);
		}).catch(error => {
			setLoading(false);
			setWarningOpen(true);
			setWarningText(error.response.data);
			initialValue();
			return;
		});
		setLoading(false);
	};
	async function getImageData(from, to) {
		const active = nfilterActive === null || nfilterActive === '' ? null : nfilterActive === 'true';
		const url = `${baseURL}api/pageContentsImage/search?from=${from}&to=${to}`;
		const headers = { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
		if (props.pageType === 'emalon') {
			headers.agency = nEmalonAgencyCode;
		}
		await axios({
			method: 'post',
			url: url,
			headers,
			data: {
				// "pageIdToExclude": "OrgProduct",
				pageIdListtoExclude: getPageIdListForBannerDestination(),
				'pageId': nfilterPageID === '' ? null : nfilterPageID,
				'imageId': nfilterImageID === '' ? null : nfilterImageID,
				'imageUrls': nfilterImageURL === '' ? null : nfilterImageURL,
				'description': nfilterDescription === '' ? null : nfilterDescription,
				"active": active,
			}
		}).then(response => {
			const data = response.data;
			setData(data);
			setImageData(data['data'])
		})
		setLoading(false);
	}
	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}
	const handleChangeID = (event) => {
		setPageID(event.target.value);
	}
	const handleChangeCode = (event) => {
		setImageID(event.target.value);
	}
	const handleChangeDescription = (event) => {
		setDescription(event.target.value);
	}
	////////////////////////
	const handleFilterChangeID = (event) => {
		if (event.target.value === '') {
			setFilterPageID(null);
		}
		else {
			setFilterPageID(event.target.value);
		}
	}
	const handleFilterChangeCode = (event) => {
		if (event.target.value === '') {
			setFilterImageID(null);
		}
		else {
			setFilterImageID(event.target.value);
		}
	}
	const handleFilterChangeImage = (event) => {
		setFilterImageURL(event.target.value);
	}
	const handleFilterDescription = (event) => {
		setFilterDescription(event.target.value);
	}
	const onChangeFilterActive = (event) => {
		setFilterActive(event.target.value);
	}

	////////////////
	function handleChangePage(event, value) {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage
		getImageData(from, to);
	}
	function handleChangeRowsPerPage(event) {
		setRowsPerPage(event.target.value);
		setPage(0)
		const temp = Number(event.target.value)
		const from = 1;
		const to = temp
		getImageData(from, to);
	}
	function initialValue() {
		setPageID(null);
		setImageID(null);
		setDescription('');
		setImageLinksArray([]);
	}
	function deleteImageLinkOneItem(index) {
		setImageLinksArray(imageLinksArray.filter((e, n) => n !== index));
	}
	function editImageLinkOneItem(index) {
		setAddEditState('edit');
		const item = imageLinksArray[index];
		item.type = item.type ? item.type : 'exist';
		setEditingImageLinkIndex(index);
		setEditingImageLink(item);
		setEditImageLinkModal(true);
	}
	function onChangeImageOrder(inx) {
		const images = [...imageLinksArray];
		const prevImage = images[inx];
		const nextImage = images[inx + 1];
		images[inx] = nextImage;
		images[inx + 1] = prevImage;
		setImageLinksArray(images);
	}
	function saveEditingImageLinkOneItem() {
		const currentList = [...imageLinksArray];
		currentList[editingImageLinkIndex] = editingImageLink;
		setImageLinksArray(currentList);
		setEditImageLinkModal(false);
	}
	function handleEditImageLinkModalClose() {
		if (addEditState === 'add') {
			const list = [...imageLinksArray];
			setImageLinksArray(list.filter((d, inx) => inx !== list.length - 1));
		}
		setEditingImageLink(null);
		setEditingImageLinkIndex(null);
		setEditImageLinkModal(false);
		setAddEditState('');
	}
	function handleChangeLink(event) {
		const item = { ...editingImageLink };
		item.href = event.target.value;
		setEditingImageLink(item);
	}
	function handleChangeCaption(event) {
		const item = { ...editingImageLink };
		item.caption = event.target.value;
		setEditingImageLink(item);
	}
	function handleChangeTextColor(color) {
		const item = { ...editingImageLink };
		item.textColor = `#${color.hex}`;
		setEditingImageLink(item);
	}
	function handleChangeSubDescription(event) {
		const item = { ...editingImageLink };
		if(!item.cmgoExt) item.cmgoExt = {};
		item.cmgoExt.description = event.target.value;
		setEditingImageLink(item);
	}
	function addNewItem() {
		setAddEditState('add');
		const inx = imageLinksArray.length;
		const newItem = { image: null, href: null, caption: null, type: 'new' };
		const list = [...imageLinksArray];
		list.push(newItem);
		setEditingImageLinkIndex(inx);
		setEditingImageLink(newItem);
		setImageLinksArray(list);
		setEditImageLinkModal(true);
	}

	
	const onSubImageDrop = (picture, file) => {
		const item = { ...editingImageLink };
		if (!item.cmgoExt) item.cmgoExt = {};
		if (!item.cmgoExt?.subImages){
			item.cmgoExt.subImages = [];
		}
		item.cmgoExt.subImages.push(picture[picture.length - 1])
		setEditingImageLink(item);
	};
	function deleteSubImageLinkOneItem(index) {
		const item = { ...editingImageLink };
		const subImages = item.cmgoExt.subImages.filter((e, n) => n !== index);
		item.cmgoExt.subImages = subImages;
		setEditingImageLink(item);
	}
	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className="w-full flex flex-col">
			<Modal
				open={warningOpen}
				onClose={handleCloseWarning}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Warning</h2>
					<p id='server-modal-description'>{warningText}</p>
					<Button className='whitespace-no-wrap normal-case'
						variant='contained'
						color='secondary'
						style={{ marginTop: '10px' }}
						onClick={handleCloseWarning}>Close
					</Button>
				</div>
			</Modal>
			<Modal
				open={confirmOpen}
				onClose={handleCloseConfirm}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Confirm</h2>
					<p id='server-modal-description'>{confirmText}</p>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={confirmProcess}>Confirm
					</Button>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={handleCloseConfirm}>Cancel
					</Button>
				</div>
			</Modal>
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={openFilter}
				onClose={handleFilterClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={openFilter}>
					<div className={classes.paper}>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title' >Filter Setting</h2>
						</div>
						<div style={{ display: 'grid' }}>
							<TextField className={classes.textField} defaultValue={nfilterPageID} onChange={handleFilterChangeID} label="PageID" />
							<TextField className={classes.textField} defaultValue={nfilterImageID} onChange={handleFilterChangeCode} label="ImageID" />
							<TextField className={classes.textField} defaultValue={nfilterImageURL} onChange={handleFilterChangeImage} label="ImageURL" />
							<TextField className={classes.textField} defaultValue={nfilterDescription} onChange={handleFilterDescription} label="Description" />
							<FormControl required className={classes.formControl}>
								<FormHelperText>Active State</FormHelperText>
								<Select
									native
									onChange={onChangeFilterActive}
									value={nfilterActive}
									inputProps={{
										id: 'age-native-required',
									}}
								>
									<option aria-label='None' value=''>All</option>
									<option value='true'>Active</option>
									<option value='false'>Unactive</option>
								</Select>
							</FormControl>
						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' color='secondary' onClick={searchImageList}>
								Filter
							</Button>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleFilterClose}>
								Cancel
							</Button>
						</div>
					</div>

				</Fade>
			</Modal>
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={openEditImageLinkModal}
				onClose={handleEditImageLinkModalClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={openEditImageLinkModal}>
					<div className={classes.paper}>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title'>{addEditState === 'add' ? 'Add New Item' : 'Edit Item'}</h2>
						</div>
						<div style={{ display: 'grid' }}>
							<div style={{ display: '-webkit-inline-box', overflow: 'auto' }}>
								{!editingImageLink?.image ? "" :
									<div style={{ position: 'relative' }}>
										{editingImageLink.type === 'exist' ?
											<img alt='' style={{ cursor: 'pointer', width: '100px', maxHeight: '100px', margin: '10px' }} src={editingImageLink.image} />
											:
											<img alt='' style={{ cursor: 'pointer', width: '100px', maxHeight: '100px', margin: '10px' }} src={URL.createObjectURL(editingImageLink.image)} />
										}
									</div>
								}
							</div>
							<ImageUploader
								className={classes.imageUploader}
								withIcon={false}
								buttonStyles={{ fontSize: '12px' }}
								fileContainerStyle={{ padding: '0px', boxShadow: 'none' }}
								buttonText="Choose Image"
								withLabel={false}
								withPreview={false}
								onChange={onImageDrop}
								imgExtension={[".jpg", ".gif", ".png", ".gif", ".jpeg", ".jfif"]}
								maxFileSize={5242880}
							/>
							{
								siteID === 2 ? 
								<div style={{ display: '-webkit-inline-box', overflow: 'auto' }}>
									{editingImageLink?.cmgoExt?.subImages && editingImageLink?.cmgoExt?.subImages?.length ? editingImageLink.cmgoExt.subImages.map((k, i) =>
										<div style={{ display: 'flex' }} key={i}>
											<div style={{ position: 'relative' }}>
												<button className={classes.deleteImage} onClick={(e) => deleteSubImageLinkOneItem(i)}>X</button>
												{typeof(k) === 'string' ?
													<img alt='' className={classes.thumbnailStyle} src={k}/>
													:
													<img alt='' className={classes.thumbnailStyle} src={URL.createObjectURL(k)}/>
												}
											</div>
										</div>
									) : ''}
								</div> : ''
							}
							{
								siteID === 2 ?
								<ImageUploader
									className={classes.imageUploader}
									withIcon={false}
									buttonStyles={{ fontSize: '12px' }}
									fileContainerStyle={{ padding: '0px', boxShadow: 'none' }}
									buttonText="Choose Sub Image"
									withLabel={false}
									withPreview={false}
									onChange={onSubImageDrop}
									imgExtension={[".jpg", ".gif", ".png", ".gif", ".jpeg", ".jfif"]}
									maxFileSize={5242880}
								/> : ''
							}
							<TextField className={classes.textField} defaultValue={editingImageLink?.href || ''} onChange={handleChangeLink} label="Href" />
							<TextField className={classes.textField} defaultValue={editingImageLink?.caption || ''} onChange={handleChangeCaption} label="Caption" />
							{siteID === 2 ? <TextField className={classes.textField} defaultValue={editingImageLink?.cmgoExt?.description || ''} onChange={handleChangeSubDescription} label="Description" /> : ''}
							{siteID === 2 ? 
							<FormControl required className={classes.formControl}>
								<FormHelperText>Text Color</FormHelperText>
								<ColorPicker
									name="text-color"
									defaultValue={createColor(editingImageLink?.textColor || '#000')}
									value={createColor(editingImageLink?.textColor || '#000')}
									onChange={handleChangeTextColor}
									className={classes.bgColor}
								/>
							</FormControl> : ''}
						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' color='secondary' onClick={saveEditingImageLinkOneItem}>
								{addEditState === 'add' ? 'Add' : 'Update'}
							</Button>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleEditImageLinkModalClose}>
								Cancel
							</Button>
						</div>
					</div>

				</Fade>
			</Modal>
			<Modal
				aria-labelledby="transition-modal-title"
				aria-describedby="transition-modal-description"
				className={classes.modal}
				open={open}
				onClose={handleClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={open}>
					<div className={classes.paper}>
						<h2 id="transition-modal-title" style={{ textAlign: 'center' }}>Content {buttonText}</h2>
						<div style={{ display: 'flow-root', maxWidth: '500px', maxHeight: '500px', overflowY: 'auto', overflowX: 'hidden' }}>
							{buttonText === 'Edit' ?
								userRole === 'superadmin' ?
									<div style={{ textAlign: 'center', display: 'grid', marginBottom: '10px' }}>
										<TextField inputProps={{ readOnly: true }} className={classes.textField} label="Kind of Site" defaultValue={getSiteNameFromID(siteID)} />
									</div> : null
								:
								<div style={{ textAlign: 'center', display: 'grid' }}>
									<TextField onChange={handleChangeID} className={classes.textField} label="PageID" defaultValue={pageID} />
									<TextField onChange={handleChangeCode} className={classes.textField} label="ImageID" defaultValue={imageID} />
									{userRole === 'superadmin' ?
										<FormControl required className={classes.formControl}>
											<FormHelperText>Kind of Site</FormHelperText>
											<Select
												native
												onChange={ev => setSiteID(ev.target.value)}
												value={siteID}
												inputProps={{
													id: 'age-native-required',
												}}
											>
												{constantKindsSites.map((kind, idx) => <option key={idx} value={kind.value}>{kind.label}</option>)}
											</Select>
										</FormControl>
										: null
									}
								</div>
							}
							<div style={{ display: '-webkit-inline-box', overflow: 'auto' }}>
								{imageLinksArray == null ? '' : imageLinksArray.map((k, i) =>
									<div style={{ display: 'flex' }} key={i}>
										<div style={{ position: 'relative' }}>
											<button className={classes.deleteImage} onClick={(e) => deleteImageLinkOneItem(i)}>X</button>
											{k.type === 'new' && k.image ?
												<img alt='' className={classes.thumbnailStyle} src={URL.createObjectURL(k.image)} onClick={(e) => editImageLinkOneItem(i)} />
												:
												<img alt='' className={classes.thumbnailStyle} src={k.image} onClick={(e) => editImageLinkOneItem(i)} />
											}
										</div>
										{
											((imageLinksArray.length - 1) === i) ? '' :
												<IconButton edge="end" aria-label="Replace order" onClick={(e) => onChangeImageOrder(i)}>
													<SyncAltIcon />
												</IconButton>
										}
									</div>
								)}
							</div>
							<div className={classes.button_group}>
								<Button className={classes.buttons} variant="contained" onClick={addNewItem} color="primary">
									Add new Item
								</Button>
							</div>
							<div style={{ textAlign: 'center', display: 'grid' }}>
								<TextField onChange={handleChangeDescription} className={classes.textField} label="Description" defaultValue={description} />
							</div>
							<FormControlLabel
								control={
									<Checkbox
										checked={nActive}
										onChange={handleChangeCheckbox}
										name='checkedC'
										color='primary'
									/>
								}
								label='Active'
								className={classes.checkboxform}
							/>
						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant="contained" onClick={editProcess} color="secondary">
								{buttonText}
							</Button>
							<Button className={classes.buttons} variant="contained" color="primary" onClick={handleClose}>
								Cancel
							</Button>
						</div>
					</div>
				</Fade>
			</Modal>
			<div>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => addHotelImange()}
				>
					<span className='hidden sm:flex'>Add Contents</span>
					<span className='flex sm:hidden'>Add</span>
				</Button>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => openSearchModel()}
				>
					<span className='hidden sm:flex'><SearchIcon />Filter</span>
					<span className='flex sm:hidden'><SearchIcon /></span>
				</Button>
			</div>
			<FuseScrollbars className="flex-grow overflow-x-auto">
				<Table stickyHeader className="min-w-xl" aria-labelledby="tableTitle">
					<ImageBuilderTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={imageData.length}
					/>
					<TableBody>
						{_.orderBy(
							imageData,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className="h-64 cursor-pointer"
									hover
									tabIndex={-1}
									key={i}
								>
									<TableCell className="w-60 md:w-124 z-99" component="th" scope="row">
									</TableCell>
									<TableCell className="w-120 md:w-124 z-99" component="th" scope="row" onClick={() => editHandleOpen(i)}>
										{n.pageId}
									</TableCell>
									<TableCell className="w-120 md:w-124 z-99" component="th" scope="row" onClick={() => editHandleOpen(i)}>
										{n.imageId}
									</TableCell>
									<TableCell className="w-120 md:w-124 z-99" component="th" scope="row" onClick={() => editHandleOpen(i)}>
										{n.description}
									</TableCell>
									<TableCell className="p-4 md:p-16 truncate" component="th" scope="row" align="center" style={{ textAlign: '-webkit-center' }}>
										<Carousel autoPlay={false} transitionTime="2000" showThumbs={false} width="400px">
											{n.imageWithHrefList === null ? "" : n.imageWithHrefList.map((k, j) =>
												<div key={j}>
													<img style={{ width: '400px', maxHeight: '200px', margin: 'auto' }} alt="" src={k.image} />
												</div>
											)}
										</Carousel>
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left' onClick={() => editHandleOpen(i)}>
										{n.imageWithHrefList === null ? null : n.imageWithHrefList.map((k, j) =>
											k.href === null ? '' : <Chip key={j} className={classes.chipStyle} label={k.href.length > 50 ? `${k.href.substr(0, 50)} ...` : k.href} variant='outlined' />
										)}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left' onClick={() => editHandleOpen(i)}>
										{n.imageWithHrefList === null ? null : n.imageWithHrefList.map((k, j) =>
											k.caption === null ? '' : <Chip key={j} className={classes.chipStyle} label={k.caption} variant='outlined' />
										)}
									</TableCell>
									<TableCell>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.active && 'bg-red',
												n.active && 'bg-green',

											)}
										/>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => editHandleOpen(i)} tabIndex="0" type="button" title="Edit">
											<span className="MuiIconButton-label"><span className="material-icons MuiIcon-root" aria-hidden="true">edit</span></span><span className="MuiTouchRipple-root"></span></button>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => deleteHandle(i)} tabIndex="0" type="button" title="Edit">
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className="flex-shrink-0 border-t-1"
				component="div"
				count={data.total}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}

export default withRouter(ImageBuilderTable);
