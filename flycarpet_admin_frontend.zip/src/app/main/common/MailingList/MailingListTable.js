import FuseScrollbars from '@fuse/core/FuseScrollbars';
import _ from '@lodash';
import axios from 'axios';
// import {Parser} from 'htmlparser2';
import {
	Checkbox, Table, TableBody, TableCell, TablePagination, TableRow, Modal, Backdrop, Fade, TextField, Grid,
	Button, FormControl, FormHelperText, FormControlLabel, Select, Chip, List, ListItem, ListItemText, ListSubheader,
	Avatar, IconButton, ListItemAvatar
} from '@material-ui/core';
import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import FuseLoading from '@fuse/core/FuseLoading';
import AgencyTableHead from './MailingListTableHead';
import { makeStyles } from '@material-ui/core/styles';
import SearchIcon from '@material-ui/icons/Search';
import DeleteIcon from '@material-ui/icons/Delete';
import GroupIcon from '@material-ui/icons/Group';
import PhoneIcon from '@material-ui/icons/Phone';
import MailIcon from '@material-ui/icons/Mail';
import AddCircleOutline from '@material-ui/icons/AddCircleOutline';
import ContactPhoneIcon from '@material-ui/icons/ContactPhone';
import ContactMailIcon from '@material-ui/icons/ContactMail';
import { useDomesticDeal } from 'app/main/store/hooks';

import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicExtended from "ckeditor5-build-classic-extended";
import { baseURL } from '../../utils';

import './editor.css'
import { parse } from 'date-fns';

const operations = ['Pack', 'Domestic', 'Camingo'];

function MailingListTable(props) {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			// margin: theme.spacing(1),
			minWidth: 120,
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			minWidth: 200,
			maxHeight: "100vh",
			overflowY: "auto",
		},
		button_group: {
			textAlign: 'center',
			padding: 30,
		},
		buttons: {
			marginRight: '10px'
		},
		checkboxform: {
			marginLeft: '-10px'
		},
		textfield: {
			width: '100%'
		},
		deleteImage: {
			position: 'absolute',
			top: '1px',
			right: '7px',
			color: '#fff',
			background: '#ff4081',
			borderRadius: '50%',
			textAign: 'center',
			cursor: 'pointer',
			fontSize: '17px',
			fontWeight: 'bold',
			lineHeight: '20px',
			width: '20px',
			height: '20px'
		},
		chipStyle: {
			height: '20px',
			margin: '1px',
			color: 'white',
			fontSize: '12px',
			background: '#32606b'
		},
		ellipsisDiv: {
			maxWidth: '160px',
			maxHeight: '50px',
			overflow: 'hidden',
			textOverflow: 'ellipsis',
			whiteSpace: 'nowrap',
		},
		ellipsisSpan: {
			display: 'block',
			overflow: 'hidden',
			textOverflow: 'ellipsis',
			whiteSpace: 'nowrap',
		}
	}));

	const {
		fetchDomesticAgencyDealCodes,
		rsAgencyCodes,
	} = useDomesticDeal();

	const classes = useStyles();

	const [mailingList, setMailingList] = useState([]);
	const [messagingCaseList, setMessagingCaseList] = useState(null);
	const [orgUserList, setOrgUserList] = useState([]);
	/**
	 * The agencies list for filter search
	 */
	const [existAgencies, setExistAgencies] = useState([]);
	/**
	 * The all agencies list to show in the table
	 */
	const [allAgencies, setAllAgencies] = useState([]);
	/**
	 * The agencies list for each operations
	 */
	const [agenciesByOperation, setAgenciesByOperation] = useState(null);

	const [msgCase, setMsgCase] = useState(null);
	const [currentID, setCurrentID] = useState(null);
	const [agencyCode, setAgencyCode] = useState(null);
	const [nOperation, setOperation] = useState(null);
	const [description, setDescription] = useState(null);
	const [tag1, setTag1] = useState(null);
	const [tag2, setTag2] = useState(null);

	const [nPhone, setPhone] = useState([]);
	const [addingPhone, setAddingPhone] = useState('');
	const [emailsList, setEmailsList] = useState([]);
	const [addingEmail, setAddingEmail] = useState('');
	const [userList, setUserList] = useState([]);
	const [addingUser, setAddingUser] = useState('');

	const [nFilterShowOperationSpecific, setFilterShowOperationSpecific] = useState(false);
	const [nFilterAgencyCode, setFilterAgencyCode] = useState(null);
	const [nFilterOperation, setFilterOperation] = useState(null);

	const [nFilterDescription, setFilterDescription] = useState(null);
	const [nFilterTag1, setFilterTag1] = useState(null);
	const [nFilterTag2, setFilterTag2] = useState(null);
	const [nFilterEmail, setFilterEmail] = useState(null);
	const [nFilterPhone, setFilterPhone] = useState(null);
	const [nFilterUsername, setFilterUsername] = useState(null);
	const [nFilterMessagingCase, setFilterMessagingCase] = useState(null);

	const [nButtonText, setButtonText] = useState(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [confirmText, setConfirmText] = useState(null);
	const [warningOpen, setWarningOpen] = useState(false);
	const [warningText, setWarningText] = useState(null);

	const [loading, setLoading] = useState(true);
	const [selected] = useState([]);
	const [data, setData] = useState([]);
	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});
	const [open, setOpen] = React.useState(false);
	const [openFilter, setOpenFilter] = useState(false);

	useEffect(() => {
		getAgencyTemplate(0, true);
		getAllAgencies();
		getUserList();
		getMailingListData(1, 10);
	}, []);

	useEffect(() => {
		setAgenciesByOperation(rsAgencyCodes);
	}, [rsAgencyCodes]);

	async function getMailingListData(from, to) {
		await axios({
			method: 'post',
			url: `${baseURL}api/mailingList/search?from=${from}&to=${to}`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"showOperationSpecific": nFilterShowOperationSpecific,
				"agencyCode": nFilterAgencyCode,
				"operation": nFilterOperation === null ? null : +nFilterOperation,
				"description": nFilterDescription === '' ? null : nFilterDescription,
				"tag1": nFilterTag1 === '' ? null : nFilterTag1,
				"tag2": nFilterTag2 === '' ? null : nFilterTag2,
				"mail": nFilterEmail === '' ? null : nFilterEmail,
				"username": nFilterUsername === '' ? null : nFilterUsername,
				"phone": nFilterPhone === '' ? null : nFilterPhone,
				"messagingCase": nFilterMessagingCase,
			}
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				const data = response.data;
				setData(data);
				setMailingList(data['data'])
			}
		}).catch(error => {
			setLoading(false);
			setWarningOpen(true);
			setWarningText(error.response.data.title);
		});
		setLoading(false);
	}
	async function getUserList() {
		await axios({
			method: 'get',
			url: `${baseURL}api/user/?from=1&to=100`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				const data = response.data;
				setOrgUserList(data['data'])
			}
		}).catch(error => {
			console.log(error);
		});
	}
	async function getMsgTemplate(ops) {
		const opsParam = (ops === null) ? '?ops=' : `?ops=${ops}`
		await axios({
			method: 'get',
			url: `${baseURL}api/mailingList/msgCasesTemplate${opsParam}`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				const data = response.data;
				setMessagingCaseList(data);
			}
		}).catch(error => {
			setLoading(false);
			setWarningOpen(true);
			setWarningText(error.response.data.title);
		});
	}
	async function getMsgTemplateAll() {
		await axios({
			method: 'get',
			url: `${baseURL}api/mailingList/msgCasesTemplate/all`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				const data = response.data;
				setMessagingCaseList(data);
			}
		}).catch(error => {
			setLoading(false);
			setWarningOpen(true);
			setWarningText(error.response.data.title);
		});
	}
	async function getAllAgencies() {
		await axios({
			method: 'get',
			url: `${baseURL}api/agency/?from=1&to=1000`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				const data = response.data;
				setAllAgencies(data['data']);
			}
		}).catch(error => {
			setLoading(false);
			setWarningOpen(true);
			setWarningText(error.response.data.title);
		});
	}
	async function getExistAgencies(ops) {
		await axios({
			method: 'get',
			url: `${baseURL}api/mailingList/agencyCodes?ops=${ops}`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				const data = response.data;
				setExistAgencies(data);
			}
		}).catch(error => {
			setLoading(false);
			setWarningOpen(true);
			setWarningText(error.response.data.title);
		});
	}

	const getAgencyTemplate = (ops, isFirst) => {
		if (!isFirst && ops !== null) {
			fetchDomesticAgencyDealCodes({ operation: ops, type: 'mailing' });
		} else {
			setAgenciesByOperation(null);
		}
		if (isFirst) {
			getMsgTemplate(null);
		} else {
			getMsgTemplate(ops);
		}
		if (ops !== null) getExistAgencies(ops);
	}


	const addMailingItem = () => {
		setButtonText('Add');
		initialValue();
		setOpen(true);
	};
	const handleOpen = (index) => {
		const ops = mailingList[index]['operation']
		setButtonText('Edit');
		setCurrentID(mailingList[index]['id']);
		setMsgCase(mailingList[index]['messagingCase']);

		setOperation(ops);
		getAgencyTemplate(ops);

		setAgencyCode(mailingList[index]['agencyCode']);
		setDescription(mailingList[index]['description']);
		setTag1(mailingList[index]['tag1']);
		setTag2(mailingList[index]['tag2']);
		setPhone(mailingList[index]['isrPhones']);
		setEmailsList(mailingList[index]['emails']);
		let users = [];
		if (mailingList[index]['userPreferences']) {
			mailingList[index]['userPreferences'].map(user => {
				users.push({
					"username": user.username,
					"sendMail": user.sendMail,
					"sendPhoneMsg": user.sendPhoneMsg
				})
			})
		}
		setUserList(users);

		setOpen(true);
	};
	const deleteHandle = async (index) => {
		setCurrentID(mailingList[index]['id'])
		setConfirmText("Do you want to drop the item of this mailing list?");
		setConfirmOpen(true);
	}

	const openSearchModel = () => {
		setOpenFilter(true);
	};
	const handleClose = () => {
		initialValue();
		setOpen(false);
	};
	const handleFilterClose = () => {
		setOpenFilter(false);
	};
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}
	const handleCloseWarning = () => {
		setWarningOpen(false);
	};

	const searchMailingList = () => {
		setPage(0);
		getMailingListData(1, rowsPerPage);
		setOpenFilter(false);
	}
	const editProcess = async () => {
		setLoading(true);
		var post_url;
		if (nButtonText === 'Edit') {
			post_url = `${baseURL}api/mailingList/${currentID}`;
		}
		else {
			post_url = `${baseURL}api/mailingList`;
		}
		const data = {
			"messagingCase": msgCase,
			"operation": nOperation === null ? null : +nOperation,
			"agencyCode": agencyCode,
			"description": description,
			"tag1": tag1,
			"tag2": tag2,
			"isrPhones": nPhone,
			"emails": emailsList,
			"userPreferences": userList
		};
		await axios({
			method: 'post',
			url: post_url,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: data
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				getMailingListData(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}
			initialValue();
			setLoading(false);
			setOpen(false);
		}).catch(error => {
			setLoading(false);
			setWarningOpen(true);
			setWarningText(error.response.data.title);
		});
	};
	const confirmProcess = async () => {
		setLoading(true);
		await axios.delete(`${baseURL}api/mailingList/${currentID}`, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		}).then(response => {
			if (response.data.error !== null && response.data.error.message !== null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			} else {
				getMailingListData(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}
			initialValue();
			setLoading(false);
			setOpen(false);
			setConfirmOpen(false);
		}).catch(error => {
			setLoading(false);
			setConfirmOpen(false);
			setWarningOpen(true);
			setWarningText(error.response.data);
		});

	};

	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}

	function onChangeTag1(event) {
		setTag1(event.target.value)
	}
	function onChangeTag2(event) {
		setTag2(event.target.value)
	}
	function onClickAddPhone() {
		const phone = [...nPhone];
		phone.push(+addingPhone);
		setPhone(phone);
		setAddingPhone('');
	}
	const onClickDeletePhone = (inx) => {
		const phone = [...nPhone];
		phone.splice(inx, 1);
		setPhone(phone);
	}
	function onClickAddEmail() {
		const email = [...emailsList];
		email.push(addingEmail);
		setEmailsList(email);
		setAddingEmail('');
	}
	const onClickDeleteEmail = (inx) => {
		const email = [...emailsList];
		email.splice(inx, 1);
		setEmailsList(email);
	}
	function onClickAddUser(event) {
		if (addingUser === '') return;
		const users = userList ? [...userList] : [];
		users.push({
			"username": addingUser,
			"sendMail": true,
			"sendPhoneMsg": true
		});

		setUserList(users);
		setAddingUser('');
	}
	const onChangeUserPhone = (inx) => {
		const users = userList ? [...userList] : [];
		users[inx].sendPhoneMsg = !users[inx].sendPhoneMsg;
		setUserList(users);
	}
	const onChangeUserMail = (inx) => {
		const users = userList ? [...userList] : [];
		users[inx].sendMail = !users[inx].sendMail;
		setUserList(users);
	}
	const onClickDeleteUser = (inx) => {
		const users = [...userList];
		users.splice(inx, 1);
		setUserList(users);
	}
	function onChangeShowSpecific(event) {
		setFilterShowOperationSpecific(event.target.checked);

		// if(!event.target.checked){
		// 	getMsgTemplateAll();
		// }
		// const ops = event.target.value || null;
		// setOperation(ops);
		// getAgencyTemplate(ops);
		// setAgencyCode(null);
	}
	function onChangeOperation(event) {
		const ops = event.target.value || null;
		setOperation(ops);
		getAgencyTemplate(ops);
		setAgencyCode(null);
	}
	function onChangeMsgCase(event) {
		setMsgCase(event.target.value);
	}
	function onChangeAgency(event) {
		setAgencyCode(event.target.value);
	}
	/////////////////////////////////////////////////
	function onChangeFilterDescription(event) {
		setFilterDescription(event.target.value)
	}
	function onChangeFilterTag1(event) {
		setFilterTag1(event.target.value)
	}
	function onChangeFilterTag2(event) {
		setFilterTag2(event.target.value)
	}
	function onChangeFilterUsername(event) {
		setFilterUsername(event.target.value)
	}
	function onChangeFilterPhone(event) {
		setFilterPhone(event.target.value)
	}
	function onChangeFilterEmail(event) {
		setFilterEmail(event.target.value)
	}
	function onChangeFilterAgency(event) {
		setFilterAgencyCode(event.target.value)
	}
	function onChangeFilterOperation(event) {
		const ops = event.target.value || null;
		setFilterOperation(ops);
		getAgencyTemplate(ops);
		setFilterAgencyCode(null);
	}
	function onChangeMessagingCase(event) {
		setFilterMessagingCase(event.target.value || null)
	}

	//////////////////////////////////////////////
	function handleChangePage(event, value) {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage
		getMailingListData(from, to);
	}
	function handleChangeRowsPerPage(event) {
		setRowsPerPage(event.target.value);
		setPage(0)
		const temp = Number(event.target.value)
		const from = 1;
		const to = temp
		getMailingListData(from, to);
	}

	function initialValue() {
		setCurrentID(null);
		setMsgCase(null);
		setOperation(null);
		setAgencyCode(null);
		setDescription(null);
		setTag1(null);
		setTag2(null);
		setPhone([]);
		setEmailsList([]);
		setUserList([]);
	}
	const showEllipsisDOM = (pHtmlString) => {
		return pHtmlString;
		// return `<span style="display: block;
		// 	white-space: nowrap;
		// 	overflow: hidden;
		// 	text-overflow: ellipsis;">
		// 	${pHtmlString}
		// </span>`;
	}

	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className="w-full flex flex-col">
			<Modal
				open={warningOpen}
				onClose={handleCloseWarning}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Warning</h2>
					<p id='server-modal-description'>{warningText}</p>
					<Button className='whitespace-no-wrap normal-case'
						variant='contained'
						color='secondary'
						style={{ marginTop: '10px' }}
						onClick={handleCloseWarning}>Close
					</Button>
				</div>
			</Modal>
			<Modal
				open={confirmOpen}
				onClose={handleCloseConfirm}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Confirm</h2>
					<p id='server-modal-description'>{confirmText}</p>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={confirmProcess}>Confirm
					</Button>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={handleCloseConfirm}>Cancel
					</Button>
				</div>
			</Modal>
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={openFilter}
				onClose={handleFilterClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={openFilter}>
					<div className={classes.paper}>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title' >Filter Setting</h2>
						</div>
						<div style={{ display: 'grid' }}>
							<FormControl required className={classes.formControl}>
								<FormControlLabel
									control={
										<Checkbox
											checked={nFilterShowOperationSpecific}
											onChange={onChangeShowSpecific}
											name="checkedC"
											color="primary"
										/>
									}
									label="Show Operation Specific"
									className={clsx('mt-10', classes.checkboxform)}
								/>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Operation</FormHelperText>
								<Select
									native
									onChange={onChangeFilterOperation}
									value={nFilterOperation === null ? '' : nFilterOperation}
									name='Code'
									inputProps={{
										id: 'operation-native-required',
									}}
									disabled={!nFilterShowOperationSpecific}
								>
									<option value=''></option>
									{operations.map((n, i) =>
										<option key={i} value={i}>{n}</option>
									)}
								</Select>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Agency</FormHelperText>
								<Select
									native
									onChange={onChangeFilterAgency}
									value={nFilterAgencyCode || ''}
									name='Code'
									inputProps={{
										id: 'agency-native-required',
									}}
									disabled={!nFilterShowOperationSpecific}
								>
									<option value=''></option>
									{existAgencies == null ? '' : existAgencies.map((n, i) =>
										<option key={i} value={n}>{agenciesByOperation?.find((a) => a.code === n)?.name || ''}</option>
									)}
								</Select>
							</FormControl>
							<br/>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Messaging Case</FormHelperText>
								<Select
									native
									onChange={onChangeMessagingCase}
									value={nFilterMessagingCase || ''}
									name='fiilerMessagingCase'
									inputProps={{
										id: 'filter-messageing-case',
									}}
								>
									<option value=''></option>
									{messagingCaseList === null ? '' : messagingCaseList.map((n, i) =>
										<option key={i} value={n.messagingCase}>{n.messagingCase}</option>
									)}
								</Select>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Description</FormHelperText>
								<TextField defaultValue={nFilterDescription} className={classes.textfield} onChange={onChangeFilterDescription} />
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Tag1</FormHelperText>
								<TextField defaultValue={nFilterTag1} className={classes.textfield} onChange={onChangeFilterTag1} />
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Tag2</FormHelperText>
								<TextField defaultValue={nFilterTag2} className={classes.textfield} onChange={onChangeFilterTag2} />
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Username</FormHelperText>
								<TextField defaultValue={nFilterUsername} className={classes.textfield} onChange={onChangeFilterUsername} />
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>PhoneNumber</FormHelperText>
								<TextField defaultValue={nFilterPhone} type="Number" className={classes.textfield} onChange={onChangeFilterPhone} />
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Email</FormHelperText>
								<TextField defaultValue={nFilterEmail} className={classes.textfield} onChange={onChangeFilterEmail} />
							</FormControl>

						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' color='secondary' onClick={searchMailingList}>
								Filter
							</Button>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleFilterClose}>
								Cancel
							</Button>

						</div>
					</div>

				</Fade>
			</Modal>
			<Modal
				aria-labelledby="transition-modal-title"
				aria-describedby="transition-modal-description"
				className={classes.modal}
				open={open}
				onClose={handleClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={open}>
					<div className={classes.paper}>
						<h2 id="transition-modal-title" style={{ textAlign: 'center' }}>{nButtonText} Mailing List</h2>
						<div style={{ textAlign: 'center', display: 'grid' }}>

							<Grid container justify='space-between' style={{ margin: '10px 5px' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Operation</FormHelperText>
									<Select
										native
										onChange={onChangeOperation}
										value={nOperation === null ? '' : nOperation}
										name='Operation'
										inputProps={{
											id: 'operation-native-required',
										}}
									>
										<option value=''></option>
										{operations.map((n, i) =>
											<option key={i} value={i}>{n}</option>
										)}
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Messaging Case</FormHelperText>
									<Select
										native
										onChange={onChangeMsgCase}
										value={msgCase || ''}
										name='messageCase'
										inputProps={{
											id: 'msgCase-native-required',
										}}
									>
										<option value=''></option>
										{messagingCaseList === null ? '' : messagingCaseList.map((n, i) =>
											<option key={i} value={n.messagingCase}>{n.messagingCase}</option>
										)}
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Agency</FormHelperText>
									<Select
										native
										onChange={onChangeAgency}
										value={agencyCode || ''}
										name='AgencyCode'
										inputProps={{
											id: 'agency-native-required',
										}}
									>
										<option value=''></option>
										{agenciesByOperation == null ? '' : agenciesByOperation.map((n, i) =>
											<option key={i} value={n.code}>{n.name}</option>
										)}
									</Select>
								</FormControl>
							</Grid>

							<FormControl required className={classes.formControl}>
								<FormHelperText>Description</FormHelperText>
								<div className='static-text-modal'>
									<CKEditor
										editor={ClassicExtended}
										data={description || ''}
										config={
											{
												mediaEmbed: {
													previewsInData: true
												},
											}
										}
										onChange={(event, editor) => {
											const data = editor.getData();
											setDescription(data);
										}}
									/>
								</div>
							</FormControl>

							<Grid container justify='space-between' style={{ margin: '10px 5px' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Tag1</FormHelperText>
									<TextField defaultValue={tag1} className={classes.textfield} onChange={onChangeTag1} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Tag2</FormHelperText>
									<TextField defaultValue={tag2} className={classes.textfield} onChange={onChangeTag2} />
								</FormControl>
							</Grid>

							<Grid container justify='space-between' style={{ margin: '10px 5px' }}>
								<FormControl required className={classes.formControl} style={{ width: '25%' }}>
									<FormHelperText>PhoneNumber</FormHelperText>
									<div className="flex justify-center max-w-full">
										<TextField className={classes.textfield} value={addingPhone} type="Number" onChange={e => { setAddingPhone(e.target.value) }} />
										<IconButton edge="end" aria-label="Add phone" onClick={onClickAddPhone}>
											<AddCircleOutline />
										</IconButton>
									</div>
									<List>
										<ListSubheader component="div">Phones</ListSubheader>
										{
											nPhone.map((phone, i) => (
												<ListItem key={i}>
													<ListItemAvatar>
														<Avatar>
															<ContactPhoneIcon />
														</Avatar>
													</ListItemAvatar>
													<ListItemText
														primary={phone}
													/>
													<IconButton edge="end" aria-label="delete" onClick={(e) => onClickDeletePhone(i)}>
														<DeleteIcon />
													</IconButton>
												</ListItem>
											))}
									</List>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Email</FormHelperText>
									<div className="flex justify-center max-w-full">
										<TextField className={classes.textfield} value={addingEmail} onChange={e => { setAddingEmail(e.target.value) }} />
										<IconButton edge="end" aria-label="Add email" onClick={onClickAddEmail}>
											<AddCircleOutline />
										</IconButton>
									</div>
									<List>
										<ListSubheader component="div">Emails</ListSubheader>
										{
											emailsList.map((email, i) => (
												<ListItem key={i}>
													<ListItemAvatar>
														<Avatar>
															<ContactMailIcon />
														</Avatar>
													</ListItemAvatar>
													<ListItemText
														primary={email}
													/>
													<IconButton edge="end" aria-label="delete" onClick={(e) => onClickDeleteEmail(i)}>
														<DeleteIcon />
													</IconButton>
												</ListItem>
											))}
									</List>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '25%' }}>
									<FormHelperText>User Preferernces</FormHelperText>
									<div className="flex justify-center max-w-full">
										<Select
											native
											onChange={e => { setAddingUser(e.target.value) }}
											value={addingUser || ''}
											name='UserPreferernces'
											inputProps={{
												id: 'user-native-required',
											}}
										>
											<option value=''></option>
											{orgUserList == null ? '' : orgUserList.map((n, i) =>
												<option key={i} value={n.userName}>{n.userName}</option>
											)}
										</Select>
										<IconButton edge="end" aria-label="Add user" onClick={onClickAddUser}>
											<AddCircleOutline />
										</IconButton>
									</div>
									<List>
										<ListSubheader component="div">User Preferernces</ListSubheader>
										{
											userList?.map((user, i) => (
												<ListItem key={i}>
													<ListItemAvatar>
														<Avatar>
															<GroupIcon />
														</Avatar>
													</ListItemAvatar>
													<ListItemText
														primary={user.username}
													/>
													<IconButton edge="end" aria-label="change user phone" color={user.sendPhoneMsg ? `primary` : `default`} onClick={(e) => onChangeUserPhone(i)}>
														<ContactPhoneIcon />
													</IconButton>
													<IconButton edge="end" aria-label="Change user mail" color={user.sendMail ? `primary` : `default`} onClick={(e) => onChangeUserMail(i)}>
														<ContactMailIcon />
													</IconButton>
													<IconButton edge="end" aria-label="delete" onClick={(e) => onClickDeleteUser(i)}>
														<DeleteIcon />
													</IconButton>
												</ListItem>
											))}
									</List>
								</FormControl>
							</Grid>

						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant="contained" onClick={editProcess} color="secondary">
								{nButtonText}
							</Button>
							<Button className={classes.buttons} variant="contained" color="primary" onClick={handleClose}>
								Cancel
							</Button>

						</div>
					</div>
				</Fade>
			</Modal>
			<div>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => addMailingItem()}
				>
					<span className='hidden sm:flex'>Add Mailing</span>
					<span className='flex sm:hidden'>Add</span>
				</Button>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => openSearchModel()}
				>
					<span className='hidden sm:flex'><SearchIcon />Filter</span>
					<span className='flex sm:hidden'><SearchIcon /></span>
				</Button>
			</div>
			<FuseScrollbars className="flex-grow overflow-x-auto">
				<Table stickyHeader className="min-w-xl" aria-labelledby="tableTitle">
					<AgencyTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={mailingList.length}
					/>
					<TableBody>
						{_.orderBy(
							mailingList,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className="h-64 cursor-pointer"
									hover
									tabIndex={-1}
									key={i}
									title={n.messagingCaseDescription}
								>
									<TableCell padding="none" className="w-20 md:w-20 text-center z-99">
									</TableCell>
									<TableCell className="p-4 md:p-16 min-w-256" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.messagingCase}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{operations[n.operation]}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{allAgencies?.find((agency) => agency.code === n.agencyCode)?.odyAgentCode || ''}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										<div className='ellipsisDiv' dangerouslySetInnerHTML={{ __html: showEllipsisDOM(n.description) }} />
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="right" onClick={() => handleOpen(i)}>
										{n.tag1}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="right" onClick={() => handleOpen(i)}>
										{n.tag2}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.isrPhones === null ? null : n.isrPhones.map((phone, index) =>
											phone ? <Chip key={index} className={classes.chipStyle} label={phone} variant='outlined' /> : ''
										)}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.emails === null ? null : n.emails.map((email, index) =>
											email ? <Chip key={index} className={classes.chipStyle} label={email} variant='outlined' /> : ''
										)}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.userPreferences === null ? null : n.userPreferences.map((user, index) =>
											user ? <Chip key={index} className={classes.chipStyle}
												label={user.username}
												avatar={
													<div>
														{ user.sendPhoneMsg ? <PhoneIcon style={{ color: 'white', width: '14px', height: '14px' }} /> : <></> }
														{ user.sendMail ? <MailIcon style={{ color: 'white', width: '14px', height: '14px' }} /> : <></> }
													</div>
												}
												variant='outlined' /> : ''
										)}
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => handleOpen(i)} tabIndex="0" type="button" title="Edit"><span className="MuiIconButton-label"><span className="material-icons MuiIcon-root" aria-hidden="true">edit</span></span><span className="MuiTouchRipple-root"></span></button>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => deleteHandle(i)} tabIndex="0" type="button" title="Edit">
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className="flex-shrink-0 border-t-1"
				component="div"
				count={data.total}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}

export default withRouter(MailingListTable);
