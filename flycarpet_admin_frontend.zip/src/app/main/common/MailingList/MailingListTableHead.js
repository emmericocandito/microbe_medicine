import { makeStyles } from '@material-ui/core/styles';
import { TableCell, TableHead, TableRow, TableSortLabel, Tooltip } from '@material-ui/core';
import React from 'react';

const rows = [
  {
    id: 'messagingCase',
    align: 'left',
    disablePadding: false,
    label: 'Messaging Case',
    sort: true,
  },
  {
    id: 'operation',
    align: 'left',
    disablePadding: false,
    label: 'Operation',
    sort: true
  },
  {
    id: 'agencyCode',
    align: 'left',
    disablePadding: false,
    label: 'Agency Code',
    sort: true
  },
  {
    id: 'description',
    align: 'left',
    disablePadding: false,
    label: 'description',
    sort: true
  },
  {
    id: 'tag1',
    align: 'left',
    disablePadding: false,
    label: 'Tag1',
    sort: true
  },
  {
    id: 'tag2',
    align: 'left',
    disablePadding: false,
    label: 'Tag2',
    sort: true
  },
  {
    id: 'isrPhones',
    align: 'left',
    disablePadding: false,
    label: 'Phone Number',
    sort: true
  },
  {
    id: 'emails',
    align: 'left',
    disablePadding: false,
    label: 'Emails',
    sort: true
  },
  {
    id: 'usernames',
    align: 'left',
    disablePadding: false,
    label: 'User Preferernces',
    sort: true
  },
  {
    id: 'action',
    align: 'center',
    disablePadding: false,
    label: 'Edit',
    sort: true
  },
  {
    id: 'action',
    align: 'center',
    disablePadding: false,
    label: 'Delete',
    sort: true
  },
];

function MailingListTableHead(props) {

  const createSortHandler = property => event => {
    props.onRequestSort(event, property);
  };

  return (
    <TableHead>
      <TableRow className="h-64">
        <TableCell padding="none" className="w-20 md:w-20 text-center z-99">
        </TableCell>
        {rows.map((row, i) => {
          return (
            <TableCell
              className="p-4 md:p-16 w-224"
              key={i}
              align={row.align}
              padding={row.disablePadding ? 'none' : 'default'}
              sortDirection={props.order.id === row.id ? props.order.direction : false}
            >
              {row.sort && (
                <Tooltip
                  title="Sort"
                  placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                  enterDelay={300}
                >
                  <TableSortLabel
                    active={props.order.id === row.id}
                    direction={props.order.direction}
                    onClick={createSortHandler(row.id)}
                  >
                    {row.label}
                  </TableSortLabel>
                </Tooltip>
              )}
            </TableCell>
          );
        }, this)}
      </TableRow>
    </TableHead>
  );
}

export default MailingListTableHead;
