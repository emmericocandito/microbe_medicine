import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../store';
import MailingListHeader from './MailingListHeader';
import MailingListTable from './MailingListTable';
// import jwt from 'jwt-decode'
// var userRole = jwt(window.localStorage.getItem('jwt_access_token')).role;

function MailingList() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<MailingListHeader />}
			content={<MailingListTable />}
			innerScroll
		/>
	);
}

export default withReducer('BasicData', reducer)(MailingList);
