import React, { memo } from 'react';
import MultiSelection from './MultiSelection';

const MultiDestinations = props => {
  const {
    loading,
    title,
    checkedItems,
    sourceList,
    extraData,

    onMessage
  } = props;


  const checked = extraData?.checked ?? '';
  const getNameFromItem = pItem => {
    if(!pItem) return '';
    return extraData?.showCode ? pItem.code : pItem.name;
  }
  const getNameFromCode = pCode => {
    if (sourceList === null) return;
    const item = sourceList.find(el => el.code === pCode);
    return getNameFromItem(item) || pCode;
  }
  const getValue = pItem => {
    return pItem.code;
  }

  const moreProps = { ...props, extraData: { checked, getNameFromItem, getNameFromCode, getValue } };

  return (
    <MultiSelection {...moreProps} />
  );
};

export default memo(MultiDestinations);
