import React, { memo } from 'react';
import MultiSelection from './MultiSelection'

const MultiCategories = props => {
  const {
    loading,
    title,
    checkedItems,
    sourceList,
    extraData,

    onMessage
  } = props;

  const checked = extraData?.checked ?? 'empty';
  const getNameFromItem = pItem => {
    return pItem?.name_Loc?.content ?? pItem?.name;
  }
  const getNameFromCode = pCode => {
    if (sourceList === null) return;
    const item = sourceList.find(el => el.code === pCode);
    return getNameFromItem(item);
  }
  const getValue = pItem => {
    return pItem.code;
  }

  const moreProps = { ...props, extraData: { checked, getNameFromCode, getNameFromItem, getValue } }

  return (
    <MultiSelection
      {...moreProps}
    />
  );
};

export default memo(MultiCategories);
