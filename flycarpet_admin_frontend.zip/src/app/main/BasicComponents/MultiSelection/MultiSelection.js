import React, { useEffect, useState, memo, useCallback } from 'react';
import {
  CircularProgress,
  FormGroup,
  FormControlLabel,
  FormControl,
  FormHelperText,
  MenuItem,
  Select,
  Input,
  ListItemText,
  Checkbox,
  Typography
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';

const MultiSelection = props => {
  const {
    id,
    loading,
    title,
    checkedItems,
    sourceList,
    extraData: { checked, showBtSelect, getNameFromCode, getNameFromItem, getValue },

    onMessage
  } = props;

  const ITEM_HEIGHT = 48;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 15 + ITEM_PADDING_TOP,
      }
    }
  };
  const useStyles = makeStyles(theme => ({
    formControl: {
      margin: theme.spacing(1),
      minWidth: '12%',
      borderRadius: '5px'
    }
  }));
  const classes = useStyles();

  const handleChangeSelection = useCallback(event => {
    onMessage('changedCheckedItems', {
      id,
      items: event.target.value
    });
  }, []);
  const checkAllItems = () => {
    if (sourceList) {
      onMessage('changedCheckedItems', {
        id,
        items: sourceList.map((item, idx) => getValue(item))
      });
    }
  };
  const isCheckedAllItems = () => {
    return sourceList && sourceList.length > 0 ? checkedItems.length === sourceList.length : false;
  };
  const handleCheckAll = event => {
    checkAllItems();
  };
  const isReleasedAllItems = () => {
    return sourceList && sourceList.length > 0 ? checkedItems.length === 0 : false;
  };
  const handleReleaseAll = event => {
    if (sourceList) {
      onMessage('changedCheckedItems', {
        id,
        items: []
      });
    }
  };

  useEffect(() => {
    if (checked === 'empty') handleReleaseAll();
    if (checked === 'all') checkAllItems();
  }, []);

  return (
    <FormControl required className={classes.formControl}>
      <FormHelperText>{title}</FormHelperText>
      {loading ? (
        <CircularProgress className="w-xs max-w-full ml-60 mr-60" color="secondary" />
      ) : (
        <div>
          <Select
            labelId="demo-mutiple-chip-label"
            id="demo-mutiple-chip"
            multiple
            value={checkedItems}
            style={{ maxWidth: '200px', width: '200px' }}
            onChange={handleChangeSelection}
            input={<Input />}
            renderValue={selected =>
              // <div className={classes.chips}>
              // 	{selected.map((key, i) => (
              // 		<Chip key={i} label={getHotelName(key, chooseCode)} className={classes.chip} />
              // 	))}
              // </div>
              selected.map((key, i) => getNameFromCode(key)).join(', ')
            }
            MenuProps={MenuProps}
          >
            {sourceList === null
              ? ''
              : sourceList.map((n, i) => (
                <MenuItem key={i} value={getValue(n)} name={getValue(n)}>
                  <Checkbox checked={checkedItems?.indexOf(getValue(n)) > -1} />
                  <ListItemText
                    primary={getNameFromItem(n)}
                  />
                </MenuItem>
              ))}
          </Select>
          {showBtSelect !== undefined && !showBtSelect ?
            '' :
            (
              <FormGroup className="flex-row" style={{maxWidth: '200px', width: '200px', margin: 'auto'}}>
                <FormControlLabel
                  control={<Checkbox size="small" onChange={handleCheckAll} checked={isCheckedAllItems()} />}
                  label={<Typography style={{ fontSize: '10px' }}>Check All</Typography>}
                />
                <FormControlLabel
                  control={
                    <Checkbox size="small" onChange={handleReleaseAll} checked={isReleasedAllItems()} />
                  }
                  label={<Typography style={{ fontSize: '10px' }}>Release All</Typography>}
                />
              </FormGroup>
            )
          }
        </div>
      )}
    </FormControl>
  );
};

export default memo(MultiSelection);
