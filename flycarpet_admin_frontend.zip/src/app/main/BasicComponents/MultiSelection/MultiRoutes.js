import React, { memo } from 'react';
import MultiSelection from './MultiSelection';

// {
//   code: 'home',
//   name: 'home',
// }

const MultiRoutes = props => {
  const {
    id,
    loading,
    title,
    checkedItems,
    sourceList,
    extraData,

    onMessage
  } = props;


  const checked = extraData?.checked ?? '';
  const getNameFromItem = pItem => {
    return pItem?.name ?? '';
  }
  const getNameFromCode = pCode => {
    if (sourceList === null) return;
    const item = sourceList.find(el => el.code === pCode);
    return getNameFromItem(item) || pCode;
  }
  const getValue = pItem => {
    return pItem.code;
  }

  const moreProps = { ...props, extraData: { checked, getNameFromItem, getNameFromCode, getValue, showBtSelect: false } };

  return (
    <MultiSelection {...moreProps} />
  );
};

export default memo(MultiRoutes);
