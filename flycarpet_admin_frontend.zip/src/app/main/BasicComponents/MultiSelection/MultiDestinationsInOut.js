import React, { memo } from 'react';
import MultiSelection from './MultiSelection';

const MultiDestinationsInOut = props => {
  const {
    loading,
    title,
    checkedItems,
    sourceList,
    extraData,

    onMessage
  } = props;


  const newSourceList = [];
  sourceList.forEach(item => {
    newSourceList.push({...item, outbound: true, id: item.code + "_out"});
    newSourceList.push({...item, outbound: false, id: item.code + "_in"});
  });

  const checked = extraData?.checked ?? '';
  const getNameFromItem = pItem => {
    if(!pItem) return '';

    if(pItem.outbound) {
      return `${pItem.code} / TLV`;
    } else {
      return `TLV / ${pItem.code}`;
    }
  }
  const getNameFromCode = pCode => {
    if (newSourceList === null) return;
    const item = newSourceList.find(el => el.id === pCode);
    return getNameFromItem(item) || pCode;
  }
  const getValue = pItem => {
    return pItem.id;
  }

  const moreProps = { ...props, sourceList: newSourceList, extraData: { checked, getNameFromItem, getNameFromCode, getValue } };

  return (
    <MultiSelection {...moreProps} />
  );
};

export default memo(MultiDestinationsInOut);
