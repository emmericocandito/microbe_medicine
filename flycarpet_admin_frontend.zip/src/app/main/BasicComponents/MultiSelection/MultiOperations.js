import React, { memo } from 'react';
import MultiSelection from './MultiSelection';

// { label: 'Package Stie', value: 0, code: 'package', ellipsis: 'Pack' },

const MultiRoutes = props => {
  const {
    loading,
    title,
    checkedItems,
    sourceList,
    extraData,

    onMessage
  } = props;

  const checked = extraData?.checked ?? '';
  const getNameFromItem = pItem => {
    return pItem?.label ?? '';
  }
  const getNameFromCode = pCode => {
    if (sourceList === null) return;
    const item = sourceList.find(el => el.code === pCode);
    if(!item) return pCode;
    return getValue(item);
  }
  const getValue = pItem => {
    return pItem.code;
  }

  const moreProps = { ...props, extraData: { checked, getNameFromItem, getNameFromCode, getValue, showBtSelect: false } };

  return (
    <MultiSelection {...moreProps} />
  );
};

export default memo(MultiRoutes);
