import React, { useEffect, useState, memo, useMemo } from 'react'
import {
  modal, Backdrop, Button,
  FormControl, FormControlLabel, TextField,
  Checkbox,
  Modal, Grid,
  CircularProgress,
  Table, TableHead, TableBody, TableRow, TableCell,
} from '@material-ui/core'
import FusePageCarded from '@fuse/core/FusePageCarded';
import FuseScrollbars from '@fuse/core/FuseScrollbars';
import FuseAnimate from '@fuse/core/FuseAnimate';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import { Autocomplete } from '@material-ui/lab';
import clsx from 'clsx'
import dayjs from 'dayjs'

import { MultiActionModal } from 'app/main/BasicComponents/customModal';

import { useHotelAvailRoom } from 'app/main/store/hooks'
import intervalToDuration from 'date-fns/esm/fp/intervalToDuration/index.js';
import { getHotelNameStore } from 'app/main/store/slices/VacationPackage/packages/packagesSlice';

const SelectionModal = props => {
  const duration = 60, from = dayjs(), to = from.add(duration - 1, 'day');
  const { open, extraData, onMessage: sendMessage } = props;
  const { checked, checkedItems, getNameFromCode, getNameFromItem, getValue, chooseDestCode, sourceList } = extraData;

  const [grouping, setGrouping] = useState(false);
  const [formatHotels, setFormatHotels] = useState([]);
  const [showHotels, setShowHotels] = useState([]);

  const useStyles = makeStyles((theme) => ({
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: '3px',
      textAlign: "center",
      overflowY: "auto",
      maxHeight: "90vh",
      maxWidth: '90%',
    },
    formControl: {
      margin: '2px 5px',
      minWidth: 60,
    },
    modal: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    empty: {
      color: '#d5d5d5',
      textAlign: 'center',
    },
    height75: {
      maxHeight: '75vh',
    },
    room: {
      textAlign: 'center',
      marginTop: '5px',
    },
    roomStatus: {
      fontSize: '10px',
    }
  }))
  const classes = useStyles()

  const propsColumns = [
    {
      id: 'idx',
      align: 'left',
      disablePadding: false,
      label: 'Index',
      sort: false,
      type: 'text'
    },
    {
      id: 'id',
      align: 'left',
      disablePadding: false,
      label: 'code',
      sort: true,
      type: 'text',
      show: 'hide'
    },
  ]

  const [pickedHotel, setPickedHotel] = useState(null);
  const [optionsHotels, setOptionsHotels] = useState({
    options: [],
    getOptionLabel: (option) => getHotelName(option),
  });
  const getHotelName = (pHotel) => {
    return pHotel?.[1]?.name ?? pHotel?.[0] ?? 'N/A';
  }
  useEffect(() => {
    setOptionsHotels({
      options: formatHotels,
      getOptionLabel: (option) => getHotelName(option),
    })
  }, [formatHotels])
  useEffect(() => {
    if (pickedHotel) {
      setShowHotels([pickedHotel]);
    } else {
      setShowHotels(formatHotels);
    }
  }, [pickedHotel])



  const [titleActionModal, setTitleActionModal] = useState('WARNING !');
  const [wordActionModal, setWordActionModal] = useState('');
  const [openActionModal, setOpenActionModal] = useState(false);
  const [actionsModal, setActionsModal] = useState([
    { label: 'Close', code: 'close' }
  ])
  const showActionModal = (pOption) => {
    setTitleActionModal(pOption.title);
    setWordActionModal(pOption.word);
    setActionsModal(pOption.actions);
    setOpenActionModal(true);
  };
  const onMessageActionModal = (pType, pMsg) => {
    if (pType === 'selectAction') {
      switch (pMsg.code) {
        case 'close':
          break;
        default:
          console.log(`missed the handle of ${pType}`);
      }
      setOpenActionModal(false);
    } else if (pType === 'closeModal') {
      setOpenActionModal(false);
    }
  }

  const closeModal = () => {
    sendMessage({
      type: 'action',
      action: 'close',
    });
  }

  const { loading, allItems, fetchAvailRoom } = useHotelAvailRoom();
  useEffect(async () => {
    if (sourceList?.length > 0 && !loading) {
      setGrouping(true);
      const option = {
        hotelIds: sourceList.map(hotel => hotel.hotelId),
        destCode: chooseDestCode,
      };
      const response = await fetchAvailRoom(option);
      if (response?.payload?.status !== 'success') {
        const options = {
          ...response.payload.data,
          actions: [
            { label: 'Close', code: 'close' }
          ]
        }
        showActionModal(options);
      }
    }
  }, [sourceList]);

  const makeDateList = () => {
    const list = [];
    for (let i = 0; i < duration; i++) {
      list.push(from.add(i, 'day').format('YYYY-MM-DD'))
    }
    return list;
  }
  const dateList = useMemo(() => makeDateList(), []);

  const isSelected = (pId) => {
    return checkedItems.includes(Number(pId));
  }
  const checkedHotel = (pId) => {
    sendMessage({
      type: 'action',
      action: 'pick',
      id: Number(pId),
    })
  }
  const makeRowsBody = () => {
    return showHotels.map((data, idx) => {
      if (data == null) return null;
      const hotelId = data[0], availRoom = data[1].availRoom;
      return (
        <TableRow
          className="h-64 cursor-pointer"
          hover
          tabIndex={-1}
          key={hotelId}
        >
          <TableCell className="p-4 md:p-16" component="th" scope="row">
            <Checkbox
              inputProps={{ 'aria-label': 'controlled' }}
              checked={isSelected(hotelId)}
              onChange={() => checkedHotel(hotelId)}
            />
          </TableCell>
          <TableCell className="p-4 md:p-16 truncate" component="th" scope="row" onClick={() => checkedHotel(hotelId)}>
            {data[1].name}
          </TableCell>
          <TableCell className="p-4 md:p-16 truncate" component="th" scope="row" onClick={() => checkedHotel(hotelId)}>
            {data[1].free}
          </TableCell>
          {dateList.map((date, keyCol) => {
            const rooms = availRoom[date];
            let detailRoomDom = null;
            if (rooms === undefined) {
              detailRoomDom = (
                <TableCell key={keyCol} className={clsx('p-4', 'md:p-16', 'truncate', classes.empty)} component="th" scope="row" onClick={() => checkedHotel(hotelId)}>
                  N/A
                </TableCell>
              )
            } else {
              detailRoomDom = (
                <TableCell key={keyCol} className="p-4 md:p-16 truncate" component="th" scope="row" onClick={() => checkedHotel(hotelId)}>
                  {rooms.map((room, keyRoom) => {
                    return (
                      <div key={keyRoom} className={classes.room}>
                        <p>{room.label}</p>
                        <p className={classes.roomStatus}>{room.status}</p>
                      </div>
                    )
                  })}
                </TableCell>
              );
            }
            return detailRoomDom;
          })}
        </TableRow>
      )
    })

  }
  const makeRowData = (pRoom) => {
    if (!pRoom) return null;
    return {
      name: getNameFromCode(Number(pRoom.La_ID)),
      free: pRoom.Free,
      availRoom: {
        [pRoom.La_date]: [{
          label: `${pRoom.Free} - ${pRoom.La_class}`,
          status: pRoom.La_status,
        }],
      }
    }
  }
  useEffect(() => {
    if (!open || loading) return;
    let hotelGroup = {};
    if (sourceList) {
      hotelGroup = sourceList.reduce((group, hotel) => {
        group[hotel.hotelId] = {
          name: getNameFromCode(Number(hotel.hotelId)),
          free: 0,
          availRoom: {}
        }
        return group;
      }, hotelGroup);
    }
    hotelGroup = allItems[chooseDestCode]?.reduce((group, room) => {
      const formatRoom = makeRowData(room);
      if (group[room.La_ID] !== undefined) {
        const currGroup = group[room.La_ID];
        if (currGroup['availRoom'][room.La_date] !== undefined) {
          group[room.La_ID]['availRoom'][room.La_date].push(formatRoom['availRoom'][room.La_date][0]);
        } else {
          group[room.La_ID]['availRoom'][room.La_date] = formatRoom['availRoom'][room.La_date];
        }
        const duration = to.diff(dayjs(room.La_date, 'YYYY-MM-DD'), 'hour');
        if (duration > 0) group[room.La_ID]['free'] += formatRoom.free;
      } else {
        group[room.La_ID] = formatRoom;
      }
      return group;
    }, hotelGroup);
    if (hotelGroup !== undefined) {
      const sortHotelGroup = Object.entries(hotelGroup)
        .sort(([, v1], [, v2]) => {
          if (v1.name > v2.name) return 1;
          if (v1.name < v2.name) return -1;
          return 0;
        })
      // .reduce((group, [k, v]) => ({
      //   ...group,
      //   [k]: v,
      // }), {})
      setFormatHotels(sortHotelGroup);
      setShowHotels(sortHotelGroup);
      console.log(sortHotelGroup);
    }
    setGrouping(false);
  }, [open, loading])

  const initialState = () => {
    setGrouping(false);
    setFormatHotels([]);
    setShowHotels([]);
  }
  const initialize = () => {
    initialState();
  }
  useEffect(() => {
    initialize();
  }, [])

  return (
    <>
      <Modal
        open={open}
        onClose={closeModal}
        className={classes.modal}
        closeAfterTransition
        aria-labelledby='transition-modal-title'
        aria-describedby='transition-modal-description'
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >

        {loading || grouping ? <CircularProgress className='w-xs max-w-full' color='secondary' /> :
          <div className={clsx('flex', 'flex-1', 'items-center', 'justify-between', classes.paper)}>
            <div>
              <Grid container className='m-32'>
                <Typography className="hidden sm:flex mx-0 sm:mx-12 m-20" variant="h6">
                  {`Available Hotel Rooms under ${chooseDestCode} Destination`}
                </Typography>
                <FormControl className="ml-160 w-320">
                  <Autocomplete
                    {...optionsHotels}
                    id='pageId'
                    selectOnFocus
                    renderInput={(params) => (
                      <TextField {...params} label='Kind of Product page' variant='standard' />
                    )}
                    value={pickedHotel}
                    onChange={(event, newValue) => {
                      setPickedHotel(newValue);
                    }}
                    getOptionSelected={(option, value) => getHotelName(option) === getHotelName(value)}
                  />
                </FormControl>
              </Grid>
              <FuseScrollbars className={clsx('flex-grow', 'overflow-x-auto', classes.height75)}>
                <Table stickyHeader className="min-w-xl" aria-labelledby="tableTitle">
                  <TableHead>
                    <TableRow className="h-64">
                      <TableCell></TableCell>
                      <TableCell>Hotel Name</TableCell>
                      <TableCell>Free Rooms</TableCell>
                      {dateList.map((date, idx) => (
                        <TableCell key={idx}>{date}</TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {makeRowsBody()}
                  </TableBody>
                </Table>
              </FuseScrollbars>
            </div>
          </div>
        }
      </Modal>
      <MultiActionModal
        open={openActionModal}
        title={titleActionModal}
        description={wordActionModal}
        actionList={actionsModal}
        onMessage={onMessageActionModal}
      />
    </>
  )
}

export default memo(SelectionModal);