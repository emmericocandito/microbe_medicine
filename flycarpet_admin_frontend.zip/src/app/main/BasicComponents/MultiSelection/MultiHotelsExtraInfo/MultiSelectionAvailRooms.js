import React, { useEffect, useState, memo, useCallback } from 'react';
import {
  CircularProgress,
  FormGroup,
  FormControlLabel,
  FormControl,
  FormHelperText,
  MenuItem,
  Select,
  Input,
  ListItemText,
  Checkbox,
  Typography,
  Paper, InputBase, IconButton
} from '@material-ui/core';
import DirectionsIcon from '@material-ui/icons/Directions'
import { makeStyles } from '@material-ui/core/styles';
import _ from '@lodash'

import SelectionModal from './SelectionModal'

const MultiSelectionAvailRooms = props => {
  const {
    loading,
    title,
    sourceList,
    extraData,

    onMessage: sendMessage
  } = props;
  const { checked, checkedItems, getNameFromCode, getNameFromItem, getValue, chooseDestCode } = extraData;

  const useStyles = makeStyles(theme => ({
    formControl: {
      margin: '5px',
      minWidth: '12%',
      borderRadius: '5px'
    }
  }));
  const classes = useStyles();

  const [openSelectionModal, setOpenSelectionModal] = useState(false);
  const onMessageSelectionModal = pMsg => {
    if (pMsg.type === 'action') {
      switch (pMsg.action) {
        case 'pick':
          handleChangeSelection(pMsg.id);
          break;
        case 'pickMulti':
          handleChangeSelection(pMsg.extraData?.selectedRowIds ?? [], true);
          break;
        case 'close':
          setOpenSelectionModal(false);
          break;
        default:
          setOpenSelectionModal(false);
          console.log(`missed the ${pMsg.type} handle when selecting multiple hotels`)
      }
    }
  }
  const handleChangeSelection = (pId, pMulti = false) => {
    let newSelection = [];
    if (!pMulti) {
      newSelection = [...checkedItems];
      const idx = checkedItems.indexOf(pId);
      if (idx > -1) {
        newSelection.splice(idx, 1);
      } else {
        newSelection.push(pId);
      }
    } else {
      newSelection = pId;
    }
    sendMessage('changedCheckedItems', {
      items: newSelection
    });
  };
  const checkAllItems = () => {
    if (sourceList) {
      sendMessage('changedCheckedItems', {
        items: sourceList.map((item, idx) => getValue(item))
      });
    }
  };
  const isCheckedAllItems = () => {
    return sourceList && sourceList.length > 0 ? checkedItems.length === sourceList.length : false;
  };
  const handleCheckAll = event => {
    checkAllItems();
  };
  const isReleasedAllItems = () => {
    return sourceList && sourceList.length > 0 ? checkedItems.length === 0 : false;
  };
  const handleReleaseAll = event => {
    if (sourceList) {
      sendMessage('changedCheckedItems', {
        items: []
      });
    }
  };
  const getChoosedHotels = () => {
    return checkedItems.map(code => getNameFromCode(code)).join(', ')
  }
  const isEmpty = () => {
    return !sourceList || sourceList.length === 0
  }

  const handleShowModal = event => {
    setOpenSelectionModal(true);
  }

  useEffect(() => {
    handleReleaseAll();
    if (checked === 'all') checkAllItems();
  }, [sourceList])

  const initialState = () => {
    setOpenSelectionModal(false);
  }
  const initialize = async () => {
    initialState();
  }
  useEffect(async () => {
    initialize();
  }, [])

  return (
    <>
      <FormControl required className={classes.formControl}>
        <FormHelperText>{title}</FormHelperText>
        {(loading) ? (
          <CircularProgress className="w-xs max-w-full ml-60 mr-60" color="secondary" />
        ) : (
          <div>
            <Paper
              component="form"
              sx={{ display: 'flex', alignItems: 'center', width: 400 }}
            >
              <InputBase
                sx={{ ml: 1, flex: 1 }}
                placeholder=""
                inputProps={{ 'aria-label': 'selected Hotels', 'readOnly': 'readOnly' }}
                value={getChoosedHotels()}
              />
              <IconButton color="primary" aria-label="directions" style={{ padding: 0 }} onClick={handleShowModal} disabled={isEmpty()}>
                <DirectionsIcon />
              </IconButton>
            </Paper>
            <FormGroup className="flex-row">
              <FormControlLabel
                control={<Checkbox size="small" onChange={handleCheckAll} checked={isCheckedAllItems()} />}
                label={<Typography style={{ fontSize: '10px' }}>Check All</Typography>}
              />
              <FormControlLabel
                control={
                  <Checkbox size="small" onChange={handleReleaseAll} checked={isReleasedAllItems()} />
                }
                label={<Typography style={{ fontSize: '10px' }}>Release All</Typography>}
              />
            </FormGroup>
          </div>
        )}
      </FormControl>
      <SelectionModal
        open={openSelectionModal}
        extraData={{ ...extraData, sourceList }}
        onMessage={onMessageSelectionModal}
      />
    </>
  );
};

export default memo(MultiSelectionAvailRooms);
