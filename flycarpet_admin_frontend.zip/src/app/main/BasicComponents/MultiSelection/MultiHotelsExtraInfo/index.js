import React, { memo } from 'react';
import MultiSelectionAvailRooms from './MultiSelectionAvailRooms';
import MultiSelection from '../MultiSelection';
const defaultExtraInfo = {
  checked: 'empty',
  chooseDestCode: '',
  typeInfo: 'defaultSelection',
}

const MultiHotelsExtraInfo = props => {
  const {
    loading,
    title,
    checkedItems,
    sourceList,
    extraData,

    onMessage
  } = props;

  const { checked, chooseDestCode, typeInfo } = { ...defaultExtraInfo, ...extraData };

  const getNameFromItem = pItem => {
    let name = '';
    if (pItem) {
      name = pItem?.nameTranslationHeb === null || pItem?.nameTranslationHeb === ''
      ? pItem.nameTranslationEng
      : pItem.nameTranslationHeb;
    }
    return name;
  }
  const getNameFromCode = pCode => {
    if (sourceList === null || sourceList.length === 0) return;
    const item = sourceList.find(el => el.hotelId === pCode);
    return getNameFromItem(item);
  }
  const getValue = pItem => {
    return pItem.hotelId;
  }

  const moreProps = { ...props, extraData: { checked, checkedItems, chooseDestCode, getNameFromItem, getNameFromCode, getValue } };

  return (
    <>
      {typeInfo === 'availRoom' && <MultiSelectionAvailRooms {...moreProps} />}
      {typeInfo === 'defaultSelection' && <MultiSelection {...moreProps} />}
    </>
  );
}

export default memo(MultiHotelsExtraInfo);