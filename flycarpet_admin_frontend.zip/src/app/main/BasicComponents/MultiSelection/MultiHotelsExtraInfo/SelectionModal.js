import React, { useEffect, useState, memo, useMemo } from 'react'
import {
  Backdrop,
  Modal, Grid,
  CircularProgress,
} from '@material-ui/core'
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';

import clsx from 'clsx'
import dayjs from 'dayjs'

import { MultiActionModal } from 'app/main/BasicComponents/customModal';
import StickyTable from 'app/main/BasicComponents/StickyTable';

import { useHotelAvailRoom } from 'app/main/store/hooks';

const IndeterminateCheckbox = React.forwardRef(
  ({ indeterminate, ...rest }, ref) => {
    const defaultRef = React.useRef()
    const resolvedRef = ref || defaultRef

    React.useEffect(() => {
      resolvedRef.current.indeterminate = indeterminate
    }, [resolvedRef, indeterminate])

    return (
      <>
        <input type="checkbox" ref={resolvedRef} {...rest} />
      </>
    )
  }
)

function DefaultColumnFilter({
  column: { filterValue, preFilteredRows, setFilter },
}) {
  const count = preFilteredRows.length

  return (
    <input
      value={filterValue || ''}
      onChange={e => {
        setFilter(e.target.value || undefined) // Set undefined to remove the filter entirely
      }}
      placeholder={`Search ${count} records...`}
    />
  )
}

// This is a custom filter UI for selecting
// a unique option from a list
function SelectColumnFilter({
  column: { filterValue, setFilter, preFilteredRows, id },
}) {
  // Calculate the options for filtering
  // using the preFilteredRows
  const options = React.useMemo(() => {
    const options = new Set()
    preFilteredRows.forEach(row => {
      options.add(row.values[id])
    })
    return [...options.values()]
  }, [id, preFilteredRows])

  // Render a multi-select box
  return (
    <select
      value={filterValue}
      onChange={e => {
        setFilter(e.target.value || undefined)
      }}
    >
      <option value="">All</option>
      {options.map((option, i) => (
        <option key={i} value={option}>
          {option}
        </option>
      ))}
    </select>
  )
}

// This is a custom filter UI that uses a
// slider to set the filter value between a column's
// min and max values
function SliderColumnFilter({
  column: { filterValue, setFilter, preFilteredRows, id },
}) {
  // Calculate the min and max
  // using the preFilteredRows

  const [min, max] = React.useMemo(() => {
    let min = preFilteredRows.length ? preFilteredRows[0].values[id] : 0
    let max = preFilteredRows.length ? preFilteredRows[0].values[id] : 0
    preFilteredRows.forEach(row => {
      min = Math.min(row.values[id], min)
      max = Math.max(row.values[id], max)
    })
    return [min, max]
  }, [id, preFilteredRows])

  return (
    <>
      <input
        type="range"
        min={min}
        max={max}
        value={filterValue || min}
        onChange={e => {
          setFilter(parseInt(e.target.value, 10))
        }}
      />
      <button onClick={() => setFilter(undefined)}>Off</button>
    </>
  )
}

// This is a custom UI for our 'between' or number range
// filter. It uses two number boxes and filters rows to
// ones that have values between the two
function NumberRangeColumnFilter({
  column: { filterValue = [], preFilteredRows, setFilter, id },
}) {
  const [min, max] = React.useMemo(() => {
    let min = preFilteredRows.length ? preFilteredRows[0].values[id] : 0
    let max = preFilteredRows.length ? preFilteredRows[0].values[id] : 0
    preFilteredRows.forEach(row => {
      min = Math.min(row.values[id], min)
      max = Math.max(row.values[id], max)
    })
    return [min, max]
  }, [id, preFilteredRows])

  return (
    <div
      style={{
        display: 'flex',
      }}
    >
      <input
        value={filterValue[0] || ''}
        type="number"
        onChange={e => {
          const val = e.target.value
          setFilter((old = []) => [val ? parseInt(val, 10) : undefined, old[1]])
        }}
        placeholder={`Min (${min})`}
        style={{
          width: '70px',
          marginRight: '0.5rem',
        }}
      />
      to
      <input
        value={filterValue[1] || ''}
        type="number"
        onChange={e => {
          const val = e.target.value
          setFilter((old = []) => [old[0], val ? parseInt(val, 10) : undefined])
        }}
        placeholder={`Max (${max})`}
        style={{
          width: '70px',
          marginLeft: '0.5rem',
        }}
      />
    </div>
  )
}

const SelectionModal = props => {
  const duration = 60, from = dayjs(), to = from.add(duration - 1, 'day');
  const { open, extraData, onMessage: sendMessage } = props;
  const { checked, checkedItems, getNameFromCode, getNameFromItem, getValue, chooseDestCode, sourceList } = extraData;
  const [grouping, setGrouping] = useState(false);
  const [formatHotels, setFormatHotels] = useState([]);

  const useStyles = makeStyles((theme) => ({
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: '3px',
      textAlign: "center",
      overflowY: "auto",
      maxHeight: "90vh",
      maxWidth: '90%',
    },
    formControl: {
      margin: '2px 5px',
      minWidth: 60,
    },
    modal: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    empty: {
      color: '#d5d5d5',
      textAlign: 'center',
    },
    height65: {
      maxHeight: '65vh',
    },
    room: {
      textAlign: 'center',
      marginTop: '5px',
    },
    roomStatus: {
      fontSize: '10px',
    }
  }))
  const classes = useStyles();

  const [titleActionModal, setTitleActionModal] = useState('WARNING !');
  const [wordActionModal, setWordActionModal] = useState('');
  const [openActionModal, setOpenActionModal] = useState(false);
  const [actionsModal, setActionsModal] = useState([
    { label: 'Close', code: 'close' }
  ])
  const showActionModal = (pOption) => {
    setTitleActionModal(pOption.title);
    setWordActionModal(pOption.word);
    setActionsModal(pOption.actions);
    setOpenActionModal(true);
  };
  const onMessageActionModal = (pType, pMsg) => {
    if (pType === 'selectAction') {
      switch (pMsg.code) {
        case 'close':
          break;
        default:
          console.log(`missed the handle of ${pType}`);
      }
      setOpenActionModal(false);
    } else if (pType === 'closeModal') {
      setOpenActionModal(false);
    }
  }

  const closeModal = () => {
    sendMessage({
      type: 'action',
      action: 'close',
    });
  }

  const { loading, allItems, fetchAvailRoom } = useHotelAvailRoom();
  useEffect(async () => {
    if (sourceList?.length > 0 && !loading) {
      setGrouping(true);
      const option = {
        hotelIds: sourceList.map(hotel => hotel.hotelId),
        destCode: chooseDestCode,
      };
      const response = await fetchAvailRoom(option);
      if (response?.payload?.status !== 'success') {
        const options = {
          ...response.payload.data,
          actions: [
            { label: 'Close', code: 'close' }
          ]
        }
        showActionModal(options);
      }
    }
  }, [sourceList]);

  const getCellRoomByDate = (pDate) => {
    return ({ row }) => {
      const rooms = row.original[pDate];
      let detailRoomDom = null;
      if (rooms.length === 0) {
        detailRoomDom = (
          <div className={clsx('p-4', 'md:p-16', 'truncate')} component="th" scope="row" style={{
            color: '#d5d5d5',
            textAlign: 'center',
          }}>
            N/A
          </div>
        )
      } else {
        detailRoomDom = (
          <div className="p-4 md:p-16 truncate" component="th" scope="row" >
            {rooms.map((room, keyRoom) => {
              return (
                <div key={keyRoom} style={{
                  textAlign: 'center',
                  marginTop: '5px',
                }}>
                  <p>{room.label}</p>
                  <p style={{ fontSize: '10px' }}>{room.status}</p>
                </div>
              )
            })}
          </div>
        );
      }
      return detailRoomDom;
    }
  }
  const makeDateList = () => {
    const list = [];
    for (let i = 0; i < duration; i++) {
      list.push(from.add(i, 'day').format('YYYY-MM-DD'))
    }
    return list;
  }
  const dateList = useMemo(() => makeDateList(), []);
  const propsColumns = useMemo(() => {
    const columns = [
      {
        Header: "Hotel",
        Footer: "Hotel",
        sticky: "left",
        columns: [
          {
            id: 'selection',
            Header: ({ getToggleAllRowsSelectedProps }) => (
              <div>
                <IndeterminateCheckbox {...getToggleAllRowsSelectedProps()} />
              </div>
            ),
            Footer: " ",
            Cell: ({ row }) => {
              return (
                <div>
                  <IndeterminateCheckbox {...row.getToggleRowSelectedProps()} />
                </div>
              )
            },
            width: 50,
          },
          {
            Header: "Name",
            Footer: "Name",
            accessor: "name",
            filter: 'fuzzyText',
            Filter: DefaultColumnFilter,
            width: 250,
          }
        ]
      },
    ];

    const dayInfo = {
      Header: 'Detail Informations',
      Footer: 'Detail Informations',
      columns: dateList.map(date => {
        return {
          Header: date,
          Footer: date,
          width: 100,
          Cell: getCellRoomByDate(date)
        }
      }),
    };

    const sumInfo = {
      Header: 'All',
      Footer: 'All',
      sticky: "right",
      columns: [
        {
          Header: 'Avail Room',
          Footer: 'Avail Room',
          // accessor: 'availRoom',
          Cell: ({ row }) => (row.original.availRoom),
          width: 80,
        }
      ],
    }
    columns.push(dayInfo, sumInfo);
    return columns;
  }, []);

  const onMesageFromTable = (pMsg) => {
    switch (pMsg.action) {
      case 'pickMulti':
        sendMessage({
          type: 'action',
          action: 'pickMulti',
          extraData: pMsg.extraData,
        });
        break;
      case 'pick':
        sendMessage({
          type: 'action',
          action: 'pick',
          id: Number(pMsg.id),
        });
        break;
      default:
        console.log(`please define the handler for ${pMsg.action}`);
    }
  }

  const isSelected = (pId) => {
    return checkedItems.includes(Number(pId));
  }

  const makeRowData = (pRoom) => {
    if (!pRoom) return null;
    let { La_ID, Free: free, La_status: status, La_class, La_date: date } = pRoom;
    if (free < 0) {
      free = 0;
      status = 'N/A';
    }
    return {
      name: getNameFromCode(Number(La_ID)),
      free,
      availRoom: {
        [date]: [{
          label: `${free} - ${La_class}`,
          status,
        }],
      }
    }
  }
  useEffect(() => {
    if (!open || loading) return;
    let hotelGroup = {};
    if (sourceList) {
      hotelGroup = sourceList.reduce((group, hotel) => {
        group[hotel.hotelId] = {
          name: getNameFromCode(Number(hotel.hotelId)),
          free: 0,
          availRoom: {}
        }
        return group;
      }, hotelGroup);
    }
    hotelGroup = allItems[chooseDestCode]?.reduce((group, room) => {
      const formatRoom = makeRowData(room);
      if (group[room.La_ID] !== undefined) {
        const currGroup = group[room.La_ID];
        if (currGroup['availRoom'][room.La_date] !== undefined) {
          group[room.La_ID]['availRoom'][room.La_date].push(formatRoom['availRoom'][room.La_date][0]);
        } else {
          group[room.La_ID]['availRoom'][room.La_date] = formatRoom['availRoom'][room.La_date];
        }
        const duration = to.diff(dayjs(room.La_date, 'YYYY-MM-DD'), 'hour');
        if (duration > 0) group[room.La_ID]['free'] += formatRoom.free;
      } else {
        group[room.La_ID] = formatRoom;
      }
      return group;
    }, hotelGroup);
    if (hotelGroup !== undefined) {
      const sortHotelGroup = Object.entries(hotelGroup)
        .sort(([, v1], [, v2]) => {
          if (v1.name > v2.name) return 1;
          if (v1.name < v2.name) return -1;
          return 0;
        })
      // .reduce((group, [k, v]) => ({
      //   ...group,
      //   [k]: v,
      // }), {})
      setFormatHotels(sortHotelGroup.map(hotel => {
        const { name, free, availRoom } = hotel[1];
        const hotelData = {
          id: hotel[0],
          pick: isSelected(hotel[0]),
          name: name,
          availRoom: hotel[1].free,
        }
        dateList.forEach(date => {
          hotelData[date] = availRoom?.[date] ?? [];
        })
        return hotelData;
      }));
    }
    setGrouping(false);
  }, [open, loading])

  const initialState = () => {
    setGrouping(false);
    setFormatHotels([]);
  }
  const initialize = () => {
    initialState();
  }
  useEffect(() => {
    initialize();
  }, [])

  return (
    <>
      <Modal
        open={open}
        onClose={closeModal}
        className={classes.modal}
        closeAfterTransition
        aria-labelledby='transition-modal-title'
        aria-describedby='transition-modal-description'
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >

        {loading || grouping ? <CircularProgress className='w-xs max-w-full' color='secondary' /> :
          <div className={clsx('flex', 'flex-1', 'items-center', 'justify-between', classes.paper)}>
            {/* <div> */}
            <Grid container className='w-100'>
              <Grid container item className='m-20 w-100'>
                <Typography className="hidden sm:flex m-auto" variant="h6">
                  {`Available Hotel Rooms under ${chooseDestCode} Destination`}
                </Typography>
              </Grid>
              <Grid container item className='w-100'>
                <StickyTable
                  columns={propsColumns}
                  data={formatHotels}
                  extraData={{ showHeader: true, showFooter: false }}
                  onMessage={onMesageFromTable}
                />
              </Grid>
            </Grid>
          </div>
        }
      </Modal>
      <MultiActionModal
        open={openActionModal}
        title={titleActionModal}
        description={wordActionModal}
        actionList={actionsModal}
        onMessage={onMessageActionModal}
      />
    </>
  )
}

export default memo(SelectionModal);