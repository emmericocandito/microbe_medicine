import React, { memo } from 'react';
import MultiSelection from './MultiSelection'

const MultiSubcategories = props => {
  const {
    loading,
    title,
    checkedItems,
    sourceList,
    extraData,

    onMessage
  } = props;

  const showBtSelect = extraData?.showBtSelect ?? true;
  const checked = extraData?.checked ?? checkedItems.length > 0 ? '' : 'empty';

  const getNameFromItem = pItem => {
    if(!pItem) return '';
    const name = (pItem.labelForAdmin && pItem.labelForAdmin !== '') ? pItem.labelForAdmin : pItem.title !== '' ? pItem.title : pItem.id;
    return name;
  }
  const getNameFromCode = pCode => {
    const item = sourceList[pCode];
    return getNameFromItem(item);
  }
  const getValue = pItem => {
    return sourceList.indexOf(pItem);
  }

  const moreProps = { ...props, extraData: { checked, showBtSelect, getNameFromCode, getNameFromItem, getValue } }

  return (
    <MultiSelection
      {...moreProps}
    />
  );
};

export default memo(MultiSubcategories);
