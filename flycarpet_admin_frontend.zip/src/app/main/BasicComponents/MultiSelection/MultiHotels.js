import React, { memo } from 'react';
import MultiSelection from './MultiSelection';

const MultiHotels = props => {
	const {
		loading,
		title,
		checkedItems,
		sourceList,
		extraData,

		onMessage
	} = props;

	const chooseDestCode = extraData?.chooseDestCode ?? '';
	const checked = extraData?.checked ?? 'empty';
	const getNameFromItem = pItem => {
		return pItem.nameTranslationHeb === null || pItem.nameTranslationHeb === ''
			? pItem.nameTranslationEng
			: pItem.nameTranslationHeb;
	}
	const getNameFromCode = pCode => {
		if (sourceList === null) return;
		const item = sourceList.find(el => el.hotelId === pCode);
		return getNameFromItem(item);
	}
	const getValue = pItem => {
		return pItem.hotelId;
	}

	const moreProps = { ...props, extraData: { checked, getNameFromItem, getNameFromCode, getValue } };

	return (
		<MultiSelection {...moreProps} />
	);
}

export default memo(MultiHotels);
