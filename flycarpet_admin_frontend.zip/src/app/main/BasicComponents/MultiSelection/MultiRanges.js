import React, { memo } from 'react';
import MultiSelection from './MultiSelection';

const MultiRanges = props => {
	const {
		loading,
		title,
		checkedItems,
		sourceList,
		extraData,

		onMessage
	} = props;

	const checked = extraData?.checked ?? 'empty';
	const getNameFromItem = pItem => {
		return `${pItem.packStartDate} : ${pItem.packDuration} nights : ${pItem.avl} seats`;
	}
	const getNameFromCode = pCode => {
		const item = sourceList[pCode];
		return getNameFromItem(item);
	}
	const getValue = pItem => {
		return sourceList.indexOf(pItem);
	}

	const moreProps = { ...props, extraData: { checked, getNameFromItem, getNameFromCode, getValue } };

	return (
		<MultiSelection {...moreProps} />
	);
};

export default memo(MultiRanges);
