import React, { memo } from 'react';
import MultiSelection from './MultiSelection';

const MultiDealTypesDomestic = props => {
  const {
    loading,
    title,
    checkedItems,
    sourceList,
    extraData,

    onMessage
  } = props;

  const checked = extraData?.checked ?? 'empty';
  const getNameFromItem = pItem => {
    return pItem?.name || pItem?.id || '';
  }
  const getNameFromCode = pCode => {
    if (sourceList === null) return;
    const item = sourceList.find(el => el.id === pCode);
    return getNameFromItem(item);
  }
  const getValue = pItem => {
    return pItem.id;
  }

  const moreProps = { ...props, extraData: { checked, getNameFromItem, getNameFromCode, getValue } };

  return (
    <MultiSelection {...moreProps} />
  );
}

export default memo(MultiDealTypesDomestic);

// const {
//   loading: loadingDealCatetoryDomestic,
//   allItems: allDealCategoriesDomestic,

//   fetchAllItems: fetchDealCategoryDomestic,
// } = useDomesticDealCategory();