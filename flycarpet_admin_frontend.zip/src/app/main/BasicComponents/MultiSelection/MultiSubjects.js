import React, { memo } from 'react';
import MultiSelection from './MultiSelection';

const MultiSubjets = props => {
  const {
    loading,
    title,
    checkedItems,
    sourceList,
    extraData,

    onMessage
  } = props;

  const checked = extraData?.checked ?? '';
  const getNameFromItem = pItem => {
    return pItem?.name_Loc?.content ?? pItem.name;
  }
  const getNameFromCode = pCode => {
    if (sourceList === null) return;
    const item = sourceList.find(el => el.code === pCode);
    return !item ? pCode : getNameFromItem(item);
  }
  const getValue = pItem => {
    return pItem.code;
  }

  const moreProps = { ...props, extraData: { checked, getNameFromCode, getNameFromItem, getValue } };

  return (
    <MultiSelection
      {...moreProps}
    />
  );
}

export default memo(MultiSubjets);