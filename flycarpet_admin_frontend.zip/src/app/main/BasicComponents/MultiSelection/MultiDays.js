import React, { memo } from 'react';
import MultiSelection from './MultiSelection';

const MultiDays = props => {
	const {
		loading,
		title,
		checkedItems,
		sourceList,
		extraData,

		onMessage
	} = props;

	const showBtSelect = extraData?.showBtSelect ?? true;
	const kindLabel = extraData?.kindLabel ?? 'full';
	const checked = extraData?.checked ?? '';

	const getNameByKind = (pItem) => {
		let name = pItem.id;
		if (kindLabel === 'full') {
			name = pItem.label;
		} else if (kindLabel === 'ellipsis') {
			name = pItem.labelEllipsis;
		}
		return name;
	}
	const getNameFromItem = pItem => {
		return getNameByKind(pItem);
	}
	const getNameFromCode = pCode => {
		const item = sourceList[pCode];
		return getNameFromItem(item);
	}
	const getValue = pItem => {
		return sourceList.indexOf(pItem);
	}

	const moreProps = { ...props, extraData: { showBtSelect, checked, getNameFromItem, getNameFromCode, getValue } };

	return (
		<MultiSelection {...moreProps} />
	);
};

export default memo(MultiDays);
