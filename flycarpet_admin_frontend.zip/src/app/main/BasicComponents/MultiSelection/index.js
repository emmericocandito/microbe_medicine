import MultiHotels from './MultiHotels';
import MultiDuration from './MultiDuration';
import MultiRanges from './MultiRanges';
import MultiCategories from './MultiCategories';
import MultiDestinations from './MultiDestinations';
import MultiDestinationsInOut from './MultiDestinationsInOut';
import MultiAppDealCategories from './MultiAppDealCategories.js';
import MultiSubjects from './MultiSubjects';
import MultiHotelsExtraInfo from './MultiHotelsExtraInfo';
import MultiSubcategory from './MultiSubcategory';
import MultiDays from './MultiDays';

import MultiDealTypesDomestic from './MultiDealTypesDomestic';
import MultiDealTypesPackage from './MultiDealTypesPackage';

import MultiRoutes from './MultiRoutes';
import MultiOperations from './MultiOperations';

import MultiFlights from './MultiFlights';

export {
  MultiCategories,
  MultiSubcategory,
  MultiAppDealCategories,
  MultiDestinations,
  MultiDestinationsInOut,
  MultiDuration,
  MultiHotels,
  MultiRanges,
  MultiSubjects,
  MultiHotelsExtraInfo,
  MultiDays,

  MultiDealTypesDomestic,
  MultiDealTypesPackage,

  MultiRoutes,
  MultiOperations,

  MultiFlights,
};
