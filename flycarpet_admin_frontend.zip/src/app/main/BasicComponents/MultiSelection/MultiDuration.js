import React, { memo } from 'react';
import MultiSelection from './MultiSelection';

const MultiDuration = props => {
	const {
		loading,
		title,
		checkedItems,
		sourceList,
		extraData,

		onMessage
	} = props;

	const checked = extraData?.checked ?? '';
	const getNameFromItem = pItem => {
		return pItem;
	}
	const getNameFromCode = pCode => {
		if (sourceList === null) return;
		const item = sourceList.find(el => el === pCode);
		return getNameFromItem(item);
	}
	const getValue = pItem => {
		return pItem;
	}

	const moreProps = { ...props, extraData: { checked, getNameFromItem, getNameFromCode, getValue } };
	return (
		<MultiSelection {...moreProps} />
	);
};

export default memo(MultiDuration);
