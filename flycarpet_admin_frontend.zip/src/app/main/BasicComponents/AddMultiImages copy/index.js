import React, { useState, useEffect, memo } from 'react'

import { FormControl, IconButton } from '@material-ui/core'
import TextField from '@material-ui/core/TextField'
import SyncAltIcon from '@material-ui/icons/SyncAlt';
import { makeStyles } from '@material-ui/core/styles'

import ImageUploader from "react-images-upload"
import CircularProgress from '@material-ui/core/CircularProgress';
import AddImageLink from './AddImageLink';

const AddMultiImages = (props) => {
  const { imageData, onMessage, extraData } = props;

  const useStyles = makeStyles((theme) => ({
    subComponent: {
      marginTop: '5px',
    },
    formControl: {
      margin: theme.spacing(0, 1),
      minWidth: 120,
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      textAlign: "center",
      maxHeight: "100vh",
      overflowY: "auto",
    },
    textFiled: {
      width: '100%'
    },
    deleteImage: {
      position: 'absolute',
      top: '1px',
      right: '7px',
      color: '#fff',
      background: '#ff4081',
      borderRadius: '50%',
      textAign: 'center',
      cursor: 'pointer',
      fontSize: '17px',
      fontWeight: 'bold',
      lineHeight: '20px',
      width: '20px',
      height: '20px'
    },
    imageUploader: {
      maxWidth: '500px',
    },
    button_group: {
      padding: 30,
    },
    buttons: {
      marginRight: '10px'
    },
  }));

  const classes = useStyles();

  const [showCaption, setShowCaption] = useState(false);
  const [enableArrange, setEnableArrange] = useState(false);

  const [loadingCircle_gallery, setLoadingGalleryCircle] = useState(false);
  const [gallery, setGalleries] = useState([]);
  const [existingGalleryList, setExistingGalleryList] = useState([]);

  useEffect(() => {
    setShowCaption(extraData?.showCaption ?? false);
    setEnableArrange(extraData?.enableArrange ?? false);
  }, [extraData]);

  const handleSetGalleryImgUrl = (link) => {
    const arr = [...existingGalleryList];
    arr.push(link);
    setExistingGalleryList(arr);
  }
  const deleteExistingGallery = (index) => {
    setExistingGalleryList(existingGalleryList.filter((e, n) => n !== index));
  }
  const onGalleryDrop = (picture) => {
    setGalleries(picture);
  };
  const deleteGallery = (index) => {
    setGalleries(gallery.filter((e, n) => n !== index));
  }

  const onChangeImageOrder = (idx) => {
    const images = [...existingGalleryList];
    const prevImage = images[idx];
    const nextImage = images[idx + 1];
    images[idx] = nextImage;
    images[idx + 1] = prevImage;
    setExistingGalleryList(images);
  }

  useEffect(() => {
    onMessage('changedImage', {
      kind: 'gallery',
      id: imageData?.id ?? '',
      galleryUrls: existingGalleryList,
      galleryFiles: gallery,
    });
  }, [existingGalleryList, gallery])


  // all //
  const initialize = () => {
    setExistingGalleryList(imageData.galleryUrls || []);
    setGalleries(imageData.galleryFiles || []);
  }
  useEffect(() => {
    initialize();
  }, []);


  return (
    <div className={classes.subComponent}>
      {(!imageData || imageData?.title === '') ? '' :
        <div style={{ textAlign: 'left' }}>
          <h4 id='update-image' >{imageData?.title ?? ''}</h4>
        </div>
      }
      <div className={classes.border_style}>
        <div className={classes.fo_circular}>
          {loadingCircle_gallery ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
        </div>
        <div style={{ display: '-webkit-inline-box', overflow: 'auto' }}>
          {existingGalleryList == null ? "" : existingGalleryList.map((k, i) =>
            <div style={{ position: 'relative' }} key={i}>
              <button className={classes.deleteImage} onClick={(e) => deleteExistingGallery(i)}>X</button>
              <img alt='' style={{ width: '100px', maxHeight: '100px', margin: '10px' }} src={k} />
            </div>
          )}
          {gallery == null ? "" : gallery.map((n, j) =>
            <div>
              <div style={{ position: 'relative' }} key={j}>
                <button className={classes.deleteImage} onClick={(e) => deleteGallery(j)}>X</button>
                <img alt='' style={{ width: '100px', height: '100px', margin: '10px' }} src={URL.createObjectURL(n)} />
              </div>
              {(enableArrange && gallery.length - 1 === j) ? '' :
                <IconButton edge="end" aria-label="Replace order" onClick={(e) => onChangeImageOrder(j)}>
                  <SyncAltIcon />
                </IconButton>
              }
            </div>
          )}
        </div>
        <AddImageLink addingImageType={'Gallery'} setPictureLink={handleSetGalleryImgUrl} />
        <ImageUploader
          withPreview={false}
          withIcon={false}
          buttonStyles={{ fontSize: '12px' }}
          fileContainerStyle={{ padding: '0px', boxShadow: 'none' }}
          buttonText="Add Gallerys"
          withLabel={false}
          onChange={onGalleryDrop}
          imgExtension={[".jpg", ".gif", ".png", ".gif", ".jpeg", ".jfif"]}
          maxFileSize={524288000}
        />
      </div>
    </div>
  )
};

export default memo(AddMultiImages);