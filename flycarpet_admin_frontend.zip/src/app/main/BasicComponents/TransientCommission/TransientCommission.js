
import React, { useEffect, useState, memo } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Button, Grid, FormControl, TextField, FormHelperText, Table, TableHead, TableBody, TableRow, TableCell} from '@material-ui/core';

const TransientCommission = (props) => {
  const useStyles = makeStyles((theme) => ({
		formControl: {
			margin: '2px 5px',
			minWidth: 60,
			width: 'auto'
		},
		buttons: {
			marginLeft: '10px',
			height: '40px'
		},
	}));
	const classes = useStyles();

	const [commissionCheckin, setCommissionCheckin] = useState(null);
	const [commissionCheckout, setCommissionCheckout] = useState(null);
	const [commissionValue, setCommissionValue] = useState(null);
	const [commissionRemark, setCommissionRemark] = useState('');
	// const [nDayList, setDayList] = useState([]);
	const [nAction, setActionState] = useState('add');
	const [nEditIndex, setEditIndex] = useState(null);

  useEffect(() => {
  },[]);

	const addTransientCommission = () => {
    const nTransientCommissionList = props.transientCommissionList ? [...props.transientCommissionList] : [];

		if (new Date(commissionCheckin) < new Date() || new Date(commissionCheckin) > new Date(commissionCheckout)) {
			props.showMessageBox('Incorrect Date, Try again !');
			restoreInitState();
			return;
		}

		if (!commissionValue) {
			props.showMessageBox('The commission is mandatory !');
			restoreInitState();
			return;
		}

		if(commissionValue === '') return;
		const index = (!nTransientCommissionList)? -1: nTransientCommissionList.findIndex(d => (d.transientCommChkin === commissionCheckin && d.transientCommChkout === commissionCheckout && d.transientCommRemark === commissionRemark))
		if(index === -1){
			const oneCommissionItem = {};
			oneCommissionItem.transientCommChkin = commissionCheckin === null ? '' : commissionCheckin;
			oneCommissionItem.transientCommChkout = commissionCheckout === null ? '' : commissionCheckout;
			oneCommissionItem.transientComm = commissionValue === null ? 0 : Number(commissionValue);
			oneCommissionItem.transientCommRemark = commissionRemark;
			if(!nTransientCommissionList){
        props.onChangeTransientCommission([oneCommissionItem]);
			}else{
        props.onChangeTransientCommission([...nTransientCommissionList, oneCommissionItem]);
			}
		}else{
			const oneCommissionItem = {};
			oneCommissionItem.transientCommChkin = commissionCheckin === null ? '' : commissionCheckin;
			oneCommissionItem.transientCommChkout = commissionCheckout === null ? '' : commissionCheckout;
			oneCommissionItem.transientComm = commissionValue === '' ? 0 : Number(commissionValue);
			oneCommissionItem.transientCommRemark = commissionRemark;
			nTransientCommissionList[index] = oneCommissionItem;
      props.onChangeTransientCommission(nTransientCommissionList);
		}
		setCommissionRemark('');
		setCommissionCheckin('');
		setCommissionCheckout('');
		setCommissionValue(0);
	}
	const editTransientCommission = () => {
    const nTransientCommissionList = [...props.transientCommissionList];

		if (new Date(commissionCheckin) < new Date() || new Date(commissionCheckin) > new Date(commissionCheckout)) {
			props.showMessageBox('Incorrect Date, Try again !');
			restoreInitState();
			return;
		}

		if (!commissionValue) {
			props.showMessageBox('The commission is mandatory !');
			restoreInitState();
			return;
		}

		if(nEditIndex !== null){
			const oneCommissionItem = {};
			oneCommissionItem.transientCommChkin = commissionCheckin === null ? '' : commissionCheckin;
			oneCommissionItem.transientCommChkout = commissionCheckout === null ? '' : commissionCheckout;
			oneCommissionItem.transientComm = commissionValue === '' ? 0 : Number(commissionValue);
			oneCommissionItem.transientCommRemark = commissionRemark;
			nTransientCommissionList[nEditIndex] = oneCommissionItem;
      props.onChangeTransientCommission(nTransientCommissionList);
		}
		restoreInitState();
	}
	const deleteTransientCommission = async (i) => {
    const nTransientCommissionList = [...props.transientCommissionList]; // make a separate copy of the array
		var index = nTransientCommissionList.indexOf(nTransientCommissionList[i])
		if (index !== -1) {
			nTransientCommissionList.splice(index, 1);
      props.onChangeTransientCommission(nTransientCommissionList);
		}
		restoreInitState();
	}
	const cancelEdit = () => {
		restoreInitState();
	}

	const restoreInitState = () => {
		setCommissionRemark('');
		setCommissionCheckin('');
		setCommissionCheckout('');
		setCommissionValue(0);

		setEditIndex(null);

		setActionState('add');
	}

  const handleChangeCheckin = (event) => {
		if(event !== null){
			setCommissionCheckin(event.target.value);
		} else {
			setCommissionCheckin(null);
		}
	}
	const handleChangeCheckout = (event) => {
		if(event !== null){
			setCommissionCheckout(event.target.value);
		} else {
			setCommissionCheckout(null);
		}
	}
	const handleChangeCommission = (event) => {
		if (event !== null) {
			setCommissionValue(event.target.value);
		} else {
			setCommissionValue(null);
		}
	};
  const handleChangeRemark = (event) => {
		if(event !== null){
			setCommissionRemark(event.target.value);
		} else {
			setCommissionRemark('');
		}
	}
	const editItem = async (i) => {
    const nTransientCommissionList = [...props.transientCommissionList];
		setCommissionCheckin(nTransientCommissionList[i].transientCommChkin);
		setCommissionCheckout(nTransientCommissionList[i].transientCommChkout);
		setCommissionValue(nTransientCommissionList[i].transientComm);
		setCommissionRemark(nTransientCommissionList[i].transientCommRemark);

		setEditIndex(i);
		
		setActionState('edit');
	}

  return (
    <div>
      <Grid container justify='space-between' style={{ margin: '10px 0px' }}>
				
        <FormControl required className={classes.formControl}>
          <FormHelperText>Checkin</FormHelperText>
          <TextField
            id="date-1"
            type="date"
            value={commissionCheckin === null ? '' : commissionCheckin}
            onChange={handleChangeCheckin}
            className={classes.textField1}
						inputProps={{
							min: new Date().toISOString().slice(0, 10)
						}}
          />
        </FormControl>
        <FormControl required className={classes.formControl}>
          <FormHelperText>Checkout</FormHelperText>
          <TextField
            id="date-2"
            type="date"
            value={commissionCheckout === null ? '' : commissionCheckout}
            onChange={handleChangeCheckout}
            className={classes.textField1}
						inputProps={{
							min: commissionCheckin ? new Date(commissionCheckin).toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10)
						}}
          />
        </FormControl>
        <FormControl required className={classes.formControl}>
          <FormHelperText>Commission</FormHelperText>
          <TextField
            id='commission-number'
            type='number'
            value={commissionValue == null ? 0 : commissionValue}
            onChange={handleChangeCommission}
            InputLabelProps={{
              shrink: true,
            }}
            InputProps={{
              inputProps: {
                min: 0,
                max: 100
              }
            }}
          />
        </FormControl>
				<FormControl required className={classes.formControl}>
					<FormHelperText>Commission remark</FormHelperText>
					<TextField
            id='commission-remark'
            type='text'
            value={commissionRemark}
            onChange={handleChangeRemark}
          />
				</FormControl>
        <FormControl required className={classes.formControl}>
          <Button className={classes.buttons} color='secondary' variant='contained' onClick={(nAction === 'edit') ? editTransientCommission : addTransientCommission }>
						{(nAction === 'edit') ? 'Update': 'Add'}
					</Button>
        </FormControl>
				{
					(nAction === 'edit') ?
						(<FormControl required className={classes.formControl}>
							<Button className={classes.buttons} color='secondary' variant='contained' onClick={cancelEdit}>Cancel</Button>
						</FormControl>) : null
				}
      </Grid>
      {!props.transientCommissionList || props.transientCommissionList.length === 0 ? null :
        <Table className={classes.table} aria-label="caption table">
          <TableHead>
            <TableRow>
              <TableCell>Checkin</TableCell>
              <TableCell>Checkout</TableCell>
              <TableCell>Commission</TableCell>
              <TableCell>Remark</TableCell>
							<TableCell align="center">Edit</TableCell>
              <TableCell>Delete</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {props.transientCommissionList.map((n, index) => (
              <TableRow key={index}>
                <TableCell className='p-4 md:p-16' component="th" scope="row" size="small">{n.transientCommChkin}</TableCell>
                <TableCell className='p-4 md:p-16' size="small">{n.transientCommChkout}</TableCell>
                <TableCell className='p-4 md:p-16' size="small">{n.transientComm}</TableCell>
                <TableCell className='p-4 md:p-16' component="th" scope="row" size="small">{n.transientCommRemark}</TableCell>
								<TableCell className="w-40 md:w-64 text-center z-99" component='th' scope='row' align='left' size="small">
									<button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
										onClick={() => editItem(index)}
										tabIndex='0' type='button' title='Edit'>
										<span className='MuiIconButton-label'>
											<span className='material-icons MuiIcon-root' aria-hidden='true'>edit</span>
										</span>
										<span className='MuiTouchRipple-root'></span>
									</button>
								</TableCell>
                <TableCell className="w-40 md:w-64 text-center z-99" component='th' scope='row' align='left' size="small">
                    <button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
                    onClick={() => deleteTransientCommission(index)}
                      tabIndex='0' type='button' title='Delete'>
                      <span className='MuiIconButton-label'>
                        <span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
                      </span>
                      <span className='MuiTouchRipple-root'></span>
                    </button>
                  </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      }
    </div>
  )
    
}

export default memo(TransientCommission);
