import React, { useState, useEffect, memo } from 'react'

import FormControl from '@material-ui/core/FormControl'
import TextField from '@material-ui/core/TextField'
import { makeStyles } from '@material-ui/core/styles'

import ImageUploader from "react-images-upload"

const AddImage = (props) => {
  const { imageData, onMessage, extraData } = props;

  const useStyles = makeStyles((theme) => ({
    subComponent: {
      marginTop: '5px',
    },
    formControl: {
      margin: theme.spacing(0, 1),
      minWidth: 120,
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      textAlign: "center",
      maxHeight: "100vh",
      overflowY: "auto",
    },
    textFiled: {
      width: '100%'
    },
    deleteImage: {
      position: 'absolute',
      top: '1px',
      right: '7px',
      color: '#fff',
      background: '#ff4081',
      borderRadius: '50%',
      textAign: 'center',
      cursor: 'pointer',
      fontSize: '17px',
      fontWeight: 'bold',
      lineHeight: '20px',
      width: '20px',
      height: '20px'
    },
    imageUploader: {
      maxWidth: '500px',
    },
    button_group: {
      padding: 30,
    },
    buttons: {
      marginRight: '10px'
    },
  }));

  const classes = useStyles();

  const [showCaption, setShowCaption] = useState(false);
  const [showHref, setShowHref] = useState(false);
  const [singleImage, setSingleImage] = useState(false);
  const [stateImage, setStateImage] = useState('Add Image');
  useEffect(() => {
    setShowCaption(extraData?.showCaption ?? false);
    // setSingleImage(extraData?.singleImage ?? true);
    setShowHref(extraData?.showHref ?? false);
    if (imageData?.Url === '' && imageData?.file === null) {
      setStateImage('Add Image');
    } else {
      setStateImage('Update Image');
    }

  }, [extraData, imageData]);

  const getImageURL = () => {
    return imageData?.Url || imageData?.Blob || '';
  }
  const handleImgUrlChangeName = (event) => {
    onMessage('changedImage', {
      kind: 'image',
      id: imageData?.id ?? '',
      Url: event.target.value ?? '',
      Blob: '',
      file: null,
    });
  }
  const handleUploadImage = (pImg) => {
    onMessage('changedImage', {
      kind: 'image',
      id: imageData?.id ?? '',
      Url: '',
      Blob: URL.createObjectURL(pImg[0]),
      file: pImg[0],
    });
  }
  const deleteImage = () => {
    onMessage('changedImage', {
      id: imageData?.id ?? '',
      Url: '',
      Blob: '',
      file: null,
      href: '',
      caption: '',
    });
  }
  const handleImgCaption = (ev) => {
    onMessage('changedCaption', {
      id: imageData?.id ?? '',
      caption: ev.target.value ?? '',
    })
  }
  const handleChangeHref = (ev) => {
    onMessage('changedCaption', {
      id: imageData?.id ?? '',
      href: ev.target.value ?? '',
    })
  }

  return (
    <div className={classes.subComponent}>
      {(!imageData || imageData?.title === '') ? '' :
        <div style={{ textAlign: 'left' }}>
          <h4 id='update-image' >{imageData?.title ?? ''}</h4>
        </div>
      }
      <div style={{ display: 'flex' }}>
        <FormControl className={classes.formControl} style={{ margin: 'auto' }}>
          {showCaption && <TextField onChange={handleImgCaption} className={classes.textFiled} label="Caption" value={imageData?.caption ?? ''} />}
          <TextField onChange={handleChangeHref} className={classes.textFiled} label="Href" value={imageData?.href ?? ''} />
          <TextField onChange={handleImgUrlChangeName} className={classes.textFiled} label="Image URL" value={imageData?.Url ?? ''} />
          {getImageURL() === '' ? '' :
            <div style={{ display: 'flex', overflow: 'auto' }}>
              <div style={{ position: 'relative', margin: 'auto' }} >
                <button className={classes.deleteImage} onClick={(e) => deleteImage()}>X</button>
                <img alt='' style={{ height: '70px', margin: '10px' }} src={getImageURL()} />
              </div>
            </div>
          }
          <ImageUploader
            className={classes.imageUploader}
            withIcon={false}
            buttonStyles={{ fontSize: '12px' }}
            fileContainerStyle={{ padding: '0px', boxShadow: 'none' }}
            buttonText={stateImage}
            withLabel={false}
            withPreview={false}
            onChange={handleUploadImage}
            singleImage={singleImage}
            imgExtension={[".jpg", ".gif", ".png", ".gif", ".jpeg", ".jfif"]}
            maxFileSize={524288000}
          />
        </FormControl>
      </div>
    </div>
  )
};

export default memo(AddImage);