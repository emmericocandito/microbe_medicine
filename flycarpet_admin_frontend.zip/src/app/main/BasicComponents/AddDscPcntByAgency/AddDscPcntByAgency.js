import React, { useEffect, useState, memo } from 'react';
import { Select, FormControl, FormHelperText, TextField, Button,
  Table, TableHead, TableRow, TableCell, TableBody } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';

function AddDscPcntByAgency(props) {
	const useStyles = makeStyles(theme => ({
		formControl: {
			margin: '2px 5px',
			minWidth: 60,
			width: '100%'
		},
		buttons: {
			marginLeft: '10px',
			height: '40px'
		},
    table: {
      marginLeft: '0px',
      marginRight: '0px',
    },
	}));
	const classes = useStyles();

  const [actionType, setActionType] = useState('add');
  const [resultList, setResultList] = useState([]);

  const [currentAgencyCode, setCurrentAgencyCode] = useState(null);
  const [discountByAgency, setDiscountByAgency] = useState(0);

  useEffect(() => {
    setResultList(props.agencyDiscountList);
  }, []);

  useEffect(() => {
    props.onChangeDiscountListByAgency(resultList);
  }, [resultList]);

	const addingAction = () => {
    if(!currentAgencyCode) return;
		const inx = resultList.findIndex(d => d.agencyCode === currentAgencyCode);
		if (actionType === 'add' && inx === -1) {
			const oneResultItem = {};
			oneResultItem.agencyCode = currentAgencyCode;
			oneResultItem.discount = +discountByAgency;

			setResultList([...resultList, oneResultItem]);
		} else if ((actionType === 'edit' && inx !== -1) || (actionType === 'add' && inx !== -1)) {
			const list = [...resultList];
			const oneResultItem = {};
			oneResultItem.agencyCode = currentAgencyCode;
			oneResultItem.discount = +discountByAgency;
			list[inx] = oneResultItem;
			setResultList(list);
		}
		exitingEditAction();
	};
	const exitingEditAction = () => {
    setCurrentAgencyCode(null);
    setDiscountByAgency(0);
		setActionType('add');
	};
	const editingAction = (inx) => {
		setCurrentAgencyCode(resultList[inx].agencyCode);
		setDiscountByAgency(resultList[inx].discount);
		setActionType('edit');
	};
	const deletingAction = (inx) => {
		const list = [...resultList];
		if (inx !== -1) {
			list.splice(inx, 1);
			setResultList(list);
		}
	};


  return (
  <>
    <div style={{ display: 'grid', marginLeft: '20px', marginRight: '20px' }}>
      <div style={{ display: 'flex', marginTop: '10px' }}>
        <FormControl
          required
          className={classes.formControl}
          style={{ width: '50%', marginLeft: '5px' }}
        >
          <FormHelperText>Agency</FormHelperText>
          <Select
            native
            name="Agency"
            onChange={e => setCurrentAgencyCode(e.target.value || null)}
            value={currentAgencyCode === null ? '' : currentAgencyCode}
            inputProps={{
              id: 'select-destination'
            }}
          >
            <option aria-label="None" value={null} />
            {props.agencies === null
              ? ''
              : props.agencies.map((n, i) => (
                <option key={i} value={n.code}>
                  {n.name}
                </option>
              ))}
          </Select>
        </FormControl>
        <div style={{ width: '100%', marginRight: '5px' }}>
          <FormControl className={classes.formControl}>
            <FormHelperText>Discount</FormHelperText>
            <TextField
              type="number"
              onChange={e => setDiscountByAgency(e.target.value || 0)}
              value={discountByAgency}
            />
          </FormControl>
        </div>
        {actionType === 'edit' ? (
          <Button
            className={classes.buttons}
            color="secondary"
            variant="contained"
            onClick={event => exitingEditAction(event)}
          >
            exit
          </Button>
        ) : null}
        <Button
          className={classes.buttons}
          color="secondary"
          variant="contained"
          onClick={event => addingAction(event)}
        >
          {actionType}
        </Button>
      </div>
    </div>

    <Table className={classes.table} aria-label="caption table">
      <TableHead>
        <TableRow>
          <TableCell>Agency Name</TableCell>
          <TableCell align="center">Discount</TableCell>
          <TableCell align="center">Edit</TableCell>
          <TableCell align="center">Delete</TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {resultList.map((n, inx) => (
          <TableRow key={inx}>
            <TableCell className="p-4 md:p-16" component="th" scope="row" size="small">
              {props.agencies.find((agency) => (agency.code === n.agencyCode))?.name || ''}
            </TableCell>
            <TableCell className="p-4 md:p-16" align="center" size="small">
              {n.discount}
            </TableCell>
            <TableCell
              className="w-40 md:w-64 text-center z-99"
              component="th"
              scope="row"
              align="left"
              size="small"
            >
              <button
                className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit"
                onClick={() => editingAction(inx)}
                tabIndex="0"
                type="button"
                title="Edit"
              >
                <span className="MuiIconButton-label">
                  <span
                    className="material-icons MuiIcon-root"
                    aria-hidden="true"
                  >
                    edit
                  </span>
                </span>
                <span className="MuiTouchRipple-root" />
              </button>
            </TableCell>
            <TableCell
              className="w-40 md:w-64 text-center z-99"
              component="th"
              scope="row"
              align="left"
              size="small"
            >
              <button
                className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit"
                onClick={() => deletingAction(inx)}
                tabIndex="0"
                type="button"
                title="Delete"
              >
                <span className="MuiIconButton-label">
                  <span
                    className="material-icons MuiIcon-root"
                    aria-hidden="true"
                  >
                    delete
                  </span>
                </span>
                <span className="MuiTouchRipple-root" />
              </button>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  </>
  );
}

export default memo(AddDscPcntByAgency);