import React, { memo, useState, useEffect } from 'react';
import clsx from 'clsx';

import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import { TableBody, TableRow, TableCell, Table, Button, IconButton, Collapse, Box, } from '@material-ui/core';
import "react-responsive-carousel/lib/styles/carousel.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';
import InsideTable from 'app/main/BasicComponents/InsideTable';
import { LineChart, Line, Tooltip, ResponsiveContainer } from 'recharts';

function ActionTableBody(props) {
  const { propColumns, bodyRows, onMessageBody, insideTable, showInsideTableHeader } = props;
  const showColumns = propColumns[propColumns.length-1]

  const [enabledInsideTable, setEnabledInsideTable] = useState(false);
  const [columnsInsideTable, setColumnsInsideTable] = useState([]);
  const [propInsideTable, setPropInsideTable] = useState('');
  useEffect(() => {
    if(insideTable) {
      setEnabledInsideTable(insideTable.enable);
      setColumnsInsideTable(insideTable.columns);
      setPropInsideTable(insideTable.moreData);
    }
  }, [insideTable])

  const [openRows, setOpenRows] = useState({});

  const eventHandlerColumn = (prop, id) => ev => {
    const col = showColumns.find(el => el.id === prop);
    if (col && col.type !== 'button' && (col.click === undefined || col.click === 'enable')) onMessageBody({ evtType: 'column', kind: prop, id });
  }
  const showSplite = (prop) => {
    const col = showColumns.find(el => el.id === prop);
    return col?.splite ?? '';
  }
  const eventHandlerButton = (prop, id) => ev => {
    onMessageBody({ evtType: 'button', kind: prop, id });
  }
  const getStyleColumn = (pColumn, pRow) => {
    const styles = pRow?.extraData?.style ?? [];
    return styles.find(el => el.column === pColumn)?.value ?? {};
  }
  const getColumnContent = (pColumn, pRow) => {
    const { id, align, disablepadding, label, sort, type } = pColumn;
    if (type !== 'button') {
      const value = pRow?.[id] ?? '';
      const style = getStyleColumn(id, pRow);
      switch (type) {
        case 'text':
          return <p style={{...style}} className='whitespace-no-wrap'>{value}</p>;
        case 'ellipsisText':
          return (
            <p style={{...style, width: '20%', textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap'}}>{value}</p>
          );
        case 'boolean':
          return (
            <i
              className={clsx(
                'inline-block w-8 h-8 rounded mx-8',
                !value && 'bg-red',
                value && 'bg-green',
              )}
            />
          );
        case 'image':
          return (
            <img alt='' style={{ cursor: 'pointer', width: '100px', maxHeight: '100px', margin: '10px' }} src={value} />
          );
        case 'carousel':
          return (
            <Carousel autoPlay={false} transitionTime="2000" showThumbs={false} width="250px">
              {value == null ? "" : value.map((k, i) =>
                <div key={i}>
                  <img alt='' style={{ width: '200px', height: '150px', margin: 'auto' }} src={value[i]} />
                </div>
              )}
            </Carousel>
          );
        case 'lineChart':
          return (
            <LineChart width={150} height={50} data={value.data} >
              <Line type="monotone" dataKey={value.dataKey} stroke="#8884d8" strokeWidth={2} dot={false} animationDuration={0}/>
            </LineChart>
          );
        case 'component':
          return value;
        default:
          return value;
      }
    } else if (type === 'button') {
      switch (id) {
        case 'add':
          return (
            <Button
              className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit"
              onClick={eventHandlerButton(id, pRow.id)}
              tabIndex="0" type="button" title="Add">
              <span className="MuiIconButton-label">
                <span className="material-icons MuiIcon-root" aria-hidden="true">add</span>
              </span>
              <span className="MuiTouchRipple-root"></span>
            </Button>
          );
        case 'clone':
          return (
            <Button
              className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit"
              onClick={eventHandlerButton(id, pRow.id)}
              tabIndex="0" type="button" title="Copy">
              <span className="MuiIconButton-label">
                <span className="material-icons MuiIcon-root" aria-hidden="true">copy</span>
              </span>
              <span className="MuiTouchRipple-root"></span>
            </Button>
          );
        case 'edit':
          return (
            <Button
              className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit"
              onClick={eventHandlerButton(id, pRow.id)}
              tabIndex="0" type="button" title="Edit">
              <span className="MuiIconButton-label">
                <span className="material-icons MuiIcon-root" aria-hidden="true">edit</span>
              </span>
              <span className="MuiTouchRipple-root"></span>
            </Button>
          );
        case 'delete':
          return (
            <Button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
              onClick={eventHandlerButton(id, pRow.id)}
              // disabled={n.isAppDeal} //peinding
              tabIndex='0' type='button' title='Delete'>
              <span className='MuiIconButton-label'>
                <span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
              </span>
              <span className='MuiTouchRipple-root'></span>
            </Button>
          );
        case 'extend':
          const showExtends = (enabledInsideTable && pRow[propInsideTable].length>0 )
          return (showExtends ?
              (<IconButton aria-label="expand row" size="small" onClick={() => toggleRow(pRow.idx)}>
                {openRows[pRow.idx] ? (
                  <KeyboardArrowUpIcon />
                ) : (
                  <KeyboardArrowDownIcon />
                )}
              </IconButton>)
              :
              null
            )
        case 'generate':
            return (<Button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
              onClick={eventHandlerButton(id, pRow.id)}
              // disabled={n.isAppDeal} //peinding
              tabIndex='0' type='button' title={label}>
              <span className='MuiIconButton-label'>
                <span className="material-icons MuiIcon-root" aria-hidden="true">save</span>
              </span>
              <span className='MuiTouchRipple-root'></span>
            </Button>)
        case 'upward':
          return (
            <Button
              className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit"
              onClick={eventHandlerButton(id, pRow.id)}
              tabIndex="0" type="button" title="Order">
              <span className="MuiIconButton-label">
                <span className="material-icons MuiIcon-root" aria-hidden="true">arrow_upward</span>
              </span>
              <span className="MuiTouchRipple-root"></span>
            </Button>
          );
        default:
          return (
            <Button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
              onClick={eventHandlerButton(id, pRow.id)}
              // disabled={n.isAppDeal} //peinding
              tabIndex='0' type='button' title={label}>
              <span className='MuiIconButton-label'>
                <span className='material-icons MuiIcon-root' aria-hidden='true'>information</span>
              </span>
              <span className='MuiTouchRipple-root'></span>
            </Button>
          );
      }
    }
  }
  const addColmuns = pRow => {
    const rowContent = showColumns.map(col => {
      return (
        col.show !== 'hide' && <TableCell
          key={col.id}
          className={clsx('w-40 md:w-64 z-99', showSplite(col.id) && 'border-r-1')}
          component='td'
          scope='row'
          align={col.align}
          onClick={eventHandlerColumn(col.id, pRow.id)}
        >
          {getColumnContent(col, pRow)}
        </TableCell>
      );
    })
    return rowContent;
  }

  const toggleRow = pRowIdx => {
		const stateOpen = openRows[pRowIdx] !== undefined ? !openRows[pRowIdx] : true;
		setOpenRows(openRows => {
			return { ...openRows, [pRowIdx]: stateOpen };
		});
	};

  const receiveMessageFromInsideTable = (pMsg) => {
    onMessageBody(pMsg);
  }

  useEffect(() => {
    setOpenRows({});
  }, [])

  return (
    <TableBody>
      {bodyRows.map((row, idx) => {
        return (
          <React.Fragment key={idx}>
            <TableRow
              className='h-64 cursor-pointer'
              hover
              tabIndex={-1}
              style={{backgroundColor: row?.background ?? 'white'}}
            >
              {addColmuns(row)}
            </TableRow>
            {(enabledInsideTable && row?.[propInsideTable]?.length > 0) && (
              <TableRow
                className='cursor-pointer'
                hover
              >
                <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={showColumns.length}>
                  <Collapse in={openRows[row.idx]} timeout="auto" unmountOnExit>
                    <Box sx={{ margin: 1, padding: '2px 10px' }}>
                      <InsideTable
                        key={`insidetable_${idx}`}
                        propColumns={columnsInsideTable}
                        bodyRows={row?.[propInsideTable]}
                        showHeader={showInsideTableHeader}
                        onMessage={receiveMessageFromInsideTable}
                      />
                    </Box>
                  </Collapse>
                </TableCell>
              </TableRow>
            )}
          </React.Fragment>
        );
      })}
    </TableBody>
  );
}

export default memo(ActionTableBody);