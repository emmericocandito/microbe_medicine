import React, { memo } from 'react';
import {
  TableCell, TableHead, TableRow, TableSortLabel, Tooltip
} from '@material-ui/core';
import clsx from 'clsx';

  // type: item
  // {
  //   id: 'more',
  //   align: 'left',
  //   disablePadding: false,
  //   label: 'More Deals',
  //   sort: false,
  //   type: 'type',
  //   show: 'hide',
  //   children: [
  //     {
  //       id: 'idx',
  //       align: 'left',
  //       disablePadding: false,
  //       label: 'Index',
  //       sort: false,
  //       type: 'text'
  //     },
  //   ]
  // },

function ActionTableHead(props) {
  const { propColumns, order, onMessageHead } = props;

  const createSortHandler = prop => ev => {
    onMessageHead({
      kind: 'sort',
      data: { event: ev, property: prop }
    })
  };

  const calcColSpan = columns => {
    if(columns === undefined) return 0;
    return columns.filter(item => item.show != 'hide').length;
  }
  
  const createTableRow = (row) => {
    return (
      
      row.map((item) => {
        const { id, align, disablePadding, label, sort, children, splite, show } = item;
        return (
          show !== 'hide' && <TableCell
            className={clsx(splite && 'border-r-1', 'p-4 md:p-10')}
            key={id}
            align={align}
            padding={disablePadding ? 'none' : 'default'}
            sortDirection={order.id === id ? order.direction : false}
            colSpan={calcColSpan(children)}
          >
            {sort && (
              <Tooltip
                title='Sort'
                placement={align === 'right' ? 'bottom-end' : 'bottom-start'}
                enterDelay={300}
              >
                <TableSortLabel
                  active={order.id === id}
                  direction={order.direction}
                  onClick={createSortHandler(id)}
                >
                  {label}
                </TableSortLabel>
              </Tooltip>
            )}
            {!sort && label}
          </TableCell>
        );
      })
    );
  }

  return (
    <TableHead>
      {propColumns.map((rowHead, idx) => {
        return (
          <TableRow className='h-64' key={idx}>
            {createTableRow(rowHead)}
          </TableRow>
        )
      })}
    </TableHead>
  )
}

export default memo(ActionTableHead);