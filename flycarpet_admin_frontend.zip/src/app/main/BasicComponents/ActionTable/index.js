import React, { useState, memo, useEffect, useContext } from 'react';
import _ from '@lodash';

import ActionTableHead from './ActionTableHead';
import ActionTableBody from './ActionTableBody';
import FuseScrollbars from '@fuse/core/FuseScrollbars';
import { Table, TablePagination } from '@material-ui/core';
import { TableStatusContext } from 'app/main/Context/tableStatusContext'

function ActionTable(props) {
  const { propColumns, bodyRows, onMessage: sendMessage, extraData, insideTable, showInsideTableHeader } = props;
  const {
    statusTotal,
    statusPage,
    statusRowsPerPage,
    statusOrder,

    setStatusTotal,
    setStatusOrder,
    setStatusPage,
    setStatusRowsPerPage,
  } = useContext(TableStatusContext);

  const [showPagination, setShowPagination] = useState(true);
  const [sortedRows, setSortedRows] = useState(bodyRows);
  const [showingRows, setShowingRows] = useState([]);

  function createArraysPerDepth(list, depthList, depth = 0) {
    list.forEach(item => {
      if(depthList[depth] === undefined) {
        depthList[depth] = [item];
      } else {
        depthList[depth].push(item);
      }
      if(Array.isArray(item.children)){
        createArraysPerDepth(item.children, depthList, depth+1);
      }
    });
    return depthList;
  }
  const columnsHeaderDepth = createArraysPerDepth(propColumns, []);

  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [page, setPage] = useState(0);
  const handleChangePage = (ev, value) => {
    movePage(value);
  }
  const handleChangeRowsPerPage = (ev) => {
    movePage(0);
    setRowsPerPage(ev.target.value);
  }
  const movePage = (pPage) => {
    if (bodyRows.length < (pPage + 1) * rowsPerPage) {
      setStatusPage && setStatusPage(pPage);
      sendMessage({ evtType: 'loadMore' });
    }
    setPage(pPage);
  }
  const onMessageBody = (pMsg) => {
    sendMessage(pMsg);
  }
  useEffect(() => {
    setStatusPage && setStatusPage(page);
    setStatusRowsPerPage && setStatusRowsPerPage(rowsPerPage);

    setShowingRows(sortedRows.slice(page * rowsPerPage, (page + 1) * rowsPerPage));
  }, [page, sortedRows, rowsPerPage])

  const [order, setOrder] = useState({
    direction: 'asc',
    id: null
  });
  const onMessageHead = (pMsg) => {
    const id = pMsg?.data?.property ?? null;
    const direction = order.id === id && order.direction === 'asc' ? 'desc' : 'asc';
    setOrder({ direction, id })
  }
  const getTotalRows = () => {
    let total = statusTotal ?? 0;
    return total > 0 ? total : bodyRows.length;
  }
  useEffect(() => {
    setStatusOrder && setStatusOrder(order);

    const rows = _.orderBy(bodyRows,
      [
        o => {
          switch (order.id) {
            default:
              return o[order.id];
          }
        }
      ],
      [order.direction]
    );
    setSortedRows(rows);
  }, [order, bodyRows]);
  useEffect(() => {
    statusTotal && setStatusTotal(statusTotal);
    statusOrder && setOrder(statusOrder);
    statusPage && setPage(statusPage);
    statusRowsPerPage && setRowsPerPage(statusRowsPerPage);
  }, [bodyRows])
  useEffect(() => {
    setShowPagination(extraData?.showPagination ?? true);
  }, [extraData])

  return (
    <>
      <FuseScrollbars className='flex-grow overflow-x-auto'>
        <Table stickyHeader aria-labelledby='tableTitle'>
          <ActionTableHead
            propColumns={columnsHeaderDepth}
            onMessageHead={onMessageHead}
            order={order}
          />
          <ActionTableBody
            propColumns={columnsHeaderDepth}
            bodyRows={showingRows}
            onMessageBody={onMessageBody}
            insideTable={insideTable}
            showInsideTableHeader={showInsideTableHeader ?? true}
          />
        </Table>
      </FuseScrollbars>
      {!showPagination ? "" :
        <TablePagination
          className='flex-shrink-0 border-t-1'
          component='div'
          count={getTotalRows()}
          rowsPerPage={rowsPerPage}
          page={page}
          backIconButtonProps={{
            'aria-label': 'Previous Page'
          }}
          nextIconButtonProps={{
            'aria-label': 'Next Page'
          }}
          onChangePage={handleChangePage}
          onChangeRowsPerPage={handleChangeRowsPerPage}
        />
      }
    </>
  );
}

export default memo(ActionTable);