import React, { useState, useEffect, memo } from 'react'

import FormControl from '@material-ui/core/FormControl'
import TextField from '@material-ui/core/TextField'
import { makeStyles } from '@material-ui/core/styles'

import {DropzoneArea} from 'material-ui-dropzone';

const UploadFile = (props) => {
  const { fileData, onMessage, extraData } = props;

  const useStyles = makeStyles((theme) => ({
    subComponent: {
      marginTop: '5px',
    },
    formControl: {
      margin: theme.spacing(0, 1),
      minWidth: 120,
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      textAlign: "center",
      maxHeight: "100vh",
      overflowY: "auto",
    },
    textFiled: {
      width: '100%',
      marginBottom: '10px',
    },
    deleteFile: {
      position: 'absolute',
      top: '1px',
      right: '7px',
      color: '#fff',
      background: '#ff4081',
      borderRadius: '50%',
      textAign: 'center',
      cursor: 'pointer',
      fontSize: '17px',
      fontWeight: 'bold',
      lineHeight: '20px',
      width: '20px',
      height: '20px'
    },
    fileUploader: {
      width: '50%',
      margin: 'auto'
    },
    button_group: {
      padding: 30,
    },
    buttons: {
      marginRight: '10px'
    },
  }));

  const classes = useStyles();

  const [showCaption, setShowCaption] = useState(false);
  const [showHref, setShowHref] = useState(false);
  const [singleFile, setSingleFile] = useState(false);
  const [stateFile, setStateFile] = useState('Add File');
  useEffect(() => {
    setShowCaption(extraData?.showCaption ?? false);
    setShowHref(extraData?.showHref ?? false);
    setSingleFile(extraData?.singleFile ?? true);
    setShowHref(extraData?.showHref ?? false);
    if (fileData?.Url === '' && fileData?.file === null) {
      setStateFile('Add File');
    } else {
      setStateFile('Update File');
    }

  }, [extraData, fileData]);

  const getFileURL = () => {
    return fileData?.Url || fileData?.Blob || fileData?.name || '';
  }
  const getFileName = () => {
    return fileData?.file?.name ?? fileData?.name ?? '';
  }
  const availableUpload = () => {
    let available = true;
    if(singleFile && getFileURL() !== '') available = false;
    return available; 
  }
  const handleFileUrlChangeName = (event) => {
    onMessage('changedFile', {
      kind: 'file',
      id: fileData?.id ?? '',
      Url: event.target.value ?? '',
      Blob: '',
      file: null,
      name: '',
    });
  }
  const handleUploadFile = (pFile) => {
    if(pFile.length ===0) return;
    onMessage('changedFile', {
      kind: 'file',
      id: fileData?.id ?? '',
      Url: '',
      Blob: URL.createObjectURL(pFile[0]),
      file: pFile[0],
      name: pFile[0].name,
    });
  }
  const deleteFile = () => {
    onMessage('changedFile', {
      id: fileData?.id ?? '',
      Url: '',
      Blob: '',
      file: null,
      href: '',
      caption: '',
      name: '',
    });
  }
  const handleFileCaption = (ev) => {
    onMessage('changedCaption', {
      id: fileData?.id ?? '',
      caption: ev.target.value ?? '',
    })
  }
  const handleChangeHref = (ev) => {
    onMessage('changedCaption', {
      id: fileData?.id ?? '',
      href: ev.target.value ?? '',
    })
  }

  return (
    <div className={classes.subComponent}>
      {(!fileData || fileData?.title === '') ? '' :
        <div style={{ textAlign: 'left' }}>
          <h4 id='update-file' >{fileData?.title ?? ''}</h4>
        </div>
      }
      <div style={{ display: 'flex' }}>
        <FormControl className={classes.formControl} style={{ margin: 'auto' }}>
          {showCaption && <TextField onChange={handleFileCaption} className={classes.textFiled} label="Caption" value={fileData?.caption ?? ''} />}
          {showHref && <TextField onChange={handleChangeHref} className={classes.textFiled} label="Href" value={fileData?.href ?? ''} />}
          <TextField onChange={handleFileUrlChangeName} className={classes.textFiled} label="File URL" value={fileData?.Url ?? ''} />
          {availableUpload() ? 
            <DropzoneArea onChange={handleUploadFile} classes={{ root: classes.fileUploader}}/> :
            (<div style={{ display: 'flex', overflow: 'auto' }}>
              <div style={{ position: 'relative', margin: 'auto' }} >
                <button className={classes.deleteFile} onClick={(e) => deleteFile()}>X</button>
                <img alt='' style={{ height: '70px', margin: '10px' }} src="assets/images/logos/pdf-icon.jpg" />
                <p>{getFileName()}</p>
              </div>
            </div>)
          }
        </FormControl>
      </div>
    </div>
  )
};

export default memo(UploadFile);