import React, { useState, memo, useEffect, useContext } from 'react';
import _ from '@lodash';

import InsideTableHead from './InsideTableHead';
import InsideTableBody from './InsideTableBody';
import FuseScrollbars from '@fuse/core/FuseScrollbars';
import { Grid, Table } from '@material-ui/core';

function InsideTable(props) {
  const { propColumns, bodyRows, onMessage: sendMessage, extraData, showHeader, miniHeader } = props;
  const [sortedRows, setSortedRows] = useState(bodyRows);
  const [showingRows, setShowingRows] = useState([]);

  const maxHeight = extraData?.maxHeight ?? '90vh';
  const maxWidth = extraData?.maxWidth ?? '100%';

  function createArraysPerDepth(list, depthList, depth = 0) {
    list.forEach(item => {
      if(depthList[depth] === undefined) {
        depthList[depth] = [item];
      } else {
        depthList[depth].push(item);
      }
      if(Array.isArray(item.children)){
        createArraysPerDepth(item.children, depthList, depth+1);
      }
    });
    return depthList;
  }
  const columnsHeaderDepth = createArraysPerDepth(propColumns, []);

  const onMessageBody = (pMsg) => {
    sendMessage(pMsg);
  }

  useEffect(() => {
    setShowingRows(sortedRows);
  }, [sortedRows])

  const [order, setOrder] = useState({
    direction: 'asc',
    id: null
  });
  const onMessageHead = (pMsg) => {
    const id = pMsg?.data?.property ?? null;
    const direction = order.id === id && order.direction === 'asc' ? 'desc' : 'asc';
    setOrder({ direction, id })
  }
  useEffect(() => {
    const rows = _.orderBy(bodyRows,
      [
        o => {
          switch (order.id) {
            default:
              return o[order.id];
          }
        }
      ],
      [order.direction]
    );
    setSortedRows(rows);
  }, [order, bodyRows]);

  return (
    <Grid container style={{maxHeight, maxWidth, overflowY: 'auto'}}>
      <FuseScrollbars className='flex-grow overflow-x-auto'>
        <Table stickyHeader aria-labelledby='tableTitle'>
          { (showHeader ?? true) &&
            <InsideTableHead
              propColumns={columnsHeaderDepth}
              headerHeight={miniHeader? 40 : 64}
              onMessageHead={onMessageHead}
              order={order}
            />
          }
          <InsideTableBody
            propColumns={columnsHeaderDepth}
            bodyRows={showingRows}
            onMessageBody={onMessageBody}
            extraData={extraData}
          />
        </Table>
      </FuseScrollbars>
    </Grid>
  );
}

export default memo(InsideTable);