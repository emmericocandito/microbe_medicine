import React, { memo } from 'react';
import clsx from 'clsx';

import KeyboardArrowUpIcon from '@material-ui/icons/KeyboardArrowUp';
import KeyboardArrowDownIcon from '@material-ui/icons/KeyboardArrowDown';
import { TableBody, TableRow, TableCell, Table, Button, IconButton, TextField } from '@material-ui/core';
import "react-responsive-carousel/lib/styles/carousel.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';

function InsideTableBody(props) {
  const { propColumns, bodyRows, onMessageBody, extraData} = props;
  const showColumns = propColumns[propColumns.length-1]

  const eventHandlerColumn = (prop, id) => ev => {
    const col = showColumns.find(el => el.id === prop);
    if (col && col.type !== 'button' && (col.click === undefined || col.click === 'enable')) onMessageBody({ evtType: 'column', kind: prop, id });
  }
  const showSplite = (prop) => {
    const col = showColumns.find(el => el.id === prop);
    return col?.splite ?? '';
  }
  const eventHandlerButton = (prop, id) => ev => {
    onMessageBody({ evtType: 'button', kind: prop, id });
  }
  const eventHandlerChanged = (id, columnId) => ev => {
    onMessageBody({ evtType: 'changeRow', id, columnId, value: ev.target.value });
  }
  const getStyleColumn = (pColumn, pRow) => {
    const styles = pRow?.extraData?.style ?? [];
    return styles.find(el => el.column === pColumn)?.value ?? {};
  }
  const getColumnContent = (pColumn, pRow) => {
    const { id, align, disablepadding, label, sort, type } = pColumn;
    const value = pRow?.[id] ?? '';
    const style = getStyleColumn(id, pRow);
    if (type !== 'button') {
      switch (type) {
        case 'input':
          return <TextField className='border-1 w-60' value={value}
                onChange={eventHandlerChanged(pRow.id, id)}/>;
        case 'check':
          return <input type='checkbox'/>;
        case 'text':
          return <p style={{...style}} className='whitespace-no-wrap'>{value}</p>;
        case 'ellipsisText':
          return (
            <p style={{...style, width: '20%', textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap'}}>{value}</p>
          );
        case 'boolean':
          return (
            <i
              className={clsx(
                'inline-block w-8 h-8 rounded mx-8',
                !value && 'bg-red',
                value && 'bg-green',
              )}
            />
          );
        case 'image':
          return (
            <img alt='' style={{ cursor: 'pointer', width: '100px', maxHeight: '100px', margin: '10px' }} src={value} />
          );
        case 'carousel':
          return (
            <Carousel autoPlay={false} transitionTime="2000" showThumbs={false} width="250px">
              {value == null ? "" : value.map((k, i) =>
                <div key={i}>
                  <img alt='' style={{ width: '200px', height: '150px', margin: 'auto' }} src={value[i]} />
                </div>
              )}
            </Carousel>
          );
        case 'component':
          return value;
        default:
          return value;
      }
    } else if (type === 'button') {
      switch (id) {
        case 'add':
          return (
            <Button
              className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit"
              onClick={eventHandlerButton(id, pRow.id)}
              tabIndex="0" type="button" title="Add">
              <span className="MuiIconButton-label">
                <span className="material-icons MuiIcon-root" aria-hidden="true">add</span>
              </span>
              <span className="MuiTouchRipple-root"></span>
            </Button>
          );
        case 'clone':
          return (
            <Button
              className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit"
              onClick={eventHandlerButton(id, pRow.id)}
              tabIndex="0" type="button" title="Copy">
              <span className="MuiIconButton-label">
                <span className="material-icons MuiIcon-root" aria-hidden="true">copy</span>
              </span>
              <span className="MuiTouchRipple-root"></span>
            </Button>
          );
        case 'edit':
          return (
            <Button
              className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit"
              onClick={eventHandlerButton(id, pRow.id)}
              tabIndex="0" type="button" title="Edit">
              <span className="MuiIconButton-label">
                <span className="material-icons MuiIcon-root" aria-hidden="true">edit</span>
              </span>
              <span className="MuiTouchRipple-root"></span>
            </Button>
          );
        case 'delete':
          return (
            <Button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
              onClick={eventHandlerButton(id, pRow.id)}
              // disabled={n.isAppDeal} //peinding
              tabIndex='0' type='button' title='Delete'>
              <span className='MuiIconButton-label'>
                <span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
              </span>
              <span className='MuiTouchRipple-root'></span>
            </Button>
          );
        case 'generate':
            return (<Button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
              onClick={eventHandlerButton(id, pRow.id)}
              // disabled={n.isAppDeal} //peinding
              disabled={style.disabled ?? false}
              tabIndex='0' type='button' title={label}>
              <span className='MuiIconButton-label'>
                <span className="material-icons MuiIcon-root" aria-hidden="true">save</span>
              </span>
              <span className='MuiTouchRipple-root'></span>
            </Button>)
        case 'upward':
          return (
            <Button
              className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit"
              onClick={eventHandlerButton(id, pRow.id)}
              tabIndex="0" type="button" title="Order">
              <span className="MuiIconButton-label">
                <span className="material-icons MuiIcon-root" aria-hidden="true">arrow_upward</span>
              </span>
              <span className="MuiTouchRipple-root"></span>
            </Button>
          );
        default:
          return (
            <Button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
              onClick={eventHandlerButton(id, pRow.id)}
              // disabled={n.isAppDeal} //peinding
              tabIndex='0' type='button' title={label}>
              <span className='MuiIconButton-label'>
                <span className='material-icons MuiIcon-root' aria-hidden='true'>information</span>
              </span>
              <span className='MuiTouchRipple-root'></span>
            </Button>
          );
      }
    }
  }
  const addColmuns = pRow => {
    const rowContent = showColumns.map(col => {
      return (
        col.show !== 'hide' && <TableCell
          key={col.id}
          className={clsx('w-40 md:w-64 z-99', showSplite(col.id) && 'border-r-1')}
          component='td'
          scope='row'
          align={col.align}
          onClick={eventHandlerColumn(col.id, pRow.id)}
        >
          {getColumnContent(col, pRow)}
        </TableCell>
      );
    })
    return rowContent;
  }
  return (
    <TableBody>
      {bodyRows?.length>0 && bodyRows.map((row, idx) => {
        return (
          <TableRow
            className='h-64 cursor-pointer'
            hover
            tabIndex={-1}
            key={idx}
            style={{backgroundColor: row?.background ?? 'white'}}
          >
            {addColmuns(row)}
          </TableRow>
        );
      })}
    </TableBody>
  );
}

export default memo(InsideTableBody);