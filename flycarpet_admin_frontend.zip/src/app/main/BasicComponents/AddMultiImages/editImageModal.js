import React, { useEffect, useState, memo, useCallback } from 'react';
import { makeStyles } from '@material-ui/core/styles';

import {
  Modal, Fade, Grid, Backdrop, Button, TextField,
  FormHelperText, FormControl, FormControlLabel, Select, Checkbox,
} from '@material-ui/core';


import AddImage from 'app/main/BasicComponents/AddImage';

const EditorModal = (props) => {
  const { open, extraData, onMessage: sendMessage } = props;

  const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: '2px 5px',
      minWidth: 60,
    },
    modal: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      textAlign: "center",
      maxHeight: "100vh",
      overflowY: "auto",
    },
    checkboxform: {
      display: 'block',
    },
  }));
  const classes = useStyles();

  const [openEdit, setOpenEdit] = useState(false);
  const handleCloseModal = () => {
    setOpenEdit(false);
    sendMessage({
      type: 'action',
      action: 'close',
    });
  }
  const handleSave = () => {
    sendMessage({
      type: 'action',
      action: action === 'Update' ? 'update' : 'save',
      extraData: {
        imageData,
      }
    })
  }

  const [action, setAction] = useState('Add');
  const [disabledSave, setDisabledSave] = useState(true);
  const [buttonText, setButtonText] = useState('');
  const [showCaption, setShowCaption] = useState(true);

  const [imageData, setImageData] = useState(null);
  const receiveMessageFromAddImage = useCallback((pType, pMsg) => {
    switch (pType) {
      case 'changedImage': case 'changedCaption':
        setImageData({ ...imageData, ...pMsg });
        break;
      default:
    }
  }, [imageData]);

  const setPickedState = (pData) => {
    setAction('Update');
    setImageData(pData);
  }

  useEffect(() => {
    const data = extraData?.editData ?? null;
    setShowCaption(extraData?.showCaption ?? true);
    if (data) {
      setPickedState(data);
      setButtonText('Edit Image');
    } else {
      initialize();
      setButtonText('Add Image')
    }
    setOpenEdit(open);
  }, [open, extraData]);

  useEffect(() => {
    if (imageData && (imageData.file !== null || imageData.Url !== '')) {
      setDisabledSave(false);
    } else {
      setDisabledSave(true);
    }
  }, [imageData])

  const initialize = () => {
    setButtonText('');
    setImageData({
      Url: '',
      image: '',
      href: '',
      file: null,
      caption: '',
    });
  }
  useEffect(() => {
    initialize();
  }, []);


  return (
    <div className="w-full flex flex-col">
      <Modal
        open={openEdit}
        onClose={handleCloseModal}
        className={classes.modal}
        closeAfterTransition
        aria-labelledby='transition-modal-title'
        aria-describedby='transition-modal-description'
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Fade in={openEdit}>
          <div className={classes.paper}>
            <h2 id="transition-modal-title" style={{ textAlign: 'center' }}>Content {buttonText}</h2>
            <Grid container style={{ display: 'flow-root', maxWidth: '500px', maxHeight: '500px', overflowY: 'auto', overflowX: 'hidden' }}>
              <FormControl className='mt-20'>
                <AddImage
                  imageData={imageData}
                  extraData={{ showCaption, singleImage: false }}
                  onMessage={receiveMessageFromAddImage}
                />
              </FormControl>
            </Grid>
            <Grid container justify='space-around'>
              <Button className="whitespace-no-wrap normal-case"
                variant="contained"
                color="primary"
                disabled={disabledSave}
                onClick={handleSave}>{action}
              </Button>
              <Button className="whitespace-no-wrap normal-case"
                variant="contained"
                color="secondary"
                onClick={handleCloseModal}>Close
              </Button>
            </Grid>
          </div>
        </Fade>
      </Modal>
    </div>
  );
}

export default memo(EditorModal);

