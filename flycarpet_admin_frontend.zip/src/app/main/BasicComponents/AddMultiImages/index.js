import React, { useState, useEffect, memo } from 'react'

import { FormControl, IconButton, Button, Grid } from '@material-ui/core'
import SyncAltIcon from '@material-ui/icons/SyncAlt';
import { makeStyles } from '@material-ui/core/styles'

import CircularProgress from '@material-ui/core/CircularProgress';

import EditImageModal from './editImageModal';


const AddMultiImages = (props) => {
  const { imageData, onMessage: sendMessage, extraData } = props;

  const useStyles = makeStyles((theme) => ({
    subComponent: {
      marginTop: '5px',
      maxWidth: '500px',
    },
    formControl: {
      margin: theme.spacing(0, 1),
      minWidth: 120,
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      textAlign: "center",
      maxHeight: "100vh",
      overflowY: "auto",
    },
    textFiled: {
      width: '100%'
    },
    deleteImage: {
      position: 'absolute',
      top: '1px',
      right: '7px',
      color: '#fff',
      background: '#ff4081',
      borderRadius: '50%',
      textAign: 'center',
      cursor: 'pointer',
      fontSize: '17px',
      fontWeight: 'bold',
      lineHeight: '20px',
      width: '20px',
      height: '20px'
    },
    imageUploader: {
      maxWidth: '500px',
    },
    button_group: {
      padding: 30,
      display: 'flex',
    },
    buttons: {
      margin: 'auto',
    },
  }));

  const classes = useStyles();

  const [listImages, setListImages] = useState([]);
  const [showCaption, setShowCaption] = useState(false);
  const [enableArrange, setEnableArrange] = useState(false);
  const [pickedData, setPickedData] = useState(null);
  const [pickedIndex, setPickedIndex] = useState(-1);

  const [loadingCircle, setLoadingCircle] = useState(true);

  const [openEditModal, setOpenEditModal] = useState(false);
  const onMessageEditModal = (pMsg) => {
    if (pMsg.type === 'action') {
      switch (pMsg.action) {
        case 'save': case 'update':
          saveItem(pMsg.extraData);
          break;
        case 'close':
          break;
        default:
          console.log(`missed the handle of ${pMsg.type}`)
      }

      setOpenEditModal(false);
    }
  }
  const saveItem = async (pData) => {
    const { imageData: image } = pData;
    let images = [...listImages];
    if (pickedData === null) { // create
      images.push(image);
    } else { //update
      if (pickedIndex > -1) {
        images[pickedIndex] = image;
        setPickedData(null);
        setPickedIndex(-1);
      }
    }
    setListImages(images);
    sendMessage({
      type: 'update',
      images
    });
  }

  const editOneImage = (pIdx) => {
    setPickedData(listImages[pIdx]);
    setPickedIndex(pIdx);
    setOpenEditModal(true);
  }

  const deleteImage = (index) => {
    let images = listImages.filter((e, n) => n !== index);
    setListImages(images);
    sendMessage({
      type: 'update',
      images
    });
  }

  const onChangeImageOrder = (idx) => {
    const images = [...listImages];
    const prevImage = images[idx];
    const nextImage = images[idx + 1];
    images[idx] = nextImage;
    images[idx + 1] = prevImage;
    setListImages(images);

    sendMessage({
      type: 'update',
      images
    });
  }

  const addNewImage = () => {
    setOpenEditModal(true);
  }

  useEffect(() => {
    setShowCaption(extraData?.showCaption ?? false);
    setEnableArrange(extraData?.enableArrange ?? false);
    if (imageData.imageData.length === 0) {
      setLoadingCircle(false);
    } else {
      setListImages(imageData.imageData);
    }
  }, [extraData, imageData]);

  useEffect(() => {
    if (listImages.length > 0 && loadingCircle) setLoadingCircle(false)
  }, [listImages]);

  const initialize = () => {

  }
  useEffect(() => {
    initialize();
  }, []);

  return (
    <div className={classes.subComponent}>
      {(!imageData || imageData?.title === '') ? '' :
        <div style={{ textAlign: 'left' }}>
          <h4 id='update-image' >{imageData?.title ?? ''}</h4>
        </div>
      }
      <div className={classes.border_style}>
        {loadingCircle ? <div className={classes.fo_circular}> <CircularProgress className='w-xs max-w-full' color='secondary' /> </div> : ''}
        <div style={{ display: '-webkit-inline-box', overflow: 'auto' }}>
          {listImages.map((n, j) =>
            <Grid container display="flex" alignItems="center" key={j} style={{ width: 'fit-content' }}>
              <Grid item style={{ position: 'relative' }} >
                <button className={classes.deleteImage} onClick={(e) => deleteImage(j)}>X</button>
                {n.file && n.Url === '' ?
                  <img alt='' style={{ width: '100px', height: 'auto', maxHeight: '100px', margin: '10px' }} src={URL.createObjectURL(n.file)} onClick={(e) => editOneImage(j)} />
                  :
                  <img alt='' style={{ width: '100px', height: 'auto', maxHeight: '100px', margin: '10px' }} src={n.Url} onClick={(e) => editOneImage(j)} />
                }
              </Grid>
              {
                (!enableArrange) ? '' :
                  (
                    (listImages.length - 1 === j) ? '' :
                      <IconButton edge="end" aria-label="Replace order" onClick={(e) => onChangeImageOrder(j)}>
                        <SyncAltIcon />
                      </IconButton>
                  )
              }
            </Grid>
          )}
        </div>
        <div className={classes.button_group}>
          <Button className={classes.buttons} variant="contained" onClick={addNewImage} color="primary">
            Add New Image
          </Button>
        </div>
        <EditImageModal
          open={openEditModal}
          extraData={{ editData: pickedData, showCaption }}
          onMessage={onMessageEditModal}
        />
      </div>
    </div>
  )
};

export default memo(AddMultiImages);