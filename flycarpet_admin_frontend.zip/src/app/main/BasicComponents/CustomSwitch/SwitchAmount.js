import React, { memo, useState, useEffect } from 'react';
import {
  FormControl,
  TextField,
  InputAdornment,
  Switch,
  Typography
} from '@material-ui/core';
import { styled } from '@material-ui/core/styles';

const MaterialUISwitch = styled(Switch)(({ theme }) => ({
  width: 80,
  height: 34,
  padding: 7,
  '& .MuiSwitch-switchBase': {
    margin: 1,
    padding: 0,
    transform: 'translateX(6px)',
    '&.Mui-checked': {
      color: '#fff',
      transform: 'translateX(40px)',
      '& .MuiSwitch-thumb:before': {
        backgroundImage: `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 24 24"><path fill="${encodeURIComponent(
          theme.palette.getContrastText(theme.palette.primary.main),
        )}" d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z"/></svg>')`,
      },
      '& + .MuiSwitch-track': {
        opacity: 1,
        backgroundColor: theme.palette.mode === 'dark' ? '#8796A5' : '#aab4be',
      },
    },
  },
  '& .MuiSwitch-thumb': {
    backgroundColor: theme.palette.mode === 'dark' ? '#003892' : '#001e3c',
    width: 32,
    height: 32,
    '&:before': {
      content: "''",
      position: 'absolute',
      width: '100%',
      height: '100%',
      left: 0,
      top: 0,
      backgroundRepeat: 'no-repeat',
      backgroundPosition: 'center',
      backgroundImage: `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 24 24"><path fill="${encodeURIComponent(
        theme.palette.getContrastText(theme.palette.primary.main),
      )}" d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z"/></svg>')`,
    },
  },
  '& .MuiSwitch-track': {
    opacity: 1,
    backgroundColor: theme.palette.mode === 'dark' ? '#8796A5' : '#aab4be',
    borderRadius: 20 / 2,
  },
}));

const SwitchAmount = (props) => {

  const { reset, units, onMessage } = props;

  const [sActiveUnit, setActiveUnit] = useState(units[0]);
  const [sAmountToReduce, setAmountToReduce] = useState(0);

  const changeUnit = (evt) => {
    const actUnit = evt.target.checked ? units[1] : units[0];
    setActiveUnit(actUnit);
    setAmountToReduce(0);
    onMessage('changedUnit', {
      data: { amount: 0, unit: actUnit },
    })
  }

  const changeAmount = (evt) => {
    let value = Math.round(evt.target.value);
    if (value < 0) value = 0;
    if (sActiveUnit === '%' && value > 100) value = 100;
    setAmountToReduce(value);
    onMessage('changedAmount', {
      data: { amount: value, unit: sActiveUnit }
    });
  }

  const initialize = () => {
    setActiveUnit(units[0]);
    setAmountToReduce(0);
  };

  useEffect(() => {
    if (reset) initialize();
    // eslint-disable-next-line
  }, [reset])

  return (
    <FormControl required >
      <div style={{ display: 'flex' }}>
        <TextField
          type='number'
          min='0'
          label="Amount To Reduce"
          id="standard-start-adornment"
          value={sAmountToReduce}
          sx={{ m: 1, width: '15ch' }}
          InputProps={{
            startAdornment: <InputAdornment position="start">{sActiveUnit}</InputAdornment>,
          }}
          variant="standard"
          onChange={changeAmount}
        />
        <div direction="row" spacing={1} alignitems="center" style={{ display: 'flex', alignSelf: 'flex-end', marginLeft: '15px' }}>
          <Typography className='mt-8'>{units[0]}</Typography>
          <MaterialUISwitch inputProps={{ 'aria-label': 'ant design' }} onChange={changeUnit} checked={sActiveUnit === units[1]} />
          <Typography className='mt-8'>{units[1]}</Typography>
        </div>
      </div>
    </FormControl>
  );
};

export default memo(SwitchAmount);