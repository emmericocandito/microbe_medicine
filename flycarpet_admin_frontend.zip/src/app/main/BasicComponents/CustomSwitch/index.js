import SwitchAmount from './SwitchAmount';

export { SwitchAmount };