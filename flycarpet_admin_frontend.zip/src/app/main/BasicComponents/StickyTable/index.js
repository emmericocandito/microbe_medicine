import React, { memo, useEffect, useMemo } from "react";
import styled from "styled-components";
import { useTable, useBlockLayout, useRowSelect, useFilters, useGlobalFilter, useAsyncDebounce } from "react-table";
import { useSticky } from "react-table-sticky";
import { matchSorter } from 'match-sorter';

const Styles = styled.div`
  padding: 1rem;
  width: 100%;
  height: 500px;
  overflow: hidden;

  .table {
    border: 1px solid #ddd;
    width: 100%;
    height: 480px;
    display: block;

    .tr {
      width: 100%;

      :last-child {
        .td {
          border-bottom: 0;
        }
      }
    }

    .th,
    .td {
      padding: 5px;
      border-bottom: 1px solid #ddd;
      border-right: 1px solid #ddd;
      background-color: #fff;
      overflow: hidden;
      display: flex !important;

      :last-child {
        border-right: 0;
      }

      .resizer {
        display: inline-block;
        width: 5px;
        height: 100%;
        position: absolute;
        right: 0;
        top: 0;
        transform: translateX(50%);
        z-index: 1;

        &.isResizing {
          background: red;
        }
      }
    }

    &.sticky {
      overflow: scroll;
      .header,
      .footer {
        position: sticky;
        z-index: 1;
      }

      .header {
        top: 0;
        box-shadow: 0px 3px 3px #ccc;
      }

      .footer {
        bottom: 0;
        box-shadow: 0px -3px 3px #ccc;
      }

      .body {
        position: relative;
        z-index: 0;
      }

      [data-sticky-td] {
        position: sticky;
      }

      [data-sticky-last-left-td] {
        box-shadow: 2px 0px 3px #ccc;
      }

      [data-sticky-first-right-td] {
        box-shadow: -2px 0px 3px #ccc;
      }
    }
  }
`;

const IndeterminateCheckbox = React.forwardRef(
  ({ indeterminate, ...rest }, ref) => {
    const defaultRef = React.useRef()
    const resolvedRef = ref || defaultRef

    React.useEffect(() => {
      resolvedRef.current.indeterminate = indeterminate
    }, [resolvedRef, indeterminate])

    return (
      <>
        <input type="checkbox" ref={resolvedRef} {...rest} />
      </>
    )
  }
)

// Define a default UI for filtering
function GlobalFilter({
  preGlobalFilteredRows,
  globalFilter,
  setGlobalFilter,
}) {
  const count = preGlobalFilteredRows.length
  const [value, setValue] = React.useState(globalFilter)
  const onChange = useAsyncDebounce(value => {
    setGlobalFilter(value || undefined)
  }, 200)

  return (
    <span>
      Search:{' '}
      <input
        value={value || ""}
        onChange={e => {
          setValue(e.target.value);
          onChange(e.target.value);
        }}
        placeholder={`${count} records...`}
        style={{
          fontSize: '1.1rem',
          border: '0',
        }}
      />
    </span>
  )
}

// Define a default UI for filtering
function DefaultColumnFilter({
  column: { filterValue, preFilteredRows, setFilter },
}) {
  const count = preFilteredRows.length

  return (
    <input
      value={filterValue || ''}
      onChange={e => {
        setFilter(e.target.value || undefined) // Set undefined to remove the filter entirely
      }}
      placeholder={`Search ${count} records...`}
    />
  )
}

function fuzzyTextFilterFn(rows, id, filterValue) {
  return matchSorter(rows, filterValue, { keys: [row => row.values[id]] })
}

// Let the table remove the filter if the string is empty
fuzzyTextFilterFn.autoRemove = val => !val

function StickyTable(props) {
  const { columns, data, Option, extraData, onMessage: sendMessage } = props;
  const showHeader = extraData?.showHeader ?? true;
  const showFooter = extraData?.showFooter ?? true;

  const defaultOption = {
    minWidth: 50,
    width: 50,
    maxWidth: 400,
    // Filter: DefaultColumnFilter,
  };
  const defaultColumn = useMemo(() => Object.assign(defaultOption, Option), []);

  const defaultSelectedRowIds = useMemo(
    () => {
      let ids = {};
      data.forEach((row, idx) => {
        ids[idx] = row.pick;
      })
      return ids;
    }, []
  )
  const filterTypes = React.useMemo(
    () => ({
      // Add a new fuzzyTextFilterFn filter type.
      fuzzyText: fuzzyTextFilterFn,
      // Or, override the default text filter to use
      // "startWith"
      text: (rows, id, filterValue) => {
        return rows.filter(row => {
          const rowValue = row.values[id]
          return rowValue !== undefined
            ? String(rowValue)
              .toLowerCase()
              .startsWith(String(filterValue).toLowerCase())
            : true
        })
      },
    }),
    []
  )
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
    selectedFlatRows,
    preGlobalFilteredRows,
    setGlobalFilter,
    state: { selectedRowIds },
  } = useTable(
    {
      columns,
      data,
      defaultColumn,
      filterTypes,
      initialState: { selectedRowIds: defaultSelectedRowIds }
    },
    useBlockLayout,
    useSticky,
    useFilters,
    useGlobalFilter,
    useRowSelect,
    // hooks => {
    //   hooks.visibleColumns.push(columns => [
    //     // Let's make a column for selection
    //     {
    //       id: 'selection',
    //       sticky: "left",
    //       // The header can use the table's getToggleAllRowsSelectedProps method
    //       // to render a checkbox
    //       Header: ({ getToggleAllRowsSelectedProps }) => (
    //         <div>
    //           <IndeterminateCheckbox {...getToggleAllRowsSelectedProps()} />
    //         </div>
    //       ),
    //       // The cell can use the individual row's getToggleRowSelectedProps method
    //       // to the render a checkbox
    //       Cell: ({ row }) => {
    //         console.log(row);
    //         return (
    //           <div>
    //             <IndeterminateCheckbox {...row.getToggleRowSelectedProps()} />
    //           </div>
    //         )
    //       },
    //     },
    //     ...columns,
    //   ])
    // }
  );

  // Workaround as react-table footerGroups doesn't provide the same internal data than headerGroups
  const footerGroups = headerGroups.slice().reverse();

  useEffect(() => {
    let ids = [];
    for (const [idx, pick] of Object.entries(selectedRowIds)) {
      if (pick) ids.push(Number(data[Number(idx)].id));
    }
    sendMessage({
      type: 'action',
      action: 'pickMulti',
      extraData: {
        selectedRowIds: ids,
      }
    });
  }, [selectedRowIds])

  return (
    <Styles>
      <div
        {...getTableProps()}
        className="table sticky"
      >
        {
          showHeader === true ?
            <div className="header">
              {headerGroups.map(headerGroup => (
                <div {...headerGroup.getHeaderGroupProps()} className="tr">
                  {headerGroup.headers.map(column => (
                    <div {...column.getHeaderProps()} className="th">
                      <div className="m-auto">
                        {column.render("Header")}
                        {column.canFilter ? <div className="border-2 rounded-6">{column.render('Filter')}</div> : null}
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div> : null
        }

        <div {...getTableBodyProps()} className="body">
          {rows.map((row, i) => {
            prepareRow(row);
            return (
              <div {...row.getRowProps()} className="tr">
                {row.cells.map(cell => {
                  return (
                    <div {...cell.getCellProps()} className="td">
                      <div className="m-auto">
                        {cell.render("Cell")}
                      </div>
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>
        {
          showFooter === true ?
            <div className="footer">
              {footerGroups.map(footerGroup => (
                <div {...footerGroup.getHeaderGroupProps()} className="tr">
                  {footerGroup.headers.map(column => (
                    <div {...column.getHeaderProps()} className="td">
                      <div className="m-auto">
                        {column.render("Footer")}
                      </div>
                    </div>
                  ))}
                </div>
              ))}
            </div> : null
        }
      </div>
    </Styles>
  );
}

export default memo(StickyTable);