import React, { useState, useEffect, memo } from 'react'

import { FormControl, IconButton, Button, Grid } from '@material-ui/core'
import SyncAltIcon from '@material-ui/icons/SyncAlt';
import { makeStyles } from '@material-ui/core/styles'

import CircularProgress from '@material-ui/core/CircularProgress';

import EditFileModal from './editFileModal';


const uploadFiles = (props) => {
  const { fileData, onMessage: sendMessage, extraData } = props;

  const useStyles = makeStyles((theme) => ({
    
    subComponent: {
      marginTop: '5px',
      maxWidth: '500px',
    },
    formControl: {
      margin: theme.spacing(0, 1),
      minWidth: 120,
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      textAlign: "center",
      maxHeight: "100vh",
      overflowY: "auto",
    },
    textFiled: {
      width: '100%'
    },
    deleteFile: {
      position: 'absolute',
      top: '1px',
      right: '7px',
      color: '#fff',
      background: '#ff4081',
      borderRadius: '50%',
      textAign: 'center',
      cursor: 'pointer',
      fontSize: '17px',
      fontWeight: 'bold',
      lineHeight: '20px',
      width: '20px',
      height: '20px'
    },
    fileUploader: {
      maxWidth: '500px',
    },
    button_group: {
      padding: 30,
      display: 'flex',
    },
    buttons: {
      margin: 'auto',
    },
  }));

  const classes = useStyles();

  const [listFiles, setListFiles] = useState([]);
  const [showCaption, setShowCaption] = useState(false);
  const [enableArrange, setEnableArrange] = useState(false);
  const [pickedData, setPickedData] = useState(null);
  const [pickedIndex, setPickedIndex] = useState(-1);

  const [loadingCircle, setLoadingCircle] = useState(true);

  const [openEditModal, setOpenEditModal] = useState(false);
  const onMessageEditModal = (pMsg) => {
    if (pMsg.type === 'action') {
      switch (pMsg.action) {
        case 'save': case 'update':
          saveItem(pMsg.extraData);
          break;
        case 'close':
          break;
        default:
          console.log(`missed the handle of ${pMsg.type}`)
      }

      setOpenEditModal(false);
    }
  }
  const saveItem = async (pData) => {
    const { fileData: file } = pData;
    let files = [...listFiles];
    if (pickedData === null) { // create
      files.push(file);
    } else { //update
      if (pickedIndex > -1) {
        files[pickedIndex] = file;
        setPickedData(null);
        setPickedIndex(-1);
      }
    }
    setListFiles(files);
    sendMessage({
      type: 'update',
      files
    });
  }

  const editOneFile = (pIdx) => {
    setPickedData(listFiles[pIdx]);
    setPickedIndex(pIdx);
    setOpenEditModal(true);
  }

  const deleteFile = (index) => {
    let files = listFiles.filter((e, n) => n !== index);
    setListFiles(files);
    sendMessage({
      type: 'update',
      files
    });
  }

  const onChangeFileOrder = (idx) => {
    const files = [...listFiles];
    const prevFile = files[idx];
    const nextFile = files[idx + 1];
    files[idx] = nextFile;
    files[idx + 1] = prevFile;
    setListFiles(files);

    sendMessage({
      type: 'update',
      files
    });
  }

  const addNewFile = () => {
    setOpenEditModal(true);
  }

  useEffect(() => {
    setShowCaption(extraData?.showCaption ?? false);
    setEnableArrange(extraData?.enableArrange ?? false);
    if (fileData.fileData.length === 0) {
      setLoadingCircle(false);
    } else {
      setListFiles(fileData.fileData);
    }
  }, [extraData, fileData]);

  useEffect(() => {
    if (listFiles.length > 0 && loadingCircle) setLoadingCircle(false)
  }, [listFiles]);

  const initialize = () => {

  }
  useEffect(() => {
    initialize();
  }, []);

  return (
    <div className={classes.subComponent}>
      {(!fileData || fileData?.title === '') ? '' :
        <div style={{ textAlign: 'left' }}>
          <h4 id='update-file' >{fileData?.title ?? ''}</h4>
        </div>
      }
      <div className={classes.border_style}>
        {loadingCircle ? <div className={classes.fo_circular}> <CircularProgress className='w-xs max-w-full' color='secondary' /> </div> : ''}
        <div style={{ display: '-webkit-inline-box', overflow: 'auto' }}>
          {listFiles.map((n, j) =>
            <Grid container display="flex" alignItems="center" key={j} style={{ width: 'fit-content' }}>
              <Grid item style={{ position: 'relative' }} >
                <button className={classes.deleteFile} onClick={(e) => deleteFile(j)}>X</button>
                {n.file && n.Url === '' ?
                  <img alt='' style={{ width: '100px', height: 'auto', maxHeight: '100px', margin: '10px' }} src={URL.createObjectURL(n.file)} onClick={(e) => editOneFile(j)} />
                  :
                  <img alt='' style={{ width: '100px', height: 'auto', maxHeight: '100px', margin: '10px' }} src={n.Url} onClick={(e) => editOneFile(j)} />
                }
              </Grid>
              {
                (!enableArrange) ? '' :
                  (
                    (listFiles.length - 1 === j) ? '' :
                      <IconButton edge="end" aria-label="Replace order" onClick={(e) => onChangeFileOrder(j)}>
                        <SyncAltIcon />
                      </IconButton>
                  )
              }
            </Grid>
          )}
        </div>
        <div className={classes.button_group}>
          <Button className={classes.buttons} variant="contained" onClick={addNewFile} color="primary">
            Add New File
          </Button>
        </div>
        <EditFileModal
          open={openEditModal}
          extraData={{ editData: pickedData, showCaption }}
          onMessage={onMessageEditModal}
        />
      </div>
    </div>
  )
};

export default memo(uploadFiles);