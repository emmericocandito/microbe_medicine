import React, { useEffect, useState } from 'react';
import { Modal, Button } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';

import {
	Box, Grid,
	FormGroup, FormControlLabel, Checkbox
} from '@material-ui/core'

function MultiActionModal(props) {
	const { open, title, description, actionList, allSession, onMessage } = props;

	const useStyles = makeStyles((theme) => ({
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
			minWidth: 120
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			maxHeight: '650px',
			overflowY: 'auto'
		},
	}))
	const classes = useStyles();

	const [applyAllSession, setApplyAllSession] = useState(true);
	const [lines, setLines] = useState([]);

	const handleAction = (pCode) => {
		onMessage('selectAction', {
			code: pCode,
			allSession: allSession && applyAllSession,
		});
	}

	const closeModal = () => {
		onMessage('closeModal', {});
	}

	useEffect(() => {
		let multiLines = description.split(/[\n\r]+|<br\s*\/?>/i);
		setLines(multiLines);
	}, [description])

	return (
		<Modal
			open={open}
			onClose={closeModal}
			className={classes.modal}
			aria-labelledby='simple-modal-title'
			aria-describedby='simple-modal-description'
		>
			<Grid columns={{ xs: 8, md: 12 }} className={classes.paper} style={{ textAlign: 'center' }}>
				<h2 id='server-modal-title' >{title}</h2>
				{/* <p id='server-modal-description'>{description}</p> */}
				<div>
					{lines.map((line, index) => (
						<p key={index}>{line}</p>
					))}
				</div>
				{
					actionList.map((action, i) =>
						<Button className='whitespace-no-wrap normal-case'
							key={i}
							style={{ margin: '10px 5px' }}
							variant='contained'
							color='secondary'
							onClick={() => handleAction(action.code)}>{action.label}
						</Button>
					)
				}
				{
					allSession && (<FormGroup>
						<FormControlLabel control={<Checkbox checked={applyAllSession} onChange={() => setApplyAllSession(!applyAllSession)} />} label="please do this action for all in this session" />
					</FormGroup>)
				}
			</Grid>
		</Modal>
	);
}

export default React.memo(MultiActionModal);