import React, { useState, memo, useEffect } from 'react';
import {
  Modal, Fade,
  Box, Grid,
  FormGroup, FormControlLabel, FormControl, FormHelperText,
  Checkbox, Button, TextField,
} from '@material-ui/core'

import { makeStyles } from '@material-ui/core/styles';

function PropsModal(props) {
  const { open, title, propsList, data, onMessage: sendMessage } = props;

  const useStyles = makeStyles((theme) => ({
    modal: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      minWidth: 120
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      maxHeight: '650px',
      overflowY: 'auto'
    },
  }))
  const classes = useStyles();

  const [stateAction, setStateAction] = useState('');

  const changeProperty = (ev, id) => {
    console.log('pending', ev, id);
  }

  const contentProperty = (prop, idx) => {
    const { id, type, label, data } = prop;
    switch (type) {
      case 'text':
        return (
          <Grid item>
            <FormControl required className={classes.formControl}>
              <FormHelperText>{label}</FormHelperText>
              <div dir='rtl'>
                <TextField defaultValue={data} className={classes.textfield} onChange={ev => changeProperty(ev, id)} />
              </div>
            </FormControl>
          </Grid>
        )
      default:
        return (
          <Grid item>
            <FormControl required className={classes.formControl}>
              <FormHelperText>{label}</FormHelperText>
              <div dir='rtl'>
                <TextField defaultValue={data} className={classes.textfield} onChange={ev => changeProperty(ev, id)} />
              </div>
            </FormControl>
          </Grid>
        )
    }
  }

  const editProcess = () => {
    console.log('pending edit');
  }

  const closeModal = () => {
    sendMessage('closeModal', {});
  }

  return (
    <Modal
      open={open}
      onClose={closeModal}
      className={classes.modal}
      aria-labelledby='simple-modal-title'
      aria-describedby='simple-modal-description'
    >
      <Grid container>
        <Grid container columns={{ xs: 8, md: 12 }} className={classes.paper} justify="center">
          <h2 id='server-modal-title' >{title}</h2>
          <Grid container justify='space-around'>
            {
              propsList?.map((prop, i) => contentProperty(props, i))
            }
          </Grid>
        </Grid>
        <Grid container>
          <Button className={classes.buttons} variant="contained" onClick={editProcess} color="secondary">
            {stateAction}
          </Button>
          <Button className={classes.buttons} variant="contained" color="primary" onClick={closeModal}>
            Cancel
          </Button>
        </Grid>
      </Grid>
    </Modal>
  )
}

export default memo(PropsModal);