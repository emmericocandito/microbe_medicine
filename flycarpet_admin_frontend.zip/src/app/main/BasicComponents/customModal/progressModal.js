import React, { useState, memo, useEffect } from 'react';
import PropTypes from 'prop-types';
import {
  Modal, Fade,
  Box, Grid,
  Checkbox, Button, TextField,
  Typography,
  LinearProgress,
} from '@material-ui/core'

import { makeStyles, withStyles } from '@material-ui/core/styles';

const BorderLinearProgress = withStyles((theme) => ({
  root: {
    height: 10,
    borderRadius: 5,
  },
  colorPrimary: {
    backgroundColor: theme.palette.grey[theme.palette.type === 'light' ? 200 : 700],
  },
  bar: {
    borderRadius: 5,
    backgroundColor: '#1a90ff',
  },
}))(LinearProgress);

function LinearProgressWithLabel(props) {
  return (
    <Box display="flex" alignItems="center">
      <Box width="100%" mr={1}>
        <LinearProgress variant="determinate" {...props} color="secondary" />
      </Box>
      <Box minWidth={35}>
        <Typography variant="body2" color="textSecondary">{`${Math.round(
          props.value,
        )}%`}</Typography>
      </Box>
    </Box>
  );
}

LinearProgressWithLabel.propTypes = {
  value: PropTypes.number.isRequired,
};

function ProgressModal(props) {
  const { open, title, description, data, onMessage: sendMessage } = props;

  const useStyles = makeStyles((theme) => ({
    modal: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      minWidth: 120
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      maxHeight: '200px',
      overflowY: 'auto',
      position: 'absolute',
      bottom: '40px',
      width: '95%',
    },
  }))
  const classes = useStyles();

  const generateProgressState = () => {
    const { processed, buffer, success, all } = props.data;
    const percent = success / all * 100;
    const bufferPercent = buffer / all * 100;
    return (
      <Box width="100%" mr={1}>
        <LinearProgressWithLabel variant="buffer" value={percent} valueBuffer={bufferPercent} />
      </Box>
    );
  }

  const closeModal = () => {
    sendMessage('closeModal', {});
  }

  return open ? (
    <Grid>
      <Grid container columns={{ xs: 8, md: 12 }} className={classes.paper} justify="center">
        <h2 id='server-modal-title' >{title}</h2>
        <Grid container justify='space-around'>
          {generateProgressState()}
        </Grid>
        {description}
      </Grid>
    </Grid>
  ) : (null);
}

export default memo(ProgressModal);