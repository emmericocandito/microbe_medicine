import React, { memo, useEffect, useState } from 'react';

import {
  Radio, RadioGroup, FormControlLabel, FormControl, FormLabel,
} from '@material-ui/core'
import { makeStyles } from '@material-ui/core/styles';

const RadioGroupKind = props => {
  const {
    title,
    options,
    value,
    direction,
    onMessage,
  } = props;

  const [groupValue, setGroupValue] = useState(value);

  const useStyles = makeStyles(theme => ({
    formControl: {
      margin: theme.spacing(1, 1),
    }
  }));
  const classes = useStyles();

  const handleChange = (ev) => {
    console.log(ev.target.value);
    onMessage({
      kind: 'changeValue',
      value: ev.target.value,
    });
    setGroupValue(ev.target.value);
  }

  return (
    <FormControl className={classes.formControl}>
      <FormLabel>{title}</FormLabel>
      <RadioGroup
        row={direction === 'row'}
        aria-labelledby='radio-buttons-group'
        name='row-radio-buttons-group'
        value={groupValue}
        onChange={handleChange}
      >
        {options.map((opt, i) => (
          <FormControlLabel key={i} value={opt.value} control={<Radio />} label={opt.label} />
        ))}
      </RadioGroup>
    </FormControl>
  );
}

export default memo(RadioGroupKind);