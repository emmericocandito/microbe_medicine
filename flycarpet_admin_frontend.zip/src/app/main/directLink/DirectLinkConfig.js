// import { authRoles } from 'app/auth';
import PublishPriceOffline from './publishPriceOffline';

const DirectLinkConfig = {
	settings: {
		layout: {
			config: {
				navbar: {
					display: false
				},
				toolbar: {
					display: false
				},
				footer: {
					display: false
				},
				leftSidePanel: {
					display: false
				},
				rightSidePanel: {
					display: false
				}
			}
		}
	},
	// auth: authRoles.onlyGuest,
	routes: [
		{
			path: '/publish_prices_offline',
			component: PublishPriceOffline
		}
	]
};

export default DirectLinkConfig;
