import FuseAnimate from '@fuse/core/FuseAnimate';
import { makeStyles } from '@material-ui/core/styles';
import { Card, CardContent, Typography, Button, TextField, Grid, FormControl } from '@material-ui/core';
import { darken } from '@material-ui/core/styles/colorManipulator';
import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import { useParams, useLocation } from 'react-router-dom';
import axios from 'axios';
import { baseURL } from 'app/main/utils';

const PublishPriceOffline = (props) => {
	const { search } = useLocation();
	const params = new URLSearchParams(search);
	const flightId = params.get('flightId');
	const flightClass = params.get('flightClass');
	const publishToken = params.get('publishToken');

	const [disabledSave, setDisabledSave] = useState(!flightId);
	const [currencyIsoCode, setCurrencyIsoCode] = useState(params.get('currencyIsoCode') || 'EUR');
	const [priceAdl, setPriceAdl] = useState(Number(params.get('priceAdl') || ''));
	const [priceChd, setPriceChd] = useState(Number(params.get('priceChd') || ''));
	const [priceInf, setPriceInf] = useState(Number(params.get('priceInf') || ''));

	const useStyles = makeStyles(theme => ({
		root: {
			background: `linear-gradient(to left, ${theme.palette.primary.dark} 0%, ${darken(
				theme.palette.primary.dark,
				0.5
			)} 100%)`,
			color: theme.palette.primary.contrastText
		},
		formControl: {
			margin: '2px 15px',
			minWidth: '240px',
		},
		textFiled: {
			width: '100%'
		},
	}));
	const classes = useStyles();

	const handlePublish = async () => {
		const data = {
			flightId, flightClass,
			price: { currencyIsoCode, priceAdl, priceChd, priceInf },
			publishToken,
		}

		const response = await axios.post(baseURL + 'api/pricing/publish/citizenPlane/offline', data);
		if(response.data.error) {
			alert("Failed to publish prices." + '\n' + response.data.error.message);
		} else {
			alert("Prices published successfully.");
		}
	}

	return (
		<div
			className={clsx(
				classes.root,
				'flex flex-col flex-auto items-center justify-center flex-shrink-0 p-16 md:p-24'
			)}
		>
			<div style={{ marginBottom: '30px' }}>
				<h1>{`Publish Netto`}</h1>
			</div>
			<div className="flex w-360 md:max-w-3xl rounded-12 shadow-2xl overflow-hidden">
				<Card
					className={clsx(
						'flex flex-col w-full max-w-sm items-center justify-center'
					)}
					square
					elevation={0}
				>
					<CardContent className="flex flex-col items-center justify-center w-full py-48 w-360">
						<FuseAnimate delay={300}>
							<div className="flex flex-col items-center mb-32">
								<div className="flex">
									<img className="logo-icon w-48" src="assets/images/logos/fuse-1.png" alt="logo" />
									<div className="border-l-1 mr-4 w-1 h-40" />
									<div>
										<Typography className="text-24 font-800 logo-text" color="inherit">
											FLYING
										</Typography>
										<Typography
											className="text-16 tracking-widest -mt-8 font-700"
											color="textSecondary"
										>
											CARPET
										</Typography>
									</div>
								</div>

								<div>
									<Grid container justify='center' style={{ margin: '20px 5px', display: 'grid' }}>
										<FormControl required className={classes.formControl}>
											<TextField className={classes.textField} label="Currency" defaultValue={currencyIsoCode} InputProps={{readOnly: true,}}/>
										</FormControl>
										<FormControl required className={classes.formControl}>
											<TextField className={classes.textField} label="Adult Price" defaultValue={priceAdl} onChange={e => setPriceAdl(Number(e.target.value))} />
										</FormControl>
										<FormControl required className={classes.formControl}>
											<TextField className={classes.textField} label="Child Price" defaultValue={priceChd} onChange={e => setPriceChd(Number(e.target.value))} />
										</FormControl>
										<FormControl required className={classes.formControl}>
											<TextField className={classes.textField} label="Infant Price" defaultValue={priceInf} onChange={e => setPriceInf(Number(e.target.value))} />
										</FormControl>
									</Grid>
									<Grid container className='justify-center' style={{ marginTop: '30px' }}>
										<Button className="whitespace-no-wrap normal-case"
											variant="contained"
											color="primary"
											disabled={disabledSave}
											onClick={handlePublish}>Publish
										</Button>
									</Grid>
								</div>

							</div>
						</FuseAnimate>
					</CardContent>
				</Card>
			</div>
		</div>
	);
}


export default PublishPriceOffline;
