import React, { useCallback, createContext, useState } from "react";
import { statusResponse } from 'app/main/store/services/status';

const { STATUS_SUCCESS, STATUS_WARNING, STATUS_ERROR } = statusResponse;

export const SaveAllContext = createContext([]);

export const SaveAllContextProvider = ({ children }) => {
  const [sAllCount, setAllCount] = useState(0);
  const [sCount, setCount] = useState(0);
  const [sCountSuccess, setCountSuccess] = useState(0);
  const [sFire, setFire] = useState(false);
  const [applyAllAction, setApplyAllAction] = useState('');

  const initSaveAllState = () => {
    setCount(-1);
    setCountSuccess(0);
    setFire(false);
    setApplyAllAction('');
  };

  const fireSaveAll = () => {
    setCount(0);
    setCountSuccess(0);
    setFire(true);
    setApplyAllAction('');
  };

  const firedSave = (pState) => {
    if (!sFire) return;
    if (pState === STATUS_SUCCESS) setCountSuccess(sCountSuccess + 1);
    if (sCount + 1 > sAllCount) {
      initSaveAllState();
    } else {
      setCount(sCount + 1);
    }
  };

  const setEntireCountDeal = (pCount) => {
    setAllCount(pCount);
  };

  return (
    <SaveAllContext.Provider
      value={{
        fireState: sFire,
        countState: sCount,
        countSuccess: sCountSuccess,
        allCount: sAllCount,
        applyAllAction,
        setApplyAllAction,
        initSaveAllState,
        fireSaveAll,
        firedSave,
        setEntireCountDeal,
      }}
    >
      {children}
    </SaveAllContext.Provider>
  );
}