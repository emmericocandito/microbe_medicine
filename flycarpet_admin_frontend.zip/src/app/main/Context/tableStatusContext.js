import React, { useCallback, createContext, useState } from 'react';

export const TableStatusContext = createContext([]);

export const TableStatusContextProvider = ({ children }) => {
  const [statusTotal, setStatusTotal] = useState(0);
  const [statusPage, setStatusPage] = useState(0);
  const [statusRowsPerPage, setStatusRowsPerPage] = useState(10);
  const [statusOrder, setStatusOrder] = useState({
    direction: 'asc',
    id: null
  })

  const initTableStatus = () => {
    setStatusTotal(0);
    setStatusOrder({
      direction: 'asc',
      id: null
    });
    setStatusPage(0);
    setStatusRowsPerPage(10);
  }

  return (
    <TableStatusContext.Provider
      value={{
        statusTotal,
        statusPage,
        statusRowsPerPage,
        statusOrder,

        setStatusTotal,
        setStatusOrder,
        setStatusPage,
        setStatusRowsPerPage,
        initTableStatus,
      }}
    >
      {children}
    </TableStatusContext.Provider>
  )
}