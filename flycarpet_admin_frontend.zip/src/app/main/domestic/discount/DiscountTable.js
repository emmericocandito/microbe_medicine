import FuseScrollbars from '@fuse/core/FuseScrollbars';
import axios from 'axios';
import _ from '@lodash';
import {
	Checkbox, Table, TableBody, TableCell, TablePagination, TableRow, Modal,
	Backdrop, Fade, TextField, Button, Grid, Select, FormControl, FormHelperText, FormControlLabel,
	CircularProgress, TextareaAutosize, Input, MenuItem
} from '@material-ui/core';
import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import FuseLoading from '@fuse/core/FuseLoading';
import DiscountTableHead from './DiscountTableHead';
import { makeStyles } from '@material-ui/core/styles';
import SearchIcon from '@material-ui/icons/Search';
import { useBasicAgencyInfo } from 'app/main/store/hooks';
import { baseURL } from 'app/main/utils';

var suppliers = ["ATLANTIS", "GOC", "ISRO", "DAN", "MINI"];
function DiscountTable(props) {
	const languageCode = 'HEB';
	const useStyles = makeStyles((theme) => ({
		formControl: {
			margin: theme.spacing(0),
			// minWidth: 60,
			width: '100%',
			margin: '0px 5px'
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
			minWidth: 350
		},
		modal1: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
			minWidth: 350
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			minWidth: 450
		},
		discountboxform: {
			display: 'grid',
		},
		checkboxform: {
			margin: '0px',
			display: 'block',
		},
		button_group: {
			padding: 30,
			textAlign: 'center',
		},
		buttons: {
			marginLeft: '10px'
		},
		fo_circular: {
			textAlign: 'center',
			position: 'absolute',
			left: '50%',
			transform: 'translatex(-50%)'
		},
		ntextArea: {
			width: '100%',
			border: '1px solid gray',
			minHeight: '35px !important',
			'&:hover': {
				outlineColor: '#000000cf',
				borderRadius: '0'
			},
			'&:active': {
				outlineColor: '#000000cf',
				borderRadius: '0'
			},
			'&:focus': {
				outlineColor: '#000000cf !important',
				borderRadius: '0'
			},
		},
	}));
	const ITEM_HEIGHT = 48;
	const ITEM_PADDING_TOP = 8;
	const MenuProps = {
		PaperProps: {
			style: {
				maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
				width: 100,
			},
		},
	};
	const discountValue = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]

	const classes = useStyles();


	const [discountId, setDiscountId] = useState(null);

	const [nDestination, setDestination] = useState(null);
	const [nDestinationList, setDestinationList] = useState([]);

	const [nHotelList, setHotelList] = useState([]);
	const [nHotel, setHotel] = useState(null);

	const [nChainList, setChainList] = useState([]);
	const [nChain, setChain] = useState(null);

	const [nCategory, setCategory] = useState(null);

	const [nStartDate, setStartDate] = useState(null);
	const [nEndDate, setEndDate] = useState(null);

	const [nAgency, setAgency] = useState(null);
	const [nAgencyList, setAgencyList] = useState([]);

	const {
		basicNoAtnmAgencyInfo,
		fetchNoAtnmBasicAgencyInfo,
	} = useBasicAgencyInfo();

	const [discountH, setHomeDiscount] = useState(null);
	const [remarkH, setHomeRemark] = useState(null);

	const [discountM, setMimsharkDiscount] = useState(null);
	const [remarkM, setMimsharkRemark] = useState(null);

	const [nIsLatest, setIsLatest] = useState(false);

	const [loading, setLoading] = useState(true);
	const [loadingCircle, setLoadingCircle] = useState(false);
	const [selected] = useState([]);

	const [data, setData] = useState([]);
	const [dataLength, setDataLength] = useState(0)

	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);

	const [nButtonText, setButtonText] = useState(null);
	const [warningOpen, setWarningOpen] = useState(false);
	const [warningText, setWarningText] = useState(null);

	const [confirmText, setConfirmText] = useState(null);
	const [confirmOpen, setConfirmOpen] = useState(false);


	const [nFilterDestination, setFilterDestination] = useState(null);
	const [nFilterHotel, setFilterHotel] = useState(null);
	const [nFilterChain, setFilterChain] = useState(null);
	const [nFilterAgency, setFilterAgency] = useState(null);
	const [nFilterCategory, setFilterCategory] = useState(null)
	const [nFilterDiscountH, setFilterDiscountH] = useState(null);
	const [nFilterDiscountM, setFilterDiscountM] = useState(null);
	const [nFilterRemarkH, setFilterRemarkH] = useState(null);
	const [nFilterRemarkM, setFilterRemarkM] = useState(null);
	const [nFilterIsLatest, setFilterIsLatest] = useState(null);

	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});

	const [open, setOpen] = useState(false);
	const [openFilter, setOpenFilter] = useState(false);

	useEffect(() => {
		fetchNoAtnmBasicAgencyInfo({ operation: 1 }); // For domestic
		getHotelList();
		getDestinationList();
		getChainList();
		reopen(1, 10);
	}, []);

	useEffect(() => {
		setAgencyList(basicNoAtnmAgencyInfo);
	}, [basicNoAtnmAgencyInfo]);

	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}

	function handleChangePage(event, value) {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage
		reopen(from, to);
	}
	function handleChangeRowsPerPage(event) {
		setPage(0);
		setRowsPerPage(event.target.value);
		reopen(1, event.target.value);
	}

	const updateDiscount = async (i) => {
		setButtonText('Save');
		setDiscountId(data[i].id);
		setDestination(data[i].cityCode);
		setHotel(data[i].hotelId);
		setChain(data[i].chainId);
		setStartDate(data[i].startDate.substring(0, 10));
		setEndDate(data[i].endDate.substring(0, 10));
		setCategory(data[i].category);
		setAgency(data[i].agencyCode);
		setIsLatest(data[i].isLatest);
		setHomeDiscount(data[i].discountHomepage);
		setHomeRemark(data[i].discountHomepageRemark);
		setMimsharkRemark(data[i].discountMimshakRemark);
		setMimsharkDiscount(data[i].discountMimshak);
		setOpen(true);
	}

	const addDiscount = async () => {
		setButtonText('Add');
		initSelectValues();
		setOpen(true);
	};
	const handleClose = () => {
		initSelectValues();
		setOpen(false);
	};
	const handleFilterClose = () => {
		setOpenFilter(false);
	};
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}
	const handleCloseWarning = () => {
		setWarningOpen(false);
	};
	function initSelectValues() {
		setHotel(null);
		setChain(null);
		setStartDate(null);
		setEndDate(null);
		setCategory(null);
		setAgency(null);
		setIsLatest(false);
		setHomeDiscount(null);
		setHomeRemark(null);
		setMimsharkRemark(null);
		setMimsharkDiscount(null);
	};
	const sortHotels = function ([...arr]) {
		arr.sort((a, b) => {
			if (a.hotelName < b.hotelName) return -1;
			if (a.hotelName > b.hotelName) return 1;
			return 0;
		});
		// arr.sort((a, b) => String(a).localeCompare(String(b)));
		return arr;
	}
	async function getHotelList(destination) {
		await axios({
			method: 'post',
			url: baseURL + 'domestic/api/hotelConversion/search?from=1&to=1000',
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"mainCityCode": destination
			}
		}).then(response => {
			const data = response.data['data'];
			setHotelList(sortHotels(data));
		})
			.catch(error => {
				console.log(error)
				return;
			});
	}
	async function getDestinationList() {
		const response = await axios.get(baseURL + 'domestic/api/destination/forAdmin?from=1&to=1000');
		const data = response.data;
		setDestinationList(data);
	}

	async function getChainList() {
		await axios({
			method: 'get',
			url: baseURL + 'domestic/api/hotelChain?from=1&to=1000'
		}).then(response => {
			const data = response.data['data'];
			setChainList(data);
		})
			.catch(error => {
				console.log(error)
				return;
			});
	}

	async function editProcess(index) {

		// if (nDestination === null){
		// 	setWarningOpen(true);
		// 	setWarningText("please select Destination");
		// }
		// else
		// if (nStartDate == null || nEndDate==null){
		// 	setWarningOpen(true);
		// 	setWarningText("please set the CheckIn Date and CheckOut Date");
		// }
		// else{
		setLoadingCircle(true);
		var type;
		if (nButtonText === 'Save') {
			type = `${baseURL}domestic/api/discountRule/${discountId}`;
		}
		else {
			type = `${baseURL}domestic/api/discountRule`;
		}
		await axios({
			method: 'post',
			url: type,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"cityCode": nDestination,
				"hotelId": nHotel,
				"chainId": nChain,
				"startDate": nStartDate,
				"endDate": nEndDate,
				"category": nCategory,
				"discountMimshak": discountM == null ? null : new Number(discountM),
				"discountMimshakRemark": remarkM,
				"discountHomepage": discountH == null ? null : new Number(discountH),
				"discountHomepageRemark": remarkH,
				"agencyCode": nAgency,
				// "isLatest": nIsLatest
			}
		}).then(response => {
			setLoadingCircle(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningText(response.data.error.message);
				setWarningOpen(true);
			}
			else {
				initSelectValues();
				reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
				setOpen(false)
			}

		})
		.catch(error => {
			setLoadingCircle(false);

			let errorMessage = '';
			if (error.response) {
				errorMessage = error.response.data.title;
			} else {
				errorMessage = error.message;
			}
			setWarningOpen(true);
			setWarningText(errorMessage);
		});
		// }
	};

	async function reopen(from, to) {
		// const temp = nFilterIsLatest == '' || nFilterIsLatest == null  ? null : (nFilterIsLatest == "true" ? true : false);
		await axios({
			method: 'post',
			url: baseURL + 'domestic/api/discountRule/search?' + 'from=' + from + '&to=' + to,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"cityCode": nFilterDestination,
				"hotelIds": nFilterHotel,
				"chainIds": nFilterChain,
				"category": nFilterCategory,
				"discountMimshakList": nFilterDiscountM,
				"discountMimshakRemark": nFilterRemarkM,
				"discountHomepageList": nFilterDiscountH,
				"discountHomepageRemark": nFilterRemarkH,
				"agencyCodeRuleDefinedFor": nFilterAgency,
				"sharedToAllAgencies": null,
				// "isLatest": temp,
			}
		}).then(response => {
			setLoading(false);
			setData(response.data['data']);
			setDataLength(response.data['total'])
		})
		.catch(error => {
			setLoading(false);

			let errorMessage = '';
			if (error.response) {
				errorMessage = error.response.data.title;
			} else {
				errorMessage = error.message;
			}
			setWarningOpen(true);
			setWarningText(errorMessage);
		});
	};

	async function confirmProcess() {
		await axios.delete(baseURL + 'domestic/api/discountRule/' + discountId, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		})
		setConfirmOpen(false);
		reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
	}
	const deleteDiscount = async (i) => {
		setDiscountId(data[i]['id'])
		setConfirmText("Do you want to drop this discount?");
		setConfirmOpen(true);
	}
	const handleChangeCheckbox = (event) => {
		setIsLatest(!nIsLatest);
	};

	const handleChangenFilterIsLatest = (event) => {
		setFilterIsLatest(event.target.value);
	};

	const handleChangeDestination = (event) => {
		var temp = event.target.value;
		if (temp == '') {
			temp = null
		}
		setDestination(temp);
		setHotel(null)
		getHotelList(temp)
	};
	const handleChangeFilterDestination = (event) => {
		var temp = event.target.value;
		if (temp == '') {
			temp = null
		}
		setFilterDestination(temp);
		setFilterHotel(null)
		getHotelList(temp)
	}

	const handleChangeHotel = (event) => {
		if (event.target.value == '') {
			setHotel(null)
		} else {
			setHotel(event.target.value)
		}
	};

	const handleChangeFilterHotel = (event) => {
		if (event.target.value == '') {
			setFilterHotel(null)
		} else {
			setFilterHotel(event.target.value)
		}
	}

	const handleChangeChain = (event) => {
		if (event.target.value == '') {
			setChain(null)
		} else {
			setChain(event.target.value)
		}
	};

	const handleChangeFilterChain = (event) => {
		if (event.target.value == '') {
			setFilterChain(null)
		} else {
			setFilterChain(event.target.value)
		}
	}

	function handleChangeStartDate(event) {
		if (event.target.value == '') {
			setStartDate(null);
		} else {
			setStartDate(event.target.value);
		}
	}
	function handleChangeEndDate(event) {
		if (event.target.value == '') {
			setEndDate(null);
		} else {
			setEndDate(event.target.value);
		}
	}

	function onChangeCategory(event) {
		const temp = event.target.value == '' ? null : event.target.value
		setCategory(temp)
	}
	function onChangeFilterCategory(event) {
		const temp = event.target.value == '' ? null : event.target.value
		setFilterCategory(temp)
	}
	function onChangeAgency(event) {
		const temp = event.target.value == '' ? null : event.target.value
		setAgency(temp)
	}
	function onChangeFilterAgency(event) {
		const temp = event.target.value == '' ? null : event.target.value
		setFilterAgency(temp)
	}
	function handleChangeDiscountH(event) {
		const temp = event.target.value == '' ? null : event.target.value
		setHomeDiscount(temp);
	}
	function handleChangeFilterDiscountH(event) {

		const temp = event.target.value == '' || event.target.value == [] ? null : event.target.value;
		setFilterDiscountH(temp);
	}
	function handleChangeRemarkH(event) {
		const temp = event.target.value == '' ? null : event.target.value;
		setHomeRemark(temp);
	}
	function handleChangeFilterRemarkH(event) {
		const temp = event.target.value == '' ? null : event.target.value;
		setFilterRemarkH(temp);
	}
	function handleChangeRemarkM(event) {
		const temp = event.target.value == '' ? null : event.target.value;
		setMimsharkRemark(temp);
	}

	function handleChangeFilterRemarkM(event) {
		const temp = event.target.value == '' ? null : event.target.value
		setFilterRemarkM(temp);
	}

	function handleChangeDiscountM(event) {

		const temp = event.target.value == '' ? null : event.target.value
		setMimsharkDiscount(temp);
	}

	function handleChangeFilterDiscountM(event) {
		const temp = event.target.value == '' || event.target.value == [] ? null : event.target.value;
		setFilterDiscountM(temp);
	}

	function searchDiscount() {
		reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
		setOpenFilter(false);
	}
	const openSearchModel = () => {
		setOpenFilter(true);
	};
	const getDateFormat = (date) => {
		var year = date.getFullYear();
		var month = date.getMonth() + 1;
		var mdate = date.getDate();
		if (month < 10) {
			month = '0' + month;
		}
		if (mdate < 10) {
			mdate = '0' + mdate;
		}
		return year + '-' + month + '-' + mdate;
	}
	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className='w-full flex flex-col'>
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={openFilter}
				onClose={handleFilterClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={openFilter}>
					<div className={classes.paper}>
						<div className={classes.fo_circular}>
							{loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
						</div>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title' >Filter Setting</h2>
						</div>
						<div style={{ display: 'grid' }}>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Destination</FormHelperText>
								<Select
									native
									onChange={handleChangeFilterDestination}
									value={nFilterDestination === null ? '' : nFilterDestination}
									inputProps={{
										id: 'age-native-required',
									}}
								>
									<option aria-label='None' value='' />
									{nDestinationList.map((n, i) => (
										<option key={i} value={n.code}>
											{n.name}
										</option>
									))}
								</Select>
							</FormControl>
							<FormControl className={classes.formControl}>
								<FormHelperText>Hotel</FormHelperText>
								<Select
									labelId="demo-mutiple-name-label"
									id="demo-mutiple-name"
									multiple
									value={nFilterHotel == null ? [] : nFilterHotel}
									onChange={handleChangeFilterHotel}
									input={<Input />}
									MenuProps={MenuProps}
								>
									<MenuItem value={null}>None</MenuItem>
									{nHotelList.map((n, i) => (
										<MenuItem key={i} value={n.id}>
											{n.hotelName}
										</MenuItem>
									))}
								</Select>
							</FormControl>
							<FormControl className={classes.formControl}>
								<FormHelperText>Chain</FormHelperText>
								<Select
									labelId="demo-mutiple-name-label"
									id="demo-mutiple-name"
									multiple
									value={nFilterChain == null ? [] : nFilterChain}
									onChange={handleChangeFilterChain}
									input={<Input />}
									MenuProps={MenuProps}
								>
									<MenuItem value={null}>None</MenuItem>
									{nChainList.map((n, i) => (
										<MenuItem key={i} value={n.id}>
											{n.name}
										</MenuItem>
									))}
								</Select>
							</FormControl>
						</div>
						<Grid container justify='space-around' style={{ margin: '5px 0px', display: 'flex' }}>
							<FormControl required style={{ width: '45%' }}>
								<FormHelperText>Category</FormHelperText>
								<TextField defaultValue={nFilterCategory == null ? '' : nFilterCategory} className={classes.textfield} onChange={onChangeFilterCategory} />
							</FormControl>
							<FormControl required style={{ width: '45%' }}>
								<FormHelperText>Agency</FormHelperText>
								<Select
									native
									onChange={onChangeFilterAgency}
									value={nFilterAgency === null ? '' : nFilterAgency}
									inputProps={{
										id: 'agency-native-required',
									}}
								>
									<option aria-label='None' value='' />
									{nAgencyList.map((n, i) => (
										<option key={i} value={n.code}>
											{n.name}
										</option>
									))}
								</Select>
							</FormControl>
						</Grid>

						<Grid container justify='space-around' style={{ margin: '5px 0px', display: 'flex' }}>
							<FormControl style={{ width: '30%' }}>
								<FormHelperText>Discount</FormHelperText>
								<Select
									labelId="demo-mutiple-name-label"
									id="demo-mutiple-name"
									multiple
									value={nFilterDiscountH == null ? [] : nFilterDiscountH}
									onChange={handleChangeFilterDiscountH}
									input={<Input />}
									MenuProps={MenuProps}
								>
									<MenuItem value={null}>None</MenuItem>
									{discountValue.map((n, i) => (
										<MenuItem key={i} value={n}>
											{n}
										</MenuItem>
									))}
								</Select>
							</FormControl>
							<FormControl required style={{ width: '60%' }}>
								<FormHelperText>Discount Remark</FormHelperText>
								<TextareaAutosize
									rowsMax={1}
									aria-label="maximum height"
									// placeholder=".........."
									onChange={handleChangeFilterRemarkH}
									className={classes.ntextArea}
									defaultValue={nFilterRemarkH}
								/>
							</FormControl>
						</Grid>
						<Grid container justify='space-around' style={{ margin: '5px 0px', display: 'none' }}>
							<FormControl required style={{ width: '30%' }}>
								<FormHelperText>discount(Mimshark)</FormHelperText>
								<Select
									labelId="demo-mutiple-name-label"
									id="demo-mutiple-name"
									multiple
									value={nFilterDiscountM == null ? [] : nFilterDiscountM}
									onChange={handleChangeFilterDiscountM}
									input={<Input />}
									MenuProps={MenuProps}
								>
									<MenuItem value={null}>None</MenuItem>
									{discountValue.map((n, i) => (
										<MenuItem key={i} value={n}>
											{n}
										</MenuItem>
									))}
								</Select>
							</FormControl>
							<FormControl required style={{ width: '60%' }}>
								<FormHelperText>Remark_Mimshark</FormHelperText>
								<TextareaAutosize
									rowsMax={1}
									aria-label="maximum height"
									// placeholder=".........."
									onChange={handleChangeFilterRemarkM}
									className={classes.ntextArea}
									defaultValue={nFilterRemarkM}
								/>
							</FormControl>
						</Grid>
						<FormControl required className={classes.formControl}>
							<FormHelperText>State</FormHelperText>
							<Select
								native
								onChange={handleChangenFilterIsLatest}
								value={nFilterIsLatest == null ? '' : nFilterIsLatest}
								inputProps={{
									id: 'age-native-required',
								}}
								disabled
							>
								<option aria-label='None' value=''>All</option>
								<option value='false'>Past rules</option>
								<option value='true'>The latest only</option>
							</Select>
						</FormControl>

						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' color='secondary' onClick={searchDiscount}>
								Filter
							</Button>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleFilterClose}>
								Cancel
							</Button>
						</div>
					</div>

				</Fade>
			</Modal>
			<Modal
				open={warningOpen}
				onClose={handleCloseWarning}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Warning</h2>
					<p id='server-modal-description'>{warningText}</p>
					<Button className='whitespace-no-wrap normal-case'
						variant='contained'
						color='secondary'
						onClick={handleCloseWarning}>Close
					</Button>
				</div>
			</Modal>
			<div>
				<div className='spinner-border text-primary' role='status'>
					<span className='sr-only'>Loading...</span>
				</div>
				<Modal
					open={confirmOpen}
					onClose={handleCloseConfirm}
					className={classes.modal}
					aria-labelledby='simple-modal-title'
					aria-describedby='simple-modal-description'
				>
					<div className={classes.paper} style={{ textAlign: 'center' }}>
						<h2 id='server-modal-title' >Confirm</h2>
						<p id='server-modal-description'>{confirmText}</p>
						<Button className='whitespace-no-wrap normal-case'
							style={{ margin: '10px 5px' }}
							variant='contained'
							color='secondary'
							onClick={confirmProcess}>Confirm
						</Button>
						<Button className='whitespace-no-wrap normal-case'
							style={{ margin: '10px 5px' }}
							variant='contained'
							color='secondary'
							onClick={handleCloseConfirm}>Cancel
						</Button>
					</div>
				</Modal>
				<Modal
					aria-labelledby='transition-modal-title'
					aria-describedby='transition-modal-description'
					className={classes.modal1}
					open={open}
					onClose={handleClose}
					closeAfterTransition
					BackdropComponent={Backdrop}
					BackdropProps={{
						timeout: 500,
					}}
				>
					<Fade in={open}>
						<div className={classes.paper}>
							<div className={classes.fo_circular}>
								{loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
							</div>
							<div style={{ textAlign: 'center' }}>
								<h2 id='transition-modal-title' >Discount Builder</h2>
							</div>
							<div style={{ display: 'grid' }}>
								<FormControl required className={classes.formControl}>
									<FormHelperText>Destination</FormHelperText>
									<Select
										native
										onChange={handleChangeDestination}
										value={nDestination === null ? '' : nDestination}
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option aria-label='None' value='' />
										{nDestinationList.map((n, i) => (
											<option key={i} value={n.code}>
												{n.name}
											</option>
										))}
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl}>
									<FormHelperText>Hotel</FormHelperText>
									<Select
										native
										value={nHotel === null ? '' : nHotel}
										onChange={handleChangeHotel}
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option aria-label='None' value='' />
										{nHotelList.map((n, i) => (
											<option key={i} value={n.id}>
												{n.hotelName}
											</option>
										))}
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl}>
									<FormHelperText>Hotel Chain</FormHelperText>
									<Select
										native
										value={nChain === null ? '' : nChain}
										onChange={handleChangeChain}
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option aria-label='None' value='' />
										{nChainList.map((n, i) => (
											<option key={i} value={n.id}>
												{n.name}
											</option>
										))}
									</Select>
								</FormControl>
							</div>
							<Grid container justify='space-around' style={{ margin: '10px 0px' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Check-In From</FormHelperText>
									<TextField
										id="date-1"
										type="date"
										value={nStartDate == null ? '' : nStartDate}
										onChange={handleChangeStartDate}
										className={classes.textField1}
									/>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Check-Out To</FormHelperText>
									<TextField
										id="date-2"
										type="date"
										value={nEndDate == null ? '' : nEndDate}
										onChange={handleChangeEndDate}
										className={classes.textField1}
									/>
								</FormControl>
							</Grid>
							<Grid container justify='space-around' style={{ margin: '5px 0px', display: 'flex' }}>
								<FormControl required style={{ width: '45%' }}>
									<FormHelperText>Category</FormHelperText>
									<TextField defaultValue={nCategory} className={classes.textfield} onChange={onChangeCategory} />
								</FormControl>
								<FormControl required style={{ width: '45%' }}>
									<FormHelperText>Agency</FormHelperText>
									<Select
										native
										onChange={onChangeAgency}
										value={nAgency === null ? '' : nAgency}
										inputProps={{
											id: 'agency-native-required',
										}}
									>
										<option aria-label='None' value='' />
										{nAgencyList.map((n, i) => (
											<option key={i} value={n.code}>
												{n.name}
											</option>
										))}
									</Select>
								</FormControl>
							</Grid>
							<Grid container justify='space-around' style={{ margin: '5px 0px', display: 'flex' }}>
								<FormControl required style={{ width: '30%' }}>
									<FormHelperText>Discount</FormHelperText>
									<Select
										native
										value={discountH === null ? '' : discountH}
										onChange={handleChangeDiscountH}
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option aria-label='None' value='' />
										{discountValue.map((n, i) => (
											<option key={i} value={n}>
												{n}
											</option>
										))}
									</Select>
								</FormControl>
								<FormControl required style={{ width: '60%' }}>
									<FormHelperText>Discount Remark</FormHelperText>
									<TextareaAutosize
										rowsMax={1}
										aria-label="maximum height"
										// placeholder=".........."
										onChange={handleChangeRemarkH}
										className={classes.ntextArea}
										defaultValue={remarkH}
									/>
								</FormControl>
							</Grid>
							{/* <Grid container justify='space-around' style={{ margin: '5px 0px', display: 'flex' }}>
								<FormControl required style={{ width: '30%' }}>
									<FormHelperText>discount_Mimshark</FormHelperText>
									<Select
										native
										value={discountM === null ? '' : discountM}
										onChange={handleChangeDiscountM}
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option aria-label='None' value='' />
										{discountValue.map((n, i) => (
											<option key={i} value={n}>
												{n}
											</option>
										))}
									</Select>
								</FormControl>
								<FormControl required style={{ width: '60%' }}>
									<FormHelperText>Remark_Mimshark</FormHelperText>
									<TextareaAutosize
										rowsMax={1}
										aria-label="maximum height"
										// placeholder=".........."
										onChange={handleChangeRemarkM}
										className={classes.ntextArea}
										defaultValue={remarkM}
									/>
								</FormControl>
							</Grid> */}

							{nButtonText === 'Save' ?
								<FormControlLabel
									control={
										<Checkbox
											checked={nIsLatest}
											onChange={handleChangeCheckbox}
											name='checkedB'
											color='primary'
											disabled
										/>
									}
									label='The latest rule(All old rules won`t take effect)'
									className={classes.checkboxform}
								/> : ''}
							<div className={classes.button_group}>
								<Button className={classes.buttons} variant='contained' onClick={editProcess} color='secondary'>
									{nButtonText}
								</Button>
								<Button className={classes.buttons} variant='contained' color='primary' onClick={handleClose}>
									Cancel
								</Button>

							</div>
						</div>

					</Fade>
				</Modal>
			</div>
			<div>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 15px 15px 5px' }}
					onClick={() => addDiscount()}
				>
					<span className='hidden sm:flex'>Add Discount</span>
					<span className='flex sm:hidden'>Add</span>
				</Button>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => openSearchModel()}
				>

					<span className='hidden sm:flex'><SearchIcon />Filter</span>
					<span className='flex sm:hidden'><SearchIcon /></span>
				</Button>
			</div>
			<FuseScrollbars className='flex-grow overflow-x-auto'>
				<Table stickyHeader className='min-w-xl' aria-labelledby='tableTitle'>
					<DiscountTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={data.length}
					/>
					<TableBody>
						{_.orderBy(
							data,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className='h-64 cursor-pointer'
									hover
									tabIndex={-1}
									key={n.id}
								>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => updateDiscount(i)}>
										{n.cityCode}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => updateDiscount(i)}>
										{n.hotelConversion == null ? null : n.hotelConversion.hotelName}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => updateDiscount(i)}>
										{n.chainId == null ? null : nChainList.find((v, i, o) => v.id == n.chainId)?.name}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => updateDiscount(i)}>
										{n.category}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => updateDiscount(i)}>
										{nAgencyList && nAgencyList.find((agnc) => agnc.code === n.agencyCode)?.name || ''}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => updateDiscount(i)}>
										{n.discountHomepage}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => updateDiscount(i)}>
										{n.discountHomepageRemark}
									</TableCell>
									{/* <TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => updateDiscount(i)}>
										{n.discountMimshak}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left' onClick={() => updateDiscount(i)}>
										{n.discountMimshakRemark}
									</TableCell> */}
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left' onClick={() => updateDiscount(i)}>
										{n.startDate == null ? null : new Date(n.startDate).toString().substring(0, 15)}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left' onClick={() => updateDiscount(i)}>
										{n.endDate == null ? null : new Date(n.endDate).toString().substring(0, 15)}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left' onClick={() => updateDiscount(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.isLatest && 'bg-red',
												n.isLatest && 'bg-green',
											)}
										/>
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left'>

												<button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
													onClick={() => updateDiscount(i)}
													tabIndex='0' type='button' title='Edit'>
													<span className='MuiIconButton-label'>
														<span className='material-icons MuiIcon-root' aria-hidden='true'>edit</span>
													</span>
													<span className='MuiTouchRipple-root'></span>
												</button>
										</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component='th' scope='row' align='left'>
										<button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
											onClick={() => deleteDiscount(i)}
											tabIndex='0' type='button' title='Edit'>
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className='flex-shrink-0 border-t-1'
				component='div'
				count={dataLength}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}
export default withRouter(DiscountTable);
