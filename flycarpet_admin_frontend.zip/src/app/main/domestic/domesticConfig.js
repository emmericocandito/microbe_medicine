import React from 'react';
import Login from '../login/Login';
const token = window.localStorage.getItem('jwt_access_token');
const DomesticConfig = {
	settings: {
		layout: token == null ? {
			config: {
				navbar: {
					display: false
				},
				toolbar: {
					display: false
				},
				footer: {
					display: false
				},
				leftSidePanel: {
					display: false
				},
				rightSidePanel: {
					display: false
				}
			}
		} : {
				config: {}
			}
	},
	routes: token == null ? [
		{
			path: '/',
			component: Login
		}
	] : [
		{
			path: '/domesticDestination',
			component: React.lazy(() => import('./destination/DomesticDestination'))
		},
		{
			path: '/domestic/booking_partner',
			component: React.lazy(() => import('./partnerBooks/allBookings'))
		},
		{
			path: '/domestic/booking_stats',
			component: React.lazy(() => import('./partnerBooks/bookingStats'))
		},
		{
			path: '/domestic/commission_stats',
			component: React.lazy(() => import('./partnerBooks/confirmedCommissionStats'))
		}
	]
};

export default DomesticConfig;
