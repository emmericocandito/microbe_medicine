import withReducer from 'app/store/withReducer';
import React, { memo } from 'react';
import { useParams } from 'react-router';
import reducer from 'app/main/store';
import { TableStatusContextProvider } from 'app/main/Context/tableStatusContext';
import FusePageCarded from '@fuse/core/FusePageCarded';

import StatsSearchInfoAgentPageContent from './StatsSearchInfoAgentPageContent';
import StatsSearchInfoAgentPageHeader from './StatsSearchInfoAgentPageHeader';

function StatsSearchInfoAgent(props) {

  const routeParams = useParams();
  const { agentCode } = routeParams;

  return (
    <TableStatusContextProvider>
      <FusePageCarded
        classes={{
          content: 'flex',
          contentCard: 'overflow-hidden',
          header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
        }}
        header={<StatsSearchInfoAgentPageHeader />}
        content={<StatsSearchInfoAgentPageContent agentCode={agentCode} />}
        innerScroll
      />
    </TableStatusContextProvider>
  );
}

export default withReducer('BasicData', reducer)(memo(StatsSearchInfoAgent));

