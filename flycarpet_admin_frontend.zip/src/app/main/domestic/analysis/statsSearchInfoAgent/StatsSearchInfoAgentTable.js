import React, { memo, useEffect, useState } from 'react'

import ActionTable from 'app/main/BasicComponents/ActionTable'
import { useFormatingDate } from 'app/main/utils';

function StatsSearchInfoAgentTable(props) {

  const { rowsData, onMessage: sendMessage } = props;
  const propColumns = [
    {
      id: 'idx',
      align: 'center',
      disablePadding: false,
      label: 'Index',
      sort: false,
      type: 'text'
    },
    {
      id: 'id',
      align: 'left',
      disablePadding: false,
      label: 'code',
      sort: true,
      type: 'text',
      show: 'hide'
    },
    {
      id: 'searchDate',
      align: 'center',
      disablePadding: false,
      label: 'Search Date',
      sort: true,
      type: 'text',
      click: 'disable',
    },
    {
      id: 'checkinDate',
      align: 'center',
      disablePadding: false,
      label: 'Check In',
      sort: true,
      type: 'text',
      click: 'disable',
    },
    {
      id: 'checkoutDate',
      align: 'center',
      disablePadding: false,
      label: 'Check Out',
      sort: true,
      type: 'text',
      click: 'disable',
    },
    {
      id: 'city',
      align: 'center',
      disablePadding: false,
      label: 'City',
      sort: true,
      type: 'text',
      click: 'disable',
    },
    {
      id: 'madeBooking',
      align: 'center',
      disablePadding: false,
      label: 'Made Booking',
      sort: true,
      type: 'boolean',
      click: 'disable',
    },
  ];
  const { convertDate } = useFormatingDate();

  const [bodyRows, setBodyRows] = useState([]);



  useEffect(() => {
    if (!rowsData) return;
    const rows = rowsData.map((row, idx) => {
      const { searchDate, checkinDate, checkoutDate, city, triedBook } = row;
      return {
        idx: idx + 1,
        id: `${city}-${searchDate}`,
        searchDate: convertDate('dmy', searchDate, 'YYYY-MM-DD'),
        checkinDate: convertDate('dmy', checkinDate, 'YYYY-MM-DD'),
        checkoutDate: convertDate('dmy', checkoutDate, 'YYYY-MM-DD'),
        city,
        madeBooking: triedBook,
      }
    })
    setBodyRows(rows);
  }, [rowsData]);

  const onMessage = (pMsg) => {
    if (pMsg.evtType === 'loadMore') {
      sendMessage({
        action: pMsg.evtType,
        extraData: pMsg.extraData
      })
    }
  }

  return (
    <ActionTable
      propColumns={propColumns}
      bodyRows={bodyRows}
      onMessage={onMessage}
    />
  )
}

export default memo(StatsSearchInfoAgentTable);