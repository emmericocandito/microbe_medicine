import React from 'react';
import Login from 'app/main/login/Login';
const token = window.localStorage.getItem('jwt_access_token');
const AnalysisConfig = {
  settings: {
    layout: token == null ? {
      config: {
        navbar: {
          display: false
        },
        toolbar: {
          display: false
        },
        footer: {
          display: false
        },
        leftSidePanel: {
          display: false
        },
        rightSidePanel: {
          display: false
        }
      }
    } : {
      config: {}
    }
  },
  routes: token == null ? [
    {
      path: '/',
      component: Login
    }
  ] : [
		{
			path: '/domestic/domebookingInfoAll',
			component: React.lazy(() => import('./bookingInfoAll/BookingInfoAll'))
		},
    {
      path: '/domestic/stats_info_agent',
      component: React.lazy(() => import('./statsInfoAgent/index'))
    },
    {
      path: '/domestic/search_info_agent/:agentCode',
      component: React.lazy(() => import('./statsSearchInfoAgent/index'))
    },
    {
      path: '/domestic/partner_analysis',
      component: React.lazy(() => import('./partnerAnalysis/index'))
    },
  ]
};
export default AnalysisConfig;
