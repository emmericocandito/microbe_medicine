import React from 'react';
// import Login from '../../login/Login';
// const token = window.localStorage.getItem('jwt_access_token');

const domesticBookingInfo = {
	settings: {
		layout: {
			config: {
				navbar: {
					display: false
				},
				toolbar: {
					display: false
				},
				footer: {
					display: false
				},
				leftSidePanel: {
					display: false
				},
				rightSidePanel: {
					display: false
				}
			}
		}
	},
  	auth: null,
	// routes: token === null ? [
	// 	{
	// 		path: '/',
	// 		component: Login
	// 	}
	// ] : [
	routes: [
		{
			path: '/domestic/bookingInfo/:id',
			component: React.lazy(() => import('./bookingInfo/bookingInfoApp'))
		},
	]
};
export default domesticBookingInfo;
