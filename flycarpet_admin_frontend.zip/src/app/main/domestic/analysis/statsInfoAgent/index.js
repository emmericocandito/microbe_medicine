import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React, { memo } from 'react';
import reducer from 'app/main/store';
import StatsInfoAgentPageHeader from './StatsInfoAgentPageHeader';
import StatsInfoAgentPageContent from './StatsInfoAgentPageContent';
import { TableStatusContextProvider } from 'app/main/Context/tableStatusContext';

function StatsInfoAgent(props) {

  return (
    <TableStatusContextProvider>
      <FusePageCarded
        classes={{
          content: 'flex',
          contentCard: 'overflow-hidden',
          header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
        }}
        header={<StatsInfoAgentPageHeader />}
        content={<StatsInfoAgentPageContent />}
        innerScroll
      />
    </TableStatusContextProvider>
  );
}

export default withReducer('BasicData', reducer)(memo(StatsInfoAgent));