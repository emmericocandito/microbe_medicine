import React, { useEffect, useState, memo } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  Modal, Backdrop, Button, TextField, TextareaAutosize,
  Grid, FormHelperText, FormControl, FormControlLabel, Select, Checkbox,
} from '@material-ui/core';

import './custom.css';

import { useConstantValue } from 'app/main/utils/constantValue';

const FilterModal = (props) => {
  const { open, extraData, onMessage: sendMessage } = props;
  // const { pageKind } = extraData;

  const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: '2px 5px',
      minWidth: 60,
    },
    modal: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      textAlign: "center",
      maxHeight: "100vh",
      overflowY: "auto",
    },
    checkboxform: {
      display: 'block',
    },
  }));
  const classes = useStyles();

  const [openFilter, setOpenFilter] = useState(false);
  const handleCloseModal = () => {
    setOpenFilter(false);
    sendMessage({
      type: 'action',
      action: 'close',
    });
  }

  const [agentCode, setAgentCode] = useState('');
  const [numberSearchFrom, setNumberSearchFrom] = useState('');
  const [numberSearchTo, setNumberSearchTo] = useState('');
  const [numberBookingFrom, setNumberBookingFrom] = useState('');
  const [numberBookingTo, setNumberBookingTo] = useState('');

  const initialize = () => {
    initialState();
  }
  const initialState = () => {
    setAgentCode('');
    setNumberSearchFrom('');
    setNumberSearchTo('');
    setNumberBookingFrom('');
    setNumberBookingTo('');
  }

  const handleFilter = () => {
    const action = 'filter';
    sendMessage({
      type: 'action',
      action,
      extraData: {
        fromDate: '2023-04-02',
        toDate: '',
        OdyAgentCode: agentCode ?? null,
        numberSearchFrom: numberSearchFrom ? Number(numberSearchFrom) : null,
        numberSearchTo: numberSearchTo ? Number(numberSearchTo) : null,
        numberBookingFrom: numberBookingFrom ? Number(numberBookingFrom) : null,
        numberBookingTo: numberBookingTo ? Number(numberBookingTo) : null,
      }
    })
  }

  useEffect(() => {
    initialState();
    setOpenFilter(open);
  }, [open]);

  useEffect(() => {
    initialize();
  }, []);

  return (
    <div className="w-full flex flex-col">
      <Modal
        open={openFilter}
        onClose={handleCloseModal}
        className={classes.modal}
        closeAfterTransition
        aria-labelledby='transition-modal-title'
        aria-describedby='transition-modal-description'
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <Grid className={classes.paper}>
          <h2 id="server-modal-title" >{`Filter Agent Info`}</h2>
          <Grid container justify='space-between' style={{ margin: '20px 5px', display: 'grid' }}>
            <FormControl className={classes.formControl}>
              <TextField className={classes.textField} label="Agent Code" defaultValue={agentCode} onChange={e => setAgentCode(e.target.value)} />
            </FormControl>
            <FormControl className={classes.formControl}>
              <TextField className={classes.textField} label="From Number of Search" defaultValue={numberSearchFrom} onChange={e => setNumberSearchFrom(e.target.value)} />
            </FormControl>
            <FormControl className={classes.formControl}>
              <TextField className={classes.textField} label="To Number of Search" defaultValue={numberSearchTo} onChange={e => setNumberSearchTo(e.target.value)} />
            </FormControl>
            <FormControl className={classes.formControl}>
              <TextField className={classes.textField} label="From Number of Booking" defaultValue={numberBookingFrom} onChange={e => setNumberBookingFrom(e.target.value)} />
            </FormControl>
            <FormControl className={classes.formControl}>
              <TextField className={classes.textField} label="To Number of Booking" defaultValue={numberBookingTo} onChange={e => setNumberBookingTo(e.target.value)} />
            </FormControl>
            {/* <FormControl required className={classes.formControl}>
              <FormHelperText>Booking State</FormHelperText>
              <Select
                native
                onChange={ev => setDoneBooking(ev.target.value)}
                value={doneBooking}
                inputProps={{
                  id: 'age-native-required',
                }}
              >
                <option aria-label='None' value={'null'}>All</option>
                <option value={true}>Done</option>
                <option value={false}>None</option>
              </Select>
            </FormControl> */}
          </Grid>
          <Grid container justify='space-around' style={{ margin: '10px 5px' }}>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="primary"
              onClick={handleFilter}>Filter
            </Button>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="secondary"
              onClick={handleCloseModal}>Close
            </Button>
          </Grid>
        </Grid>
      </Modal>
    </div>
  );
}

export default memo(FilterModal);