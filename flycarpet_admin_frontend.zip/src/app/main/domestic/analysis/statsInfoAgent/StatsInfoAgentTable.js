import React, { memo, useEffect, useState } from 'react'

import ActionTable from 'app/main/BasicComponents/ActionTable'
import { Grid, IconButton } from '@material-ui/core';
import OpenInNew from '@material-ui/icons/OpenInNew';
import dayjs from 'dayjs';

import { useFormatingDate } from 'app/main/utils';

function StatsInfoAgentTable(props) {
  const { convertDate } = useFormatingDate();
  const { rowsData, onMessage: sendMessage } = props;
  const propColumns = [
    {
      id: 'idx',
      align: 'left',
      disablePadding: false,
      label: 'Index',
      sort: false,
      type: 'text'
    },
    {
      id: 'id',
      align: 'left',
      disablePadding: false,
      label: 'code',
      sort: true,
      type: 'text',
      show: 'hide'
    },
    {
      id: 'odyAgentCode',
      align: 'left',
      disablePadding: false,
      label: 'Agent Code',
      sort: true,
      type: 'text',
      click: 'disable',
    },
    {
      id: 'loginDate',
      align: 'left',
      disablePadding: false,
      label: 'Login Date',
      sort: true,
      type: 'text',
      click: 'disable',
    },
    {
      id: 'loginDuration',
      align: 'left',
      disablePadding: false,
      label: 'Login Duration',
      sort: true,
      type: 'text',
      click: 'disable',
    },
    {
      id: 'online',
      align: 'left',
      disablePadding: false,
      label: 'Online',
      sort: true,
      type: 'boolean',
      click: 'disable',
    },
    {
      id: 'numberSearch',
      align: 'center',
      disablePadding: false,
      label: 'Number of Search',
      sort: true,
      type: 'component',
      click: 'enable',
    },
    {
      id: 'numberBooking',
      align: 'center',
      disablePadding: false,
      label: 'Number of Booking',
      sort: true,
      type: 'Notes',
      click: 'disable',
    },
  ];

  const [bodyRows, setBodyRows] = useState([]);

  const clipboardLink = (pLink) => async (event) => {
    if (navigator && navigator.clipboard && navigator.clipboard.writeText)
      return await navigator.clipboard.writeText(pLink);
    return Promise.reject('The Clipboard API is not available.');
  }

  const domLinkButtons = (pData) => {
    const link = `/domestic/search_info_agent/${pData.odyAgentCode}`;
    const ctSearch = pData.searchNum;
    return (
      <Grid style={{ width: '100px' }} className='m-auto'>
        <span className='mr-12'> {ctSearch} </span>
        <IconButton aria-label="blank" target="_blank" href={link}>
          <OpenInNew />
        </IconButton>
      </Grid>
    )
  }

  useEffect(() => {
    if (!rowsData) return;
    const rows = rowsData.map((row, idx) => {
      const { odyAgentCode, firstLoginTime, lastActionTime, durationMin, isOnline, bookNum } = row;
      return {
        idx: idx + 1, id: odyAgentCode, odyAgentCode, loginDate: convertDate('dmy', lastActionTime, 'YYYY-MM-DD'), loginDuration: durationMin, online: isOnline, numberSearch: domLinkButtons(row), numberBooking: bookNum
      }
    })
    setBodyRows(rows);
  }, [rowsData]);

  const onMessage = (pMsg) => {
    if (pMsg.evtType === 'column') {
      if (pMsg.kind === "numberSearch") {
        sendMessage({
          action: 'showSearch',
          type: pMsg.evtType,
          id: pMsg.id,
        })
      }
    } else if (pMsg.evtType === 'loadMore') {
      sendMessage({
        action: pMsg.evtType,
        extraData: pMsg.extraData
      })
    }
  }

  return (
    <ActionTable
      propColumns={propColumns}
      bodyRows={bodyRows}
      onMessage={onMessage}
    />
  )
}

export default memo(StatsInfoAgentTable);