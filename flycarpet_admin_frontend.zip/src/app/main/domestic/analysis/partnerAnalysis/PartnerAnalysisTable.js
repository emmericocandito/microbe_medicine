import FuseScrollbars from '@fuse/core/FuseScrollbars';
import axios from 'axios';
import _ from '@lodash';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import FuseLoading from '@fuse/core/FuseLoading';
import DestinationTableHead from './PartnerAnalysisTableHead';
import { makeStyles } from '@material-ui/core/styles';
import 'react-tabs/style/react-tabs.css';
import 'bootstrap-daterangepicker/daterangepicker.css';
import IconButton from '@material-ui/core/IconButton';
import OpenInNew from '@material-ui/icons/OpenInNew';
import { baseURL } from 'app/main/utils';

function PartnerAnalysisTable(props) {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			margin: theme.spacing(1),
			minWidth: 120,
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			minWidth: 100,
			minHeight: 200
		},
		button_group:
		{
			padding: 30,
			textAlign: 'center',
		},
		buttons: {
			marginRight: '10px'
		},
		textfield: {
			width: '100%'
		},
		chipStyle: {
			height: '20px',
			margin: '1px',
			color: 'white',
			fontSize: '12px',
			background: '#32606b'
		},
	}));
	const [open, setOpen] = useState(false);
	const [page, setPage] = React.useState(0);
	const [rowsPerPage, setRowsPerPage] = React.useState(10);
	const [partners, setPartners] = useState([])
	const [dataLength, setDataLength] = useState(0);
	const [selected] = useState([]);
	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});

	const [loading, setLoading] = useState(true);

	useEffect(() => {
		reopen(1, 10, '', '', '');
	}, [])

	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}

	const handleClose = () => {
		setOpen(false);
	};

	function handleChangePage(event, newPage) {
		setPage(newPage);
		const from = newPage * rowsPerPage + 1;
		const to = newPage * rowsPerPage + rowsPerPage
		reopen(from, to);
	}

	function handleChangeRowsPerPage(event) {
		setPage(0);
		setRowsPerPage(event.target.value);
		reopen(1, event.target.value);
	}

	async function reopen(from, to) {
		setLoading(true);
		await axios({
			method: 'post',
			url: baseURL + 'domestic/api/analysis/bookings/partnerStats?' + 'from=' + from + '&to=' + to,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {}
		}).then(response => {
			const data = Object.values(response.data);
			const bookingData = data.map(e => {
				const okData = getPnrData(e, "OK");
				const rqData = getPnrData(e, "RQ");
				const cxlData = getPnrData(e, "CXL");
				const othersData = getPnrData(e, "Others");

				return {
					partnerId: e[0].partnerId,
					userName: e[0].user?.userName || '',
					fullName: e[0].user?.fullName || '',
					ok_orders: okData?.orders ?? '',
					ok_payed: okData?.payed ?? '',
					ok_grossed: okData?.gross ?? '',
					ok_discount: okData?.disc ?? '',
					rq_orders: rqData?.orders ?? '',
					rq_payed: rqData?.payed ?? '',
					rq_grossed: rqData?.gross ?? '',
					rq_discount: rqData?.disc ?? '',
					cxl_orders: cxlData?.orders ?? '',
					cxl_payed: cxlData?.payed ?? '',
					cxl_grossed: cxlData?.gross ?? '',
					cxl_discount: cxlData?.disc ?? '',
					others_orders: othersData?.orders ?? '',
					others_payed: othersData?.payed ?? '',
					others_grossed: othersData?.gross ?? '',
					others_discount: othersData?.disc ?? '',
				}
			})

			setLoading(false);
			setDataLength(bookingData.length);
			setPartners(bookingData);
			setOpen(false);
		}).catch(error => {
			setLoading(false);
			setOpen(false);
		});
	}

	const getPnrData = (partnerData, pnrStatus) => {
		if(!partnerData) {
			return null;
		}
		const d = partnerData.filter(e => e.pnrHtlStatus === pnrStatus)
		return d.length > 0 ? d[0] : null;
	}
	if (loading) {
		return <FuseLoading />;
	}

	return (
		<div className="w-full flex flex-col">
			<FuseScrollbars className="flex-grow overflow-x-auto">
				<Table stickyHeader className="min-w-xl" aria-labelledby="tableTitle">
					<DestinationTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={partners.length}
					/>
					<TableBody>
						{_.orderBy(
							partners,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className="h-64 cursor-pointer"
									hover
									tabIndex={-1}
									key={i}
								>
									<TableCell padding="none" className="w-20 md:w-20 text-center z-99">
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.userName}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.fullName}
									</TableCell>
									<TableCell className="p-4 md:p-16 border-l-1" component="th" scope="row">
										{n.ok_orders}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.ok_payed === "" ? '' : '₪'+n.ok_payed}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.ok_grossed === "" ? '' : '₪'+n.ok_grossed}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.ok_discount === "" ? '' : '₪'+n.ok_discount}
									</TableCell>
									<TableCell className="p-4 md:p-16 border-l-1" component="th" scope="row">
										{n.rq_orders}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.rq_payed === "" ? '' : '₪'+n.rq_payed}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.rq_grossed === "" ? '' : '₪'+n.rq_grossed}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.rq_discount === "" ? '' : '₪'+n.rq_discount}
									</TableCell>
									<TableCell className="p-4 md:p-16 border-l-1" component="th" scope="row">
										{n.cxl_orders}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.cxl_payed === "" ? '' : '₪'+n.cxl_payed}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.cxl_grossed === "" ? '' : '₪'+n.cxl_grossed}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.cxl_discount === "" ? '' : '₪'+n.cxl_discount}
									</TableCell>
									<TableCell className="p-4 md:p-16 border-l-1" component="th" scope="row">
										{n.others_orders}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.others_payed === "" ? '' : '₪'+n.others_payed}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.others_grossed === "" ? '' : '₪'+n.others_grossed}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										{n.others_discount === "" ? '' : '₪'+n.others_discount}
									</TableCell>
									{/* <TableCell className="w-40 md:w-64 text-center z-99 border-l-1" component='th' scope='row' align='left'>
										<IconButton aria-label="delete" target="_blank" href={'/domestic/bookingInfo/' + n.partnerId}>
											<OpenInNew />
										</IconButton>
									</TableCell> */}
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className="flex-shrink-0 border-t-1"
				component="div"
				count={dataLength}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}

export default withRouter(PartnerAnalysisTable);
