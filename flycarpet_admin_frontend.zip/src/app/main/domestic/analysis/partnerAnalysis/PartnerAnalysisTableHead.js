
import { makeStyles } from '@material-ui/core/styles';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Tooltip from '@material-ui/core/Tooltip';
import React from 'react';

const rows = [
    {
        id: 'name',
        align: 'left',
        disablePadding: false,
        label: 'user Name',
        sort: true
    },
    {
        id: 'fullname',
        align: 'left',
        disablePadding: false,
        label: 'Full Name',
        sort: true
    },
    {
        id: 'ok_orders',
        align: 'left',
        disablePadding: false,
        label: 'Orders',
        class: ' border-l-1',
        sort: true
    },
    {
        id: 'ok_payed',
        align: 'left',
        disablePadding: false,
        label: 'Payed',
        sort: true
    },
    {
        id: 'ok_grossd',
        align: 'left',
        disablePadding: false,
        label: 'Grossed',
        sort: true
    },
    {
        id: 'ok_discount',
        align: 'left',
        disablePadding: false,
        label: 'Discount',
        sort: true
    },
    {
        id: 'rq_orders',
        align: 'left',
        disablePadding: false,
        label: 'Orders',
        class: ' border-l-1',
        sort: true
    },
    {
        id: 'rq_payed',
        align: 'left',
        disablePadding: false,
        label: 'Payed',
        sort: true
    },
    {
        id: 'rq_grossd',
        align: 'left',
        disablePadding: false,
        label: 'Grossed',
        sort: true
    },
    {
        id: 'rq_discount',
        align: 'left',
        disablePadding: false,
        label: 'Discount',
        sort: true
    },
    {
        id: 'cxl_orders',
        align: 'left',
        disablePadding: false,
        label: 'Orders',
        class: ' border-l-1',
        sort: true
    },
    {
        id: 'cxl_payed',
        align: 'left',
        disablePadding: false,
        label: 'Payed',
        sort: true
    },
    {
        id: 'cxl_grossd',
        align: 'left',
        disablePadding: false,
        label: 'Grossed',
        sort: true
    },
    {
        id: 'cxl_discount',
        align: 'left',
        disablePadding: false,
        label: 'Discount',
        sort: true
    },
    {
        id: 'others_orders',
        align: 'left',
        disablePadding: false,
        label: 'Orders',
        class: ' border-l-1',
        sort: true
    },
    {
        id: 'others_payed',
        align: 'left',
        disablePadding: false,
        label: 'Payed',
        sort: true
    },
    {
        id: 'others_grossd',
        align: 'left',
        disablePadding: false,
        label: 'Grossed',
        sort: true
    },
    {
        id: 'others_discount',
        align: 'left',
        disablePadding: false,
        label: 'Discount',
        sort: true
    },
    // {
    //     id: 'detail',
    //     align: 'center',
    //     disablePadding: false,
    //     label: 'Link',
    //     class: ' border-l-1',
    //     sort: true
    // }
];

function ProductsTableHead(props) {

    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };

    return (
        <TableHead>
            <TableRow className="h-64">
                <TableCell padding="none" className="w-20 md:w-20 text-center z-99"></TableCell>
                <TableCell align='center' colSpan={2}>Partner</TableCell>
                <TableCell align='center' colSpan={4} className="p-4 md:p-16 border-l-1">OK</TableCell>
                <TableCell align='center' colSpan={4} className="p-4 md:p-16 border-l-1">RQ</TableCell>
                <TableCell align='center' colSpan={4} className="p-4 md:p-16 border-l-1">CXL</TableCell>
                <TableCell align='center' colSpan={4} className="p-4 md:p-16 border-l-1">Others</TableCell>
                {/* <TableCell align='center' className="p-4 md:p-16 border-l-1"></TableCell> */}
            </TableRow>
            <TableRow className="h-64">
                <TableCell padding="none" className="w-20 md:w-20 text-center z-99">
                </TableCell>
                {rows.map(row => {
                    return (
                        <TableCell
                            className={"p-4 md:p-16" + row.class ? row.class : ''}
                            key={row.id}
                            align={row.align}
                            padding={row.disablePadding ? 'none' : 'default'}
                            sortDirection={props.order.id === row.id ? props.order.direction : false}
                        >
                            {row.sort && (
                                <Tooltip
                                    title="Sort"
                                    placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                    enterDelay={300}
                                >
                                    <TableSortLabel
                                        active={props.order.id === row.id}
                                        direction={props.order.direction}
                                        onClick={createSortHandler(row.id)}
                                    >
                                        {row.label}
                                    </TableSortLabel>
                                </Tooltip>
                            )}
                        </TableCell>
                    );
                }, this)}
            </TableRow>
        </TableHead>
    );
}

export default ProductsTableHead;
