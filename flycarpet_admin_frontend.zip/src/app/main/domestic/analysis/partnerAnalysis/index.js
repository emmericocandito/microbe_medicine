import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../../store';
import PartnerAnalysisHeader from './PartnerAnalysisHeader';
import PartnerAnalysisTable from './PartnerAnalysisTable';

function PartnerAnalysis() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<PartnerAnalysisHeader />}
			content={<PartnerAnalysisTable />}
			innerScroll
		/>
	);
}

export default withReducer('BasicData', reducer)(PartnerAnalysis);
