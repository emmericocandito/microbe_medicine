import FuseAnimate from '@fuse/core/FuseAnimate';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import { makeStyles } from '@material-ui/core/styles';
import { darken } from '@material-ui/core/styles/colorManipulator';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Typography from '@material-ui/core/Typography';
import { Alert, AlertTitle } from '@material-ui/lab';
import clsx from 'clsx';
import React, { useState, useEffect } from 'react';
import FormControl from '@material-ui/core/FormControl';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import Checkbox from '@material-ui/core/Checkbox';
import Paper from '@material-ui/core/Paper';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import axios from 'axios';
import { truncate } from 'lodash';
import { baseURL } from '../../../utils';

const useStyles = makeStyles(theme => ({
	root: {
		// background: `radial-gradient(${darken(theme.palette.primary.dark, 0.5)} 0%, ${theme.palette.primary.dark} 80%)`
	},
	divider: {
		backgroundColor: theme.palette.divider
	},
	alert: {
		width: '100%',
		'& > * + *': {
			marginTop: theme.spacing(2),
		},
	},
	paper: {
		padding: theme.spacing(2),
		// textAlign: 'center',
		color: theme.palette.text.secondary,
	},
}));

function ContactList(props) {
	const classes = useStyles();
	const [debitInFcResult, set_debitInFcResult] = useState(null);
	const [debitInFcTryAllowed, set_debitInFcTryAllowed] = useState(false);
	const [tryDisabled, setTryDisabled] = useState(false);
	const [showTryButton, setShowTryButton] = useState(true);

	useEffect(() => {
		set_debitInFcTryAllowed(props?.bookingInfo?.originalInfo?.pnr != null);
		setShowTryButton(props.bookingInfo?.originalInfo?.cardTrans);
	}, [props])

	async function handleTryDebitCard() {
		const response = await axios.post(baseURL + 'domestic/api/operation/debitInFc/' + props.bookingInfo.transactionId);
		set_debitInFcTryAllowed(!response.data.error ? true : response.data.error.pnr != '');
		set_debitInFcResult(response.data);
		alert(response.data.error ? `${response.data.error.message}` : `Succeed.`);
	}
	async function handleTrySubDebitCard(inx) {
		setTryDisabled(true);
		const apiCallLogId = props.bookingInfo?.originalInfo?.cardTrans[inx].apiCallLogId;
		const response = await axios.post(`${baseURL}domestic/api/operation/debitInFc/${props.bookingInfo.transactionId}?cardPreflight=${apiCallLogId}`);
		alert(response.data.error ? `${response.data.error.message}` : 'Succeed.');
		setTryDisabled(false);
	}

	return (
		<div className={clsx(classes.root, 'flex-grow flex-shrink-0 p-0 sm:p-10 print:p-0')}>
			<FuseAnimate animation={{ translateY: [0, '100%'] }} duration={600}>
				<Card className="mx-auto w-xl print:w-full print:shadow-none rounded-8">
					<CardContent className="p-88 print:p-0">
						<Typography className="font-light mt-0 mb-10 font-bold text-center" variant="h4" color="textSecondary">
							Unpaid booking details
						</Typography>
						<div className="flex flex-row justify-between items-start">
							<div className="flex flex-col">
								<div className="flex items-center mb-40 print:mb-0">
									<img
										width="30%"
										style={{ borderRadius: '50%' }}
										src="assets/images/examples/transaction1.jpg"
										alt="logo"
									/>
									<div className={clsx(classes.divider, 'mx-28 w-px h-128 print:mx-16')} />
									<div className="max-w-180">
										<Typography className="font-light font-bold" variant="h6" color="textSecondary">
											MAIN INFORMATION
										</Typography>
										<Typography color="textSecondary">
											HotelName : {props.bookingInfo != null && props.bookingInfo.hotelRoomsInfo != null && props.bookingInfo.hotelRoomsInfo.hotelName}
										</Typography>
										<Typography color="textSecondary">
											Hotel Supplier : {props.bookingInfo != null && props.bookingInfo.hotelSupplier}
										</Typography>
										<Typography color="textSecondary">
											BookingSucceced : {props.bookingInfo != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.bookSucceeded && 'bg-red',
													props.bookingInfo.bookSucceeded && 'bg-green',

												)}
											/>
											}
										</Typography>
										<Typography color="textSecondary">
											Payed : {props.bookingInfo != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.payed && 'bg-red',
													props.bookingInfo.payed && 'bg-green',

												)}
											/>
											}
										</Typography>
									</div>
								</div>
							</div>
							<table style={{ width: '250px' }}>
								<tbody>
									<tr>
										<td className="pb-0">
											<Typography className="font-light font-bold" variant="h6" color="textSecondary">
												Payer Information
											</Typography>
										</td>
									</tr>
									<tr>
										<td className="text-left">
											<Typography color="textSecondary">Name : {props.bookingInfo != null && props.bookingInfo.payerInfo != null && props.bookingInfo.payerInfo.name}</Typography>
										</td>
									</tr>
									<tr>
										<td className="text-left">
											<Typography color="textSecondary">Email : {props.bookingInfo != null && props.bookingInfo.payerInfo != null && props.bookingInfo.payerInfo.email}</Typography>
										</td>
									</tr>
									<tr>
										<td className="text-left">
											<Typography color="textSecondary">Mobile : {props.bookingInfo != null && props.bookingInfo.payerInfo != null && props.bookingInfo.payerInfo.mobile}</Typography>
										</td>
									</tr>
									<tr>
										<td className="text-left">
											<Typography color="textSecondary">Expiration : {props.bookingInfo != null && props.bookingInfo.payerInfo != null && props.bookingInfo.payerInfo.creditCardExpirMonth}/{props.bookingInfo != null && props.bookingInfo.payerInfo != null && props.bookingInfo.payerInfo.creditCardExpirYear}</Typography>
										</td>
									</tr>
									<tr>
										<td className="text-left">
											<Typography color="textSecondary">IdentificationNumber : {props.bookingInfo != null && props.bookingInfo.payerInfo != null && props.bookingInfo.payerInfo.identificationNumber}</Typography>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
						<div className="mt-50 print:mt-0">
							<Typography className="font-light font-bold" variant="h6" color="textSecondary">
								Hotel INFOMATION
							</Typography>
							<div style={{ display: 'flex', justifyContent: 'space-around' }}>
								<Typography color="textSecondary">CityName : {props.bookingInfo != null && props.bookingInfo.hotelRoomsInfo != null && props.bookingInfo.hotelRoomsInfo.cityName}</Typography>
								<Typography color="textSecondary">HotelID : {props.bookingInfo != null && props.bookingInfo.hotelRoomsInfo != null && props.bookingInfo.hotelRoomsInfo.hotelId}</Typography>
								<Typography color="textSecondary">CheckDate : {props.bookingInfo != null && props.bookingInfo.hotelRoomsInfo != null && props.bookingInfo.hotelRoomsInfo.checkinDate}/{props.bookingInfo != null && props.bookingInfo.hotelRoomsInfo != null && props.bookingInfo.hotelRoomsInfo.checkoutDate}</Typography>
							</div>
							<Typography className="font-light font-bold" variant="h6" color="textSecondary">
								ROOM INFOMATION
							</Typography>
							<Table className="simple">
								<TableHead>
									<TableRow>
										<TableCell>Code</TableCell>
										<TableCell>Name</TableCell>
										<TableCell>BasisCode</TableCell>
										<TableCell>TypeCode</TableCell>
										<TableCell align="left">Price</TableCell>
										<TableCell align="left">Discount(%)</TableCell>
										<TableCell align="left">Discounted</TableCell>
										<TableCell align="left">adults</TableCell>
										<TableCell align="left">children</TableCell>
										<TableCell align="left">infant</TableCell>
									</TableRow>
								</TableHead>
								<TableBody>
									{props.bookingInfo != null && props.bookingInfo.hotelRoomsInfo != null && props.bookingInfo.hotelRoomsInfo.rooms.map((data, i) => (
										<TableRow key={i}>
											<TableCell>{data.roomClassCode}</TableCell>
											<TableCell>{data.roomClassName}</TableCell>
											<TableCell>{data.basisCode}</TableCell>
											<TableCell>{data.roomCompositionTypeCode}</TableCell>
											<TableCell align="left">
												{data.totalOriginal}
											</TableCell>
											<TableCell align="left">
												{data.discountPercent}%
											</TableCell>
											<TableCell align="left">
												{data.totalAfterDiscounted}
											</TableCell>
											<TableCell align="left">
												{data.adults}
											</TableCell>
											<TableCell align="left">
												{data.children}
											</TableCell>
											<TableCell align="left">
												{data.infant}
											</TableCell>
										</TableRow>
									))}
								</TableBody>
							</Table>
						</div>
						<div className="mt-50 print:mt-0">
							<Typography className="font-light font-bold" variant="h6" color="textSecondary">
								PAX INFOMATION
							</Typography>
							<Table className="simple">
								<TableHead>
									<TableRow>
										<TableCell>Name</TableCell>
										<TableCell>Title</TableCell>
										<TableCell align="left">BirthDay</TableCell>
										<TableCell align="left">MobileNumber</TableCell>
										<TableCell align="left">EMAILADRESS</TableCell>
									</TableRow>
								</TableHead>
								<TableBody>
									{props.bookingInfo != null && props.bookingInfo.paxInfo && props.bookingInfo.paxInfo.map((data, i) => (
										<TableRow key={i}>
											<TableCell>
												<Typography className="mb-8" variant="subtitle1">
													{data.firstName}
												</Typography>
												<Typography variant="caption" color="textSecondary">
													{data.lastName}
												</Typography>
											</TableCell>
											<TableCell>{data.title}</TableCell>
											<TableCell align="left">
												{data.birthDate}
											</TableCell>
											<TableCell><a href={"tel:+" + data.mobileNumber}>{data.mobileNumber}</a></TableCell>
											<TableCell align="left"><a href={"mailto:" + data.emailAddress}>{data.emailAddress}</a></TableCell>
										</TableRow>
									))}
								</TableBody>
							</Table>
						</div>
						<div className={`${classes.alert} mt-50 print:mt-0`}>
							<Typography className="font-light mt-10 mb-10 font-bold" variant="h6" color="textSecondary">
								Results per step and returned messages
							</Typography>

							{props.bookingInfo != null && props.bookingInfo.resultsPerStep != null && props.bookingInfo.messagesPerStep != null &&
								<Alert severity="info" className="mb-10">
									<AlertTitle>1. Book to Atlantis</AlertTitle>
									<FormGroup style={{ display: 'grid', margin: '10px 0px' }}>
										<span>LastPnrGenerationMessage:</span>
										<span>{props.bookingInfo != null && props.bookingInfo.messagesPerStep != null && props.bookingInfo.messagesPerStep.lastPnrGenerationMessage}</span>
									</FormGroup>
									<FormGroup style={{ display: 'block', margin: '10px 0px' }}>
										<span>AtlantisOrderNum:</span>
										<span>{props.bookingInfo != null && props.bookingInfo.resultsPerStep != null && props.bookingInfo.resultsPerStep.atlantisOrderNum}</span>
									</FormGroup>
									<FormGroup style={{ display: 'block', margin: '10px 0px' }}>
										<FormControlLabel
											control={<Checkbox checked={props.bookingInfo.resultsPerStep.allRoomsOk} name="gilad" />}
											label="All Rooms"
										/>
									</FormGroup>
								</Alert>
							}
							{props.bookingInfo != null && props.bookingInfo.resultsPerStep != null && props.bookingInfo.messagesPerStep != null &&
								<Alert severity="info" className="mb-10">
									<AlertTitle>2. Card Verification</AlertTitle>
									<FormGroup style={{ display: 'grid', margin: '10px 0px' }}>
										<span>LastCardVerificationMessage:</span>
										<span>{props.bookingInfo != null && props.bookingInfo.messagesPerStep != null && props.bookingInfo.messagesPerStep.lastCardVerificationMessage}</span>
									</FormGroup>
								</Alert>
							}
							{props.bookingInfo != null && props.bookingInfo.resultsPerStep != null && props.bookingInfo.messagesPerStep != null &&
								<Alert severity="info" className="mb-10">
									<AlertTitle>3. Debit the card</AlertTitle>
									<FormGroup style={{ display: 'grid', margin: '10px 0px' }}>
										<span>LastSaveAndDebitMessage:</span>
										<span>{debitInFcResult? debitInFcResult.status.description : props.bookingInfo != null && props.bookingInfo.messagesPerStep != null && props.bookingInfo.messagesPerStep.lastSaveAndDebitMessage}</span>
									</FormGroup>
									<FormGroup style={{ display: 'block', margin: '10px 0px' }}>
										<span>ReceiptNo:</span>
										<span>{debitInFcResult? debitInFcResult.receiptNo : props.bookingInfo != null && props.bookingInfo.resultsPerStep != null && props.bookingInfo.resultsPerStep.receiptNo}</span>
									</FormGroup>
									<FormGroup style={{ display: 'grid', margin: '10px 0px' }}>
										<span>OdysseaConfirmCodeForReport:</span>
										<span>{debitInFcResult? debitInFcResult.odysseaConfirmCodeForReport : props.bookingInfo != null && props.bookingInfo.resultsPerStep != null && props.bookingInfo.resultsPerStep.odysseaConfirmCodeForReport}</span>
									</FormGroup>
									<FormGroup style={{ display: 'block', margin: '10px 0px' }}>
										<span>CardCompanyApproveNum:</span>
										<span>{debitInFcResult? debitInFcResult.cardApproveNum : props.bookingInfo != null && props.bookingInfo.resultsPerStep != null && props.bookingInfo.resultsPerStep.cardCompanyApproveNum}</span>
									</FormGroup>
									<FormGroup style={{ display: 'block', margin: '10px 0px' }}>
										<FormControlLabel
											control={<Checkbox checked={debitInFcResult && debitInFcResult.status.code===8 ? true : props.bookingInfo.resultsPerStep.isSaveOnly} name="gilad" />}
											label="Save Only"
										/>
										<FormControlLabel
											control={<Checkbox checked={debitInFcResult !== null ? debitInFcResult.paymentSucceeded : props.bookingInfo.resultsPerStep.paymentSucceeded ?? false} name="gilad" />}
											label="PaymentSucceced"
										/>
										<Button variant='contained' color='secondary' style={{ marginLeft: '20px' }} disabled={!debitInFcTryAllowed} onClick={handleTryDebitCard}>
											Try last card
										</Button>
									</FormGroup>
								</Alert>
							}
							{props.bookingInfo != null && props.bookingInfo.resultsPerStep != null && props.bookingInfo.messagesPerStep != null &&
								<Alert severity="info" className="mb-10">
									<AlertTitle>4. Book to the external hotel supplier</AlertTitle>
									<FormGroup style={{ display: 'grid', margin: '10px 0px' }}>
										<span>LastExternalBookingMessage:</span>
										<span>{props.bookingInfo != null && props.bookingInfo.messagesPerStep != null && props.bookingInfo.messagesPerStep.lastSaveAndDebitMessage}</span>
									</FormGroup>
									<FormGroup style={{ display: 'block', margin: '10px 0px' }}>
										<span>ExternalHotelOrderNum:</span>
										<span>{props.bookingInfo != null && props.bookingInfo.resultsPerStep != null && props.bookingInfo.resultsPerStep.externalHotelOrderNum}</span>
									</FormGroup>
									<div style={{ display: 'grid', margin: '10px 0px' }}>
										<span>pnrUpdateStatus:</span>
										{props.bookingInfo == null || props.bookingInfo.resultsPerStep == null || props.bookingInfo.resultsPerStep.pnrUpdateStatus == null ? null : props.bookingInfo.resultsPerStep.pnrUpdateStatus.map((data, index) =>
											<div key={index} style={{ display: 'flex' }}>
												<FormControlLabel
													control={<Checkbox checked={data.Succeeded} name="gilad" />}
													label="Succeeded"
												/>
												<FormGroup style={{ display: 'grid', margin: '10px 0px' }}>
													<span>Message:</span>
													<span>{data.Message}</span>
												</FormGroup>
											</div>
										)}
										<span>{props.bookingInfo != null && props.bookingInfo.resultsPerStep != null && props.bookingInfo.resultsPerStep.odysseaConfirmCodeForReport}</span>
									</div>
									<FormGroup style={{ display: 'grid', margin: '10px 0px' }}>
										<span>pdfUrlHotelVoucher:</span>
										<a href={props.bookingInfo != null && props.bookingInfo.resultsPerStep != null && props.bookingInfo.resultsPerStep.pdfUrlHotelVoucher} target="_blank"> {props.bookingInfo != null && props.bookingInfo.resultsPerStep != null && props.bookingInfo.resultsPerStep.pdfUrlHotelVoucher}</a>
									</FormGroup>
									<FormGroup style={{ display: 'grid', margin: '10px 0px' }}>
										<span>pdfUrlReceipt:</span>
										<a href={props.bookingInfo != null && props.bookingInfo.resultsPerStep != null && props.bookingInfo.resultsPerStep.pdfUrlReceipt} target="_blank"> {props.bookingInfo != null && props.bookingInfo.resultsPerStep != null && props.bookingInfo.resultsPerStep.pdfUrlReceipt}</a>
									</FormGroup>
								</Alert>
							}
						</div>
						<div className="mt-50 print:mt-0">
							<Typography className="font-light font-bold" variant="h6" color="textSecondary">
								Api Call Logs
							</Typography>
							<Table className="simple">
								<TableHead>
									<TableRow>
										<TableCell style={{width:'35%', paddingLeft:'50px'}}>Endpoint</TableCell>
										<TableCell style={{width:'16%'}}>SpentTime(ms)</TableCell>
										<TableCell align="left">Request</TableCell>
										<TableCell align="left">Response</TableCell>
										<TableCell align="left">Call Status</TableCell>
										{showTryButton ? <TableCell align="left">Try buttons</TableCell> : ''}
									</TableRow>
								</TableHead>
								<TableBody>
									<TableRow>
										<TableCell colSpan={6}>
											{
											props.bookingInfo?.bookTransApiCalls?.map((apiCallInfo, index) => {
												return (
													<Table key={index}>
														<TableBody>
															<TableRow className='p-4'>
																<TableCell> <h2>{index + 1}th Try</h2> </TableCell>
															</TableRow>
															<TableRow >
																<TableCell>
																	<Typography className="mb-8" variant="subtitle1">
																		Pnr Generation
																	</Typography>
																</TableCell>
																<TableCell>{apiCallInfo?.pnrGeneration?.spentTime}</TableCell>
																<TableCell >{apiCallInfo?.pnrGeneration?.logId &&
																	<a href={"https://api.flying-carpet.co.il/api/analysis/bookingApiLog/" +
																		apiCallInfo.pnrGeneration.logId + "/request"} target="_blank">Request</a>
																}
																</TableCell>
																<TableCell >{apiCallInfo?.pnrGeneration?.logId &&
																	<a href={"https://api.flying-carpet.co.il/api/analysis/bookingApiLog/" +
																		apiCallInfo.pnrGeneration.logId + "/response"} target="_blank">Response</a>
																}
																</TableCell>
																<TableCell>{apiCallInfo?.pnrGeneration?.httpResCode}</TableCell>
															</TableRow>
															<TableRow >
																<TableCell>
																	<Typography className="mb-8" variant="subtitle1">
																		Card Preflight
																	</Typography>
																</TableCell>
																<TableCell>{apiCallInfo?.cardPreflight?.spentTime}</TableCell>
																<TableCell >{apiCallInfo?.cardPreflight?.logId &&
																	<a href={"https://api.flying-carpet.co.il/api/analysis/bookingApiLog/" +
																		apiCallInfo.cardPreflight.logId + "/request"} target="_blank">Request</a>
																}
																</TableCell>
																<TableCell >{apiCallInfo?.cardPreflight?.logId &&
																	<a href={"https://api.flying-carpet.co.il/api/analysis/bookingApiLog/" +
																		apiCallInfo.cardPreflight.logId + "/response"} target="_blank">Response</a>
																}
																</TableCell>
																<TableCell>{apiCallInfo?.cardPreflight?.httpResCode}</TableCell>
																{showTryButton ?
																	<TableCell style={{paddingRight: 0, width: 80}}>
																		<Button variant='contained' color='secondary' disabled={tryDisabled} onClick={() => handleTrySubDebitCard(index)}>
																			Try
																		</Button>
																	</TableCell> : ''}
															</TableRow>
															<TableRow >
																<TableCell>
																	<Typography className="mb-8" variant="subtitle1">
																		Card Verification
																	</Typography>
																</TableCell>
																<TableCell>{apiCallInfo?.cardVerification?.spentTime}</TableCell>
																<TableCell >{apiCallInfo?.cardVerification?.logId &&
																	<a href={"https://api.flying-carpet.co.il/api/analysis/bookingApiLog/" +
																		apiCallInfo.cardVerification.logId + "/request"} target="_blank">Request</a>
																}
																</TableCell>
																<TableCell >{apiCallInfo?.cardVerification?.logId &&
																	<a href={"https://api.flying-carpet.co.il/api/analysis/bookingApiLog/" +
																		apiCallInfo.cardVerification.logId + "/response"} target="_blank">Response</a>
																}
																</TableCell>
																<TableCell>{apiCallInfo?.cardVerification?.httpResCode}</TableCell>
															</TableRow>
															<TableRow >
																<TableCell>
																	<Typography className="mb-8" variant="subtitle1">
																		Save and Debit
																	</Typography>
																</TableCell>
																<TableCell>{apiCallInfo?.saveAndDebit?.spentTime}</TableCell>
																<TableCell >{apiCallInfo?.saveAndDebit?.logId &&
																	<a href={"https://api.flying-carpet.co.il/api/analysis/bookingApiLog/" +
																		apiCallInfo.saveAndDebit.logId + "/request"} target="_blank">Request</a>
																}
																</TableCell>
																<TableCell >{apiCallInfo?.saveAndDebit?.logId &&
																	<a href={"https://api.flying-carpet.co.il/api/analysis/bookingApiLog/" +
																		apiCallInfo.saveAndDebit.logId + "/response"} target="_blank">Response</a>
																}
																</TableCell>
																<TableCell>{apiCallInfo?.saveAndDebit?.httpResCode}</TableCell>
															</TableRow>
															<TableRow>
																<TableCell colSpan={5}>External Books
																{
																	apiCallInfo?.externalBooks?.map((bookInfo, book_index) => {
																		return (
																			<Table key={`book_${book_index}`}>
																				<TableBody>
																					<TableRow>
																						<TableCell style={{width: '38%'}}>
																							Try {book_index+1}
																						</TableCell>
																						<TableCell>{bookInfo?.spentTime}</TableCell>
																						<TableCell >{bookInfo?.logId &&
																							<a href={"https://api.flying-carpet.co.il/api/analysis/bookingApiLog/" +
																								bookInfo.logId + "/request"} target="_blank">Request</a>
																						}
																						</TableCell>
																						<TableCell >{bookInfo?.logId &&
																							<a href={"https://api.flying-carpet.co.il/api/analysis/bookingApiLog/" +
																								bookInfo.logId + "/response"} target="_blank">Response</a>
																						}
																						</TableCell>
																						<TableCell>{bookInfo?.httpResCode}</TableCell>
																					</TableRow>
																				</TableBody>
																			</Table>
																		)
																	})
																}
																</TableCell>
															</TableRow>
															<TableRow >
																<TableCell>
																	<Typography className="mb-8" variant="subtitle1">
																		Check Pnr Status
																	</Typography>
																</TableCell>
																<TableCell>{apiCallInfo?.pnrUpdate?.spentTime}</TableCell>
																<TableCell >{apiCallInfo?.pnrUpdate?.logId &&
																	<a href={"https://api.flying-carpet.co.il/api/analysis/bookingApiLog/" +
																		apiCallInfo.pnrUpdate.logId + "/request"} target="_blank">Request</a>
																}
																</TableCell>
																<TableCell >{apiCallInfo?.pnrUpdate?.logId &&
																	<a href={"https://api.flying-carpet.co.il/api/analysis/bookingApiLog/" +
																		apiCallInfo.pnrUpdate.logId + "/response"} target="_blank">Response</a>
																}
																</TableCell>
																<TableCell>{apiCallInfo?.pnrUpdate?.httpResCode}</TableCell>
															</TableRow>
														</TableBody>
													</Table>
													)
												})
											}
										</TableCell>
									</TableRow>
								</TableBody>
							</Table>
						</div>
						<div className={`${classes.alert} mt-50 print:mt-0`}>
							<Typography className="font-light mt-10 mb-10 font-bold" variant="h6" color="textSecondary">
								BOOKING STATUS
							</Typography>
							<Typography className="font-light font-bold" variant="h6" color="textSecondary">
								SucceededBookingDocumentsDelivery
							</Typography>
							<Grid container spacing={3}>
								<Grid item xs={4}>
									<FormGroup style={{ display: 'grid', margin: '10px 0px' }}>
										<span style={{ fontWeight: 'bold' }}>Email</span>
										<span>SentTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.email != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.email.sentTime} </span>
										<span>ScheduledTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.email != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.email.scheduledTime} </span>
										<span>
											Succeced : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.email != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.email.succeeded != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.email.succeeded && 'bg-red',
													props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.email.succeeded && 'bg-green',

												)}
											/>
											}
										</span>
										<span>TriedCount : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.email != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.email.triedCount} </span>
										<span>
											Enabled : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.email != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.email.enabled != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.email.enabled && 'bg-red',
													props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.email.enabled && 'bg-green',

												)}
											/>
											}
										</span>
										<span>ErrorMessage : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.email != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.email.errorMessage} </span>
									</FormGroup>
								</Grid>
								<Grid item xs={4}>
									<FormGroup style={{ display: 'grid', margin: '10px 0px' }}>
										<span style={{ fontWeight: 'bold' }}>SMS</span>
										<span>SentTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.sms != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.sms.sentTime} </span>
										<span>ScheduledTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.sms != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.sms.scheduledTime} </span>
										<span>
											Succeced : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.sms != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.sms.succeeded != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.sms.succeeded && 'bg-red',
													props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.sms.succeeded && 'bg-green',

												)}
											/>
											}
										</span>
										<span>TriedCount : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.sms != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.sms.triedCount} </span>
										<span>
											Enabled : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.sms != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.sms.enabled != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.sms.enabled && 'bg-red',
													props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.sms.enabled && 'bg-green',

												)}
											/>
											}
										</span>
										<span>ErrorMessage : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.email != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.sms.errorMessage} </span>
									</FormGroup>
								</Grid>
								<Grid item xs={4}>
									<FormGroup style={{ display: 'grid', margin: '10px 0px' }}>
										<span style={{ fontWeight: 'bold' }}>WhatsApp</span>
										<span>SentTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.whatsapp != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.whatsapp.sentTime} </span>
										<span>ScheduledTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.whatsapp != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.whatsapp.scheduledTime} </span>
										<span>
											Succeced : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.whatsapp != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.whatsapp.succeeded != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.whatsapp.succeeded && 'bg-red',
													props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.whatsapp.succeeded && 'bg-green',

												)}
											/>
											}
										</span>
										<span>TriedCount : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.whatsapp != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.whatsapp.triedCount} </span>
										<span>
											Enabled : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.whatsapp != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.whatsapp.enabled != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.whatsapp.enabled && 'bg-red',
													props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.whatsapp.enabled && 'bg-green',

												)}
											/>
											}
										</span>
										<span>ErrorMessage : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.whatsapp != null && props.bookingInfo.afterBookingService.succeededBookingDocumentsDelivery.whatsapp.errorMessage} </span>
									</FormGroup>
								</Grid>
							</Grid>
							<Typography className="font-light font-bold" variant="h6" color="textSecondary">
								FailedBookingNotificationStatus
							</Typography>
							<Grid container spacing={3}>
								<Grid item xs={4}>
									<FormGroup style={{ display: 'grid', margin: '10px 0px' }}>
										<span style={{ fontWeight: 'bold' }}>Email</span>
										<span>SentTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.email != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.email.sentTime} </span>
										<span>ScheduledTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.email != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.email.scheduledTime} </span>
										<span>
											Succeced : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.email != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.email.succeeded != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.failedBookingNotificationStatus.email.succeeded && 'bg-red',
													props.bookingInfo.afterBookingService.failedBookingNotificationStatus.email.succeeded && 'bg-green',

												)}
											/>
											}
										</span>
										<span>TriedCount : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.email != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.email.triedCount} </span>
										<span>
											Enabled : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.email != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.email.enabled != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.failedBookingNotificationStatus.email.enabled && 'bg-red',
													props.bookingInfo.afterBookingService.failedBookingNotificationStatus.email.enabled && 'bg-green',

												)}
											/>
											}
										</span>
										<span>ErrorMessage : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.email != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.email.errorMessage} </span>
									</FormGroup>
								</Grid>
								<Grid item xs={4}>
									<FormGroup style={{ display: 'grid', margin: '10px 0px' }}>
										<span style={{ fontWeight: 'bold' }}>SMS</span>
										<span>SentTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.sms != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.sms.sentTime} </span>
										<span>ScheduledTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.sms != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.sms.scheduledTime} </span>
										<span>
											Succeced : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.sms != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.sms.succeeded != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.failedBookingNotificationStatus.sms.succeeded && 'bg-red',
													props.bookingInfo.afterBookingService.failedBookingNotificationStatus.sms.succeeded && 'bg-green',

												)}
											/>
											}
										</span>
										<span>TriedCount : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.sms != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.sms.triedCount} </span>
										<span>
											Enabled : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.sms != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.sms.enabled != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.failedBookingNotificationStatus.sms.enabled && 'bg-red',
													props.bookingInfo.afterBookingService.failedBookingNotificationStatus.sms.enabled && 'bg-green',

												)}
											/>
											}
										</span>
										<span>ErrorMessage : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.sms != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.sms.errorMessage} </span>
									</FormGroup>
								</Grid>
								<Grid item xs={4}>
									<FormGroup style={{ display: 'grid', margin: '10px 0px' }}>
										<span style={{ fontWeight: 'bold' }}>WhatsApp</span>
										<span>SentTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.whatsapp != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.whatsapp.sentTime} </span>
										<span>ScheduledTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.whatsapp != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.whatsapp.scheduledTime} </span>
										<span>
											Succeced : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.whatsapp != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.whatsapp.succeeded != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.failedBookingNotificationStatus.whatsapp.succeeded && 'bg-red',
													props.bookingInfo.afterBookingService.failedBookingNotificationStatus.whatsapp.succeeded && 'bg-green',

												)}
											/>
											}
										</span>
										<span>TriedCount : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.whatsapp != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.whatsapp.triedCount} </span>
										<span>
											Enabled : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.whatsapp != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.whatsapp.enabled != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.failedBookingNotificationStatus.whatsapp.enabled && 'bg-red',
													props.bookingInfo.afterBookingService.failedBookingNotificationStatus.whatsapp.enabled && 'bg-green',

												)}
											/>
											}
										</span>
										<span>ErrorMessage : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.whatsapp != null && props.bookingInfo.afterBookingService.failedBookingNotificationStatus.whatsapp.errorMessage} </span>
									</FormGroup>
								</Grid>
							</Grid>
							<Typography className="font-light font-bold" variant="h6" color="textSecondary">
								OperatorNotificationStatus
							</Typography>
							<Grid container spacing={3}>
								<Grid item xs={4}>
									<FormGroup style={{ display: 'grid', margin: '10px 0px' }}>
										<span style={{ fontWeight: 'bold' }}>Email</span>
										<span>SentTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.email != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.email.sentTime} </span>
										<span>ScheduledTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.email != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.email.scheduledTime} </span>
										<span>
											Succeced : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.email != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.email.succeeded != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.operatorNotificationStatus.email.succeeded && 'bg-red',
													props.bookingInfo.afterBookingService.operatorNotificationStatus.email.succeeded && 'bg-green',

												)}
											/>
											}
										</span>
										<span>TriedCount : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.email != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.email.triedCount} </span>
										<span>
											Enabled : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.email != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.email.enabled != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.operatorNotificationStatus.email.enabled && 'bg-red',
													props.bookingInfo.afterBookingService.operatorNotificationStatus.email.enabled && 'bg-green',

												)}
											/>
											}
										</span>
										<span>ErrorMessage : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.email != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.email.errorMessage} </span>
									</FormGroup>
								</Grid>
								<Grid item xs={4}>
									<FormGroup style={{ display: 'grid', margin: '10px 0px' }}>
										<span style={{ fontWeight: 'bold' }}>SMS</span>
										<span>SentTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.sms != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.sms.sentTime} </span>
										<span>ScheduledTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.sms != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.sms.scheduledTime} </span>
										<span>
											Succeced : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.sms != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.sms.succeeded != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.operatorNotificationStatus.sms.succeeded && 'bg-red',
													props.bookingInfo.afterBookingService.operatorNotificationStatus.sms.succeeded && 'bg-green',

												)}
											/>
											}
										</span>
										<span>TriedCount : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.sms != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.sms.triedCount} </span>
										<span>
											Enabled : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.sms != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.sms.enabled != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.operatorNotificationStatus.sms.enabled && 'bg-red',
													props.bookingInfo.afterBookingService.operatorNotificationStatus.sms.enabled && 'bg-green',

												)}
											/>
											}
										</span>
										<span>ErrorMessage : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.sms != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.sms.errorMessage} </span>
									</FormGroup>
								</Grid>
								<Grid item xs={4}>
									<FormGroup style={{ display: 'grid', margin: '10px 0px' }}>
										<span style={{ fontWeight: 'bold' }}>WhatsApp</span>
										<span>SentTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.whatsapp != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.whatsapp.sentTime} </span>
										<span>ScheduledTime : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.whatsapp != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.whatsapp.scheduledTime} </span>
										<span>
											Succeced : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.whatsapp != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.whatsapp.succeeded != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.operatorNotificationStatus.whatsapp.succeeded && 'bg-red',
													props.bookingInfo.afterBookingService.operatorNotificationStatus.whatsapp.succeeded && 'bg-green',

												)}
											/>
											}
										</span>
										<span>TriedCount : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.whatsapp != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.whatsapp.triedCount} </span>
										<span>
											Enabled : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.whatsapp != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.whatsapp.enabled != null && <i
												className={clsx(
													'inline-block w-8 h-8 rounded mx-8',
													!props.bookingInfo.afterBookingService.operatorNotificationStatus.whatsapp.enabled && 'bg-red',
													props.bookingInfo.afterBookingService.operatorNotificationStatus.whatsapp.enabled && 'bg-green',

												)}
											/>
											}
										</span>
										<span>ErrorMessage : {props.bookingInfo != null && props.bookingInfo.afterBookingService != null && props.bookingInfo.afterBookingService.operatorNotificationStatus != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.whatsapp != null && props.bookingInfo.afterBookingService.operatorNotificationStatus.whatsapp.errorMessage} </span>
									</FormGroup>
								</Grid>
							</Grid>

						</div>
						<div className="mt-96 print:mt-0 print:px-16">
							{/* <Typography className="mt-15 mb-15 print:mb-12" variant="body1" style={{ lineHeight: '2.5' }}>
								Note: Only the bookings that has at least 1 phone number have this page.
							</Typography> */}
							<div className="flex">
								<div className="flex-shrink-0">
									<img className="w-32" src="assets/images/logos/fuse-1.png" alt="logo" />
								</div>
								<Typography className="mt-15 mb-15 print:mb-12" variant="body1" style={{ lineHeight: '2.5' }}>
									Please contact with coustomer Thank you for your business.
								</Typography>
							</div>
						</div>
					</CardContent>
				</Card>
			</FuseAnimate>
		</div>
	);
}

export default ContactList;

