import FusePageSimple from '@fuse/core/FusePageSimple';
import withReducer from 'app/store/withReducer';
import React, { useEffect, useState } from 'react';
import ContactsList from './ContactsList';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { baseURL } from '../../../utils';

function ContactsApp(props) {
	const routeParams = useParams();
	const [bookingInfo, setBookingInfo] = useState(null);

	useEffect(() => {
		getBookingInfo(routeParams.id)
	}, []);

	function getBookingInfo(transactionID) {
		axios.get(baseURL + 'domestic/api/analysis/bookings/' + transactionID).then(response => {
			const bookingInfo = response.data;
			setBookingInfo(bookingInfo);
		}).catch(error => {
			console.log(error)
			// window.location.assign("/errors/error-404")
		});
	};

	return (
		<>
			<FusePageSimple
				classes={{
					content: 'flex flex-col h-full',
				}}
				content={<ContactsList bookingInfo={bookingInfo} />}
			/>
		</>
	);
}

export default withReducer('contactsApp')(ContactsApp);
