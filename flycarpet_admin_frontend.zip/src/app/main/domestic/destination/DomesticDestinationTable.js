import FuseScrollbars from '@fuse/core/FuseScrollbars';
import axios from 'axios';
import _ from '@lodash';
import Checkbox from '@material-ui/core/Checkbox';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import FuseLoading from '@fuse/core/FuseLoading';
import DestinationTableHead from './DomesticDestinationTableHead';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import Backdrop from '@material-ui/core/Backdrop';
import Fade from '@material-ui/core/Fade';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import FormControl from '@material-ui/core/FormControl';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import SearchIcon from '@material-ui/icons/Search';
import Select from '@material-ui/core/Select';
import { baseURL, isHighTeckUser } from 'app/main/utils';

function DestinationTable(props) {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			margin: '8px 0px',
			minWidth: 120,
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			width: 950,
			maxHeight: '90vh',
			overflowY: 'auto'
		},
		button_group: {
			textAlign: 'center',
			padding: 30,
		},
		buttons: {
			// float: 'right',
			marginRight: '10px'
		},
		textfield: {
			width: '100%'
		},
		ntextArea: {
			width: '100%',
			border: '1px solid gray',
			minHeight: '35px !important',
			'&:hover': {
				outlineColor: '#000000cf',
				borderRadius: '0'
			},
			'&:active': {
				outlineColor: '#000000cf',
				borderRadius: '0'
			},
			'&:focus': {
				outlineColor: '#000000cf !important',
				borderRadius: '0'
			},
		},
		imageUploader: {
			maxWidth: '500px',

		},
		deleteImage: {
			position: 'absolute',
			top: '1px',
			right: '7px',
			color: '#fff',
			background: '#ff4081',
			borderRadius: '50%',
			textAign: 'center',
			cursor: 'pointer',
			fontSize: '17px',
			fontWeight: 'bold',
			lineHeight: '20px',
			width: '20px',
			height: '20px'
		},
	}));

	const classes = useStyles();
	const [loading, setLoading] = useState(true);
	const [warningOpen, setWarningOpen] = useState(false);
	const [warningText, setWarningText] = useState(null);
	const [nCodeState, setCode] = useState(null);
	const [nNameState, setNameState] = useState(null);
	// const [nEnState, setEn] = useState(null);
	// const [nHeState, setHe] = useState(null);
	// const [nRuState, setRu] = useState(null);
	// const [nArState, setAr] = useState(null);
	const [nAreaState, setArea] = useState(null);
	const [nDestinationOrder, setDestinationOrder] = useState(null);
	const [nIsActiveState, setIsActive] = useState(false);

	/////////////////////////////////////////////////////
	const [nFilterNameState, setFilterName] = useState();
	const [nFilterActive, setActiveFilter] = useState(null);
	/////////////////////////////////////////////////////
	const [selected] = useState([]);
	const [data, setData] = useState([]);
	const [dataLength, setDataLength] = useState(0);
	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});

	const [open, setOpen] = React.useState(false);
	const [openFilter, setOpenFilter] = useState(false);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [nButtonText, setButtonText] = useState(null);
	const [confirmText, setConfirmText] = useState(null);

	const addDestination = () => {
		setButtonText('Add');
		setOpen(true);
	};
	const deleteHandle = async (index) => {
		const orderedData = _.orderBy(
			data,
			[
				o => {
					switch (order.id) {
						case 'categories': {
							return o.categories[0];
						}
						default: {
							return o[order.id];
						}
					}
				}
			],
			[order.direction]
		);

		setCode(orderedData[index]['code']);

		setConfirmText("Do you want to drop this Destination?");
		setConfirmOpen(true);
	}
	const openSearchModel = () => {
		setOpenFilter(true);
	};
	const handleFilterClose = () => {
		setOpenFilter(false);
	};
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}

	const handleChangeCheckbox = (event) => {
		setIsActive(event.target.checked);
	}
	const handleChangeCode = (event) => {
		setCode(event.target.value || null);
	}
	// const handleChangeEn = (event) => {
	// 	setEn(event.target.value || null);
	// }
	// const handleChangeHE = (event) => {
	// 	setHe(event.target.value || null);
	// }
	// const handleChangeRU = (event) => {
	// 	setRu(event.target.value || null);
	// }
	// const handleChangeAR = (event) => {
	// 	setAr(event.target.value || null);
	// }
	const handleChangeArea = (event) => {
		setArea(event.target.value || null);
	}
	const handleChangeOrder = (event) => {
		setDestinationOrder(event.target.value || null);
	}

	///////////////////////////////////////
	const handleChangeFilterEn = (event) => {
		setFilterName(event.target.value);
	}
	const handleChangeActiveState = (event) => {
		setActiveFilter(event.target.value);
	}

	function searchDestination() {
		setPage(0);
		reopen(1, rowsPerPage);
		setOpenFilter(false);
	}
	/////////////////////////////////
	const handleOpen = (index) => {
		if(isHighTeckUser) return;

		setButtonText('Edit');
		const orderedData = _.orderBy(
			data,
			[
				o => {
					switch (order.id) {
						case 'categories': {
							return o.categories[0];
						}
						default: {
							return o[order.id];
						}
					}
				}
			],
			[order.direction]
		);

		setCode(orderedData[index]['code']);
		setNameState(orderedData[index]['name']);
		// setEn(orderedData[index]['nameTranslations']['en']);
		// setHe(orderedData[index]['nameTranslations']['he']);
		// setRu(orderedData[index]['nameTranslations']['ru']);
		// setAr(orderedData[index]['nameTranslations']['ar']);
		setIsActive(orderedData[index]['active']);
		setDestinationOrder(orderedData[index]['order']);
		setArea(orderedData[index]['area']);
		setOpen(true);

	}
	const handleClose = () => {
		initialValue();
		setOpen(false);
	}

	const handleCloseWarning = () => {
		setWarningOpen(false);
	}
	async function editProcess() {
		setLoading(true);
		let post_url;
		if (nButtonText === 'Edit') {
			post_url = `${baseURL}domestic/api/destination/${nCodeState}`;
		}
		else {
			post_url = `${baseURL}domestic/api/destination`;
		}
		const data = {
			"code": nCodeState || null,
			"name": nNameState,
			// "nameTranslations": {
			// 		"en": nEnState || null,
			// 		"he": nHeState || null,
			// 		"ru": nRuState || null,
			// 		"ar": nArState || null
			// },
			"area": nAreaState || null,
			"active": nIsActiveState || false,
			"order": nDestinationOrder,
		}
		await axios({
			method: 'post',
			url: post_url,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: data
		}).then(response => {
			setLoading(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}
			setOpen(false);
			initialValue();
		}).catch(error => {
			setLoading(false);
			setConfirmOpen(false);
			setWarningOpen(true);
			setWarningText(JSON.stringify(error.response.data.errors));
		});
	};
	async function confirmProcess() {
		setLoading(true);
		await axios.delete(`${baseURL}domestic/api/destination/${nCodeState}`, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		}).then(response => {
			setLoading(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}
			initialValue();
			setOpen(false);
			setConfirmOpen(false);
		}).catch(error => {
			setLoading(false);
			setConfirmOpen(false);
			setWarningOpen(true);
			setWarningText(error.response.data);
		});

	};

	useEffect(() => {
		reopen(1, 10);
	}, []);


	async function reopen(from, to) {
		const active = nFilterActive == '' || nFilterActive == null ? null : nFilterActive == 'true';
		await axios({
			method: 'post',
			url: `${baseURL}domestic/api/destination/search?from=${from}&to=${to}`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"name": nFilterNameState || null,
				"active": active,
			}
		}).then(response => {
			setLoading(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				setData(response.data['data']);
				setDataLength(response.data['total']);
			}
			setOpen(false);
		}).catch(error => {
			setLoading(false);
			setWarningOpen(true);
			setWarningText(error.response.data);
		});
	}
	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}
	function handleChangePage(event, value) {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage
		reopen(from, to);
	}
	function handleChangeRowsPerPage(event) {
		setPage(0);
		setRowsPerPage(event.target.value);
		reopen(1, event.target.value);
	}
	function initialValue() {
		setCode(null);
		setIsActive(false);
		setNameState(null);
		// setEn(null);
		// setHe(null);
		// setRu(null);
		// setAr(null);
		setDestinationOrder(null);
		setArea(null);
	}
	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className="w-full flex flex-col">
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={openFilter}
				onClose={handleFilterClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={openFilter}>
					<div className={classes.paper}>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title' >Filter Setting</h2>
						</div>
						<div style={{ display: 'grid' }}>

							<TextField onChange={handleChangeFilterEn} className={classes.textfield} label="Name" defaultValue={nFilterNameState} />
							{/* <TextField onChange={handleChangeFilterCode} className={classes.textfield} label="Code" defaultValue={nFilterCodeState} />
							<TextField onChange={handleChangeFilterRU} className={classes.textfield} label="Name_RU" defaultValue={nFilterRuState} />
							<div dir='rtl'>
								<TextField onChange={handleChangeFilterHE} className={classes.textfield} label="Name_HE" defaultValue={nFilterHeState} />
							</div>
							<div dir='rtl'>
							<TextField onChange={handleChangeFilterAR} className={classes.textfield} label="Name_AR" defaultValue={nFilterArState} />
							</div>

							<FormControl required className={classes.formControl}>
								<FormHelperText>Country</FormHelperText>
								<Select
									native
									onChange={handleChangeFilterCountry}
									value={nFilterCountry}
									inputProps={{
										id: 'age-native-required',
									}}
								>
									<option aria-label='None' value=''>All</option>
									{
										nCountryList.map((n, i) => {
											return (
												<option value={n.code} key={i}>{n.name}</option>
											)
										})
									}
								</Select>
							</FormControl>

							<FormControl required className={classes.formControl}>
								<FormHelperText>LandingPageDestCode</FormHelperText>
								<Select
									native
									onChange={handleChangeFilterLandingPageDestCode}
									value={nFilterLandingPageDestCode}
									inputProps={{
										id: 'age-native-required',
									}}
								>
									<option aria-label='None' value=''>None</option>
									{
										nDestinationList.map((n, i) => {
											return (
												<option value={n.code} key={i}>{n.code}</option>
											)
										})
									}
								</Select>
							</FormControl>


							<TextField onChange={handleChangeRemarkFilterEn} className={classes.textfield} label="Remark_EN" defaultValue={nFilterRemarkEnState} />
							<TextField onChange={handleChangeRemarkFilterRU} className={classes.textfield} label="Remark_RU" defaultValue={nFilterRemarkRuState} />
							<div dir='rtl'>
								<TextField onChange={handleChangeRemarkFilterHE} className={classes.textfield} label="Remark_HE" defaultValue={nFilterRemarkHeState} />
							</div>
							<div dir='rtl'>
								<TextField onChange={handleChangeRemarkFilterAR} className={classes.textfield} label="Remark_AR" defaultValue={nFilterRemarkArState} />
							</div>

							<TextField onChange={handleChangeNoteFilterEn} className={classes.textfield} label="Note_EN" defaultValue={nFilterNoteEnState} />
							<TextField onChange={handleChangeNoteFilterRU} className={classes.textfield} label="Note_EN" defaultValue={nFilterNoteRuState} />
							<div dir='rtl'>
								<TextField onChange={handleChangeNoteFilterHE} className={classes.textfield} label="Note_HE" defaultValue={nFilterNoteHeState} />
							</div>
							<div dir='rtl'>
								<TextField onChange={handleChangeNoteFilterAR} className={classes.textfield} label="Note_AR" defaultValue={nFilterNoteArState} />
							</div>
							<TextField onChange={handleChangeImageFilter} className={classes.textfield} label="ImageURL" defaultValue={nFilterImageURL} />
							<TextField onChange={handleChangeGalleryFilter} className={classes.textfield} label="GalleryURL" defaultValue={nFilterGalleryURL} /> */}
							<FormControl required className={classes.formControl}>
								<FormHelperText>Active State</FormHelperText>
								<Select
									native
									onChange={handleChangeActiveState}
									value={nFilterActive}
									inputProps={{
										id: 'age-native-required',
									}}
								>
									<option aria-label='None' value=''>All</option>
									<option value='true'>Active</option>
									<option value='false'>Unactive</option>
								</Select>
							</FormControl>
						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' color='secondary' onClick={searchDestination}>
								Filter
							</Button>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleFilterClose}>
								Cancel
							</Button>

						</div>
					</div>

				</Fade>
			</Modal>
			<Modal
				open={confirmOpen}
				onClose={handleCloseConfirm}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Confirm</h2>
					<p id='server-modal-description'>{confirmText}</p>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={confirmProcess}>Confirm
					</Button>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={handleCloseConfirm}>Cancel
					</Button>
				</div>
			</Modal>
			<Modal
				open={warningOpen}
				onClose={handleCloseWarning}
				className={classes.modal}
				aria-labelledby="simple-modal-title"
				aria-describedby="simple-modal-description"
			>
				<div className={classes.paper}>
					<h2 id="server-modal-title" >Warning</h2>
					<p id="server-modal-description">{warningText}</p>
					<Button className="whitespace-no-wrap normal-case"
						variant="contained"
						color="secondary"
						onClick={handleCloseWarning}>Close
					</Button>
				</div>
			</Modal>
			<Modal
				aria-labelledby="transition-modal-title"
				aria-describedby="transition-modal-description"
				className={classes.modal}
				open={open}
				onClose={handleClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={open}>
					<div className={classes.paper}>
						<h2 id="transition-modal-title" style={{ textAlign: 'center' }}>Edit</h2>
						<div style={{ display: 'grid' }}>
							<TextField onChange={handleChangeCode} className={classes.textfield} label="Code" defaultValue={nCodeState || ''} />
							<TextField onChange={(e) => setNameState(e.target.value)} className={classes.textfield} label="Name" defaultValue={nNameState || ''} />
							{/* <TextField onChange={handleChangeEn} className={classes.textfield} label="Name_En" defaultValue={nEnState || ''} />
							<TextField onChange={handleChangeRU} className={classes.textfield} label="Name_RU" defaultValue={nRuState || ''} />
							<div dir='rtl'>
								<TextField onChange={handleChangeHE} className={classes.textfield} label="Name_HE" defaultValue={nHeState || ''} />
							</div>
							<div dir='rtl'>
								<TextField onChange={handleChangeAR} className={classes.textfield} label="Name_AR" defaultValue={nArState || ''} />
							</div> */}

							<TextField onChange={handleChangeArea} className={classes.textfield} label="Area" defaultValue={nAreaState || ''} />
							<TextField onChange={handleChangeOrder} className={classes.textfield} label="Order" defaultValue={nDestinationOrder || 0} type="number" />

							<FormControlLabel
								control={
									<Checkbox
										checked={nIsActiveState || false}
										onChange={handleChangeCheckbox}
										name='checkedC'
										color='primary'
									/>
								}
								label='Active'
								className={classes.checkboxform}
							/>
						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant="contained" onClick={editProcess} color="secondary">
								{nButtonText}
							</Button>
							<Button className={classes.buttons} variant="contained" color="primary" onClick={handleClose}>
								Cancel
							</Button>
						</div>
					</div>
				</Fade>
			</Modal>
			<div>
				{ !isHighTeckUser &&
					<Button
						className='whitespace-no-wrap normal-case'
						variant='contained'
						color='secondary'
						style={{ float: 'right', margin: '15px 5px' }}
						onClick={() => addDestination()}
					>
						<span className='hidden sm:flex'>Add Destination</span>
						<span className='flex sm:hidden'>Add</span>
					</Button>
				}
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => openSearchModel()}
				>
					<span className='hidden sm:flex'><SearchIcon />Filter</span>
					<span className='flex sm:hidden'><SearchIcon /></span>
				</Button>
			</div>
			<FuseScrollbars className="flex-grow overflow-x-auto">
				<Table stickyHeader className="min-w-xl" aria-labelledby="tableTitle">
					<DestinationTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={data.length}
					/>
					<TableBody>
						{_.orderBy(
							data,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className="h-64 cursor-pointer"
									hover
									tabIndex={-1}
									key={i}
								>
									<TableCell padding="none" className="w-20 md:w-20 text-center z-99">
									</TableCell>
									<TableCell className="w-80 md:w-124 z-99" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.code}
									</TableCell>


									<TableCell className="p-4 md:p-16 truncate" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.name}
									</TableCell>
									{/* <TableCell className="p-4 md:p-16 truncate" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.nameTranslations.en}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => handleOpen(i)}>
										{n.nameTranslations.ru}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="right" onClick={() => handleOpen(i)}>
										{n.nameTranslations.he}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="right" onClick={() => handleOpen(i)}>
										{n.nameTranslations.ar}
									</TableCell> */}
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="right" onClick={() => handleOpen(i)}>
										{n.area}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="right" onClick={() => handleOpen(i)}>
										{n.order}
									</TableCell>

									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="right" onClick={() => handleOpen(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.active && 'bg-red',
												n.active && 'bg-green',

											)}
										/>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="right">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => handleOpen(i)} tabIndex="0" type="button" title="Edit" disabled={isHighTeckUser}><span className="MuiIconButton-label"><span className="material-icons MuiIcon-root" aria-hidden="true">edit</span></span><span className="MuiTouchRipple-root"></span></button>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => deleteHandle(i)} tabIndex="0" type="button" title="Delete" disabled={isHighTeckUser}>
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
									<TableCell padding="none" className="w-20 md:w-20 text-center z-99">
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className="flex-shrink-0 border-t-1"
				component="div"
				count={dataLength}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}

export default withRouter(DestinationTable);
