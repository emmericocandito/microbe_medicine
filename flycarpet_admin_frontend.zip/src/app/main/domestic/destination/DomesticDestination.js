import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../store';
import DomesticDestinationHeader from './DomesticDestinationHeader';
import DomesticDestinationTable from './DomesticDestinationTable';

function DomesticDestination() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<DomesticDestinationHeader />}
			content={<DomesticDestinationTable />}
			innerScroll
		/>
	);
}

export default withReducer('BasicData', reducer)(DomesticDestination);
