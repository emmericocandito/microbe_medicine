import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../../store';
import RemarkManageHeader from './RemarkManageHeader';
import RemarkManageTable from './RemarkManageTable';

function RemarkManage() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<RemarkManageHeader pageName={'domestic'}/>}
			content={<RemarkManageTable pageName={'domestic'}/>}
			innerScroll
		/>
	);
}
 
export default withReducer('BasicData', reducer)(RemarkManage);
