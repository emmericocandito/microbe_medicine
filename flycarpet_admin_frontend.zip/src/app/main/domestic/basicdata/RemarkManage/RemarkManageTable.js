import FuseScrollbars from '@fuse/core/FuseScrollbars';
import _ from '@lodash';
import axios from 'axios';
import {
	Table, TableBody, TableCell, TablePagination, TableRow, Modal, Select, Grid, Chip,
	Backdrop, Fade, TextField, Button, FormControl, FormHelperText, FormControlLabel, Checkbox
} from '@material-ui/core';
import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import FuseLoading from '@fuse/core/FuseLoading';
import HotelChainTableHead from './RemarkManageTableHead';
import { makeStyles } from '@material-ui/core/styles';
import SearchIcon from '@material-ui/icons/Search';
import { useAgencyInfo } from 'app/main/store/hooks';
import { Autocomplete } from '@material-ui/lab';
import { calcTimeDelta } from 'react-countdown';
import { baseURL } from '../../../utils';

// const sourcesList = ["ATLANTIS", "GOC", "ISRO", "DAN", "MINI"];
// const defaultAgentList = ['FCL', 'EMALON', 'MEMSHAK'];

function RemarkTable(props) {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			// margin: theme.spacing(1),
			minWidth: 120,
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			minWidth: 200,
		},
		button_group: {
			padding: 30,
		},
		buttons: {
			float: 'right',
			marginRight: '10px'
		},
		checkboxform: {
			marginLeft: '-10px'
		},
		textfield: {
			width: '100%'
		},
		chipStyle: {
			height: '20px',
			margin: '1px',
			color: 'white',
			fontSize: '12px',
			background: '#32606b'
		},
		dateRangeWrapper: {
			width: 'calc(100% - 20px)',
			margin: '10px',
			overflowY: 'auto',
			maxHeight: '300px'
		},
		controlButton: {
			height: '28px'
		}
	}));
	const classes = useStyles();
	const [apiPrefix, setApiPrefix] = useState('');
	const [hotelsList, setHotelsList] = useState(null);
	const [rateRemarkData, setRateRemarkData] = useState([]);
	const [defaultAgencyByPage, setDefaultAgencyByPage] = useState([]);
	const {
		internalAgentList,
		fetchInternalAgent,
	} = useAgencyInfo();

	const [nRemarkId, setRemarkId] = useState(null);
	const [nHotelIdList, setHotelIdList] = useState(null);
	const [dateRanges, setDateRanges] = useState([]);
	const [nCheckinFrom, setCheckinFrom] = useState(null);
	const [nCheckoutTo, setCheckoutTo] = useState(null);
	const [nRemark, setRemark] = useState(null);

	const [nRemarkEn, setRemarkEn] = useState(null);
	const [nRemarkHe, setRemarkHe] = useState(null);
	const [nRemarkRu, setRemarkRu] = useState(null);

	const [nAgentCodeList, setAgentCodeList] = useState(null);
	const [nIsExternalSource, setIsExternalSource] = useState(true);

	const [nFilterIgnoreAgent, setFilterIgnoreAgent] = useState(true);
	const [nFilterHotelId, setFilterHotelId] = useState(null);
	const [nFilterRemark, setFilterRemark] = useState(null);
	const [nFilterAgent, setFilterAgent] = useState(null);
	const [nFilterIgnoreSource, setFilterIgnoreSource] = useState(true);
	const [nFilterIsExternalSource, setFilterIsExternalSource] = useState(false);

	const [nButtonText, setButtonText] = useState(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [confirmText, setConfirmText] = useState(null);
	const [warningOpen, setWarningOpen] = useState(false);
	const [warningText, setWarningText] = useState(null);


	const [loading, setLoading] = useState(true);
	const [selected] = useState([]);
	const [dataLength, setDataLength] = useState(0)
	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});
	const [open, setOpen] = React.useState(false);
	const [openFilter, setOpenFilter] = useState(false);

	const agencyInfoProps = {
		options: defaultAgencyByPage,
		getOptionLabel: (option) => (`${option}`),
	};
	const hotelInfoProps = {
		options: _.orderBy(hotelsList, ['hotelName'], ['asc']),
		getOptionLabel: (option) => (`${option.hotelName} - ${option.destinationName}`),
	};

	useEffect(() => {
		if (props.pageName === 'camingo') {
			// sourcesList[0] = 'Camingo';
			setApiPrefix('camingo');
			fetchInternalAgent({ operation: 2, principalType: "ForInternalAgentSite" });
		} else if (props.pageName === 'domestic') {
			setApiPrefix('domestic');
			fetchInternalAgent({ operation: 1, principalType: "ForInternalAgentSite" });
		}
	}, []);

	useEffect(() => {
		if (apiPrefix !== '') {
			getHotelsList();
			getRemarkData(1, 10);
		}
	}, [apiPrefix]);

	useEffect(() => {
		const defaultList = internalAgentList.map((agent) => agent.dabAllowedOdyAgentCodes).reduce((r, a) => r.concat(a), []);
		setAgentCodeList(defaultList);
		setDefaultAgencyByPage(defaultList);
	}, [internalAgentList]);

	const getHotelsList = async () => {
		await axios({
			method: 'get',
			url: `${baseURL}${apiPrefix}/api/hotelConversion?from=1&to=1000`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' }
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				const data = response.data;
				setHotelsList(data['data'])
			}
		}).catch(error => {
			console.log(error);
		});
		setLoading(false);
	}
	const getRemarkData = async (from, to) => {
		await axios({
			method: 'post',
			url: `${baseURL}${apiPrefix}/api/rateRemark/search?from=${from}&to=${to}`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				'hotelId': nFilterHotelId,
				'remark': nFilterRemark,
				'ignoreAgent': nFilterIgnoreAgent,
				'agent': nFilterIgnoreAgent ? null : nFilterAgent,
				'ignoreSource': nFilterIgnoreSource,
				'isExternalSource': nFilterIgnoreSource ? null : nFilterIsExternalSource,
			}
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				const data = response.data;
				setDataLength(data.total)
				setRateRemarkData(data['data'])
			}
		}).catch(error => {
			console.log(error);
		});
		setLoading(false);
	}


	const insertRemark = () => {
		setButtonText('Add');
		setOpen(true);
	};
	const deleteHandle = async (index) => {
		setRemarkId(rateRemarkData[index]['id'])
		setConfirmText("Do you want to drop this remark?");
		setConfirmOpen(true);
	}
	const handleOpen = (index) => {
		setButtonText('Edit');
		setRemarkId(rateRemarkData[index]['id']);
		setHotelIdList(rateRemarkData[index]['hotelIds']);
		setDateRanges(rateRemarkData[index]['dateRanges']);
		setRemark(rateRemarkData[index]['remark']);
		setRemarkEn(rateRemarkData[index]['remarkTrans']['en']);
		setRemarkHe(rateRemarkData[index]['remarkTrans']['he']);
		setRemarkRu(rateRemarkData[index]['remarkTrans']['ru']);
		setAgentCodeList(rateRemarkData[index]['agents']);
		setIsExternalSource(rateRemarkData[index]['isExternalSource']);
		setOpen(true);
	};

	const openSearchModel = () => {
		setOpenFilter(true);
	};
	const handleClose = () => {
		initialValue();
		setOpen(false);
	};
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}
	const handleCloseWarning = () => {
		setWarningOpen(false);
	};
	const handleFilterClose = () => {
		setOpenFilter(false);
	};
	function searchRemark() {
		setPage(0);
		getRemarkData(1, rowsPerPage);
		setOpenFilter(false);
	}
	async function editProcess() {
		setLoading(true);
		let post_url;
		if (nButtonText === 'Edit') {
			post_url = `${baseURL}${apiPrefix}/api/rateRemark/${nRemarkId}`;
		}
		else {
			post_url = `${baseURL}${apiPrefix}/api/rateRemark`;
		}
		await axios({
			method: 'post',
			url: post_url,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"hotelIds": nHotelIdList,
				"dateRanges": dateRanges,
				"remark": nRemark,
				"remarkTrans": {
					en: nRemarkEn,
					he: nRemarkHe,
					ru: nRemarkRu,
				},
				"agents": nAgentCodeList?.length ? nAgentCodeList : null,
				"isExternalSource": nIsExternalSource,
			}
		}).then(response => {
			setLoading(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				getRemarkData(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}

			initialValue();
			setOpen(false);
		}).catch(error => {
			setLoading(false);
			setConfirmOpen(false);
			setWarningOpen(true);
			setWarningText(error.response.data.title);
		});
	};
	async function confirmProcess() {
		setLoading(true);
		await axios.delete(`${baseURL}${apiPrefix}/api/rateRemark/${nRemarkId}`, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		}).then(response => {
			setLoading(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				getRemarkData(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}
			initialValue();
			setOpen(false);
			setConfirmOpen(false);
		}).catch(error => {
			setLoading(false);
			setConfirmOpen(false);
			setWarningOpen(true);
			setWarningText(error.response.data);
		});

	};
	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}
	function handleChangePage(event, value) {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage
		getRemarkData(from, to);
	}
	function handleChangeRowsPerPage(event) {
		setRowsPerPage(event.target.value);
		setPage(0)
		const temp = Number(event.target.value)
		const from = 1;
		const to = temp
		getRemarkData(from, to);
	}
	function initialValue() {
		setRemarkId(null)
		setHotelIdList(null);
		setCheckinFrom(null);
		setCheckoutTo(null);
		setDateRanges([]);
		setRemark(null);
		setAgentCodeList(defaultAgencyByPage);
		setIsExternalSource(true);
		setRemarkEn(null);
		setRemarkHe(null);
		setRemarkRu(null);
	}

	/////////////   Insert/Update change  /////////////
	const onChangeRemark = (ev) => {
		setRemark(ev.target.value || null);
	}
	const onChangeIsExternalSource = () => {
		setIsExternalSource(!nIsExternalSource);
	}

	/////////////      Filter change      /////////////

	const onChangeFilterRemark = (event) => {
		setFilterRemark(event.target.value || null);
	}
	const onChangeIgnoreAgent = () => {
		setFilterIgnoreAgent(!nFilterIgnoreAgent);
	}
	const onChangeIgnoreSource = () => {
		setFilterIgnoreSource(!nFilterIgnoreSource);
	}
	const onChangeFilterIsExternal = () => {
		setFilterIsExternalSource(!nFilterIsExternalSource);
	}

	///////////   date range change ////////////
	const onChangeCheckinFrom = (event) => {
		setCheckinFrom(event.target.value);
	}
	const onChangeCheckoutTo = (event) => {
		setCheckoutTo(event.target.value);
	}
	const onChangeDateCheckinFrom = (event, index) => {
		dateRanges[index].checkinFrom = event.target.value;
	}
	const onChangeDateCheckoutTo = (event, index) => {
		dateRanges[index].checkoutTo = event.target.value;
	}
	const handleDelete = (index) => {
		let _dataRanges = [...dateRanges];
		_dataRanges.splice(index, 1);
		setDateRanges(_dataRanges);
	};
	const handleAdd = () => {
		let _dataRanges = [...dateRanges];
		_dataRanges.push({
			checkinFrom: nCheckinFrom,
			checkoutTo: nCheckoutTo,
		});

		setDateRanges(_dataRanges);
	};

	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className="w-full flex flex-col">
			<Modal
				open={warningOpen}
				onClose={handleCloseWarning}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Warning</h2>
					<p id='server-modal-description'>{warningText}</p>
					<Button className='whitespace-no-wrap normal-case'
						variant='contained'
						color='secondary'
						style={{ marginTop: '10px' }}
						onClick={handleCloseWarning}>Close
					</Button>
				</div>
			</Modal>
			<Modal
				open={confirmOpen}
				onClose={handleCloseConfirm}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Confirm</h2>
					<p id='server-modal-description'>{confirmText}</p>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={confirmProcess}>Confirm
					</Button>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={handleCloseConfirm}>Cancel
					</Button>
				</div>
			</Modal>
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={openFilter}
				onClose={handleFilterClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={openFilter}>
					<div className={classes.paper}>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title'>Filter Setting</h2>
						</div>
						<div style={{ display: 'grid' }}>
							<FormControl required className={classes.formControl}>
								{
									hotelsList?.length ?
										(
											<Grid container justify='space-between' style={{ textAlign: 'center', display: 'flex' }}>
												<FormControl required className={classes.formControl} style={{ width: '100%' }}>
													<FormHelperText style={{ wordSpacing: '-1px' }}>Select hotel</FormHelperText>
													<Autocomplete
														{...hotelInfoProps}
														id="agent-allowed"
														value={nFilterHotelId ? hotelsList?.find((h) => h.id === nFilterHotelId) || '' : null}
														onChange={(event, newValue) => {
															setFilterHotelId(newValue?.id || null);
														}}
														renderInput={(params) => (
															<TextField {...params} variant="standard" />
														)}
													/>
												</FormControl>
											</Grid>
										) : null
								}
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Remark</FormHelperText>
								<TextField defaultValue={nFilterRemark} className={classes.textfield} onChange={onChangeFilterRemark} />
							</FormControl>

							<FormControlLabel control={<Checkbox checked={nFilterIgnoreAgent} onChange={onChangeIgnoreAgent} />} label="Ignore Agent" />
							{
								defaultAgencyByPage?.length ?
									(
										<Grid container justify='space-between' style={{ textAlign: 'center', display: 'flex' }}>
											<FormControl required className={classes.formControl} style={{ width: '100%' }}>
												<FormHelperText style={{ wordSpacing: '-1px' }}>Choose Internal Agent</FormHelperText>
												<Autocomplete
													{...agencyInfoProps}
													id="agent-allowed"
													value={nFilterAgent ? nFilterAgent || '' : null}
													onChange={(event, newValue) => {
														setFilterAgent(newValue || null);
													}}
													renderInput={(params) => (
														<TextField {...params} variant="standard" />
													)}
													disabled={nFilterIgnoreAgent}
												/>
											</FormControl>
										</Grid>
									) : null
							}

							<FormControlLabel control={<Checkbox checked={nFilterIgnoreSource} onChange={onChangeIgnoreSource} />} label="Ignore Source" />
							<FormControlLabel control={<Checkbox disabled={nFilterIgnoreSource} checked={nFilterIsExternalSource} onChange={onChangeFilterIsExternal} />} label="Is External Source" />
						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleFilterClose}>
								Cancel
							</Button>
							<Button className={classes.buttons} variant='contained' color='secondary' onClick={searchRemark}>
								Filter
							</Button>
						</div>
					</div>

				</Fade>
			</Modal>
			<Modal
				aria-labelledby="transition-modal-title"
				aria-describedby="transition-modal-description"
				className={classes.modal}
				open={open}
				onClose={handleClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={open}>
					<div className={classes.paper} style={{minWidth: '550px'}}>
						<h2 id="transition-modal-title" style={{ textAlign: 'center' }}>{nButtonText} Remark</h2>
						<div style={{ textAlign: 'center', display: 'grid' }}>

							<FormControl required className={classes.formControl}>
								{
									hotelsList?.length ?
										(
											<Grid container justify='space-between' style={{ textAlign: 'center', display: 'flex' }}>
												<FormControl required className={classes.formControl} style={{ width: '100%' }}>
													<FormHelperText style={{ wordSpacing: '-1px' }}>Select hotels</FormHelperText>
													<Autocomplete
														multiple
														{...hotelInfoProps}
														id="agent-allowed"
														value={nHotelIdList?.length ? hotelsList.filter((h) => nHotelIdList.includes(h.id)) : []}
														onChange={(event, newValue) => {
															setHotelIdList(newValue?.map((h) => h.id) || null);
														}}
														renderInput={(params) => (
															<TextField {...params} variant="standard" />
														)}
													/>
												</FormControl>
											</Grid>
										) : null
								}
							</FormControl>

							<div className={classes.dateRangeWrapper}>
								<table style={{width:'100%'}}>
									<thead style={{borderBottom: 'solid 1px gray'}}>
										<tr>
											<th>
												<FormControl required className={classes.formControl}>
													<FormHelperText>Checkin From</FormHelperText>
													<TextField type="date" className={classes.textfield} defaultValue={nCheckinFrom} onChange={onChangeCheckinFrom} />
												</FormControl>
											</th>
											<th>
												<FormControl required className={classes.formControl}>
													<FormHelperText>Checkout To</FormHelperText>
													<TextField type="date" className={classes.textfield} defaultValue={nCheckoutTo} onChange={onChangeCheckoutTo} />
												</FormControl>
											</th>
											<th>
												<Button className={`${classes.buttons} ${classes.controlButton}`} variant="contained" color="secondary" onClick={handleAdd}>
													+ add
												</Button>
											</th>
										</tr>
									</thead>

									<tbody>
										{
											dateRanges.map((dateRange, index) => (
												<tr key={index}>
													<td>
														<FormControl required className={classes.formControl}>
															<TextField type="date" className={classes.textfield} defaultValue={dateRange.checkinFrom} onChange={(e) => onChangeDateCheckinFrom(e, index) } />
														</FormControl>
													</td>
													<td>
														<FormControl required className={classes.formControl}>
															<TextField type="date" className={classes.textfield} defaultValue={dateRange.checkoutTo} onChange={(e) => onChangeDateCheckoutTo(e, index)} />
														</FormControl>
													</td>
													<td className={`flex-end`}>
														<Button className={`${classes.buttons} ${classes.controlButton}`} variant="contained" color="primary" onClick={(e) => { handleDelete(index); }}>
															delete
														</Button>
													</td>
												</tr>
											))
										}
									</tbody>
								</table>
							</div>

							<FormControl required className={classes.formControl}>
								<FormHelperText>Remark</FormHelperText>
								<TextField defaultValue={nRemark} className={classes.textfield} onChange={onChangeRemark} />
							</FormControl>
							{
								(props.pageName === 'camingo') ? (
									<>
										<FormControl required className={classes.formControl}>
											<FormHelperText>English Remark</FormHelperText>
											<TextField defaultValue={nRemarkEn} className={classes.textfield} onChange={(ev) => setRemarkEn(ev.target.value || null)} />
										</FormControl>
										<FormControl required className={classes.formControl}>
											<FormHelperText>Hebrew Remark</FormHelperText>
											<TextField defaultValue={nRemarkHe} className={classes.textfield} onChange={(ev) => setRemarkHe(ev.target.value || null)} />
										</FormControl>
										<FormControl required className={classes.formControl}>
											<FormHelperText>Russia Remark</FormHelperText>
											<TextField defaultValue={nRemarkRu} className={classes.textfield} onChange={(ev) => setRemarkRu(ev.target.value || null)} />
										</FormControl>
									</>
								) : null
							}

							{
								defaultAgencyByPage?.length ?
									(
										<Grid container justify='space-between' style={{ textAlign: 'center', display: 'flex' }}>
											<FormControl required className={classes.formControl} style={{ width: '100%' }}>
												<FormHelperText style={{ wordSpacing: '-1px' }}>Choose Internal Agent</FormHelperText>
												<Autocomplete
													multiple
													{...agencyInfoProps}
													id="agent-allowed"
													value={nAgentCodeList || []}
													onChange={(event, newValue) => {
														setAgentCodeList(newValue?.map((agent) => agent) || null);
													}}
													renderInput={(params) => (
														<TextField {...params} variant="standard" />
													)}
												/>
											</FormControl>
										</Grid>
									) : null
							}
							<FormControlLabel control={<Checkbox checked={nIsExternalSource} onChange={onChangeIsExternalSource} />} label="Is External Source" />
						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant="contained" color="primary" onClick={handleClose}>
								Cancel
							</Button>
							<Button className={classes.buttons} variant="contained" onClick={editProcess} color="secondary">
								{nButtonText}
							</Button>
						</div>
					</div>
				</Fade>
			</Modal>
			<div>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => insertRemark()}
				>
					<span className='hidden sm:flex'>Add HotelChain</span>
					<span className='flex sm:hidden'>Add</span>
				</Button>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => openSearchModel()}
				>
					<span className='hidden sm:flex'><SearchIcon />Filter</span>
					<span className='flex sm:hidden'><SearchIcon /></span>
				</Button>
			</div>
			<FuseScrollbars className="flex-grow overflow-x-auto">
				<Table stickyHeader className="min-w-xl" aria-labelledby="tableTitle">
					<HotelChainTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={rateRemarkData.length}
					/>
					<TableBody>
						{_.orderBy(
							rateRemarkData,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className="h-64 cursor-pointer"
									hover
									tabIndex={-1}
									key={i}
								>
									<TableCell padding="none" className="w-20 md:w-20 text-center z-99">
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.hotelIds ? hotelsList?.filter((hotel) => n.hotelIds.includes(hotel.id))?.map((h, i) => (<Chip key={i} className={classes.chipStyle} label={`${h.hotelName} - ${h.destinationName}`} variant='outlined' />)) : ''}
									</TableCell>
									{/* <TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.checkinFrom ? new Date(n.checkinFrom).toString().substring(0, 15) : ''}
									</TableCell>
									<TableCell className="p-4 md:p-16 text-center" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.checkoutTo ? new Date(n.checkoutTo).toString().substring(0, 15) : ''}
									</TableCell> */}
									<TableCell className="p-4 md:p-16 text-center" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.remark}
									</TableCell>
									<TableCell className="p-4 md:p-16 text-center" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.agents ? n.agents.map((agentCode, i) => (<Chip key={i} className={classes.chipStyle} label={`${agentCode}`} variant='outlined' />)) : ''}
									</TableCell>
									<TableCell className="p-4 md:p-16 text-center" component="th" scope="row" onClick={() => handleOpen(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.isExternalSource && 'bg-red',
												n.isExternalSource && 'bg-green',
											)}
										/>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => handleOpen(i)} tabIndex="0" type="button" title="Edit"><span className="MuiIconButton-label"><span className="material-icons MuiIcon-root" aria-hidden="true">edit</span></span><span className="MuiTouchRipple-root"></span></button>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => deleteHandle(i)} tabIndex="0" type="button" title="Edit">
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className="flex-shrink-0 border-t-1"
				component="div"
				count={dataLength}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}

export default withRouter(RemarkTable);
