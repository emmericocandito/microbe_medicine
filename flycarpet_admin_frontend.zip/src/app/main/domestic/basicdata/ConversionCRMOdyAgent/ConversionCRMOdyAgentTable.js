import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import axios from 'axios';
import _ from '@lodash';
import {
	Table, TableBody, TableCell, TablePagination, TableRow, Checkbox, Modal,
	Backdrop, Fade, TextField, Button, CircularProgress, FormControl, FormControlLabel,
	FormHelperText, Grid, Chip, Select,
} from '@material-ui/core';
import SearchIcon from '@material-ui/icons/Search';
import FuseScrollbars from '@fuse/core/FuseScrollbars';
import FuseLoading from '@fuse/core/FuseLoading';
import { makeStyles } from '@material-ui/core/styles';
import clsx from 'clsx';

import BasisTableHead from './ConversionCRMOdyAgentTableHead';
import { Autocomplete } from '@material-ui/lab';
import { baseURL } from '../../../utils';
import { useAgencyInfo } from 'app/main/store/hooks';

function ConversionCRMOdyAgentTable(props) {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			margin: theme.spacing(0),
			minWidth: 60,
		},
		groupControl: {
			margin: theme.spacing(0),
			marginBottom: theme.spacing(1),
			padding:theme.spacing(1),
			minWidth: 800,
			maxWidth: 800,
			border: 'solid 1px #999',
			borderRadius: '10px'
		},
		hideGroup: {
			display: 'none',
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
			minWidth: 120
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			minWidth: '700px',
		},
		discountboxform: {
			display: 'grid',
		},
		checkboxform: {
			display: 'block',
		},
		button_group: {
			padding: 30,
			textAlign: 'center',
		},
		buttons: {
			marginLeft: '10px'
		},
		fo_circular: {
			textAlign: 'center',
			position: 'absolute',
			left: '50%',
			transform: 'translatex(-50%)'
		},
		textFiled: {
			width: '100%'
		},
		chip: {
			height: '15px'
		},
		chips: {
			display: 'flex',
			flexWrap: 'wrap',
		},
		chipStyle: {
			height: '20px',
			margin: '1px',
			color: 'white',
			fontSize: '12px',
			background: '#32606b'
		},
		keywordItem: {
			margin: '5px',
		},
		keywordTableItem: {
			margin: '1px',
			padding: 0,
		},
	}));

	const classes = useStyles();

	const operationsArray = ['Pack', 'Domestic', 'Camingo'];
	const callSystemArray = ['', 'Voicepin', 'Paycall', 'Others'];
	const [nOperation, setOperation] = useState(1);
  const [odyAgentCode, setOdyAgentCode] = useState(null);
	const [odyClerkName, setOdyClerkName] = useState(null);
	const [localPhoneNumber, setLocalPhoneNumber] = useState(null);
	const [defaultAgent, setDefaultAgent] = useState(false);
	const [agentListByCallSystem, setAgentListByCallSystem] = useState([]);
	const [callCenterSystem, setCallCenterSystem] = useState(null);
	const [crmAgent, setCrmAgent] = useState(null);
	const [name, setName] = useState(null);

  const {
    agencyInfoInternal,
    fetchAgencyInfoInternal,
    getAgencyNameInternal,
  } = useAgencyInfo();

  const agencyInfoProps = {
    options: agencyInfoInternal,
    getOptionLabel: (option) => getAgencyNameInternal(option),
  };

	const [filterCRMAgentName, setFilterCRMAgentName] = useState(null);
	const [filterPhoneNumber, setFilterPhoneNumber] = useState(null);
	const [filterOdyAgentCode, setFilterOdyAgentCode] = useState(null);
	const [filterOdyClerkName, setFilterOdyClerkName] = useState(null);
	const [filterName, setFilterName] = useState(null);

	const [loading, setLoading] = useState(true);
	const [loadingCircle, setLoadingCircle] = useState(false);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [pageCount, setPageCount] = useState(10);
	const [warningOpen, setWarningOpen] = useState(false);
	const [warningText, setWarningText] = useState(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});
	const [open, setOpen] = useState(false);
	const [openFilter, setOpenFilter] = useState(false);
	
	const [currentMappingId, setCurrentMappingId] = useState(null);
	const [editCRMIndex, setEditCRMIndex] = useState(-1);

	const [nButtonText, setButtonText] = useState(null);
	const [nButtonState, setButtonState] = useState(null);
	const [selected] = useState([]);
	const [data, setData] = useState([]);
	const [page, setPage] = useState(0);

	useEffect(() => {
		reopen(1, 10);
	}, []);
	useEffect(() => {
    fetchAgencyInfoInternal({operation: nOperation});
	}, [nOperation])

	async function reopen(from, to) {
		setLoading(true);
		await axios({
			method: 'post',
			url: `${baseURL}${props.operation}/api/agentToOdyAgent/search?from=${from}&to=${to}`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				agent: filterCRMAgentName,
				isrPhone: filterPhoneNumber,
				odyAgentCode: filterOdyAgentCode,
				odyClerkName: filterOdyClerkName,
				name: filterName,
			}
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				const data = response.data;
				setPageCount(data.total);
				setData(data.data);
			}
		}).catch(error => {
			console.log(error);
		});
		setLoading(false);
		setOpen(false);

	};
	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}
	async function deleteMapping(index) {
		setCurrentMappingId(data[index].id);
		setConfirmOpen(true);
	}
	async function deleteProcess() {
		setLoading(true);
		await axios.delete(`${baseURL}${props.operation}/api/agentToOdyAgent/${currentMappingId}`, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		})
		reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
		setCurrentMappingId(null);

		setLoading(false);
		setOpen(false);
		setConfirmOpen(false);
	};
	const editMapping = async (i) => {
		setButtonText('Edit');
		setButtonState('Mapping Edit');

		setCallCenterSystem(null);
		setCrmAgent(null);
		setEditCRMIndex(-1);

		setCurrentMappingId(data[i].id || null);
		setLocalPhoneNumber(data[i].isrPhone || null);
		setName(data[i].name || null);
		setOperation(operationsArray.indexOf(data[i].odyAgent.operation));
		setOdyAgentCode(data[i].odyAgent.odyAgentCode || null);
		setOdyClerkName(data[i].odyAgent.odyClerkName || null);
		setDefaultAgent(data[i].defaultAgent || false);
		setAgentListByCallSystem(data[i].agentByCallSystem.map((m) => (`${m.callCenterSystem}-${m.agent}`)) || []);

		setOpen(true);
	}
	const handleClose = () => {
		setCurrentMappingId(null);
		initialValue();
		setOpen(false);
	}
	function initialValue() {
		setCurrentMappingId(null);
		setOperation(1);
		setAgentListByCallSystem([]);
		setLocalPhoneNumber(null);
		setName(null);
		setOdyAgentCode(null);
		setOdyClerkName(null);
		setDefaultAgent(false);

		setCallCenterSystem(null);
		setCrmAgent(null);
		setEditCRMIndex(-1);
	}
	async function editProcess() {
		setLoadingCircle(true);
		var request_url = null;
		if (nButtonState == 'Mapping Edit') {
			request_url = `${baseURL}${props.operation}/api/agentToOdyAgent/${currentMappingId}`;
		} else {
			request_url = `${baseURL}${props.operation}/api/agentToOdyAgent`;
		}
		await axios({
			method: 'post',
			url: request_url,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				agentByCallSystem: agentListByCallSystem?.map((m) => ({
					callCenterSystem: m.split('-')[0],
					agent: m.split('-')[1],
				})) || null,
				isrPhone: localPhoneNumber,
				name: name,
				odyAgent: {
						operation: operationsArray[nOperation],
						odyAgentCode: odyAgentCode,
						odyClerkName: odyClerkName
				},
				defaultAgent: defaultAgent
			}
		}).then(response => {
			setLoadingCircle(false);
			if (response.data.error != null && (Number(response.data.error.code) === 1 || Number(response.data.error.code) === 3)) {
				setWarningText(response.data.error.message);
				setWarningOpen(true);
			} else {
				reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
				initialValue();
			}
		}).catch(error => {
			setLoadingCircle(false);
			setWarningText(error.response.data);
			setWarningOpen(true);
			return;
		});
	};
	const addMapping = async () => {
		setButtonText('Add');
		setButtonState('Add Mapping');
		setCurrentMappingId(null);
		initialValue();
		setOpen(true);
	}
	function handleChangePage(event, value) {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage
		reopen(from, to);
	}
	function handleChangeRowsPerPage(event) {
		setRowsPerPage(event.target.value);
		setPage(0)
		const temp = Number(event.target.value)
		const from = 1;
		const to = temp
		reopen(from, to);
	}
	const handleCloseWarning = () => {
		setWarningOpen(false);
	}
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}
	const handleChangeCallCenterSystem = (event) => {
		setCallCenterSystem(event.target.value);
	}
	const handleChangeCRMAgent = (event) => {
		setCrmAgent(event.target.value);
	}
	const handleCRMAgentClick = (m, index) => {
		const callSystem = m.split('-')[0], agent = m.split('-')[1];
		setCallCenterSystem(callSystem);
		setCrmAgent(agent);
		setEditCRMIndex(index);
	}
	const handleCRMAgentDelete = (index) => {
		let crmAgents = [...agentListByCallSystem];
		crmAgents.splice(index, 1);
		setAgentListByCallSystem(crmAgents);
		if (index === editCRMIndex) {
			setEditCRMIndex(-1);
		}
	}
	const handleCRMAgentAdd = () => {
		if (!callCenterSystem?.trim() || !crmAgent?.trim() ) return;
		const crmItem = `${callCenterSystem}-${crmAgent}`;
		if (agentListByCallSystem.includes(crmItem)) return;

		let crmAgents = [...agentListByCallSystem];
		if (editCRMIndex !== -1) {
			crmAgents[editCRMIndex] = crmItem;
		} else {
			crmAgents.push(crmItem);
		}

		setAgentListByCallSystem(crmAgents);
		setCallCenterSystem(null);
		setCrmAgent(null);
		setEditCRMIndex(-1);
	}
	const handleChangePhoneNumber = (event) => {
		setLocalPhoneNumber(event.target.value);
	}
	const handleChangeName = (event) => {
		setName(event.target.value);
	}
	const handleChangeOdyClerkName = (event) => {
		setOdyClerkName(event.target.value);
	}
	
	const openSearchModel = () => {
		setOpenFilter(true);
	};
	const handleFilterClose = () => {
		setOpenFilter(false);
	};
	function searchRemark() {
		setPage(0);
		reopen(1, rowsPerPage);
		setOpenFilter(false);
	}

	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className='w-full flex flex-col'>
			<div>
				<div className='spinner-border text-primary' role='status'>
					<span className='sr-only'>Loading...</span>
				</div>
				<Modal
					open={warningOpen}
					onClose={handleCloseWarning}
					className={classes.modal}
					aria-labelledby='simple-modal-title'
					aria-describedby='simple-modal-description'
				>
					<div className={classes.paper}>
						<h2 id='server-modal-title' >Warning</h2>
						<p id='server-modal-description'>{warningText}</p>
						<Button className='whitespace-no-wrap normal-case'
							variant='contained'
							color='secondary'
							onClick={handleCloseWarning}>Close
						</Button>
					</div>
				</Modal>
				<Modal
					open={confirmOpen}
						onClose={handleCloseConfirm}
						className={classes.modal}
						aria-labelledby='simple-modal-title'
						aria-describedby='simple-modal-description'
					>
					<div className={classes.paper}>
						<h2 id='server-modal-title' style={{ textAlign: 'center' }} >Confirm</h2>
						<p id='server-modal-description'>Do you want to drop this Mapping</p>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained'
								color='secondary'
								onClick={deleteProcess}>Yes
							</Button>
							<Button className={classes.buttons} variant='contained'
								color='primary'
								onClick={handleCloseConfirm}>No
							</Button>
						</div>
					</div>
				</Modal>
				<Modal
					aria-labelledby='transition-modal-title'
					aria-describedby='transition-modal-description'
					className={classes.modal}
					open={openFilter}
					onClose={handleFilterClose}
					closeAfterTransition
					BackdropComponent={Backdrop}
					BackdropProps={{
						timeout: 500,
					}}
				>
					<Fade in={openFilter}>
						<div className={classes.paper}>
							<div style={{ textAlign: 'center' }}>
								<h2 id='transition-modal-title'>Filter Mapping</h2>
							</div>
							<div style={{ display: 'grid' }}>
								{
									agencyInfoInternal && agencyInfoInternal.length ? 
										(
										<FormControl required className={classes.formControl} style={{ width: '100%' }}>
											<FormHelperText>Agents</FormHelperText>
											<Autocomplete
												{...agencyInfoProps}
												id="agents-list"
												value={agencyInfoInternal.find((agt) => agt.agt_Code === filterOdyAgentCode) || null}
												onChange={(event, newValue) => {
													setFilterOdyAgentCode(newValue.agt_Code);
												}}
												renderInput={(params) => (
													<TextField {...params} variant="standard" />
												)}
											/>
										</FormControl>
										) : ''
									}
								<FormControl required className={classes.formControl}>
									<FormHelperText>Ody Clerk Name</FormHelperText>
									<TextField defaultValue={filterOdyClerkName || ''} className={classes.textfield} onChange={(e) => setFilterOdyClerkName(e.target.value)} />
								</FormControl>
								<FormControl required className={classes.formControl}>
									<FormHelperText>Israel Phone</FormHelperText>
									<TextField defaultValue={filterPhoneNumber || ''} className={classes.textfield} onChange={(e) => setFilterPhoneNumber(e.target.value)} />
								</FormControl>
								<FormControl required className={classes.formControl}>
									<FormHelperText>CRM Agent Name</FormHelperText>
									<TextField defaultValue={filterCRMAgentName || ''} className={classes.textfield} onChange={(e) => setFilterCRMAgentName(e.target.value)} />
								</FormControl>
								<FormControl required className={classes.formControl}>
									<FormHelperText>Name</FormHelperText>
									<TextField defaultValue={filterName || ''} className={classes.textfield} onChange={(e) => setFilterName(e.target.value)} />
								</FormControl>
							</div>
							<div className={classes.button_group}>
								<Button className={classes.buttons} variant='contained' color='primary' onClick={handleFilterClose}>
									Cancel
								</Button>
								<Button className={classes.buttons} variant='contained' color='secondary' onClick={searchRemark}>
									Filter
								</Button>
							</div>
						</div>

					</Fade>
				</Modal>
				<Modal
					aria-labelledby='transition-modal-title'
					aria-describedby='transition-modal-description'
					className={classes.modal}
					open={open}
					onClose={handleClose}
					closeAfterTransition
					BackdropComponent={Backdrop}
					BackdropProps={{
						timeout: 500,
					}}
				>
					<Fade in={open}>
						<div className={classes.paper}>
							<div className={classes.fo_circular}>
								{loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
							</div>
							<div style={{ textAlign: 'center' }}>
								<h2 id='transition-modal-title' >{nButtonState}</h2>
							</div>
							<div>
								<Grid container justify='space-between' style={{ margin: '10px 0px', display: 'flex', justifyContent: 'space-between' }}>
									<FormControl required className={classes.formControl} style={{ width: '30%' }}>
										<FormHelperText>Operation</FormHelperText>
										<Select
											native
											onChange={e => { setOperation(e.target.value) }}
											value={nOperation || 0}
											inputProps={{
												id: 'operation',
											}}
											className={classes.checkboxform}
											disabled
										>
											{operationsArray.map((operation, inx) => (<option aria-label='None' key={inx} value={inx}>{operation}</option>))}
										</Select>
									</FormControl>
									
									{
									agencyInfoInternal && agencyInfoInternal.length ? 
										(
										<FormControl required className={classes.formControl} style={{ width: '30%' }}>
											<FormHelperText>Agents</FormHelperText>
											<Autocomplete
												{...agencyInfoProps}
												id="agents-list"
												value={agencyInfoInternal.find((agt) => agt.agt_Code === odyAgentCode) || null}
												onChange={(event, newValue) => {
													setOdyAgentCode(newValue.agt_Code);
												}}
												renderInput={(params) => (
													<TextField {...params} variant="standard" />
												)}
											/>
										</FormControl>
										) : ''
									}
									<FormControl required className={classes.formControl} style={{ width: '30%' }}>
										<FormHelperText>Ody Clerk Name</FormHelperText>
										<TextField className={classes.textfield}
											value={odyClerkName || ''} onChange={handleChangeOdyClerkName}
										/>
									</FormControl>
								</Grid>

								<Grid container justify='space-between' style={{ textAlign: 'center', marginTop: '30px' }}>
									<FormControl required className={classes.formControl} style={{ width: '100%' }}>
										<FormHelperText style={{ wordSpacing: '-1px' }}>Agent By Call System</FormHelperText>
										<Grid container style={{ textAlign: 'center', display: 'flex' }} onClick={() => { 
											setEditCRMIndex(-1);
											setCallCenterSystem(null);
											setCrmAgent(null);
										}}>
											{
												agentListByCallSystem?.map((m, i) => {
													return (
														<Chip key={i} label={`${m}`} className={classes.keywordItem} variant='outlined'
															onClick={(e) => {
																handleCRMAgentClick(m, i);
																e.stopPropagation();
															}}
															onDelete={() => handleCRMAgentDelete(i)}
														/>
													)
												})
											}
										</Grid>
									</FormControl>
								</Grid>

								<hr style={{ marginBottom: '10px' }}></hr>

								<Grid container justify='space-between' style={{ marginBottom: '30px' }}>
									<FormControl required className={classes.formControl} style={{ width: '30%' }}>
										<FormHelperText>Call center system</FormHelperText>
										<Select
											native
											onChange={e => { setCallCenterSystem(e.target.value) }}
											value={callCenterSystem || ''}
											inputProps={{
												id: 'call-center-system',
											}}
											className={classes.checkboxform}
										>
											{callSystemArray.map((call, inx) => (<option aria-label='None' key={inx} value={call}>{call}</option>))}
										</Select>
									</FormControl>
									
									<FormControl required className={classes.formControl} style={{ width: '30%' }}>
										<FormHelperText>Edit CRM agent</FormHelperText>
										<TextField className={classes.textfield}
											value={crmAgent || ''} onChange={handleChangeCRMAgent}
										/>
									</FormControl>
									<Button className={`${classes.buttons} ${classes.controlButton}`}
										style={{ height: '28px' }} variant="contained" color="secondary" onClick={handleCRMAgentAdd}>
										{ editCRMIndex === -1 ? 'add': 'update'}
									</Button>
								</Grid>

								{/* <Grid className={remarkWithDiscState ? classes.groupControl : classes.hideGroup} >
									<Grid container justify='space-between' style={{ textAlign: 'center' }}>
										<FormControl required className={classes.formControl} style={{ width: '100%' }}>
											<FormHelperText style={{ wordSpacing: '-1px' }}>Hotel External Codes</FormHelperText>
											<Grid container style={{ textAlign: 'center', display: 'flex' }}>
												{
													hotelExtIds?.map((_code, i) => {
														return (
															<Chip key={i} label={`${_code}`} className={classes.keywordItem} variant='outlined'
																onDelete={() => handleHotelCodeDelete(i)}
															/>
														)
													})
												}
											</Grid>
										</FormControl>
									</Grid>
									<hr style={{ marginBottom: '10px' }}></hr>
									<Grid container justify='space-between' style={{ width: 'calc(100% - 20px)' }}>
										<FormControl required className={classes.formControl} style={{ width: '48%' }}>
											<FormHelperText>Suppliers</FormHelperText>
											<Autocomplete
												options={suppliersList}
												value={hotelSupplier}
												selectOnFocus
												disableClearable
												onChange={handleChangeHotelSupplier}
												id="hotel-supplier"
												renderInput={(params) => (
													<TextField {...params} variant="standard" />
												)}
												getOptionSelected={(option, value) => option === value}
											/>
										</FormControl>
										<FormControl required className={classes.formControl} style={{ width: '48%' }}>
											<FormHelperText>Hotels</FormHelperText>
											<Autocomplete
												{...hotelsListOption}
												value={selectedHotel}
												selectOnFocus
												onChange={(e, newValue) => {
													setSelectedHotel(newValue);
													handleHotelCodeAdd(newValue.hotelExternalCode);
												}}
												id="select-hotel"
												disableClearable
												renderInput={(params) => (
													<TextField {...params} variant="standard" />
												)}
												getOptionSelected={(option, value) => option.hotelName === value.hotelName}
											/>
										</FormControl>
									</Grid>
									
									<Grid container justify='space-between' style={{ margin: '10px 0px', display: 'flex', justifyContent: 'space-between' }}>
										<FormControl required className={classes.formControl} style={{ width: '48%' }}>
											<FormHelperText>Discount Percent</FormHelperText>
											<TextField className={classes.textfield} value={discountPercent} onChange={handleChangeDiscountPercent} />
										</FormControl>
										<FormControl required className={classes.formControl} style={{ width: '48%' }}>
											<FormHelperText>Agent Commission Percent</FormHelperText>
											<TextField className={classes.textfield} value={agentCommissionPercent} onChange={handleChangeCommissionPercent} />
										</FormControl>
									</Grid>
								</Grid> */}

								<Grid container justify='space-between' style={{ margin: '10px 0px', display: 'flex', justifyContent: 'space-between' }}>
									<FormControl required className={classes.formControl} style={{ width: '48%' }}>
										<FormHelperText>Isr Phone Number</FormHelperText>
										<TextField className={classes.textfield} value={localPhoneNumber || ''} onChange={handleChangePhoneNumber} />
									</FormControl>
									<FormControl required className={classes.formControl} style={{ width: '48%' }}>
										<FormHelperText>Name</FormHelperText>
										<TextField className={classes.textfield} value={name || ''} onChange={handleChangeName} />
									</FormControl>
								</Grid>

								<FormControlLabel style={{ width: '100%' }}
									control={
										<Checkbox
											checked={defaultAgent}
											onChange={e => { setDefaultAgent(e.target.checked) }}
											name='default-agent'
											color='primary'
										/>
									}
									label='Default Agent'
									className={classes.checkboxform}
								/>

								{/* <FormControlLabel style={{ width: '100%' }}
									control={
										<Checkbox
											checked={active}
											onChange={e => { setActive(e.target.checked) }}
											name='active'
											color='primary'
										/>
									}
									label='Active?'
									className={classes.checkboxform}
								/> */}
							</div>
							<div className={classes.button_group}>
								<Button className={classes.buttons} variant='contained' onClick={editProcess} color='secondary'>
									{nButtonText}
								</Button>
								<Button className={classes.buttons} variant='contained' color='primary' onClick={handleClose}>
									Cancel
								</Button>
							</div>
						</div>

					</Fade>
				</Modal>
			</div>
			<div>
				<Button
						className='whitespace-no-wrap normal-case'
						variant='contained'
						color='secondary'
						style={{ float: 'right', margin: '15px 5px' }}
						onClick={() => openSearchModel()}
					>
					<span className='hidden sm:flex'><SearchIcon />Filter</span>
					<span className='flex sm:hidden'><SearchIcon /></span>
				</Button>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px' }}
					onClick={() => addMapping()}
				>
					<span className='hidden sm:flex'>Add Mapping</span>
				</Button>
			</div>
			<FuseScrollbars className='flex-grow overflow-x-auto'>
				<Table stickyHeader className='min-w-xl' aria-labelledby='tableTitle'>
					<BasisTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={data.length}
					/>
					<TableBody>
						{_.orderBy(
							data,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className='h-64 cursor-pointer'
									hover
									tabIndex={-1}
									key={i}
								>
									<TableCell padding="none" className="w-40 md:w-64 text-center z-99">
										{page * rowsPerPage + 1 + i}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editMapping(i)}>
										{n.isrPhone}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editMapping(i)}>
										{n.name}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editMapping(i)}>
										{n.odyAgent.operation}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editMapping(i)}>
										{n.odyAgent.odyAgentCode}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editMapping(i)}>
										{n.odyAgent.odyClerkName}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editMapping(i)}>
										{
											n.agentByCallSystem?.map((m, i) => {
												return (
													<Chip key={i} label={`${m.callCenterSystem}-${m.agent}`} className={classes.keywordTableItem} variant='outlined'/>
												)
											})
										}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editMapping(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.defaultAgent && 'bg-red',
												n.defaultAgent && 'bg-green',
											)}
										/>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component='th' scope='row' align='left'>
										<button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
											onClick={() => editMapping(i)}
											tabIndex='0' type='button' title='Edit'>
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>edit</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => deleteMapping(i)} tabIndex="0" type="button" title="Edit">
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className='flex-shrink-0 border-t-1'
				component='div'
				count={pageCount}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}
export default withRouter(ConversionCRMOdyAgentTable);
