import React, { useEffect, useState } from 'react';
import axios from 'axios';
import clsx from 'clsx';
import 'react-tabs/style/react-tabs.css';
import Modal from '@material-ui/core/Modal';
import Backdrop from '@material-ui/core/Backdrop';
import Fade from '@material-ui/core/Fade';
import Button from '@material-ui/core/Button';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import Collapse from '@material-ui/core/Collapse';
import Avatar from '@material-ui/core/Avatar';
import Chip from '@material-ui/core/Chip';
import EmailIcon from '@material-ui/icons/Email';
import SmartphoneIcon from '@material-ui/icons/Smartphone';
import BirthdayIcon from '@material-ui/icons/Cake';
import FavoriteBorderIcon from '@material-ui/icons/FavoriteBorder';
import IconButton from '@material-ui/core/IconButton';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { makeStyles } from '@material-ui/core/styles';
import CircularProgress from '@material-ui/core/CircularProgress';
import ShowMoreText from 'react-show-more-text';
import ReactHtmlParser from 'react-html-parser';
import { Carousel } from 'react-responsive-carousel';
import "react-responsive-carousel/lib/styles/carousel.css";
import CardHeader from '@material-ui/core/CardHeader';
import EditIcon from '@material-ui/icons/Edit';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import FormControl from '@material-ui/core/FormControl';
import FormHelperText from '@material-ui/core/FormHelperText';
import Select from '@material-ui/core/Select';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import { use } from 'marked';
import ImageUploader from "react-images-upload";
import DoneIcon from '@material-ui/icons/Done';
import FuseLoading from '@fuse/core/FuseLoading';
import { baseURL } from '../../../utils';

const useStyles = makeStyles((theme) => ({
    root: {
        maxWidth: '100%',
        margin: '20px 10px',
        boxShadow: '0 0px 4px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
    },
    formControl: {
        margin: theme.spacing(0),
        // minWidth: 60,
        width: '100%',
        margin: '0px 10px'
    },
    formControl1: {
        margin: theme.spacing(0),
        // minWidth: 60,
        width: '100%',
        // margin: '0px 10px',
        border: '1px solid #d8d8d8',
        margin: '10px',
        borderRadius: '5px'
    },
    modal: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        margin: 'auto',
    },
    modal1: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        margin: 'auto',
        minWidth: 200,
    },
    paper: {
        backgroundColor: theme.palette.background.paper,
        border: '2px solid #000',
        boxShadow: theme.shadows[5],
        padding: theme.spacing(2, 2, 3),
        textAlign: "center",
        maxHeight: '600px',
        maxWidth: '800px',
        overflow: 'auto'
    },
    avatar: {
        width: 72,
        height: 72,
        padding: 8,
        marginLeft: '20px',
        background: theme.palette.background.default,
        boxSizing: 'content-box',
        '& > img': {
            borderRadius: '50%'
        }
    },
    actionExtend: {
        alignItems: 'flex-start',
    },
    expandOpen: {
        transform: 'rotate(180deg)',
    },
    chipStyle: {
        margin: '5px',
        color: '#6f6e6e',
        fontSize: '10px',
        height: '25px',
        '&:hover': {
            backgroundColor: 'green !important',
            color: 'white !important'
        },
        '&:active': {
            backgroundColor: 'green !important',
            color: 'white !important'
        },
        '&:focus': {
            backgroundColor: 'green !important',
            color: 'white !important'
        },
    },
    button_group: {
        padding: 25,
        textAlign: 'center',
    },
    buttons: {
        marginLeft: '10px'
    },
    ntextArea: {
        width: '100%',
        border: '1px solid gray',
        minHeight: '35px !important',
        '&:hover': {
            outlineColor: '#000000cf',
            borderRadius: '0'
        },
        '&:active': {
            outlineColor: '#000000cf',
            borderRadius: '0'
        },
        '&:focus': {
            outlineColor: '#000000cf !important',
            borderRadius: '0'
        },
    },
    deleteImage: {
        position: 'absolute',
        top: '1px',
        right: '7px',
        color: '#fff',
        background: '#ff4081',
        borderRadius: '50%',
        textAign: 'center',
        cursor: 'pointer',
        fontSize: '17px',
        fontWeight: 'bold',
        lineHeight: '20px',
        width: '20px',
        height: '20px'
    },
    border_style: {
        border: '1px solid #d8d8d8',
        margin: '10px',
        borderRadius: '5px'
    }
}));

function HotelInfoPanelTable(props) {
    const classes = useStyles();
    const [openEdit, setModalOpen] = useState(false);
    const [expanded, setExpanded] = useState(null);
    const [detailInfo, setDetailInfo] = useState(null);
    const [index, setIndex] = useState();
    // const [loadingCircle, setLoadingCircle] = useState(false);
    const [loading, setLoading] = useState(false);



    // const [destinationList, setDestinationList] = useState([])
    const [hotelList, setHotelList] = useState([]);

    // const [destination, setDestination] = useState(null);
    const [hotel, setHotel] = useState(props.hotelId);
    const [roomClasses, setRoomClasses] = useState(props.roomClasses);
    const [facilities, setFacilities] = useState(props.facilities);
    const [mainImageUrls, setMainImageUrls] = useState(props.mainImageUrls);
    const [galleryImageUrls, setGalleryImageUrls] = useState(props.galleryImageUrls);
    const [description, setDescription] = useState(props.hotelDescription);
    const [mainImage, setMainImage] = useState(null);
    const [galleryImage, setGalleryImage] = useState(null);

    const [exsitRoomClassImage, setExsitRoomClassImage] = useState([]);
    const [roomClassImage, setRoomClassImage] = useState([]);

    const [roomId, setRoomID] = useState(null);
    const [roomDes, setRoomDes] = useState(null);
    const [roomName, setRoomName] = useState(null);
    const [roomClassModalOpen, setRoomClassModalOpen] = useState(false);

    const [facilityCode, setFacilityCode] = useState(null);
    const [facilityName, setFacilityName] = useState(null);
    const [facilityModalOpen, setFacilityModalOpen] = useState(false);

    const [nButtonText, setButtonText] = useState(null);
    const [confirmOpen, setConfirmOpen] = useState(false);
    const [confirmText, setConfirmText] = useState(null);
    const [warningOpen, setWarningOpen] = useState(false);
    const [warningText, setWarningText] = useState(null);

    async function getHotelList(destination) {
        await axios({
            method: 'post',
            url: baseURL + 'domestic/api/hotelConversion/search?from=1&to=1000',
            headers: {
                'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*',
                'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
            },
            data: {
                // "mainCityCode": destination
            }
        }).then(response => {
            const data = response.data['data'];
            setHotelList(data);
        })
            .catch(error => {
                console.log(error)
                return;
            });
    }
    async function editProcess() {
        setLoading(true);
        let data = new FormData();
        data.append('hotelId', hotel);
        data.append('hotelDescription', description);
        for (var i = 0; i < roomClasses.length; i++) {
            data.append('roomClasses[' + i + '].id', roomClasses[i].id);
            data.append('roomClasses[' + i + '].name', roomClasses[i].name);
            if (roomClasses[i].imageUrls != null) {
                roomClasses[i].imageUrls.forEach(file => {
                    data.append('roomClasses[' + i + '].imageUrls', file);
                });
            }
            if (roomClasses[i].imageFiles != null) {
                roomClasses[i].imageFiles.forEach(file => {
                    data.append('roomClasses[' + i + '].imageFiles', file);
                });
            }
        }
        for (var i = 0; i < facilities.length; i++) {
            data.append('facilities[' + i + '].code', facilities[i].code);
            data.append('facilities[' + i + '].name', facilities[i].name);
        }

        await axios({
            method: 'post',
            url: baseURL + 'domestic/api/hotelInfo/' + props.id,
            headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
            data: data
        }).then(response => {
            setLoading(false);
            if (response.data.error != null && response.data.error.message != null) {
                setWarningOpen(true);
                setWarningText(response.data.error.message);
            }
            else {
                // reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
            }
            // setOpen(false);
            // initialValue();
        }).catch(error => {
            setLoading(false);
            setWarningOpen(true);
            setWarningText(error.response.data);
        });
    }
    // async function getDestinationList() {
    //     const response = await axios.get(baseURL + 'domestic/api/destination/forAdmin?from=1&to=1000');
    //     const data = response.data;
    //     setDestinationList(data);
    // }

    const handleExpandClick = () => {
        setExpanded(!expanded);
    };
    const handleCloseModal = () => {
        setModalOpen(false);
    }
    const handleCloseWarning = () => {
        setWarningOpen(false);
    }
    const handleCloseConfirm = () => {
        setConfirmOpen(false);
    }
    const handleCloseRoomClassModal = () => {
        setRoomClassModalOpen(false)
    }
    const handleCloseFacilitiesModal = () => {
        setFacilityModalOpen(false)
    }
    const openEditRoomClassModal = (i) => {
        setIndex(i);
        setRoomID(roomClasses[i].id)
        setRoomDes(roomClasses[i].description);
        setRoomName(roomClasses[i].name);
        setExsitRoomClassImage(roomClasses[i].imageUrls);
        setButtonText('Save');
        setRoomClassModalOpen(true);
    }
    const openEditFacilitiesModal = (i) => {
        setIndex(i);
        setFacilityCode(facilities[i].code)
        setFacilityName(facilities[i].name);
        setButtonText('Save');
        setFacilityModalOpen(true);
    }
    const openDetail = () => {
        // getDestinationList();
        getHotelList(null);
        setModalOpen(true);
    }
    async function confirmProcess() { }
    function executeOnClick(isExpanded) {
    }
    ///////////////////////////////////////////////////////////////////////////////////////////
    // const handleChangeDestination = (event) => {
    //     var temp = event.target.value;
    //     if (temp == '') {
    //         temp = null
    //     }
    //     setDestination(temp);
    //     setHotel(null)
    //     getHotelList(temp)
    // };

    const handleChangeHotel = (event) => {
        setHotel(event.target.value)
    };
    function deleteRoomClass(index) {
        setRoomClasses(roomClasses.filter((e, n) => n !== index));
    }
    function deleteFacilites(index) {
        setFacilities(facilities.filter((e, n) => n !== index));
    }
    function openAddRoomClassModal() {
        setRoomID(null);
        setRoomDes(null);
        setRoomName(null);
        setExsitRoomClassImage(null);
        setRoomClassImage(null);
        setButtonText('Add');
        setRoomClassModalOpen(true);
    }
    function openAddFacilitiesModal() {
        setFacilityCode(null);
        setFacilityName(null);
        setButtonText('Add');
        setFacilityModalOpen(true);
    }
    const onImageDrop = (picture) => {
        setRoomClassImage(picture)
    };
    const onMainImageDrop = (picture) => {
        setMainImage(picture)
    };
    const onGalleryImageDrop = (picture) => {
        setGalleryImage(picture)
    };

    function deleteExistingImage(index) {
        setExsitRoomClassImage(exsitRoomClassImage.filter((e, n) => n !== index));
    }
    function deleteImage(index) {
        setRoomClassImage(roomClassImage.filter((e, n) => n !== index));
    }
    function updateRoomClass() {
        if (nButtonText == 'Add') {
            const obj = { 'id': roomId, 'name': roomName, 'description': roomDes, 'imageUrls': null, 'imageFiles': roomClassImage };
            let myArr = [...roomClasses]
            myArr.push(obj)
            setRoomClasses(myArr)
        }
        else {
            roomClasses[index].description = roomDes;
            roomClasses[index].name = roomName;
            roomClasses[index].imageUrls = exsitRoomClassImage;
            roomClasses[index].imageFiles = roomClassImage;
            var temp = roomClasses
            setRoomClasses(temp);
        }

        setRoomClassModalOpen(false);
    }
    function updateFacilites() {
        if (nButtonText == 'Add') {
            const obj = { 'code': facilityCode, 'name': facilityName };
            let myArr = [...facilities]
            myArr.push(obj)
            setFacilities(myArr)
        }
        else {
            facilities[index].code = facilityCode;
            facilities[index].name = facilityName;
            var temp = facilities
            setFacilities(temp);
        }

        setFacilityModalOpen(false);
    }
    function onChangeRoomID(e) {
        if (e.target.value == '') {
            setRoomID(null);
        }
        else {
            setRoomID(Number(e.target.value));
        }
    }
    function onChangeRoomDes(e) {
        if (e.target.value == '') {
            setRoomDes(null);
        }
        else {
            setRoomDes(e.target.value);
        }
    }
    function onChangeRoomName(e) {
        if (e.target.value == '') {
            setRoomName(null);
        }
        else {
            setRoomName(e.target.value);
        }
    }
    function onChangeFacilityCode(e) {
        if (e.target.value == '') {
            setFacilityCode(null);
        }
        else {
            setFacilityCode(e.target.value);
        }
    }
    function onChangeFacilityName(e) {
        if (e.target.value == '') {
            setFacilityName(null);
        }
        else {
            setFacilityName(e.target.value);
        }
    }
    function onChangeDescription(e) {
        if (e.target.value == '') {
            setDescription(null);
        }
        else {
            setDescription(e.target.value);
        }
    }

    if (loading) {
        return <FuseLoading />;
    }
    return (
        <div>

            <Card className={classes.root} >
                <div style={{ display: 'flex' }}>
                    <div style={{ width: '100%', display: 'flex' }} >
                        {props.mainImageUrls == null || props.mainImageUrls.length == 0 ? <img alt='' style={{ width: '110px', height: '80px', margin: 'auto', padding: '2px' }} src=' ' /> :
                            <Carousel autoPlay={false} transitionTime="2000" showThumbs={false} width="100px">
                                {props.mainImageUrls.map((k, i) =>
                                    <div key={i}>
                                        <img alt='' style={{ width: '100px', height: '80px', margin: 'auto', padding: '2px' }} src={k} />
                                    </div>
                                )}
                            </Carousel>
                        }
                        <div style={{ margin: 'auto 20px', display: 'grid', width: '100%' }}>
                            <div style={{ fontWeight: '600' }}>
                                {props.hotelConversion.hotelName == null ? '' : props.hotelConversion.hotelName}
                            </div>
                            <ShowMoreText
                                lines={3}
                                more='Show more'
                                less='Show less'
                                className='content-css'
                                anchorClass='my-anchor-css-class'
                                onClick={executeOnClick}
                                expanded={false}
                                style={{ marginBottom: '20px' }}
                            // width={800}
                            >
                                {ReactHtmlParser(props.hotelDescription)}
                            </ShowMoreText>
                        </div>
                    </div>
                    <CardActions disableSpacing className={classes.actionExtend}>
                        <IconButton
                            className={clsx(classes.expand, {
                                [classes.expandOpen]: expanded,
                            })}
                            onClick={handleExpandClick}
                            aria-expanded={expanded}
                            aria-label='show more'
                        >
                            <ExpandMoreIcon />
                        </IconButton>
                        <IconButton
                            className={clsx(classes.expand, {
                                [classes.expandOpen]: expanded,
                            })}
                            onClick={openDetail}
                            aria-expanded={expanded}
                            aria-label='show more'
                        >
                            <EditIcon />
                        </IconButton>
                    </CardActions>
                </div>
                <Collapse in={expanded} timeout='auto' unmountOnExit>
                    {props.facilities == null ? null :
                        <div style={{ border: '1px solid #d8d8d8', borderRadius: '3px', margin: '5px' }}>
                            <span style={{ paddingLeft: '10px', fontWeight: '600' }}>Facilities</span>
                            <div>
                                {props.facilities.map((n, i) =>
                                    <Chip
                                        key={i}
                                        className={classes.chipStyle}
                                        label={n.name}
                                        variant='outlined'
                                    />
                                )}
                            </div>
                        </div>
                    }
                    {props.roomClasses == null ? null :
                        <div style={{ border: '1px solid #d8d8d8', borderRadius: '3px', margin: '5px' }}>
                            <span style={{ paddingLeft: '10px', fontWeight: '600' }}>RoomClass</span>
                            <div style={{ display: 'flex' }}>
                                {props.roomClasses.map((n, i) =>
                                    <div key={i} style={{ textAlign: 'center', margin: '2px' }}>
                                        <Carousel autoPlay={false} transitionTime="2000" showThumbs={false} width="100px">
                                            {n.imageUrls == null ? "" : n.imageUrls.map((k, j) =>
                                                <div key={j}>
                                                    <img alt={k.name} style={{ width: '80px', height: '50px', margin: 'auto', padding: '2px' }} src={k} />
                                                </div>
                                            )}
                                        </Carousel>
                                        <Chip
                                            className={classes.chipStyle}
                                            label={n.name}
                                            variant='outlined'
                                        />
                                    </div>
                                )}
                            </div>
                        </div>
                    }
                </Collapse>
            </Card>
        </div>
    );
}
export default HotelInfoPanelTable;