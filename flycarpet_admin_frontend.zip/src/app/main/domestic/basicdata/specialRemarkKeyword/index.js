import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../../store';
import KeywordHeader from './SpecialRemarkKeywordHeader';
import KeywordTable from './SpecialRemarkKeywordTable';

function SpecialRemarkKeyword() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<KeywordHeader operation="domestic"/>}
			content={<KeywordTable operation="domestic"/>}
			innerScroll
		/>
	);
}

export default withReducer('BasicData', reducer)(SpecialRemarkKeyword);
