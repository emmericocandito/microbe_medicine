import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import axios from 'axios';
import _ from '@lodash';
import {
	Table, TableBody, TableCell, TablePagination, TableRow, Checkbox, Modal,
	Backdrop, Fade, TextField, Button, CircularProgress, FormControl, FormControlLabel,
	FormHelperText, Grid, Chip,
} from '@material-ui/core';
import FuseScrollbars from '@fuse/core/FuseScrollbars';
import FuseLoading from '@fuse/core/FuseLoading';
import { makeStyles } from '@material-ui/core/styles';
import clsx from 'clsx';

import BasisTableHead from './SpecialRemarkKeywordTableHead';
import { Autocomplete } from '@material-ui/lab';
import { baseURL } from '../../../utils';
import keycode from 'keycode';

function SpecialRemarkKeywordTable(props) {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			margin: theme.spacing(0),
			minWidth: 60,
		},
		groupControl: {
			margin: theme.spacing(0),
			marginBottom: theme.spacing(1),
			padding:theme.spacing(1),
			minWidth: 800,
			maxWidth: 800,
			border: 'solid 1px #999',
			borderRadius: '10px'
		},
		hideGroup: {
			display: 'none',
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
			minWidth: 120
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
		},
		discountboxform: {
			display: 'grid',
		},
		checkboxform: {
			display: 'block',
		},
		button_group: {
			padding: 30,
			textAlign: 'center',
		},
		buttons: {
			marginLeft: '10px'
		},
		fo_circular: {
			textAlign: 'center',
			position: 'absolute',
			left: '50%',
			transform: 'translatex(-50%)'
		},
		textFiled: {
			width: '100%'
		},
		chip: {
			height: '15px'
		},
		chips: {
			display: 'flex',
			flexWrap: 'wrap',
		},
		chipStyle: {
			height: '20px',
			margin: '1px',
			color: 'white',
			fontSize: '12px',
			background: '#32606b'
		},
		keywordItem: {
			margin: '5px',
		},
		keywordTableItem: {
			margin: '1px',
			padding: 0,
		},
	}));

	const classes = useStyles();

	const [categoriesOfRemark, setCategoriesOfRemark] = useState([]);
	const [sitesToShowIn, setSitesToShownIn] = useState([]);
	const suppliersList = ["...", "GOC", "ISRO", "DAN", "MINI"];
	const [allHotelsList, setAllHotelsList] = useState([]);
	const [hotelsList, setHotelsList]= useState([]);
	const [hotelsListOption, setOptionsHotels] = useState({
    options: [],
    getOptionLabel: (option) => option.hotelName,
  });
	
	const [loading, setLoading] = useState(true);
	const [loadingCircle, setLoadingCircle] = useState(false);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [pageCount, setPageCount] = useState(10);
	const [warningOpen, setWarningOpen] = useState(false);
	const [warningText, setWarningText] = useState(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});
	const [open, setOpen] = useState(false);

	const [keyword, setKeyword] = useState('');
	const [keywordIndex, setKeywordIndex] = useState(-1);

	const [keyPhrases, setKeyPhrases] = useState([]);
	const [remark, setRemark] = useState('');
	const [displayPerPriceList, setDisplayPerPriceList] = useState(false);
	const [remarkCategory, setRemarkCategory] = useState(null);
	const [siteToShowIn, setSiteToShown] = useState(null);
	const [active, setActive] = useState(true);
	const [currentKeyPhrasesId, setCurrentKeyPhrasesId] = useState(null);

	const [discountPercent, setDiscountPercent] = useState(0);
	const [agentCommissionPercent, setAgentCommPct] = useState(0);
	const [hotelSupplier, setHotelSupplier] = useState(null);
	const [hotelExtIds, setHotelExtIds] = useState([]);
	const [selectedHotel, setSelectedHotel] = useState(null);
	const [remarkWithDiscState, setRemarkWithDiscState] = useState(false);

	const [nButtonText, setButtonText] = useState(null);
	const [nButtonState, setButtonState] = useState(null);
	const [selected] = useState([]);
	const [data, setData] = useState([]);
	const [page, setPage] = useState(0);

	useEffect(() => {
		reopen(1, 10);
		fetchingAllHotels();
		fetchRemarkCategories();
		fetchSiteToShownList();
	}, []);

  useEffect(() => {
    setOptionsHotels({
      options: hotelsList.sort((a, b) => { return (a.hotelName < b.hotelName) ? -1 : 1 }),
			getOptionLabel: (option) => option.hotelName,
    })
  }, [hotelsList]);

  useEffect(() => {
		setSelectedHotel(null);
		const supplierIndex = suppliersList.indexOf(hotelSupplier);
		setHotelsList(allHotelsList.filter((hotel) => hotel.source === supplierIndex));
  }, [hotelSupplier]);

	useEffect(() => {
		if (remarkCategory === 'remarkWithDisc') {
			setSiteToShown('agent');
			setRemarkWithDiscState(true);
		} else {
			setRemarkWithDiscState(false);
			setHotelExtIds([]);
			setAgentCommPct(0);
			setDiscountPercent(0);
			setHotelSupplier(null);
		}
	}, [remarkCategory]);

	async function fetchingAllHotels() {
		setLoading(true);
		await axios({
			method: 'get',
			url: `${baseURL}${props.operation}/api/hotelConversion/?from=1&to=1000`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {}
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				const data = response.data;
				setAllHotelsList(data.data);
			}
		}).catch(error => {
			console.log(error);
		});
		setLoading(false);
		setOpen(false);
	}
	async function fetchRemarkCategories() {
		setLoading(true);
		await axios({
			method: 'get',
			url: `${baseURL}${props.operation}/api/specialRemarkRule/remarkCategory`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {}
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				const data = response.data;
				setCategoriesOfRemark(data);
			}
		}).catch(error => {
			console.log(error);
		});
		setLoading(false);
		setOpen(false);
	}

	async function fetchSiteToShownList() {
		setLoading(true);
		await axios({
			method: 'get',
			url: `${baseURL}${props.operation}/api/specialRemarkRule/siteToShowIn`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {}
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				const data = response.data;
				setSitesToShownIn(data);
			}
		}).catch(error => {
			console.log(error);
		});
		setLoading(false);
		setOpen(false);
	}

	async function reopen(from, to) {
		setLoading(true);
		await axios({
			method: 'get',
			url: `${baseURL}${props.operation}/api/specialRemarkRule?from=${from}&to=${to}`,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {}
		}).then(response => {
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				const data = response.data;
				setPageCount(data.total);
				setData(data.data);
			}
		}).catch(error => {
			console.log(error);
		});
		setLoading(false);
		setOpen(false);

	};
	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}
	async function deleteKeyPhrases(index) {
		setCurrentKeyPhrasesId(data[index].id);
		setConfirmOpen(true);
	}
	async function deleteProcess() {
		setLoading(true);
		await axios.delete(`${baseURL}${props.operation}/api/specialRemarkRule/${currentKeyPhrasesId}`, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		})
		reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
		setCurrentKeyPhrasesId(null);
		setDiscountPercent(0);
		setAgentCommPct(0);
		setHotelExtIds([]);
		setHotelSupplier(null);

		setLoading(false);
		setOpen(false);
		setConfirmOpen(false);
	};
	const editKeyPhrases = async (i) => {
		setButtonText('Edit');
		setButtonState('Special Keywords Edit');

		setKeyword('');
		setKeywordIndex(-1);

		setCurrentKeyPhrasesId(data[i].id);
		setKeyPhrases(data[i].keyPhrases);
		setRemark(data[i].remark);
		setDisplayPerPriceList(data[i].displayPerPriceList);
		setSiteToShown(data[i].siteToShowIn);
		setRemarkCategory(data[i].remarkCategory);
		setActive(data[i].active);
		
		setDiscountPercent(data[i].specialDiscountCommission?.discountPct || 0);
		setAgentCommPct(data[i].specialDiscountCommission?.agentCommissionPct || 0);
		setHotelExtIds(data[i].hotelExtIds || []);
		setHotelSupplier(data[i].hotelSupplier);
		setRemarkWithDiscState(false);

		setOpen(true);
	}
	const handleClose = () => {
		setCurrentKeyPhrasesId(null);
		initialValue();
		setOpen(false);
	}
	function initialValue() {
		setKeyword('');
		setKeywordIndex(-1);

		setKeyPhrases([]);
		setRemark('');
		setDisplayPerPriceList(true);
		setSiteToShown(sitesToShowIn[0]);
		setRemarkCategory(categoriesOfRemark[0]);
		
		setDiscountPercent(0);
		setAgentCommPct(0);
		setHotelExtIds([]);
		setHotelSupplier(null);
		setRemarkWithDiscState(false);

		setActive(true);
	}
	async function editProcess() {
		setLoadingCircle(true);
		var request_url = null;
		if (nButtonState == 'Special Keywords Edit') {
			request_url = `${baseURL}${props.operation}/api/specialRemarkRule/${currentKeyPhrasesId}`;
		} else {
			request_url = `${baseURL}${props.operation}/api/specialRemarkRule`;
		}
		await axios({
			method: 'post',
			url: request_url,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"KeyPhrases": keyPhrases,
				"Remark": remark,
				"DisplayPerPriceList": displayPerPriceList,
				"RemarkCategory": remarkCategory,
				"SiteToShowIn": siteToShowIn,
				"Active": active,
				"HotelExtIds": hotelExtIds.length > 0 ? hotelExtIds : null,
				"HotelSupplier": (hotelSupplier === '...') ? null : hotelSupplier,
				"SpecialDiscountCommission": remarkWithDiscState ? {
					"DiscountPct": +discountPercent,
					"AgentCommissionPct": +agentCommissionPercent,
				} : null,
			}
		}).then(response => {
			setLoadingCircle(false);
			if (response.data.error != null && (Number(response.data.error.code) === 1 || Number(response.data.error.code) === 3)) {
				setWarningText(response.data.error.message);
				setWarningOpen(true);
			} else {
				reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
				initialValue();
			}
		}).catch(error => {
			setLoadingCircle(false);
			setWarningText(error.response.data);
			setWarningOpen(true);
			return;
		});
	};
	const addKeyPhrases = async () => {
		setButtonText('Add');
		setButtonState('Add Special Keyword');
		setCurrentKeyPhrasesId(null);
		initialValue();
		setOpen(true);
	}
	function handleChangePage(event, value) {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage
		reopen(from, to);
	}
	function handleChangeRowsPerPage(event) {
		setRowsPerPage(event.target.value);
		setPage(0)
		const temp = Number(event.target.value)
		const from = 1;
		const to = temp
		reopen(from, to);
	}
	const handleCloseWarning = () => {
		setWarningOpen(false);
	}
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}
	const handleKeywordChange = (event) => {
		setKeyword(event.target.value);
	}
	const handleKeyPressKeyword = (event) => {
		if (keycode(event) === 'enter') {
			setKeyword(event.target.value);
			handleKeywordAdd();
		}
	}
	const handleKeywordClick = (_keyword, index) => {
		setKeyword(_keyword);
		setKeywordIndex(index);
	}
	const handleKeywordDelete = (index) => {
		let _keywords = [...keyPhrases];
		_keywords.splice(index, 1);
		setKeyPhrases(_keywords);
		if (index === keywordIndex) {
			setKeywordIndex(-1);
		}
	}
	const handleKeywordAdd = (event) => {
		if (keyword === '') return;
		if (keyPhrases.includes(keyword)) return;

		let _keywords = [...keyPhrases];
		if (keywordIndex !== -1) {
			_keywords[keywordIndex] = keyword;
		} else {
			_keywords.push(keyword);
		}

		setKeyPhrases(_keywords);
		setKeyword('');
		setKeywordIndex(-1);
	}
	const handleChangeRemark = (event) => {
		setRemark(event.target.value);
	}
	const handleChangeCategoryOfRemark = (event) => {
		setRemarkCategory(event.target.innerHTML);
	}
	const handleChangeSiteToShowIn = (event) => {
		setSiteToShown(event.target.innerHTML);
	}

	const handleHotelCodeDelete = (index) => {
		let _hotelIds = [...hotelExtIds];
		_hotelIds.splice(index, 1);
		setHotelExtIds(_hotelIds);
	}
	const handleHotelCodeAdd = (extCode) => {
		if (extCode === '') return;
		if (hotelExtIds.includes(extCode)) return;

		let _hotelIds = [...hotelExtIds];
		_hotelIds.push(extCode);

		setHotelExtIds(_hotelIds);
	}
	const handleChangeHotelSupplier = (event) => {
		const source = event.target.innerHTML;
		setHotelSupplier(source);
		setHotelExtIds([]);
	}
	const handleChangeDiscountPercent = (event) => {
		setDiscountPercent(event.target.value);
	}
	const handleChangeCommissionPercent = (event) => {
		setAgentCommPct(event.target.value);
	}

	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className='w-full flex flex-col'>
			<div>
				<div className='spinner-border text-primary' role='status'>
					<span className='sr-only'>Loading...</span>
				</div>
				<Modal
					open={warningOpen}
					onClose={handleCloseWarning}
					className={classes.modal}
					aria-labelledby='simple-modal-title'
					aria-describedby='simple-modal-description'
				>
					<div className={classes.paper}>
						<h2 id='server-modal-title' >Warning</h2>
						<p id='server-modal-description'>{warningText}</p>
						<Button className='whitespace-no-wrap normal-case'
							variant='contained'
							color='secondary'
							onClick={handleCloseWarning}>Close
						</Button>
					</div>
				</Modal>
				<Modal
					open={confirmOpen}
					onClose={handleCloseConfirm}
					className={classes.modal}
					aria-labelledby='simple-modal-title'
					aria-describedby='simple-modal-description'
				>
					<div className={classes.paper}>
						<h2 id='server-modal-title' style={{ textAlign: 'center' }} >Confirm</h2>
						<p id='server-modal-description'>Do you want to drop this Rule</p>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained'
								color='secondary'
								onClick={deleteProcess}>Yes
							</Button>
							<Button className={classes.buttons} variant='contained'
								color='primary'
								onClick={handleCloseConfirm}>No
							</Button>
						</div>
					</div>
				</Modal>
				<Modal
					aria-labelledby='transition-modal-title'
					aria-describedby='transition-modal-description'
					className={classes.modal}
					open={open}
					onClose={handleClose}
					closeAfterTransition
					BackdropComponent={Backdrop}
					BackdropProps={{
						timeout: 500,
					}}
				>
					<Fade in={open}>
						<div className={classes.paper}>
							<div className={classes.fo_circular}>
								{loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
							</div>
							<div style={{ textAlign: 'center' }}>
								<h2 id='transition-modal-title' >{nButtonState}</h2>
							</div>
							<div>
								<Grid container justify='space-between' style={{ margin: '10px 0px', display: 'flex', justifyContent: 'space-between' }}>
									<FormControl required className={classes.formControl} style={{ width: '100%' }}>
										<FormHelperText>Category of Remark</FormHelperText>
										<Autocomplete
											options={categoriesOfRemark}
											value={remarkCategory}
											onChange={handleChangeCategoryOfRemark}
											id="category_remark"
											disableClearable
											renderInput={(params) => (
												<TextField {...params} variant="standard" />
											)}
										/>
									</FormControl>
								</Grid>

								<Grid className={classes.groupControl}>
									<Grid container justify='space-between' style={{ textAlign: 'center' }}>
										<FormControl required className={classes.formControl} style={{ width: '100%' }}>
											<FormHelperText style={{ wordSpacing: '-1px' }}>Key Phrases</FormHelperText>
											<Grid container style={{ textAlign: 'center', display: 'flex' }} onClick={() => { setKeywordIndex(-1); }}>
												{
													keyPhrases?.map((_keyword, i) => {
														return (
															<Chip key={i} label={`${_keyword}`} className={classes.keywordItem} variant='outlined'
																onClick={(e) => {
																	handleKeywordClick(_keyword, i);
																	e.stopPropagation();
																}}
																onDelete={() => handleKeywordDelete(i)}
															/>
														)
													})
												}
											</Grid>
										</FormControl>
									</Grid>
									<hr style={{ marginBottom: '10px' }}></hr>
									<Grid container justify='space-between' style={{ width: 'calc(100% - 20px)' }}>
										<TextField placeholder='edit keyword' className={classes.textfield} style={{ marginLeft: '10px', width: 'calc(100% - 120px)' }}
											value={keyword} onChange={handleKeywordChange} onKeyDown={handleKeyPressKeyword}
										/>
										<Button className={`${classes.buttons} ${classes.controlButton}`} style={{ marginLeft: '10px', height: '28px' }} variant="contained" color="secondary" onClick={handleKeywordAdd}>
											{ keywordIndex === -1 ? 'add': 'update'}
										</Button>
									</Grid>
								</Grid>

								<Grid className={remarkWithDiscState ? classes.groupControl : classes.hideGroup} >
									<Grid container justify='space-between' style={{ textAlign: 'center' }}>
										<FormControl required className={classes.formControl} style={{ width: '100%' }}>
											<FormHelperText style={{ wordSpacing: '-1px' }}>Hotel External Codes</FormHelperText>
											<Grid container style={{ textAlign: 'center', display: 'flex' }}>
												{
													hotelExtIds?.map((_code, i) => {
														return (
															<Chip key={i} label={`${_code}`} className={classes.keywordItem} variant='outlined'
																onDelete={() => handleHotelCodeDelete(i)}
															/>
														)
													})
												}
											</Grid>
										</FormControl>
									</Grid>
									<hr style={{ marginBottom: '10px' }}></hr>
									<Grid container justify='space-between' style={{ width: 'calc(100% - 20px)' }}>
										<FormControl required className={classes.formControl} style={{ width: '48%' }}>
											<FormHelperText>Suppliers</FormHelperText>
											<Autocomplete
												options={suppliersList}
												value={hotelSupplier}
												selectOnFocus
												disableClearable
												onChange={handleChangeHotelSupplier}
												id="hotel-supplier"
												renderInput={(params) => (
													<TextField {...params} variant="standard" />
												)}
												getOptionSelected={(option, value) => option === value}
											/>
										</FormControl>
										<FormControl required className={classes.formControl} style={{ width: '48%' }}>
											<FormHelperText>Hotels</FormHelperText>
											<Autocomplete
												{...hotelsListOption}
												value={selectedHotel}
												selectOnFocus
												onChange={(e, newValue) => {
													setSelectedHotel(newValue);
													handleHotelCodeAdd(newValue.hotelExternalCode);
												}}
												id="select-hotel"
												disableClearable
												renderInput={(params) => (
													<TextField {...params} variant="standard" />
												)}
												getOptionSelected={(option, value) => option.hotelName === value.hotelName}
											/>
										</FormControl>
									</Grid>
									
									<Grid container justify='space-between' style={{ margin: '10px 0px', display: 'flex', justifyContent: 'space-between' }}>
										<FormControl required className={classes.formControl} style={{ width: '48%' }}>
											<FormHelperText>Discount Percent</FormHelperText>
											<TextField className={classes.textfield} value={discountPercent} onChange={handleChangeDiscountPercent} />
										</FormControl>
										<FormControl required className={classes.formControl} style={{ width: '48%' }}>
											<FormHelperText>Agent Commission Percent</FormHelperText>
											<TextField className={classes.textfield} value={agentCommissionPercent} onChange={handleChangeCommissionPercent} />
										</FormControl>
									</Grid>
								</Grid>

								<Grid container justify='space-between' style={{ margin: '10px 0px', display: 'flex', justifyContent: 'space-between' }}>
									<FormControl required className={classes.formControl} style={{ width: '48%' }}>
										<FormHelperText>Sites to show</FormHelperText>
										<Autocomplete
											options={sitesToShowIn}
											value={siteToShowIn}
											onChange={handleChangeSiteToShowIn}
											id="sites_to_shown"
											disableClearable
											disabled={remarkWithDiscState}
											renderInput={(params) => (
												<TextField {...params} variant="standard" />
											)}
										/>
									</FormControl>
									<FormControl required className={classes.formControl} style={{ width: '48%' }}>
										<FormHelperText>Remark</FormHelperText>
										<TextField className={classes.textfield} value={remark} onChange={handleChangeRemark} />
									</FormControl>
								</Grid>

								<FormControlLabel style={{ width: '100%' }}
									control={
										<Checkbox
											checked={displayPerPriceList}
											onChange={e => { setDisplayPerPriceList(e.target.checked) }}
											name='display_per_pricelist'
											color='primary'
										/>
									}
									label='Display per PriceList?'
									className={classes.checkboxform}
								/>

								<FormControlLabel style={{ width: '100%' }}
									control={
										<Checkbox
											checked={active}
											onChange={e => { setActive(e.target.checked) }}
											name='active'
											color='primary'
										/>
									}
									label='Active?'
									className={classes.checkboxform}
								/>
							</div>
							<div className={classes.button_group}>
								<Button className={classes.buttons} variant='contained' onClick={editProcess} color='secondary'>
									{nButtonText}
								</Button>
								<Button className={classes.buttons} variant='contained' color='primary' onClick={handleClose}>
									Cancel
								</Button>
							</div>
						</div>

					</Fade>
				</Modal>
			</div>
			<div>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px' }}
					onClick={() => addKeyPhrases()}
				>
					<span className='hidden sm:flex'>Add Keyword</span>
				</Button>
			</div>
			<FuseScrollbars className='flex-grow overflow-x-auto'>
				<Table stickyHeader className='min-w-xl' aria-labelledby='tableTitle'>
					<BasisTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={data.length}
					/>
					<TableBody>
						{_.orderBy(
							data,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className='h-64 cursor-pointer'
									hover
									tabIndex={-1}
									key={i}
								>
									<TableCell padding="none" className="w-40 md:w-64 text-center z-99">
										{page * rowsPerPage + 1 + i}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editKeyPhrases(i)}>
										{n.keyPhrases?.map((keyword, i) => (<Chip key={i} className={classes.chipStyle} label={`${keyword}`} variant='outlined' />)) }
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editKeyPhrases(i)}>
										{n.remark}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editKeyPhrases(i)}>
										{n.hotelSupplier}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editKeyPhrases(i)}>
										{
											n.hotelExtIds?.map((_code, i) => {
												return (
													<Chip key={i} label={`${_code}`} className={classes.keywordTableItem} variant='outlined'/>
												)
											})
										}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => editKeyPhrases(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.displayPerPriceList && 'bg-red',
												n.displayPerPriceList && 'bg-green',
											)}
										/>
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left' onClick={() => editKeyPhrases(i)}>
										{n.remarkCategory}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left' onClick={() => editKeyPhrases(i)}>
										{n.siteToShowIn}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left' onClick={() => editKeyPhrases(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.active && 'bg-red',
												n.active && 'bg-green',
											)}
										/>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component='th' scope='row' align='left'>
										<button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
											onClick={() => editKeyPhrases(i)}
											tabIndex='0' type='button' title='Edit'>
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>edit</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => deleteKeyPhrases(i)} tabIndex="0" type="button" title="Edit">
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className='flex-shrink-0 border-t-1'
				component='div'
				count={pageCount}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}
export default withRouter(SpecialRemarkKeywordTable);
