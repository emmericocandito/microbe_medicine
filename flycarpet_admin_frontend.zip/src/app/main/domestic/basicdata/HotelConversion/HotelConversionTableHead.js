import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Tooltip from '@material-ui/core/Tooltip';
import React from 'react';

const rows = [
    
    {
        id: 'Hotel',
        align: 'left',
        disablePadding: false,
        label: 'HotelImage',
        sort: false
    },
    {
        id: 'hotelName',
        align: 'left',
        disablePadding: false,
        label: 'HotelName',
        sort: true
    },
    {
        id: 'hotelChainId',
        align: 'left',
        disablePadding: false,
        label: 'HotelChainName',
        sort: true
    },
    {
        id: 'hotelAtlantisCode',
        align: 'left',
        disablePadding: false,
        label: 'AtlantisCode',
        sort: true
    },
    {
        id: 'hotelExternalCode',
        align: 'left',
        disablePadding: false,
        label: 'ExternalCode',
        sort: true
    },
    {
        id: 'hotelOldAtlantisCode',
        align: 'left',
        disablePadding: false,
        label: 'OldAtlantisCode',
        sort: true
    },
    {
        id: 'mainCityCode',
        align: 'left',
        disablePadding: false,
        label: 'MainCityCode',
        sort: true
    },
    {
        id: 'secondCityCode',
        align: 'left',
        disablePadding: false,
        label: 'SecondCityCode',
        sort: true
    },
    {
        id: 'atlantisSupplierCode',
        align: 'left',
        disablePadding: false,
        label: 'AtlanticSupplierCode',
        sort: true
    },
    {
        id: 'source',
        align: 'left',
        disablePadding: false,
        label: 'Supplier',
        sort: true
    },
    {
        id: 'commission',
        align: 'left',
        disablePadding: false,
        label: 'Commission',
        sort: true
    },
    {
        id: 'discount',
        align: 'left',
        disablePadding: false,
        label: 'Discount',
        sort: true
    },
    {
        id: 'priority',
        align: 'center',
        disablePadding: false,
        label: 'Priority',
        sort: true
    },
    {
        id: 'promoterPhone',
        align: 'left',
        disablePadding: false,
        label: 'PromoterPhone',
        sort: true
    },
    {
        id: 'promoterMame',
        align: 'left',
        disablePadding: false,
        label: 'PromoterMame',
        sort: true
    },
    {
        id: 'forceValidation',
        align: 'left',
        disablePadding: false,
        label: 'ForceValidation',
        sort: true
    },
    {
        id: 'active',
        align: 'left',
        disablePadding: false,
        label: 'Active',
        sort: true
    },
    {
        id: 'edit',
        align: 'center',
        disablePadding: false,
        label: 'Edit',
        sort: true
    },
    {
        id: 'delete',
        align: 'center',
        disablePadding: false,
        label: 'Delete',
        sort: true
    }
    
];

function ProductsTableHead(props) {

    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };

    return (
        <TableHead>
            <TableRow className="h-64">
                {rows.map(row => {
                    return (
                        <TableCell
                            className="p-4 md:p-16"
                            key={row.id}
                            align={row.align}
                            padding={row.disablePadding ? 'none' : 'default'}
                            sortDirection={props.order.id === row.id ? props.order.direction : false}
                        >
                            {row.sort && (
                                <Tooltip
                                    title="Sort"
                                    placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                    enterDelay={300}
                                >
                                    <TableSortLabel
                                        active={props.order.id === row.id}
                                        direction={props.order.direction}
                                        onClick={createSortHandler(row.id)}
                                    >
                                        {row.label}
                                    </TableSortLabel>
                                </Tooltip>
                            )}
                        </TableCell>
                    );
                }, this)}
            </TableRow>
        </TableHead>
    );
}

export default ProductsTableHead;
