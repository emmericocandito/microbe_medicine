import FuseScrollbars from '@fuse/core/FuseScrollbars';
import axios from 'axios';
import _ from '@lodash';
import {
	Checkbox, Table, TableBody, TableCell, TablePagination, TableRow, Modal, Backdrop, Fade,
	TextField, Button, Select, FormControl, FormHelperText, FormControlLabel, Grid
} from '@material-ui/core';
import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import FuseLoading from '@fuse/core/FuseLoading';
import HotelConversionTableHead from './HotelConversionTableHead';
import { makeStyles } from '@material-ui/core/styles';
import CircularProgress from '@material-ui/core/CircularProgress'
import SearchIcon from '@material-ui/icons/Search';
import { TransientCommission } from 'app/main/BasicComponents/TransientCommission';
import { baseURL, isHighTeckUser } from 'app/main/utils';

var suppliers = ["...", "GOC", "ISRO", "DAN", "MINI"];
function HotelConversionTable() {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			margin: theme.spacing(0, 1),
			minWidth: 120,
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			textAlign: "center",
			overflow: 'auto',
			maxHeight: '750px'
		},
		button_group:
		{
			padding: 30,
			textAlign: 'center',
		},
		buttons:
		{
			marginRight: '10px'
		},
		fo_circular: {
			textAlign: 'center',
			position: 'absolute',
			left: '50%',
			transform: 'translatex(-50%)'
		},
	}));
	const classes = useStyles();
	const [dealLength, setDealLength] = useState(0);
	const [warningOpen, setWarningOpen] = useState(false);
	const [openFilter, setOpenFilter] = useState(false);
	const [nButtonText, setButtonText] = useState(null);
	const [warningText, setWarningText] = useState(null);
	const [loading, setLoading] = useState(true);
	const [loadingCircle, setLoadingCircle] = useState(false);
	const [selected] = useState([]);
	const [data, setData] = useState([]);
	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [confirmText, setConfirmText] = useState(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});

	const [hotelConversionID, setHotelConversionID] = useState();
	const [hotelChainList, setHotelChainList] = useState([]);
	const [destList, setDestList] = useState([]);

	const [hotelChainID, setHotelChainID] = useState(null);
	const [hotelName, setHotelName] = useState(null);
	const [mainCityCode, setMainCityCode] = useState(null);
	const [secondCityCode, setSecondCityCode] = useState(null);
	const [atlantisSupplierCode, setAtlantisSupplierCode] = useState(null);
	const [hotelAtlantisCode, setHotelAtlantisCode] = useState(null);
	const [hotelExternalCode, setHotelExternalCode] = useState(null);
	const [hotelOldAtlantisCode, setHotelOldAtlantisCode] = useState(null);
	const [source, setSource] = useState(null);
	const [priority, setPriority] = useState(null);
	const [commission, setCommission] = useState(null);
	const [discount, setDiscount] = useState(null);
	const [promoterPhone, setPromoterPhone] = useState(null)
	const [promoterName, setPromoterName] = useState(null);
	const [forceValidation, setForceValidation] = useState(false);
	const [isActive, setIsActive] = useState(false);

	const [nTransientCommissionList, setTransientCommissionList] = useState([]);

	const [nFilterhotelAtlantisCode, setFilterHotelAtlantisCode] = useState(null);
	const [nFilterHotelOldAtlantisCode, setFilterHotelOldAtlantisCode] = useState(null);
	const [nFilterhotelChainID, setFilterHotelChainID] = useState(null);
	const [nFilterhotelName, setFilterHotelName] = useState(null);
	const [nFiltermainCityCode, setFilterMainCityCode] = useState(null);
	const [nFiltersecondCityCode, setFilterSecondCityCode] = useState(null);
	const [nFilteratlantisSupplierCode, setFilterAtlantisSupplierCode] = useState(null);
	const [nFilterhotelExternalCode, setFilterHotelExternalCode] = useState(null);
	const [nFiltersource, setFilterSource] = useState(null);
	const [nFilterpriority, setFilterPriority] = useState(null);
	const [nFiltercommission, setFilterCommission] = useState(null);
	const [nFilterdiscount, setFilterDiscount] = useState(null);
	const [nFilterpromoterPhone, setFilterPromoterPhone] = useState(null)
	const [nFilterpromoterName, setFilterPromoterName] = useState(null);
	const [nFilterForceValidation, setFilterForceValidation] = useState('');
	const [nFilterMissingHotelInfo, setFilterMissingHotelInfo] = useState(null);
	const [nFilterHasExtraComm, setFilterHasExtraComm] = useState(null);
	const [nFilterIsActive, setFilterIsActive] = useState('');


	const [open, setOpen] = React.useState(false);
	useEffect(() => {
		reopen(1, 10);
		getHotelChainData();
		getDestList();
	}, []);
	useEffect(() => {
		const orderedData = _.orderBy(
			data,
			[
				o => {
					switch (order.id) {
						case 'categories': {
							return o.categories[0];
						}
						default: {
							return o[order.id];
						}
					}
				}
			],
			[order.direction]
		);
		setData(orderedData);

	}, [order]);

	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}

	async function getHotelChainData() {
		const response = await axios.get(baseURL + 'domestic/api/hotelChain?' + 'from=1&to=1000')
		const data = response.data;
		setHotelChainList(data['data']);
	}
	async function getDestList() {
		const response = await axios.get(baseURL + 'domestic/api/destination/forAdmin?' + 'from=1&to=1000')
		const data = response.data;
		setDestList(data);
	}

	async function reopen(from, to) {
		const temp = nFilterForceValidation == '' ? null : nFilterForceValidation == "true";
		const isFilterActive = nFilterIsActive == '' ? null : nFilterIsActive == "true";
		const temp2 = (nFilterMissingHotelInfo == '' || nFilterMissingHotelInfo == null) ? null : nFilterMissingHotelInfo == "true";
		await axios({
			method: 'post',
			url: baseURL + 'domestic/api/hotelConversion/search?' + 'from=' + from + '&to=' + to,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"hotelAtlantisCode": nFilterhotelAtlantisCode,
				"hotelOldAtlantisCode": nFilterHotelOldAtlantisCode,
				"hotelName": nFilterhotelName,
				"hotelChainId": nFilterhotelChainID,
				"mainCityCode": nFiltermainCityCode,
				"secondCityCode": nFiltersecondCityCode,
				"atlantisSupplierCode": nFilteratlantisSupplierCode,
				"hotelExternalCode": nFilterhotelExternalCode,
				"source": Number(nFiltersource) ? Number(nFiltersource) : null,
				"ignoreSource": nFiltersource === null,
				"priority": nFilterpriority == null ? null : Number(nFilterpriority),
				"commission": nFiltercommission == null ? null : Number(nFiltercommission),
				"discount": nFilterdiscount == null ? null : Number(nFilterdiscount),
				"promoterPhone": nFilterpromoterPhone,
				"promoterMame": nFilterpromoterName,
				"forceValidation": temp,
				"active": isFilterActive,
				"missingHotelInfo": temp2,
				"hasExtraCommission": (nFilterHasExtraComm === null || nFilterHasExtraComm === '') ? null : nFilterHasExtraComm === 'true',
			}
		}).then(response => {
			setLoading(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningText(response.data.error.message);
				setWarningOpen(true);
			}
			else {
				setDealLength(response.data['total']);
				setData(response.data['data']);
			}
			setOpen(false);
		}).catch(error => {
			setLoading(false);
			setWarningOpen(true);
			setWarningText("Error");
		});
	}

	async function confirmProcess() {
		setLoading(true);
		await axios.delete(baseURL + 'domestic/api/hotelConversion/' + hotelConversionID, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		}).then(response => {
			setLoading(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningOpen(true);
				setWarningText(response.data.error.message);
			}
			else {
				reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}
			setOpen(false);
			setConfirmOpen(false);
		}).catch(error => {
			setLoading(false);
			setConfirmOpen(false);
			setWarningOpen(true);
			setWarningText(error.response.data);
		});
		setConfirmOpen(false);
	}

	async function handleUpdate() {

		if (hotelName == null) {
			setWarningText("Please insert HotelName");
			setWarningOpen(true);
		}
		else if (priority == null) {
			setWarningText("Please set Priority");
			setWarningOpen(true);
		}
		else {
			setLoadingCircle(true);
			let url;
			if (nButtonText === 'Save') {
				url = baseURL + 'domestic/api/hotelConversion/' + hotelConversionID;
			}
			else {
				url = baseURL + 'domestic/api/hotelConversion';
			}
			await axios({
				method: 'post',
				url: url,
				headers: { 
					'Content-Type': 'application/json',
					'Access-Control-Allow-Origin': '*',
					'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token') },
				data: {
					"hotelAtlantisCode": hotelAtlantisCode,
					"hotelOldAtlantisCode": hotelOldAtlantisCode,
					"hotelName": hotelName,
					"hotelChainId": hotelChainID,
					"mainCityCode": mainCityCode,
					"secondCityCode": secondCityCode,
					"atlantisSupplierCode": atlantisSupplierCode,
					"hotelExternalCode": hotelExternalCode,
					"source": Number(source) ? Number(source) : null,
					"priority": priority == null ? null : Number(priority),
					"commission": commission == null ? null : Number(commission),
					"discount": discount == null ? null : Number(discount),
					"promoterPhone": promoterPhone,
					"promoterMame": promoterName,
					"forceValidation": forceValidation,
					"active": isActive,
					"transientCommissions": nTransientCommissionList,
				}
			}).then(response => {
				setLoadingCircle(false);
				if (response.data.error != null && response.data.error.message != null) {
					setWarningText(response.data.error.message);
					setWarningOpen(true);
				}
				else {
					setOpen(false);
					reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
					inputInitial();
				}
			}).catch(error => {
				setLoadingCircle(false);
				setWarningText("HTTP REQUEST ERROR");
				setWarningOpen(true);
				return;
			});
		}

	};


	////////////////////////////////////////
	function onChangeHotelName(event) {
		if (event.target.value == '') {
			setHotelName(null);
		}
		else {
			setHotelName(event.target.value);
		}
	}
	function onSelectHotelChain(event) {
		if (event.target.value == '') {
			setHotelChainID(null);
		}
		else {
			setHotelChainID(event.target.value);
		}
	}
	function onChangeMainCity(event) {
		if (event.target.value == '') {
			setMainCityCode(null);
		}
		else {
			setMainCityCode(event.target.value);
		}
	}
	function onChangeSecondCity(event) {
		if (event.target.value == '') {
			setSecondCityCode(null);
		}
		else {
			setSecondCityCode(event.target.value);
		}
	}
	function onChangeAtlantisSupplier(event) {
		if (event.target.value == '') {
			setAtlantisSupplierCode(null);
		}
		else {
			setAtlantisSupplierCode(event.target.value);
		}
	}
	function onChangePriority(event) {
		if (event.target.value == '') {
			setPriority(null);
		}
		else {
			setPriority(event.target.value);
		}
	}
	function onChangeSource(event) {
		if (event.target.value == '') {
			setSource(null)
		}
		else {
			setSource(event.target.value)
		}
	}
	function onChangeDiscountValue(event) {
		if (event.target.value == '') {
			setDiscount(null);
		}
		else {
			setDiscount(event.target.value);
		}
	}
	function onChangeCommission(event) {
		if (event.target.value == '') {
			setCommission(null);
		}
		else {
			setCommission(event.target.value);
		}
	}
	function onChangeHotelAtlantisCode(event) {
		if (event.target.value == '') {
			setHotelAtlantisCode(null);
		}
		else {
			setHotelAtlantisCode(event.target.value);
		}
	}
	function onChangeHotelOldAtlantisCode(event) {
		if (event.target.value == '') {
			setHotelOldAtlantisCode(null);
		}
		else {
			setHotelOldAtlantisCode(event.target.value);
		}
	}
	function onChangeHotelExternanCode(event) {
		if (event.target.value == '') {
			setHotelExternalCode(null);
		}
		else {
			setHotelExternalCode(event.target.value);
		}
	}
	function onChangePromoterPhone(event) {
		if (event.target.value == '') {
			setPromoterPhone(null);
		}
		else {
			setPromoterPhone(event.target.value);
		}
	}
	function onChangePromoterMame(event) {
		if (event.target.value == '') {
			setPromoterName(null);
		}
		else {
			setPromoterName(event.target.value);
		}
	}
	/////////////////////////////////

	function onFilterChangeHotelName(event) {
		if (event.target.value == '') {
			setFilterHotelName(null);
		}
		else {
			setFilterHotelName(event.target.value);
		}
	}
	function onFilterSelectHotelChain(event) {
		if (event.target.value == '') {
			setFilterHotelChainID(null);
		}
		else {
			setFilterHotelChainID(event.target.value);
		}
	}
	function onFilterChangeMainCity(event) {
		if (event.target.value == '') {
			setFilterMainCityCode(null);
		}
		else {
			setFilterMainCityCode(event.target.value);
		}
	}
	function onFilterChangeSecondCity(event) {
		if (event.target.value == '') {
			setFilterSecondCityCode(null);
		}
		else {
			setFilterSecondCityCode(event.target.value);
		}
	}
	function onFilterChangeAtlantisSupplier(event) {
		if (event.target.value == '') {
			setFilterAtlantisSupplierCode(null);
		}
		else {
			setFilterAtlantisSupplierCode(event.target.value);
		}
	}
	function onFilterChangePriority(event) {
		if (event.target.value == '') {
			setFilterPriority(null);
		}
		else {
			setFilterPriority(event.target.value);
		}
	}
	function onFilterChangeSource(event) {
		if (event.target.value == '') {
			setFilterSource(null);
		}
		else {
			setFilterSource(event.target.value);
		}
	}
	function onFilterChangeDiscountValue(event) {
		if (event.target.value == '') {
			setFilterDiscount(null);
		}
		else {
			setFilterDiscount(event.target.value);
		}
	}
	function onFilterChangeCommission(event) {
		if (event.target.value == '') {
			setFilterCommission(null);
		}
		else {
			setFilterCommission(event.target.value);
		}
	}
	function onFilterChangeHotelAtlantisCode(event) {
		if (event.target.value == '') {
			setFilterHotelAtlantisCode(null);
		}
		else {
			setFilterHotelAtlantisCode(event.target.value);
		}
	}
	function onFilterChangeHotelOldAtlantisCode(event) {
		if (event.target.value == '') {
			setFilterHotelOldAtlantisCode(null);
		}
		else {
			setFilterHotelOldAtlantisCode(event.target.value);
		}
	}
	function onFilterChangeHotelExternalCode(event) {
		if (event.target.value == '') {
			setFilterHotelExternalCode(null);
		}
		else {
			setFilterHotelExternalCode(event.target.value);
		}
	}
	function onFilterChangePromoterPhone(event) {
		if (event.target.value == '') {
			setFilterPromoterPhone(null);
		}
		else {
			setFilterPromoterPhone(event.target.value);
		}
	}
	function onFilterChangePromoterMame(event) {
		if (event.target.value == '') {
			setFilterPromoterName(null);
		}
		else {
			setFilterPromoterName(event.target.value);
		}
	}
	function onFilterChangeForceValidation(event) {
		setFilterForceValidation(event.target.value);
	}
	function onFilterChangeActivation(event) {
		setFilterIsActive(event.target.value);
	}

	function onChangeFilterMissingHotelInfo(e) {
		setFilterMissingHotelInfo(e.target.value);
	}
	function onChangeHasExtraCommission(e) {
		setFilterHasExtraComm(e.target.value);
	}


	const addConversion = async () => {
		setButtonText('Add');
		inputInitial();
		setOpen(true);
	};

	const editConversion = (index) => {
		if(isHighTeckUser) return;

		setButtonText('Save');
		setHotelConversionID(data[index].id);
		setHotelAtlantisCode(data[index].hotelAtlantisCode);
		setHotelOldAtlantisCode(data[index].hotelOldAtlantisCode);
		setHotelChainID(data[index].hotelChainId);
		setHotelName(data[index].hotelName);
		setMainCityCode(data[index].mainCityCode);
		setSecondCityCode(data[index].secondCityCode);
		setAtlantisSupplierCode(data[index].atlantisSupplierCode);
		setHotelExternalCode(data[index].hotelExternalCode);
		setSource(data[index].source);
		setPriority(data[index].priority);
		setCommission(data[index].commission);
		setDiscount(data[index].discount);
		setPromoterPhone(data[index].promoterPhone);
		setPromoterName(data[index].promoterMame);
		setForceValidation(data[index].forceValidation);
		setIsActive(data[index].active);
		setTransientCommissionList(data[index].transientCommissions || []);
		setOpen(true);
	};

	const deleteCoversion = async (index) => {
		setHotelConversionID(data[index].id);
		setConfirmText("Do you want to drop this HotelConversion?");
		setConfirmOpen(true);
	}
	const handleClose = () => {
		inputInitial();
		setOpen(false);
	};
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}
	const handleCloseWarning = () => {
		setWarningOpen(false);
	}
	function inputInitial() {
		setHotelConversionID(null);
		setHotelAtlantisCode(null);
		setHotelOldAtlantisCode(null);
		setHotelChainID(null);
		setHotelName(null);
		setMainCityCode(null);
		setSecondCityCode(null);
		setAtlantisSupplierCode(null);
		setHotelExternalCode(null);
		setSource(null);
		setPriority(null);
		setCommission(null);
		setDiscount(null);
		setPromoterPhone(null);
		setPromoterName(null);
		setForceValidation(false);
		setTransientCommissionList([]);
	}
	function handleChangePage(event, value) {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage;
		reopen(from, to)
	}
	function handleChangeRowsPerPage(event) {
		setRowsPerPage(event.target.value);
		setPage(0);
		const temp = Number(event.target.value)
		const from = 1;
		const to = temp;
		reopen(from, to)

	}
	function onChangeForceValidation() {
		setForceValidation(!forceValidation);
	}
	function onChangeActivation() {
		setIsActive(!isActive);
	}
	function searchConversion() {
		setPage(0);
		reopen(1, rowsPerPage);
		setOpenFilter(false);
	}

	const handleFilterClose = () => {
		setOpenFilter(false);
	};

	const openSearchModel = () => {
		setOpenFilter(true);
	};

	const handleChangeTransientCommission = (list) => {
		setTransientCommissionList(list);
	}

	const handleShowErrorMessage = (message) => {
		setWarningText(message);
		setWarningOpen(true);
	}

	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className="w-full flex flex-col">
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={openFilter}
				onClose={handleFilterClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={openFilter}>
					<div className={classes.paper}>
						<div className={classes.fo_circular}>
							{loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
						</div>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title' >HotelConversion Filter</h2>
						</div>
						<div className={classes.formControl} style={{ display: 'grid' }}>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>HotelAtlantisCode</FormHelperText>
									<TextField value={nFilterhotelAtlantisCode == null ? '' : nFilterhotelAtlantisCode} onChange={onFilterChangeHotelAtlantisCode} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>HotelExternalCode</FormHelperText>
									<TextField value={nFilterhotelExternalCode == null ? '' : nFilterhotelExternalCode} onChange={onFilterChangeHotelExternalCode} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>HotelOldAtlantisCode</FormHelperText>
									<TextField value={nFilterHotelOldAtlantisCode == null ? '' : nFilterHotelOldAtlantisCode} onChange={onFilterChangeHotelOldAtlantisCode} />
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>HotelChain</FormHelperText>
									<Select
										native
										onChange={onFilterSelectHotelChain}
										defaultValue={nFilterhotelChainID == null ? '' : nFilterhotelChainID}
										name='Code'
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option value=''>...</option>
										{hotelChainList == null ? '' : hotelChainList.map((n, i) =>
											<option key={i} value={n.id}>{n.name}</option>
										)}
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>HotelName</FormHelperText>
									<TextField value={nFilterhotelName == null ? '' : nFilterhotelName} onChange={onFilterChangeHotelName} />
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>MainCity</FormHelperText>
									<Select
										native
										onChange={onFilterChangeMainCity}
										defaultValue={nFiltermainCityCode == null ? '' : nFiltermainCityCode}
										name='Code'
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option value=''>...</option>
										{destList == null ? '' : destList.map((n, i) =>
											<option key={i} value={n.code}>{n.name}</option>
										)}
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>SecondCity</FormHelperText>
									<TextField value={nFiltersecondCityCode == null ? '' : nFiltersecondCityCode} onChange={onFilterChangeSecondCity} />
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>AtlantisSupplierCode</FormHelperText>
									<TextField onChange={onFilterChangeAtlantisSupplier} defaultValue={nFilteratlantisSupplierCode == null ? '' : nFilteratlantisSupplierCode} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '45%' }}>
									<FormHelperText>Priority(1~10)</FormHelperText>
									<TextField
										id='standard-number'
										type='number'
										min='0'
										max='10'
										defaultValue={nFilterpriority == null ? 0 : Number(nFilterpriority)}
										onChange={onFilterChangePriority}
										InputProps={{
											inputProps: {
												min: 0,
												max: 10
											}
										}}
									/>
								</FormControl>
							</Grid>

							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between', flexWrap: 'nowrap' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>External Source</FormHelperText>
									<Select
										native
										onChange={onFilterChangeSource}
										defaultValue={nFiltersource === null ? '' : nFiltersource}
										name='Code'
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option value=''>All</option>
										{suppliers == null ? '' : suppliers.map((n, i) =>
											<option key={i} value={i}>{n}</option>
										)}
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>discount(1~20%)</FormHelperText>
									<TextField
										id='standard-number'
										type='number'
										min='0'
										max='20'
										defaultValue={nFilterdiscount == null ? 0 : nFilterdiscount}
										onChange={onFilterChangeDiscountValue}
										InputProps={{
											inputProps: {
												min: 0,
												max: 20
											}
										}}
									/>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Commission</FormHelperText>
									<TextField
										id='standard-number'
										type='number'
										min='0'
										max='20'
										defaultValue={nFiltercommission == null ? 0 : nFiltercommission}
										onChange={onFilterChangeCommission}
										InputProps={{
											inputProps: {
												min: 0,
												max: 20
											}
										}}
									/>
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between', flexWrap: 'nowrap' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>PromoterPhone</FormHelperText>
									<TextField value={nFilterpromoterPhone == null ? '' : nFilterpromoterPhone} onChange={onFilterChangePromoterPhone} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>promoterMame</FormHelperText>
									<TextField value={nFilterpromoterName == null ? '' : nFilterpromoterName} onChange={onFilterChangePromoterMame} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>ForceValidationWhenUpdate</FormHelperText>
									<Select
										native
										onChange={onFilterChangeForceValidation}
										value={nFilterForceValidation || ''}
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option aria-label='None' value=''>All</option>
										<option value='true'>True</option>
										<option value='false'>False</option>
									</Select>
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between', flexWrap: 'nowrap' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>MissingHotelInfo</FormHelperText>
									<Select
										native
										onChange={onChangeFilterMissingHotelInfo}
										value={nFilterMissingHotelInfo || ''}
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option aria-label='None' value=''>All</option>
										<option value='true'>True</option>
										<option value='false'>False</option>
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Has Extra Commission</FormHelperText>
									<Select
										native
										onChange={onChangeHasExtraCommission}
										value={nFilterHasExtraComm || ''}
										inputProps={{
											id: 'extra-commission-required',
										}}
									>
										<option aria-label='None' value=''>All</option>
										<option value='true'>True</option>
										<option value='false'>False</option>
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Active</FormHelperText>
									<Select
										native
										onChange={onFilterChangeActivation}
										value={nFilterIsActive || ''}
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option aria-label='None' value=''>All</option>
										<option value='true'>True</option>
										<option value='false'>False</option>
									</Select>
								</FormControl>
							</Grid>

						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' onClick={searchConversion} color='secondary'>
								Search
							</Button>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleFilterClose}>
								Cancel
							</Button>
						</div>
					</div>

				</Fade>
			</Modal>
			<Modal
				open={confirmOpen}
				onClose={handleCloseConfirm}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Confirm</h2>
					<p id='server-modal-description'>{confirmText}</p>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={confirmProcess}>Confirm
					</Button>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={handleCloseConfirm}>Cancel
					</Button>
				</div>
			</Modal>
			<Modal
				open={warningOpen}
				onClose={handleCloseWarning}
				className={classes.modal}
				aria-labelledby="simple-modal-title"
				aria-describedby="simple-modal-description"
			>
				<div className={classes.paper}>
					<h2 id="server-modal-title" >Warning</h2>
					<p id="server-modal-description">{warningText}</p>
					<Button className="whitespace-no-wrap normal-case"
						variant="contained"
						color="secondary"
						onClick={handleCloseWarning}>Close
					</Button>
				</div>
			</Modal>
			<Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={open}
				onClose={handleClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={open}>
					<div className={classes.paper}>
						<div className={classes.fo_circular}>
							{loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
						</div>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title' >HotelConversion</h2>
						</div>
						<div className={classes.formControl} style={{ display: 'grid' }}>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>HotelAtlantisCode</FormHelperText>
									<TextField value={hotelAtlantisCode == null ? '' : hotelAtlantisCode} onChange={onChangeHotelAtlantisCode} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>HotelExternalCode</FormHelperText>
									<TextField value={hotelExternalCode == null ? '' : hotelExternalCode} onChange={onChangeHotelExternanCode} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>HotelOldAtlantisCode</FormHelperText>
									<TextField value={hotelOldAtlantisCode == null ? '' : hotelOldAtlantisCode} onChange={onChangeHotelOldAtlantisCode} />
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '40%' }}>
									<FormHelperText>HotelChain</FormHelperText>
									<Select
										native
										onChange={onSelectHotelChain}
										defaultValue={hotelChainID == null ? '' : hotelChainID}
										name='Code'
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option value=''>...</option>
										{hotelChainList == null ? '' : hotelChainList.map((n, i) =>
											<option key={i} value={n.id}>{n.name}</option>
										)}
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '40%' }}>
									<FormHelperText>HotelName</FormHelperText>
									<TextField value={hotelName == null ? '' : hotelName} onChange={onChangeHotelName} />
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '40%' }}>
									<FormHelperText>MainCity</FormHelperText>
									<Select
										native
										onChange={onChangeMainCity}
										defaultValue={mainCityCode == null ? '' : mainCityCode}
										name='Code'
										inputProps={{
											id: 'age-native-required',
										}}
									>
										<option value=''>...</option>
										{destList == null ? '' : destList.map((n, i) =>
											<option key={i} value={n.code}>{n.name}</option>
										)}
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '40%' }}>
									<FormHelperText>SecondCity</FormHelperText>
									<TextField value={secondCityCode == null ? '' : secondCityCode} onChange={onChangeSecondCity} />
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl}>
									<FormHelperText>AtlantisSupplierCode</FormHelperText>
									<TextField onChange={onChangeAtlantisSupplier} defaultValue={atlantisSupplierCode == null ? '' : atlantisSupplierCode} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '40%' }}>
									<FormHelperText>Priority(1~10)</FormHelperText>
									<TextField
										id='standard-number'
										type='number'
										min='0'
										max='10'
										defaultValue={priority == null ? 0 : Number(priority)}
										onChange={onChangePriority}
										InputProps={{
											inputProps: {
												min: 0,
												max: 10
											}
										}}
									/>
								</FormControl>
							</Grid>

							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between', flexWrap: 'nowrap' }}>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>External Source</FormHelperText>
									<Select
										native
										onChange={onChangeSource}
										defaultValue={source || 0}
										name='Code'
										inputProps={{
											id: 'age-native-required',
										}}
									>
										{/* <option value=''>...</option> */}
										{suppliers == null ? '' : suppliers.map((n, i) =>
											<option key={i} value={i}>{n}</option>
										)}
									</Select>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>discount(1~20%)</FormHelperText>
									<TextField
										id='standard-number'
										type='number'
										min='0'
										max='20'
										defaultValue={discount == null ? 0 : discount}
										onChange={onChangeDiscountValue}
										InputProps={{
											inputProps: {
												min: 0,
												max: 20
											}
										}}
									/>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '30%' }}>
									<FormHelperText>Commission</FormHelperText>
									<TextField
										id='standard-number'
										type='number'
										min='0'
										max='20'
										defaultValue={commission == null ? 0 : commission}
										onChange={onChangeCommission}
										InputProps={{
											inputProps: {
												min: 0,
												max: 20
											}
										}}
									/>
								</FormControl>
							</Grid>
							<Grid container style={{ margin: '10px auto', display: 'flex', justifyContent: 'space-between' }}>
								<FormControl required className={classes.formControl} style={{ width: '25%' }}>
									<FormHelperText>PromoterPhone</FormHelperText>
									<TextField value={promoterPhone == null ? '' : promoterPhone} onChange={onChangePromoterPhone} />
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: '25%' }}>
									<FormHelperText>promoterMame</FormHelperText>
									<TextField value={promoterName == null ? '' : promoterName} onChange={onChangePromoterMame} />
								</FormControl>
								<FormControlLabel
									control={
										<Checkbox
											checked={forceValidation}
											onChange={onChangeForceValidation}
											name='checkedC'
											color='primary'
										/>
									}
									label='ForceValidation'
									className={classes.checkboxform}
									style={{ width: '25%' }}
								/>
								<FormControlLabel
									control={
										<Checkbox
											checked={isActive}
											onChange={onChangeActivation}
											name='checkedC'
											color='primary'
										/>
									}
									label='Active'
									className={classes.checkboxform}
									style={{ width: '15%' }}
								/>
							</Grid>
							<FormHelperText>Transient Commission</FormHelperText>
							<TransientCommission
								transientCommissionList={nTransientCommissionList}
								showMessageBox={handleShowErrorMessage}
								onChangeTransientCommission={handleChangeTransientCommission}
							/>
						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' onClick={handleUpdate} color='secondary'>
								{nButtonText}
							</Button>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleClose}>
								Cancel
							</Button>
						</div>
					</div>
				</Fade>
			</Modal>
			<div>
				{ !isHighTeckUser &&
					<Button
						className='whitespace-no-wrap normal-case'
						variant='contained'
						color='secondary'
						style={{ float: 'right', margin: '15px 5px' }}
						onClick={() => addConversion()}
					>
						<span className='hidden sm:flex'>Add Conversion</span>
						<span className='flex sm:hidden'>Add</span>
					</Button>
				}
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => openSearchModel()}
				>

					<span className='hidden sm:flex'><SearchIcon />Filter</span>
					<span className='flex sm:hidden'><SearchIcon /></span>
				</Button>
			</div>
			<FuseScrollbars className="flex-grow overflow-x-auto">
				<Table stickyHeader className="min-w-xl" aria-labelledby="tableTitle">
					<HotelConversionTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={data.length}
					/>
					<TableBody>
						{_.orderBy(
							data,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className="h-64 cursor-pointer"
									hover
									tabIndex={-1}
									key={n.id}
								>
									<TableCell className="p-4 md:p-16" component="th" scope="row">
										<img alt='' style={{ height: '50px', width: '50px' }} src={n.imageUrl} />
									</TableCell>
									<TableCell className="p-4 md:p-16 truncate" component="th" scope="row" onClick={() => editConversion(i)}>
										{n.hotelName}
									</TableCell>
									<TableCell className="p-4 md:p-16 truncate" component="th" scope="row" onClick={() => editConversion(i)}>
										{n.hotelChainName}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{n.hotelAtlantisCode}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{n.hotelExternalCode}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{n.hotelOldAtlantisCode}
									</TableCell>
									<TableCell className="p-4 md:p-16 truncate" component="th" scope="row" onClick={() => editConversion(i)}>
										{n.mainCityCode}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{n.secondCityCode}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{n.atlantisSupplierCode}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{suppliers[n.source || 0]}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{n.commission}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="center" onClick={() => editConversion(i)}>
										{n.discount == null ? null : n.discount + '%'}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{n.priority}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{n.promoterPhone}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left" onClick={() => editConversion(i)}>
										{n.promoterMame}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left' onClick={() => editConversion(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.forceValidation && 'bg-red',
												n.forceValidation && 'bg-green',
											)}
										/>
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left' onClick={() => editConversion(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.active && 'bg-red',
												n.active && 'bg-green',
											)}
										/>
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => editConversion(i)} tabIndex="0" type="button" title="Edit" disabled={isHighTeckUser}><span className="MuiIconButton-label"><span className="material-icons MuiIcon-root" aria-hidden="true">edit</span></span><span className="MuiTouchRipple-root"></span></button>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component='th' scope='row' align='left'>
										<button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
											onClick={() => deleteCoversion(i)}
											tabIndex='0' type='button' title='Delete' disabled={isHighTeckUser}>
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className="flex-shrink-0 border-t-1"
				component="div"
				count={dealLength}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}

export default withRouter(HotelConversionTable);
