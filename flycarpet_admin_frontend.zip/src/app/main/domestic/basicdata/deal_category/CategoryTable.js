import FuseScrollbars from '@fuse/core/FuseScrollbars';
import _ from '@lodash';
import axios from 'axios';
import Checkbox from '@material-ui/core/Checkbox';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import FuseLoading from '@fuse/core/FuseLoading';
import CategoryTableHead from './CategoryTableHead';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import Backdrop from '@material-ui/core/Backdrop';
import Fade from '@material-ui/core/Fade';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import FormControl from '@material-ui/core/FormControl';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import SearchIcon from '@material-ui/icons/Search';
import MenuItem from '@material-ui/core/MenuItem';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import { useDomesticDeal } from 'app/main/store/hooks'
import { baseURL } from '../../../utils';

function AgencyTable(props) {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			// margin: theme.spacing(1),
			minWidth: 120,
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			minWidth: 200,
		},
		button_group: {
			padding: 30,
		},
		buttons: {
			float: 'right',
			marginRight: '10px'
		},
		checkboxform: {
			marginLeft: '-10px'
		},
		textfield: {
			width: '100%'
		}
	}));

	const {
		fetchDomesticAgencyDealCodes,

		rsLoading,
		rsAgencyCodes,
	} = useDomesticDeal();

	const classes = useStyles();
	const [nDealCategoryCode, setDealCategoryCode] = useState(null);
	const [nName, setName] = useState('');
	const [nActive, setActive] = useState(false);
	const [categoryOrder, setCategoryOrder] = useState(0);

	// const [nFilterName, setFilterName] = useState(null);
	// const [nFilterActive, setFilterActive] = useState(null);

	const [nButtonText, setButtonText] = useState(null);
	const [confirmOpen, setConfirmOpen] = useState(false);
	const [confirmText, setConfirmText] = useState(null);
	const [warningOpen, setWarningOpen] = useState(false);
	const [warningText, setWarningText] = useState(null);

	const [sAgencyCode, setAgencyCode] = useState('');


	const [loading, setLoading] = useState(true);
	const [selected] = useState([]);
	const [dataLength, setDataLength] = useState(0)
	const [dealCategory, setDealCategory] = useState([]);
	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);
	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});

	const [open, setOpen] = React.useState(false);
	const [openFilter, setOpenFilter] = useState(false);
	const addHotelChain = () => {
		setButtonText('Add');
		setOpen(true);
	};
	const deleteHandle = async (index) => {
		setDealCategoryCode(dealCategory[index]['id'])
		setConfirmText("Do you want to drop this DealCategory?");
		setConfirmOpen(true);
	}
	const handleOpen = (index) => {
		setButtonText('Save');
		setDealCategoryCode(dealCategory[index]['id']);
		setName(dealCategory[index]['name']);
		setCategoryOrder(dealCategory[index]['sortOrder']);
		setActive(dealCategory[index]['active']);
		setAgencyCode(dealCategory[index]['agencyCode'] || '')
		setOpen(true);
	};

	const openSearchModel = () => {
		setOpenFilter(true);
	};
	const handleClose = () => {
		initialValue();
		setOpen(false);
	};
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}
	const handleCloseWarning = () => {
		setWarningOpen(false);
	};
	const handleFilterClose = () => {
		setOpenFilter(false);
	};
	function searchHotelList() {
		setPage(0);
		getDealCategoryData(1, rowsPerPage);
		setOpenFilter(false);
	}
	async function editProcess() {
		setLoading(true);
		var post_url;
		if (nButtonText === 'Save') {
			post_url = baseURL + 'domestic/api/dealCategory/' + nDealCategoryCode;
		}
		else {
			post_url = baseURL + 'domestic/api/dealCategory';
		}
		await axios({
			method: 'post',
			url: post_url,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"name": nName,
				"active": nActive,
				"sortOrder": categoryOrder,
				"agencyCode": sAgencyCode
			}
		}).then(response => {
			setLoading(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningText(response.data.error.message);
				setWarningOpen(true);
			}
			else {
				getDealCategoryData(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}
			initialValue();
			setOpen(false);
		}).catch(error => {
			setLoading(false);
			setConfirmOpen(false);
			setWarningOpen(true);
			setWarningText(error.response.data.errors.Name);
		});
	};
	async function confirmProcess() {
		setLoading(true);
		await axios.delete(baseURL + 'domestic/api/dealCategory/' + nDealCategoryCode, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		}).then(response => {
			setLoading(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningText(response.data.error.message);
				setWarningOpen(true);
			} else {
				getDealCategoryData(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
			}
			initialValue();
			setOpen(false);
			setConfirmOpen(false);
		}).catch(error => {
			setLoading(false);
			setConfirmOpen(false);
			setWarningOpen(true);
			setWarningText(error.response.data);
		});

	};
	async function getDealCategoryData(from, to) {
		const response = await axios.get(baseURL + 'domestic/api/dealCategory?' + 'from=' + from + '&to=' + to)
		const data = response.data;
		setDataLength(data.total)
		setDealCategory(data['data'])
		setLoading(false);
	}
	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}

	function onChangeName(event) {
		if (event.target.value === '') {
			setName(null)
		}
		else {
			setName(event.target.value)
		}
	}
	function onChangeCategoryOrder(event) {
		if (event.target.value === '') {
			setCategoryOrder(null)
		}
		else {
			setCategoryOrder(Number(event.target.value))
		}
	}
	function onChangeActive() {
		setActive(!nActive);
	}

	/////////////////////////////////////////////////
	// function onChangeFilterName(event) {
	// 	if (event.target.value == ''){
	// 		setFilterName(null);
	// 	}
	// 	else{
	// 		setFilterName(event.target.value)
	// 	}
	// }
	// function onChangeFilterCommission(event) {
	// 	if(event.target.value==''){
	// 		setFilterCommission(null)
	// 	}
	// 	else{
	// 		setFilterCommission(event.target.value)
	// 	}
	// }
	//////////////////////////////////////////////
	function handleChangePage(event, value) {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage
		getDealCategoryData(from, to);
	}
	function handleChangeRowsPerPage(event) {
		setRowsPerPage(event.target.value);
		setPage(0)
		const temp = Number(event.target.value)
		const from = 1;
		const to = temp
		getDealCategoryData(from, to);
	}
	function initialValue() {
		setDealCategoryCode(null)
		setName('');
		setCategoryOrder(0);
		setActive(false);
		setAgencyCode('');
	}

	const handleChangeProperty = prop => event => {
		let value = '', key = '';
		switch (prop) {
			case 'agencyCode':
				setAgencyCode(event.target.value);
				break;
			default:
		}

	}

	useEffect(() => {
		fetchDomesticAgencyDealCodes();
		getDealCategoryData(1, 10);
	}, [])

	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className="w-full flex flex-col">
			<Modal
				open={warningOpen}
				onClose={handleCloseWarning}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Warning</h2>
					<p id='server-modal-description'>{warningText}</p>
					<Button className='whitespace-no-wrap normal-case'
						variant='contained'
						color='secondary'
						style={{ marginTop: '10px' }}
						onClick={handleCloseWarning}>Close
					</Button>
				</div>
			</Modal>
			<Modal
				open={confirmOpen}
				onClose={handleCloseConfirm}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Confirm</h2>
					<p id='server-modal-description'>{confirmText}</p>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={confirmProcess}>Confirm
					</Button>
					<Button className='whitespace-no-wrap normal-case'
						style={{ margin: '10px 5px' }}
						variant='contained'
						color='secondary'
						onClick={handleCloseConfirm}>Cancel
					</Button>
				</div>
			</Modal>
			{/* <Modal
				aria-labelledby='transition-modal-title'
				aria-describedby='transition-modal-description'
				className={classes.modal}
				open={openFilter}
				onClose={handleFilterClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={openFilter}>
					<div className={classes.paper}>
						<div style={{ textAlign: 'center' }}>
							<h2 id='transition-modal-title' >Filter Setting</h2>
						</div>
						<div style={{ display: 'grid' }}>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Name</FormHelperText>
								<TextField defaultValue={nFilterName} className={classes.textfield} onChange={onChangeFilterName} />
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Commission</FormHelperText>
								<TextField defaultValue={nFilterCommission} className={classes.textfield} onChange={onChangeFilterCommission} />
							</FormControl>
						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant='contained' color='primary' onClick={handleFilterClose}>
								Cancel
							</Button>
							<Button className={classes.buttons} variant='contained' color='secondary' onClick={searchHotelList}>
								Filter
							</Button>
						</div>
					</div>

				</Fade>
			</Modal> */}
			<Modal
				aria-labelledby="transition-modal-title"
				aria-describedby="transition-modal-description"
				className={classes.modal}
				open={open}
				onClose={handleClose}
				closeAfterTransition
				BackdropComponent={Backdrop}
				BackdropProps={{
					timeout: 500,
				}}
			>
				<Fade in={open}>
					<div className={classes.paper}>
						<h2 id="transition-modal-title" style={{ textAlign: 'center' }}>{nButtonText}</h2>
						<div style={{ textAlign: 'center', display: 'grid' }}>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Name</FormHelperText>
								<TextField defaultValue={nName} className={classes.textfield} onChange={onChangeName} />
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Sort Order</FormHelperText>
								<TextField defaultValue={categoryOrder} className={classes.textfield} onChange={onChangeCategoryOrder} />
							</FormControl>
							<FormControl variant='standard' sx={{ m: 1, minWidth: 120 }}>
								<InputLabel id="label_group_select">Agency</InputLabel>
								<Select
									id="agencyCode"
									labelId='agency_code_select'
									value={sAgencyCode}
									onChange={handleChangeProperty('agencyCode')}
									label="AgencyCode"
									inputProps={{ 'aria-label': 'Without label' }}
								>
									<MenuItem value={''}>
										<em>None</em>
									</MenuItem>
									{rsAgencyCodes.map((item, i) => (
										<MenuItem value={item.code} key={item.code}>{item.name}</MenuItem>
									))}
								</Select>
							</FormControl>
							<FormControlLabel
								control={
									<Checkbox
										checked={nActive}
										onChange={onChangeActive}
										name='checkedC'
										color='primary'
									/>
								}
								label='Active'
								className={classes.checkboxform}
							/>
						</div>
						<div className={classes.button_group}>
							<Button className={classes.buttons} variant="contained" color="primary" onClick={handleClose}>
								Cancel
							</Button>
							<Button className={classes.buttons} variant="contained" onClick={editProcess} color="secondary">
								{nButtonText}
							</Button>
						</div>
					</div>
				</Fade>
			</Modal>
			<div>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => addHotelChain()}
				>
					<span className='hidden sm:flex'>Add Category</span>
					<span className='flex sm:hidden'>Add</span>
				</Button>
				{/* <Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 5px' }}
					onClick={() => openSearchModel()}
				>
					<span className='hidden sm:flex'><SearchIcon />Filter</span>
					<span className='flex sm:hidden'><SearchIcon /></span>
				</Button>				 */}
			</div>
			<FuseScrollbars className="flex-grow overflow-x-auto">
				<Table stickyHeader className="min-w-xl" aria-labelledby="tableTitle">
					<CategoryTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={dealCategory.length}
					/>
					<TableBody>
						{_.orderBy(
							dealCategory,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className="h-64 cursor-pointer"
									hover
									tabIndex={-1}
									key={i}
								>
									<TableCell padding="none" className="w-20 md:w-20 text-center z-99">
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.name}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{rsAgencyCodes.find((a) => a.code === n.agencyCode)?.name || ''}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{new Date(n.createTime).toString().substring(0, 21)}
									</TableCell>
									<TableCell className="p-4 md:p-16" component="th" scope="row" onClick={() => handleOpen(i)}>
										{n.sortOrder}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left' onClick={() => handleOpen(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.active && 'bg-red',
												n.active && 'bg-green',
											)}
										/>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => handleOpen(i)} tabIndex="0" type="button" title="Edit"><span className="MuiIconButton-label"><span className="material-icons MuiIcon-root" aria-hidden="true">edit</span></span><span className="MuiTouchRipple-root"></span></button>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component="th" scope="row" align="left">
										<button className="MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit" onClick={() => deleteHandle(i)} tabIndex="0" type="button" title="Delete">
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className="flex-shrink-0 border-t-1"
				component="div"
				count={dataLength}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}

export default withRouter(AgencyTable);
