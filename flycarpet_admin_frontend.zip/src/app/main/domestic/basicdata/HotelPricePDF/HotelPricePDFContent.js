import React, { useEffect, useState, memo, useContext } from 'react';
import FuseLoading from '@fuse/core/FuseLoading';

import {
  Button
} from '@material-ui/core'
import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import SearchIcon from '@material-ui/icons/Search';

import { MultiActionModal } from 'app/main/BasicComponents/customModal';
import HotelPricePDFTable from './HotelPricePDFTable';
import EditorModal from './editorModal';
import FilterModal from './filterModal';

import { useHotelPricePDF, useHotelChain, useDomesticDestinations, useDomesticHotels } from 'app/main/store/hooks'

import { TableStatusContext } from 'app/main/Context/tableStatusContext';
const numberLoadingItems = 100;

function HotelPricePDFContent(props) {

  const {
    loading,
    total,
    allItems,

    createItemStore,
    deleteItemStore,
    saveItemStore,
    createItemAsFormStore,
    saveItemAsFormStore,

    fetchAllItems,
    searchItems,
  } = useHotelPricePDF();

  const {
    total: totalChain,
    allItems: allItemsChain,

    fetchAllItems: fetchAllItemsChain,
  } = useHotelChain();

  const {
    loading: loadingHotel,
    total: totalHotels,
    allItems: allItemsHotels,

    fetchAllItems: fetchAllItemsHotels,
    searchItems: searchItemsHotels,
  } = useDomesticHotels();

  const {
    total: totalDestinations,
    allItems: allDestinations,

    fetchAllItems: fetchAllItemsDestinations,
  } = useDomesticDestinations();

  const { initTableStatus, setStatusTotal, statusRowsPerPage } = useContext(TableStatusContext);

  const [showingRows, setShowingRows] = useState([]);
  const [activeItemId, setActiveItemId] = useState('');
  const [editData, setEditData] = useState(null);

  const [titleActionModal, setTitleActionModal] = useState('WARNING !');
  const [wordActionModal, setWordActionModal] = useState('');
  const [openActionModal, setOpenActionModal] = useState(false);
  const [actionsModal, setActionsModal] = useState([
    { label: 'Close', code: 'close' }
  ])
  const showActionModal = (pOption) => {
    setTitleActionModal(pOption.title);
    setWordActionModal(pOption.word);
    setActionsModal(pOption.actions);
    setOpenActionModal(true);
  };
  const onMessageActionModal = (pType, pMsg) => {
    if (pType === 'selectAction') {
      switch (pMsg.code) {
        case 'agreeDelete':
          deleteItem(activeItemId);
          break;
        case 'close':
          break;
        default:
          console.log(`missed the handle of ${pType}`);
      }
      setOpenActionModal(false);
    } else if (pType === 'closeModal') {
      setOpenActionModal(false);
    }
  }
  const deleteItem = async (pID) => {
    const data = { id: pID };
    const response = await deleteItemStore(data);
    if (response.payload.status !== 'success') {
      const options = {
        ...response.payload.data,
        actions: [
          { label: 'Close', code: 'close' }
        ]
      }
      showActionModal(options);
    }
  }

  const [openEditModal, setOpenEditModal] = useState(false);
  const onMessageEditModal = (pMsg) => {
    if (pMsg.type === 'action') {
      switch (pMsg.action) {
        case 'create': case 'update':
          saveItem(pMsg.extraData);
          break;
        case 'confirmDelete':
          confirmDelete({ id: pMsg.id });
          break;
        case 'close':
          break;
        default:
          console.log(`missed the handle of ${pMsg.type}`)
      }

      setOpenEditModal(false);
    }
  }
  const saveItem = async (pData) => {
    const data = { ...pData };
    if (activeItemId === '') { // create
      const response = await createItemAsFormStore(data);
      if (response.payload.status !== 'success') {
        const options = {
          ...response.payload.data,
          actions: [
            { label: 'Close', code: 'close' }
          ]
        }
        showActionModal(options);
      }
    } else { //update
      const response = await saveItemAsFormStore({ id: activeItemId, data });
      if (response.payload.status !== 'success') {
        const options = {
          ...response.payload.data,
          actions: [
            { label: 'Close', code: 'close' }
          ]
        }
        showActionModal(options);
      }
      setActiveItemId('');
    }
  }

  const [searchOption, setSearchOption] = useState(null);
  const [openFilterModal, setOpenFilterModal] = useState(false);
  const onMessageFilterModal = (pMsg) => {
    if (pMsg.type === 'action') {
      switch (pMsg.action) {
        case 'filter':
          searchItem({ data: pMsg.extraData });
          break;
        case 'close':
          break;
        default:
          console.log(`missed the handle of ${pMsg.type}`)
      }
      setOpenFilterModal(false);
    }
  }
  const searchingItems = async (pOption) => {
    const response = await searchItems(pOption);
    if (response.payload.status !== 'success') {
      const options = {
        ...response.payload.data,
        actions: [
          { label: 'Close', code: 'close' }
        ]
      }
      showActionModal(options);
    }
  }
  const searchItem = (pData) => {
    initTableStatus();
    let option = {
      ...pData,
      from: 1,
      to: numberLoadingItems,
    };
    setSearchOption(option);
    searchingItems(option);
  }

  const addItem = () => {
    setActiveItemId('');
    setEditData(null);
    setOpenEditModal(true);
  }
  const editItem = (pID) => {
    setActiveItemId(pID);
    const activeItem = showingRows.find(el => el.id === pID);
    setEditData(activeItem);
    setOpenEditModal(true);
  }
  const confirmDelete = (pData) => {
    if (pData.id !== '' && pData.id !== null) {
      setActiveItemId(pData.id);
      showActionModal({
        title: 'NOTICE !',
        word: 'Do you want to drop the price PDF ?',
        actions: [
          { label: 'Ok', code: 'agreeDelete' },
          { label: 'Cancel', code: 'close' }
        ]
      });
    }
  }
  const onMessageTable = (pMsg) => {
    if (pMsg.action === 'edit') {
      editItem(pMsg.id);
    } else if (pMsg.action === 'delete') {
      confirmDelete(pMsg);
    } else if (pMsg.action === 'loadMore') {
      if (searchOption === null) {
        fetchingItems({
          from: allItems.length,
          to: allItems.length + Math.max(numberLoadingItems, statusRowsPerPage) - 1,
        });
      } else {
        searchingItems({
          ...searchOption,
          from: searchOption.to,
          to: searchOption.to + Math.max(numberLoadingItems, statusRowsPerPage) - 1,
        })
      }
    } else {
      console.log(`please add the handler for ${pMsg.action} action`);
    }
  }

  useEffect(() => {
    setShowingRows(allItems);
    setStatusTotal(total);
  }, [allItems])


  const fetchingItems = async (pOption) => {
    const response = await fetchAllItems(pOption);
    if (response.payload.status !== 'success') {
      const options = {
        ...response.payload.data,
        actions: [
          { label: 'Close', code: 'close' }
        ]
      }
      showActionModal(options);
    }
  }
  const initialize = async () => {
    await fetchAllItemsChain();
    await fetchAllItemsDestinations();
    await fetchAllItemsHotels();
    await fetchingItems({
      from: 0,
      to: numberLoadingItems
    });
  }
  useEffect(async () => {
    await initialize();
  }, []);

  if (loading || loadingHotel !== 'idle') {
    return <FuseLoading />
  }

  return (
    <div className='w-full flex flex-col'>
      <div>
        <Button
          className="whitespace-no-wrap normal-case"
          variant="contained"
          color="secondary"
          style={{ float: 'right', margin: '15px 5px' }}
          onClick={() => setOpenFilterModal(true)}
        >
          <span className="hidden sm:flex">
            <SearchIcon />
            Filter
          </span>
          <span className="flex sm:hidden">
            <SearchIcon />
          </span>
        </Button>
        <Button
          className='whitespace-no-wrape normal-case'
          variant='contained'
          color='secondary'
          style={{ float: 'right', margin: '15px 5px' }}
          onClick={() => addItem()}
        >
          <span className="hidden sm:flex">
            <AddCircleOutlineIcon />
            New
          </span>
          <span className="flex sm:hidden">
            <AddCircleOutlineIcon />
          </span>
        </Button>
      </div>
      <HotelPricePDFTable
        rowsData={showingRows}
        onMessage={onMessageTable}
      />
      <MultiActionModal
        open={openActionModal}
        title={titleActionModal}
        description={wordActionModal}
        actionList={actionsModal}
        onMessage={onMessageActionModal}
      />
      <EditorModal
        open={openEditModal}
        extraData={{ editData }}
        onMessage={onMessageEditModal}
      />
      <FilterModal
        open={openFilterModal}
        extraData={null}
        onMessage={onMessageFilterModal}
      />
    </div>
  )
}

export default memo(HotelPricePDFContent);