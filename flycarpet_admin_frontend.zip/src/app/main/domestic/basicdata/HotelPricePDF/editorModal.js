import React, { useEffect, useState, memo, useCallback } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  Modal, Backdrop, Button, TextField, TextareaAutosize,
  Grid, FormHelperText, FormControl, FormControlLabel, Select, Checkbox,
} from '@material-ui/core';
import { Autocomplete } from '@material-ui/lab';

import { MultiHotels } from 'app/main/BasicComponents/MultiSelection';
import UploadFile from 'app/main/BasicComponents/UploadFile';

import { useConstantValue } from 'app/main/utils';

import './custom.css';

import { useDomesticDestinations, useHotelChain, useDomesticHotels } from 'app/main/store/hooks';

const EditorModal = (props) => {
  const { open, extraData, onMessage: sendMessage } = props;

  const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: '2px 5px',
      minWidth: 250,
    },
    modal: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      textAlign: "center",
      maxHeight: "100vh",
      overflowY: "auto",
    },
    checkboxform: {
      display: 'block',
    },
  }));
  const classes = useStyles();

  const [openEdit, setOpenEdit] = useState(false);
  const handleCloseModal = () => {
    setOpenEdit(false);
    sendMessage({
      type: 'action',
      action: 'close',
    });
  }

  const [action, setAction] = useState('Add');
  const [disabledSave, setDisabledSave] = useState(true);

  const { allItems: allItemsHotelChain, getNameHotelChainFromItem, getHotelChainFromID } = useHotelChain();
  const [hotelChain, setHotelChain] = useState(null);
  const hotelChainListOrg = {
    options: allItemsHotelChain,
    getOptionLabel: (option) => getNameHotelChainFromItem(option),
  }

  const { allItems: allItemsDestination, getNameFromItem: getNameDestFromItem } = useDomesticDestinations();
  const [destination, setDestination] = useState(null);
  const destCodeListOrg = {
    options: allItemsDestination ?? [],
    getOptionLabel: (option) => getNameDestFromItem(option)
  }

  const formatHotelMultiSelection = (pHotels, pDest = '') => {
    let formatData = [];
    if (pDest === '') {
      formatData = allItemsHotel.map(pHotel => {
        return {
          hotelId: pHotel.id,
          nameTranslationHeb: pHotel.hotelName,
          nameTranslationEng: '',
        }
      });
    } else {
      formatData = allItemsHotel?.filter(pHotel => pHotel.mainCityCode === pDest).map(pHotel => {
        return {
          hotelId: pHotel.id,
          nameTranslationHeb: pHotel.hotelName,
          nameTranslationEng: '',
        }
      });
    }
    return formatData;
  }
  const { loading, allItems: allItemsHotel, getNameFromItem: getNameHotelFromItem } = useDomesticHotels();
  const [chooseHotelList, setChooseHotelList] = useState([]);
  const [chooseIDHotels, setChooseIDHotels] = useState([]);
  const [suggestHotelList, setSuggestHotelList] = useState(formatHotelMultiSelection(allItemsHotel));

  const [showCaption, setShowCaption] = useState(false);
  const [showHref, setShowHref] = useState(false);
  const [fileData, setFileData] = useState(null);
  const [fileName, setFileName] = useState('');
  const receiveMessageFromUploadFile = useCallback((pType, pMsg) => {
    switch (pType) {
      case 'changedFile': case 'changedCaption':
        setFileData({ ...fileData, ...pMsg });
        break;
      default:
    }
  }, [fileData]);

  const initialize = () => {
    initialState();
  }
  const initialState = () => {
    setAction('Add');
    setHotelChain(null);
    setDestination(null);
    setChooseIDHotels([]);
    setFileData(null);
    setFileName('');
  }

  const changeHotelChain = (ev, newValue) => {
    setHotelChain(newValue);
    setDestination(null);
    setChooseIDHotels([]);
  }
  const changeHotelCity = (event, newValue) => {
    setDestination(newValue);
    setChooseIDHotels([]);

    if (newValue) {
      setSuggestHotelList(formatHotelMultiSelection(allItemsHotel, newValue.code))
    } else {
      setSuggestHotelList(formatHotelMultiSelection(allItemsHotel))
    }
  }
  const receiveMessageFromMultiSelectHotels = useCallback((pType, pMsg) => {
    switch (pType) {
      case 'changedCheckedItems':
        setChooseIDHotels(pMsg.items);
        break;
      default:
    }
  }, []);

  const setPickedState = (pData) => {
    setAction('Update');

    setHotelChain(pData.hotelChainId ? getHotelChainFromID(pData.hotelChainId) : null);
    setDestination(null);
    setChooseIDHotels(pData.hotelId ?? []);
    setFileData({Url: pData.pricesUrl ?? '', file: pData.pricesFile ?? null, name: pData.pricesFileName ?? ''});
  }

  useEffect(() => {
    // console.log(fileData)
  }, [fileData])

  const handleSave = () => {
    sendMessage({
      type: 'action',
      action: action === 'Update' ? 'update' : 'create',
      extraData: {
        hotelChainId: hotelChain?.id ?? '',
        hotelId: chooseIDHotels ?? [],
        pricesFile: fileData?.file ?? null,
        pricesUrl: fileData?.Url ?? '',
        pricesFileName: fileData?.name ?? '',
      }
    })
  }

  useEffect(() => {
    if((fileData && (fileData.file !== null && fileData.file !== undefined)) && (hotelChain !== null || chooseIDHotels.length>0)) {
      setDisabledSave(false);
    } else {
      setDisabledSave(true);
    }
  }, [fileData, hotelChain, chooseIDHotels])

  useEffect(() => {
    const data = extraData?.editData ?? null;
    if (data) {
      setPickedState(data);
    } else {
      initialState();
    }
    setOpenEdit(open);
  }, [open, extraData]);

  useEffect(() => {
    initialize();
  }, []);

  return (
    <div className="w-full flex flex-col">
      <Modal
        open={openEdit}
        onClose={handleCloseModal}
        className={classes.modal}
        closeAfterTransition
        aria-labelledby='transition-modal-title'
        aria-describedby='transition-modal-description'
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <div className={classes.paper}>
          <h2 id="server-modal-title" >{`${action} Hotel Price PDF`}</h2>
          <Grid container justify='center' style={{ margin: '20px 5px', display: 'grid' }}>
            {chooseIDHotels.length === 0 && (<FormControl className={classes.formControl}>
              {action !== 'Update' ?
                <Autocomplete
                  {...hotelChainListOrg}
                  id='hotelChain'
                  selectOnFocus
                  value={hotelChain}
                  onChange={changeHotelChain}
                  style={{minWidth: '200px'}}
                  renderInput={(param) => (
                    <TextField {...param} label='Hotel Chain' variant='standard' />
                  )}
                />
                :
                <TextField inputProps={{ readOnly: true }} className={classes.textField} label="Hotel Chain" defaultValue={getNameHotelChainFromItem(hotelChain)} />
              }
            </FormControl>)}
            {hotelChain === null && (<>
              <FormControl className={classes.formControl}>
                <Autocomplete
                  {...destCodeListOrg}
                  id='destCode'
                  selectOnFocus
                  value={destination}
                  style={{minWidth: '200px'}}
                  onChange={changeHotelCity}
                  renderInput={(param) => (
                    <TextField {...param} label='Hotel City' variant='standard' />
                  )}
                />
              </FormControl>
              <FormControl className={classes.formControl}>
                <MultiHotels
                  loading={loading !== 'idle'}
                  title="Hotels"
                  checkedItems={chooseIDHotels}
                  sourceList={suggestHotelList}
                  extraData={{checked: (chooseIDHotels.length > 0 ? 'some' : 'empty')}}
                  onMessage={receiveMessageFromMultiSelectHotels}
                />
              </FormControl>
            </>)}
            <FormControl>
              <UploadFile 
                fileData={fileData}
                extraData={{ showCaption, showHref, singleFile: true }}
                onMessage={receiveMessageFromUploadFile}
              />
            </FormControl>
          </Grid>
          <Grid container justify='space-around' style={{ margin: '10px 5px' }}>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="primary"
              disabled={disabledSave}
              onClick={handleSave}>{action}
            </Button>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="secondary"
              onClick={handleCloseModal}>Close
            </Button>
          </Grid>
        </div>
      </Modal>
    </div>
  );
}

export default memo(EditorModal);