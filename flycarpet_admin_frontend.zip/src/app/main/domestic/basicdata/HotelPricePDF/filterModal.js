import React, { useEffect, useState, memo } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  Modal, Backdrop, Button, TextField, TextareaAutosize,
  Grid, FormHelperText, FormControl, FormControlLabel, Select, Checkbox,
} from '@material-ui/core';
import { Autocomplete } from '@material-ui/lab';

import { MultiHotels } from 'app/main/BasicComponents/MultiSelection';

import { useDomesticDestinations, useHotelChain, useDomesticHotels } from 'app/main/store/hooks';

const FilterModal = (props) => {
  const { open, extraData, onMessage: sendMessage } = props;

  const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: '2px 5px',
      minWidth: 60,
    },
    modal: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      textAlign: "center",
      maxHeight: "100vh",
      overflowY: "auto",
    },
    checkboxform: {
      display: 'block',
    },
  }));
  const classes = useStyles();

  const [openFilter, setOpenFilter] = useState(false);
  const handleCloseModal = () => {
    setOpenFilter(false);
    sendMessage({
      type: 'action',
      action: 'close',
    });
  }

  const { allItems: allItemsHotelChain, getNameHotelChainFromItem, getHotelChainFromID } = useHotelChain();
  const [hotelChain, setHotelChain] = useState(null);
  const hotelChainListOrg = {
    options: allItemsHotelChain,
    getOptionLabel: (option) => getNameHotelChainFromItem(option),
  }

  const { allItems: allItemsDestination, getNameFromItem: getNameDestFromItem } = useDomesticDestinations();
  const [destination, setDestination] = useState(null);
  const destCodeListOrg = {
    options: allItemsDestination ?? [],
    getOptionLabel: (option) => getNameDestFromItem(option)
  }

  const formatHotelMultiSelection = (pHotels, pDest = '') => {
    let formatData = [];
    if (pDest === '') {
      formatData = allItemsHotel.map(pHotel => {
        return {
          hotelId: pHotel.id,
          nameTranslationHeb: pHotel.hotelName,
          nameTranslationEng: '',
        }
      });
    } else {
      formatData = allItemsHotel?.filter(pHotel => pHotel.mainCityCode === pDest).map(pHotel => {
        return {
          hotelId: pHotel.id,
          nameTranslationHeb: pHotel.hotelName,
          nameTranslationEng: '',
        }
      });
    }
    return formatData;
  }
  const { loading, allItems: allItemsHotel, getNameFromItem: getNameHotelFromItem } = useDomesticHotels();
  const [chooseIDHotels, setChooseIDHotels] = useState(null);
  const [suggestHotelList, setSuggestHotelList] = useState(formatHotelMultiSelection(allItemsHotel));

  const [ListHotelOptions, setListHotelOptions] = useState({
    options: allItemsHotel,
    getOptionLabel: (hotel) => getNameHotelFromItem(hotel),
  })
  const changeHotel = (event, newValue) => {
    setChooseIDHotels(newValue);
  }

  const initialize = () => {
    initialState();
  }
  const initialState = () => {
    setHotelChain(null);
    setDestination(null);
    setChooseIDHotels(null);
  }

  const changeHotelChain = (ev, newValue) => {
    setHotelChain(newValue);
    setDestination(null);
    setChooseIDHotels(null);
  }
  const changeHotelCity = (event, newValue) => {
    setDestination(newValue);
    setChooseIDHotels(null);

    // if (newValue) {
    //   setSuggestHotelList(formatHotelMultiSelection(allItemsHotel, newValue.code))
    // } else {
    //   setSuggestHotelList(formatHotelMultiSelection(allItemsHotel))
    // }

    let hotels = !newValue ? allItemsHotel : allItemsHotel?.filter(pHotel => pHotel.mainCityCode === newValue.code);
    setListHotelOptions({
      options: hotels,
      getOptionLabel: (hotel) => getNameHotelFromItem(hotel),
    })
  }

  const receiveMessageFromMultiSelectHotels = (pType, pMsg) => {
    switch (pType) {
      case 'changedCheckedItems':
        setChooseIDHotels(pMsg.items);
        break;
      default:
    }
  };

  const handleFilter = () => {
    const action = 'filter';
    sendMessage({
      type: 'action',
      action,
      extraData: {
        chainId: hotelChain?.id ?? null,
        // hotelId: chooseIDHotels.length !== 0 ? chooseIDHotels : null,
        hotelId: chooseIDHotels?.id ?? null,
      }
    })
  }

  useEffect(() => {
    initialState();
    setOpenFilter(open);
  }, [open]);

  useEffect(() => {
    initialize();
  }, []);

  return (
    <div className="w-full flex flex-col">
      <Modal
        open={openFilter}
        onClose={handleCloseModal}
        className={classes.modal}
        closeAfterTransition
        aria-labelledby='transition-modal-title'
        aria-describedby='transition-modal-description'
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <div className={classes.paper}>
          <h2 id="server-modal-title">Filter Price PDF</h2>
          <Grid container justify='center' style={{ margin: '20px 5px', display: 'grid' }}>
            {/* {chooseIDHotels.length === 0 && (<FormControl className={classes.formControl}> */}
            {!chooseIDHotels && (<FormControl className={classes.formControl}>
              <Autocomplete
                {...hotelChainListOrg}
                id='hotelChain'
                selectOnFocus
                value={hotelChain}
                onChange={changeHotelChain}
                style={{minWidth: '200px'}}
                renderInput={(param) => (
                  <TextField {...param} label='Hotel Chain' variant='standard' />
                )}
              />
            </FormControl>)}
            {hotelChain === null && (<>
              <FormControl className={classes.formControl}>
                <Autocomplete
                  {...destCodeListOrg}
                  id='destCode'
                  selectOnFocus
                  value={destination}
                  style={{minWidth: '200px'}}
                  onChange={changeHotelCity}
                  renderInput={(param) => (
                    <TextField {...param} label='Hotel City' variant='standard' />
                  )}
                />
              </FormControl>
              <FormControl className={classes.formControl}>
                {/* <MultiHotels
                  loading={loading !== 'idle'}
                  title="Hotels"
                  checkedItems={chooseIDHotels}
                  sourceList={suggestHotelList}
                  extraData={{checked: (chooseIDHotels.length > 0 ? 'some' : 'empty')}}
                  onMessage={receiveMessageFromMultiSelectHotels}
                /> */}
                <Autocomplete
                  {...ListHotelOptions}
                  id='destCode'
                  selectOnFocus
                  value={chooseIDHotels}
                  style={{minWidth: '200px'}}
                  onChange={changeHotel}
                  renderInput={(param) => (
                    <TextField {...param} label='Hotel' variant='standard' />
                  )}
                />
              </FormControl>
            </>)}  
          </Grid>
          <Grid container justify='space-around' style={{ margin: '10px 5px' }}>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="primary"
              onClick={handleFilter}>Filter
            </Button>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="secondary"
              onClick={handleCloseModal}>Close
            </Button>
          </Grid>
        </div>
      </Modal>
    </div>
  );
}

export default memo(FilterModal);