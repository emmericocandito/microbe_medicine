import React, { memo, useEffect, useState, useCallback } from 'react'
import ActionTable from 'app/main/BasicComponents/ActionTable'
import { Chip } from '@material-ui/core'
import { Grid, IconButton, TextareaAutosize } from '@material-ui/core';
import OpenInNew from '@material-ui/icons/OpenInNew';
import FileCopyOutlined from '@material-ui/icons/FileCopyOutlined';
import { makeStyles } from '@material-ui/core/styles'

import { useHotelChain, useDomesticHotels } from 'app/main/store/hooks'
import {useFormatingDate} from 'app/main/utils/dateFormat'

function HotelPricePDFTable(props) {
  const { rowsData, onMessage: sendMessage } = props;
  const propColumns = [
    {
      id: 'idx',
      align: 'left',
      disablePadding: false,
      label: 'Index',
      sort: false,
      type: 'text'
    },
    {
      id: 'id',
      align: 'left',
      disablePadding: false,
      label: 'hotel Price Code',
      sort: true,
      type: 'text',
      show: 'hide'
    },
    {
      id: 'hotelChain',
      align: 'left',
      disablePadding: false,
      label: 'Hotel Chain',
      sort: true,
      type: 'text'
    },
    {
      id: 'hotel',
      align: 'left',
      disablePadding: false,
      label: 'Hotel',
      sort: true,
      type: 'component'
    },
    {
      id: 'pricesUrl',
      align: 'left',
      disablePadding: false,
      label: 'Prices Url',
      sort: true,
      type: 'component',
      click: 'disable'
    },
    {
      id: 'updateTime',
      align: 'left',
      disablePadding: false,
      label: 'Update Time',
      sort: true,
      type: 'text',
    },
    {
      id: 'createTime',
      align: 'left',
      disablePadding: false,
      label: 'Create Time',
      sort: true,
      type: 'text'
    },
    {
      id: 'edit',
      align: 'center',
      disablePadding: false,
      label: 'Edit',
      sort: false,
      type: 'button',
    },
    {
      id: 'delete',
      align: 'center',
      disablePadding: false,
      label: 'Delete',
      sort: false,
      type: 'button'
    },
  ]
  const useStyles = makeStyles(theme => ({
    hotelStyle: {
      height: '20px',
      margin: '1px',
      color: 'white',
      fontSize: '12px',
      background: '#4CAF50'
    }
  }))
  const classes = useStyles();

  const { allItems: allItemsChain } = useHotelChain();
  const { allItems: allItemsHotel } = useDomesticHotels();
  const {convertDate} = useFormatingDate();

  const [bodyRows, setBodyRows] = useState([]);

  const getNameHotelChain = useCallback(pChainId => {
    if (!pChainId) return '';
    const currChain = allItemsChain.find(chain => chain.id === pChainId);
    return currChain?.name ?? pChainId;
  }, [allItemsChain]);
  const getNameHotel = useCallback(pHotelId => {
    if (!pHotelId || allItemsHotel.length === 0) return '';
    const currHotel = allItemsHotel.find(hotel => hotel.id === pHotelId);
    return `${currHotel?.destinationName ?? ''} > ${currHotel?.hotelName ?? pHotelId}`;
  }, [allItemsHotel]);
  const getItemsHotel = useCallback(pHotelIds => {
    return pHotelIds?.map((hotelId, j) => (
      <Chip
        key={j}
        className={classes.hotelStyle}
        label={getNameHotel(hotelId)}
        variant="outlined"
      />
    )) ?? null;
  })
  const clipboardLink = (pLink) => async (event) => {
    if (navigator && navigator.clipboard && navigator.clipboard.writeText)
      return await navigator.clipboard.writeText(pLink);
    return Promise.reject('The Clipboard API is not available.');
  }
  const domLinkButtons = (pData) => {
    const link = pData;
    return (
      <Grid style={{ width: '100px' }}>
        <IconButton aria-label="clipbard" onClick={clipboardLink(link)}>
          <FileCopyOutlined />
        </IconButton>
        <IconButton aria-label="blank" target="_blank" href={link}>
          <OpenInNew />
        </IconButton>
      </Grid>
    )
  }

  const initialize = () => {
    setBodyRows([]);
  }

  useEffect(() => {
    initialize();
  }, [])

  useEffect(() => {
    if (!rowsData) return;
    const rows = rowsData.map((row, idx) => {
      const { id, hotelId, hotelChainId, pricesUrl, createTime, updateTime } = row;
      return { idx: idx + 1, id, hotel: getItemsHotel(hotelId), hotelChain: getNameHotelChain(hotelChainId), pricesUrl: domLinkButtons(pricesUrl), createTime: convertDate('dmy',createTime), updateTime: convertDate('dmy',updateTime)}
    })
    setBodyRows(rows);
  }, [rowsData]);

  const onMessage = (pMsg) => {
    if (pMsg.evtType === 'button') {
      switch (pMsg.kind) {
        case 'edit': case 'delete':
          sendMessage({
            action: pMsg.kind,
            id: pMsg.id,
          });
          break;
        default:
      }
    } else if (pMsg.evtType === 'column') {
      sendMessage({
        action: 'edit',
        id: pMsg.id,
      })
    } else if (pMsg.evtType === 'loadMore') {
      sendMessage({
        action: pMsg.evtType,
        extraData: pMsg.extraData
      })
    }
  }

  return (
    <ActionTable
      propColumns={propColumns}
      bodyRows={bodyRows}
      onMessage={onMessage}
    />
  )
}

export default memo(HotelPricePDFTable);