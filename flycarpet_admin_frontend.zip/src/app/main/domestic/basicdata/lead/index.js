import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../../store';
import Click2CallHeader from '../../../packsite/lead/Click2Call/mainHeader';
import Click2CallPanel from '../../../packsite/lead/Click2Call/mainPanel';

function Click2Call() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<Click2CallHeader operation="domestic"/>}
			content={<Click2CallPanel operation="domestic"/>}
			innerScroll
		/>
	);
}

export default withReducer('Click2Call', reducer)(Click2Call);
