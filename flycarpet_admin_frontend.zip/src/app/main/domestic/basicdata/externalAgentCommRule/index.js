import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../../store';
import ExternalAgentCommRuleHeader from './ExternalAgentCommRuletHeader';
import ExternalAgentCommRuleTable from './ExternalAgentCommRuleTable';

function ExternalAgentCommissionRule() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<ExternalAgentCommRuleHeader />}
			content={<ExternalAgentCommRuleTable />}
			innerScroll
		/>
	);
}

export default withReducer('BasicData', reducer)(ExternalAgentCommissionRule);
