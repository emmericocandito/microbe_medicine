import FuseScrollbars from '@fuse/core/FuseScrollbars';
import axios from 'axios';
import _ from '@lodash';
import {
	Checkbox, Table, TableBody, TableCell, TablePagination, TableRow, Modal,
	Backdrop, Fade, TextField, Button, Grid, FormControl, FormHelperText, FormControlLabel,
	CircularProgress, Chip
} from '@material-ui/core';
import clsx from 'clsx';
import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router-dom';
import FuseLoading from '@fuse/core/FuseLoading';
import ExternalAgentCommRuleTableHead from './ExternalAgentCommRuleTableHead';
import { makeStyles } from '@material-ui/core/styles';
import { Autocomplete } from '@material-ui/lab';
import { useAgencyInfo } from 'app/main/store/hooks';
import { baseURL } from '../../../utils';

function ExternalAgentCommRuleTable(props) {
	const useStyles = makeStyles((theme) => ({
		formControl: {
			margin: theme.spacing(0),
			// minWidth: 60,
			width: '100%',
			margin: '0px 5px'
		},
		modal: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
			minWidth: 350
		},
		modal1: {
			display: 'flex',
			alignItems: 'center',
			justifyContent: 'center',
			minWidth: 350
		},
		paper: {
			backgroundColor: theme.palette.background.paper,
			border: '2px solid #000',
			boxShadow: theme.shadows[5],
			padding: theme.spacing(2, 4, 3),
			minWidth: 450
		},
		discountboxform: {
			display: 'grid',
		},
		checkboxform: {
			margin: '0px',
			display: 'block',
		},
		button_group: {
			padding: 30,
			textAlign: 'center',
		},
		buttons: {
			marginLeft: '10px'
		},
		fo_circular: {
			textAlign: 'center',
			position: 'absolute',
			left: '50%',
			transform: 'translatex(-50%)'
		},
		ntextArea: {
			width: '100%',
			border: '1px solid gray',
			minHeight: '35px !important',
			'&:hover': {
				outlineColor: '#000000cf',
				borderRadius: '0'
			},
			'&:active': {
				outlineColor: '#000000cf',
				borderRadius: '0'
			},
			'&:focus': {
				outlineColor: '#000000cf !important',
				borderRadius: '0'
			},
		},
		chipStyle1: {
			height: '20px',
			margin: '1px',
			color: 'white',
			fontSize: '12px',
			background: '#4CAF50'
		},
		rangeItem: {
			margin: '10px'
		}
	}));

	const classes = useStyles();

	const {
		agencyInfoInternal,
		fetchAgencyInfoInternal,
		getAgencyNameInternal,
		getAgencyCodeInternal,
		getAgencyListFromCodeList,
	} = useAgencyInfo();

	const [currentEditingContent, setCurrentEditingContent] = useState(null);
	const [ruleId, setRuleId] = useState(null);

	const [agencyList, setAgencyList] = useState(null);
	const [chainList, setChainList] = useState(null);
	const [hotelList, setHotelList] = useState(null);
	const [effectDateRanges, setEffectDateRanges] = useState(null);
	const [commission, setCommission] = useState(0);
	const [active, setActive] = useState(0);

	const [rangeIndex, setRangeIndex] = useState(-1);
	const [nStartDate, setStartDate] = useState(null);
	const [nEndDate, setEndDate] = useState(null);

	const [totalChainList, setTotalChainList] = useState([]);
	const [totalHotelList, setTotalHotelList] = useState([]);

	const [loading, setLoading] = useState(true);
	const [loadingCircle, setLoadingCircle] = useState(false);
	const [selected] = useState([]);

	const [data, setData] = useState([]);
	const [dataLength, setDataLength] = useState(0)

	const [page, setPage] = useState(0);
	const [rowsPerPage, setRowsPerPage] = useState(10);

	const [nButtonText, setButtonText] = useState(null);
	const [warningOpen, setWarningOpen] = useState(false);
	const [warningText, setWarningText] = useState(null);

	const [confirmText, setConfirmText] = useState(null);
	const [confirmOpen, setConfirmOpen] = useState(false);

	const [order, setOrder] = useState({
		direction: 'asc',
		id: null
	});

	const [open, setOpen] = useState(false);

	useEffect(() => {
		fetchAgencyInfoInternal({ operation: 1 });
		getChainList();
		getHotelList();
		reopen(1, 10);
	}, []);

	useEffect(() => {
		if (currentEditingContent) {
			setAgencyList(getAgencyListFromCodeList(currentEditingContent['odyAgentCodes']));
		}
	}, [agencyInfoInternal]);

	function handleRequestSort(event, property) {
		const id = property;
		let direction = 'desc';
		if (order.id === property && order.direction === 'desc') {
			direction = 'asc';
		}
		setOrder({
			direction,
			id
		});
	}
	function handleChangePage(event, value) {
		setPage(value);
		const from = value * rowsPerPage + 1;
		const to = value * rowsPerPage + rowsPerPage
		reopen(from, to);
	}
	function handleChangeRowsPerPage(event) {
		setPage(0);
		setRowsPerPage(event.target.value);
		reopen(1, event.target.value);
	}
	function getChainListFromCodeList(codeList) {
    	return codeList ? totalChainList.filter((chain) => codeList.includes(chain.id)) : null;
	}
	function getHotelListFromCodeList(codeList) {
    	return codeList ? totalHotelList.filter((hotel) => codeList.includes(hotel.id)) : null;
	}
	function getChainNameFromCode(code) {
		return totalChainList.filter((chain) => code === chain.id)[0]?.name;
	}
	function getHotelNameFromCode(code) {
		return totalHotelList.filter((chain) => code === chain.id)[0]?.hotelName;
	}

	const updateRule = async (i) => {
		setButtonText('Edit');
		setRuleId(data[i].id);
		setCurrentEditingContent(data[i]);

		setAgencyList(getAgencyListFromCodeList(data[i].odyAgentCodes));
		setChainList(getChainListFromCodeList(data[i].chainIds));
		setHotelList(getHotelListFromCodeList(data[i].hotelIds));
		setEffectDateRanges(data[i].inEffectDateRanges);
		setCommission(data[i].commissionPct);
		setActive(data[i].active);

		setRangeIndex(-1);
		setStartDate('');
		setEndDate('');

		setOpen(true);
	}

	const addRule = async () => {
		setButtonText('Add');
		initSelectValues();
		setOpen(true);
	};
	const handleClose = () => {
		initSelectValues();
		setOpen(false);
	};
	const handleCloseConfirm = () => {
		setConfirmOpen(false);
	}
	const handleCloseWarning = () => {
		setWarningOpen(false);
	};
	function initSelectValues() {
		setCurrentEditingContent(null);

		setAgencyList(null);
		setChainList(null);
		setHotelList(null);
		setEffectDateRanges([]);
		setCommission(0);
		setActive(true);

		setRangeIndex(-1);
		setStartDate('');
		setEndDate('');
	};
	const sortHotels = function ([...arr]) {
		arr.sort((a, b) => {
			if (a.hotelName < b.hotelName) return -1;
			if (a.hotelName > b.hotelName) return 1;
			return 0;
		});
		// arr.sort((a, b) => String(a).localeCompare(String(b)));
		return arr;
	}
	async function getHotelList(destination) {
		await axios({
			method: 'post',
			url: baseURL + 'domestic/api/hotelConversion/search?from=1&to=1000',
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"mainCityCode": destination
			}
		}).then(response => {
			const data = response.data['data'];
			setTotalHotelList(sortHotels(data));
		})
			.catch(error => {
				console.log(error)
				return;
			});
	}
	async function getChainList() {
		await axios({
			method: 'get',
			url: baseURL + 'domestic/api/hotelChain?from=1&to=1000'
		}).then(response => {
			const data = response.data['data'];
			setTotalChainList(data);
		})
			.catch(error => {
				console.log(error)
				return;
			});
	}

	async function editProcess(index) {
		setLoadingCircle(true);
		var type
		if (nButtonText === 'Edit') {
			type = `${baseURL}domestic/api/agentCommissionRule/${ruleId}`;
		}
		else {
			type = `${baseURL}domestic/api/agentCommissionRule`;
		}
		await axios({
			method: 'post',
			url: type,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
			data: {
				"odyAgentCodes": agencyList ? agencyList.map((agency) => getAgencyCodeInternal(agency)) : null,
				"chainIds": chainList ? chainList.map((chain) => chain.id) : null,
				"hotelIds": hotelList ? hotelList.map((hotel) => hotel.id) : null,
				"inEffectDateRanges": effectDateRanges,
				"commissionPct": parseInt(commission),
				"active": active,
			}
		}).then(response => {
			setLoadingCircle(false);
			if (response.data.error != null && response.data.error.message != null) {
				setWarningText(response.data.error.message);
				setWarningOpen(true);
			}
			else {
				initSelectValues();
				reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
				setOpen(false)
			}

		})
		.catch(error => {
			setLoadingCircle(false);
			setWarningOpen(true);
			setWarningText(error.response);
			return;
		});
	};
	async function reopen(from, to) {
		await axios({
			method: 'get',
			url: baseURL + 'domestic/api/agentCommissionRule?' + 'from=' + from + '&to=' + to,
			headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
		}).then(response => {
			setLoading(false);
			setData(response.data['data']);
			setDataLength(response.data['total'])
		})
			.catch(error => {
				setLoading(false);
				setWarningOpen(true);
				console.log(error)
				return;
			});
	};
	async function confirmProcess() {
		await axios.delete(baseURL + 'domestic/api/agentCommissionRule/' + ruleId, {
			headers: {
				'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept, Authorization',
				'Authorization': 'Bearer ' + window.localStorage.getItem('jwt_access_token')
			}
		})
		setConfirmOpen(false);
		reopen(page * rowsPerPage + 1, page * rowsPerPage + rowsPerPage);
	}
	const deleteRule = async (i) => {
		setRuleId(data[i]['id'])
		setConfirmText("Do you want to drop this discount?");
		setConfirmOpen(true);
	}

	function handleChangeStartDate(event) {
		if (event.target.value == '') {
			setStartDate(null);
		} else {
			setStartDate(event.target.value);
		}
	}
	function handleChangeEndDate(event) {
		if (event.target.value == '') {
			setEndDate(null);
		} else {
			setEndDate(event.target.value);
		}
	}

	function handleChangeCommission(event) {
		setCommission(event.target.value);
	}
	function handleChangeActive(event) {
		setActive(event.target.checked);
	}

	const handleRangeClick = (_range, index) => {
		const _startDate = _range.fromDate?.substr(0, 10);
		const _endDate = _range.toDate?.substr(0, 10);

		setRangeIndex(index);
		setStartDate(_startDate?_startDate:'');
		setEndDate(_endDate?_endDate:'');
	}
	const handleRangeDelete = (index) => {
		let _dateRanges = [...effectDateRanges];
		_dateRanges.splice(index, 1);
		setEffectDateRanges(_dateRanges);
		if (index === rangeIndex) {
			setRangeIndex(-1);
		}
	}
	const handleClearRange = () => {
		setRangeIndex(-1);
	}
	const handleRangeAdd = (event) => {
		if (!nStartDate || nStartDate === '' || !nEndDate || nEndDate === '') return;

		if (effectDateRanges) {
			for (let i = 0; i < effectDateRanges.length; i++){
				if (effectDateRanges[i].fromDate === nStartDate && effectDateRanges[i].toDate === nEndDate) {
					return;
				}
			}
		}

		const range = {
			fromDate: nStartDate,
			toDate: nEndDate
		}

		let _dateRanges = effectDateRanges ? [...effectDateRanges] : [];
		if (rangeIndex !== -1) {
			_dateRanges[rangeIndex] = range;
		} else {
			_dateRanges.push(range);
		}

		setEffectDateRanges(_dateRanges);
		setRangeIndex(-1);
	}

	if (loading) {
		return <FuseLoading />;
	}
	return (
		<div className='w-full flex flex-col'>
			<Modal
				open={warningOpen}
				onClose={handleCloseWarning}
				className={classes.modal}
				aria-labelledby='simple-modal-title'
				aria-describedby='simple-modal-description'
			>
				<div className={classes.paper} style={{ textAlign: 'center' }}>
					<h2 id='server-modal-title' >Warning</h2>
					<p id='server-modal-description'>{warningText}</p>
					<Button className='whitespace-no-wrap normal-case'
						variant='contained'
						color='secondary'
						onClick={handleCloseWarning}>Close
					</Button>
				</div>
			</Modal>
			<div>
				<div className='spinner-border text-primary' role='status'>
					<span className='sr-only'>Loading...</span>
				</div>
				<Modal
					open={confirmOpen}
					onClose={handleCloseConfirm}
					className={classes.modal}
					aria-labelledby='simple-modal-title'
					aria-describedby='simple-modal-description'
				>
					<div className={classes.paper} style={{ textAlign: 'center' }}>
						<h2 id='server-modal-title' >Confirm</h2>
						<p id='server-modal-description'>{confirmText}</p>
						<Button className='whitespace-no-wrap normal-case'
							style={{ margin: '10px 5px' }}
							variant='contained'
							color='secondary'
							onClick={confirmProcess}>Confirm
						</Button>
						<Button className='whitespace-no-wrap normal-case'
							style={{ margin: '10px 5px' }}
							variant='contained'
							color='secondary'
							onClick={handleCloseConfirm}>Cancel
						</Button>
					</div>
				</Modal>
				<Modal
					aria-labelledby='transition-modal-title'
					aria-describedby='transition-modal-description'
					className={classes.modal1}
					open={open}
					onClose={handleClose}
					closeAfterTransition
					BackdropComponent={Backdrop}
					BackdropProps={{
						timeout: 500,
					}}
				>
					<Fade in={open}>
						<div className={classes.paper} style={{minWidth:'800px'}}>
							<div className={classes.fo_circular}>
								{loadingCircle ? <CircularProgress className='w-xs max-w-full' color='secondary' /> : null}
							</div>
							<div style={{ textAlign: 'center' }}>
								<h2 id='transition-modal-title' >Commission Rule</h2>
							</div>
							<FormControl required className={classes.formControl}>
								<FormHelperText>OdyAgentCodes</FormHelperText>
								<Autocomplete
									multiple
									options={agencyInfoInternal}
									getOptionLabel={ (option) => getAgencyNameInternal(option)}
									id="odyAgentCodes"
									value={agencyList || []}
									onChange={(event, newValue) => {
										setAgencyList(newValue);
									}}
									renderInput={(params) => (
										<TextField {...params} variant="standard" />
									)}
								/>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Hotel Chanins</FormHelperText>
								<Autocomplete
									multiple
									options={totalChainList}
									getOptionLabel={(option) => option.name}
									id="ChainIds"
									value={chainList || []}
									onChange={(event, newValue) => {
										setChainList(newValue);
									}}
									renderInput={(params) => (
										<TextField {...params} variant="standard" />
									)}
								/>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>Hotels</FormHelperText>
								<Autocomplete
									multiple
									options={totalHotelList}
									getOptionLabel={(option) => option.hotelName}
									id="hotelIds"
									value={hotelList || []}
									onChange={(event, newValue) => {
										setHotelList(newValue);
									}}
									renderInput={(params) => (
										<TextField {...params} variant="standard" />
									)}
								/>
							</FormControl>
							<FormControl required className={classes.formControl}>
								<FormHelperText>The rule is valid only if the check-in date range falls within these ranges.</FormHelperText>
								<Grid container style={{ textAlign: 'center', display: 'flex', minHeight: '36px' }} onClick={() => handleClearRange()}>
									{
										effectDateRanges?.map((range, i) => {
											return (
												<Chip key={i} variant='outlined' className={classes.rangeItem}
													label={`${range.fromDate?range.fromDate.substr(0, 10):''} ~ ${range.toDate?range.toDate.substr(0, 10):''}`}
													onClick={(e) => {
														handleRangeClick(range, i);
														e.stopPropagation();
													}}
													onDelete={() => handleRangeDelete(i)}
												/>
											)
										})
									}
								</Grid>
								<hr style={{ marginBottom: '10px' }}></hr>
							</FormControl>
							<Grid container justify='space-around' style={{ margin: '10px' }}>
								<FormControl required className={classes.formControl} style={{ width: 'calc(50% - 100px)' }}>
									<FormHelperText>from Date</FormHelperText>
									<TextField
										id="rangedate-from"
										type="date"
										value={nStartDate}
										onChange={handleChangeStartDate}
										className={classes.textField1}
									/>
								</FormControl>
								<FormControl required className={classes.formControl} style={{ width: 'calc(50% - 100px)' }}>
									<FormHelperText>to Date</FormHelperText>
									<TextField
										id="rangedate-to"
										type="date"
										value={nEndDate}
										onChange={handleChangeEndDate}
										className={classes.textField1}
									/>
								</FormControl>
								<Button className={`${classes.buttons} ${classes.controlButton}`} style={{ marginLeft: '10px', marginTop: '10px', height: '28px' }}
									variant="contained"
									color="secondary"
									onClick={handleRangeAdd}
								>
									{ rangeIndex === -1 ? 'add': 'update'}
								</Button>
							</Grid>
							<Grid container className={classes.formControl} style={{ margin: '10px 5px' }}>
								<FormControl required style={{ width: '30%' }}>
									<FormHelperText>Commission</FormHelperText>
									<TextField defaultValue={commission} className={classes.textfield} onChange={handleChangeCommission} />
								</FormControl>
								<FormControlLabel
									control={
										<Checkbox
											checked={active}
											onChange={handleChangeActive}
											name='isActive'
											color='primary'
										/>
									}
									label='Is Active'
									className={classes.checkboxform}
									style={{margin:"15px 0px 0px 50px"}}
								/>
							</Grid>
							<div className={classes.button_group}>
								<Button className={classes.buttons} variant='contained' onClick={editProcess} color='secondary'>
									{nButtonText}
								</Button>
								<Button className={classes.buttons} variant='contained' color='primary' onClick={handleClose}>
									Cancel
								</Button>

							</div>
						</div>

					</Fade>
				</Modal>
			</div>
			<div>
				<Button
					className='whitespace-no-wrap normal-case'
					variant='contained'
					color='secondary'
					style={{ float: 'right', margin: '15px 15px 15px 5px' }}
					onClick={() => addRule()}
				>
					<span className='hidden sm:flex'>Add Rule</span>
					<span className='flex sm:hidden'>Add</span>
				</Button>
			</div>
			<FuseScrollbars className='flex-grow overflow-x-auto'>
				<Table stickyHeader className='min-w-xl' aria-labelledby='tableTitle'>
					<ExternalAgentCommRuleTableHead
						numSelected={selected.length}
						order={order}
						onRequestSort={handleRequestSort}
						rowCount={data.length}
					/>
					<TableBody>
						{_.orderBy(
							data,
							[
								o => {
									switch (order.id) {
										case 'categories': {
											return o.categories[0];
										}
										default: {
											return o[order.id];
										}
									}
								}
							],
							[order.direction]
						).map((n, i) => {
							return (
								<TableRow
									className='h-64 cursor-pointer'
									hover
									tabIndex={-1}
									key={n.id}
								>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => updateRule(i)}>
										{
											n.odyAgentCodes?.map((code, i) =>
												<Chip key={i} className={classes.chipStyle1} label={code} variant='outlined' />
											)
										}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => updateRule(i)}>
										{
											n.chainIds?.map((code, i) =>
												<Chip key={i} className={classes.chipStyle1} label={getChainNameFromCode(code)} variant='outlined' />
											)
										}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => updateRule(i)}>
										{
											n.hotelIds?.map((code, i) =>
												<Chip key={i} className={classes.chipStyle1} label={getHotelNameFromCode(code)} variant='outlined' />
											)
										}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => updateRule(i)}>
										{
											n.inEffectDateRanges?.map((range, i) =>
												<Chip key={i} className={classes.chipStyle1} label={`${range.fromDate?range.fromDate.substr(0, 10):''} ~ ${range.toDate?range.toDate.substr(0, 10):''}`} variant='outlined' />
											)
										}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' onClick={() => updateRule(i)}>
										{n.commissionPct}
									</TableCell>
									<TableCell className='p-4 md:p-16' component='th' scope='row' align='left' onClick={() => updateRule(i)}>
										<i
											className={clsx(
												'inline-block w-8 h-8 rounded mx-8',
												!n.active && 'bg-red',
												n.active && 'bg-green',
											)}
										/>
									</TableCell>
									<TableCell className="w-40 md:w-64 text-center z-99" component='th' scope='row' align='left'>
										<button className='MuiButtonBase-root MuiIconButton-root MuiIconButton-colorInherit'
											onClick={() => deleteRule(i)}
											tabIndex='0' type='button' title='Edit'>
											<span className='MuiIconButton-label'>
												<span className='material-icons MuiIcon-root' aria-hidden='true'>delete</span>
											</span>
											<span className='MuiTouchRipple-root'></span>
										</button>
									</TableCell>
								</TableRow>
							);
						})}
					</TableBody>
				</Table>
			</FuseScrollbars>
			<TablePagination
				className='flex-shrink-0 border-t-1'
				component='div'
				count={dataLength}
				rowsPerPage={rowsPerPage}
				page={page}
				backIconButtonProps={{
					'aria-label': 'Previous Page'
				}}
				nextIconButtonProps={{
					'aria-label': 'Next Page'
				}}
				onChangePage={handleChangePage}
				onChangeRowsPerPage={handleChangeRowsPerPage}
			/>
		</div>
	);
}
export default withRouter(ExternalAgentCommRuleTable);
