import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Tooltip from '@material-ui/core/Tooltip';
import React from 'react';
import i18next from 'i18next';

const rows = [
    {
        id: 'odyAgentCodes',
        translate: 'odyAgentCodes',
        align: 'center',
        disablePadding: false,
        label: 'Agents',
        sort: true
    },
    {
        id: 'chainIds',
        translate: 'chainIds',
        align: 'left',
        disablePadding: false,
        label: 'Chains',
        sort: true
    },
    {
        id: 'hotelIds',
        translate: 'hotelIds',
        align: 'left',
        disablePadding: false,
        label: 'Hotels',
        sort: true
    },
    {
        id: 'inEffectDateRanges',
        translate: 'inEffectDateRanges',
        align: 'left',
        disablePadding: false,
        label: 'Check-in DateRanges to Apply',
        sort: true
    },
    {
        id: 'CommissionPct',
        translate: 'commissionPct',
        align: 'left',
        disablePadding: false,
        label: 'Commission (%)',
        sort: true
    },
    {
        id: 'active',
        translate: 'active',
        align: 'left',
        disablePadding: false,
        label: 'Active',
        sort: true
    },
    {
        id: 'delete',
        translate: 'delete',
        align: 'left',
        disablePadding: false,
        label: 'Delete',
        sort: true
    }

];

function ExternalAgentCommRuleTableHead(props) {
    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };
    return (
        <TableHead>
            <TableRow className="h-64">
                {rows.map(row => {
                    return (
                        <TableCell
                            className="p-4 md:p-16"
                            key={row.id}
                            align={row.align}
                            padding={row.disablePadding ? 'none' : 'default'}
                            sortDirection={props.order.id === row.id ? props.order.direction : false}
                        >
                            {row.sort && (
                                <Tooltip
                                    title="Sort"
                                    placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                    enterDelay={300}
                                >
                                    <TableSortLabel
                                        active={props.order.id === row.id}
                                        direction={props.order.direction}
                                        onClick={createSortHandler(row.id)}
                                    >
                                        {row.label}
                                    </TableSortLabel>
                                </Tooltip>
                            )}
                        </TableCell>
                    );
                }, this)}
            </TableRow>
        </TableHead>
    );
}

export default ExternalAgentCommRuleTableHead;
