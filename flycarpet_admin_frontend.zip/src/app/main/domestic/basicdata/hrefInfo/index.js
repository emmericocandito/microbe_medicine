import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React, { memo } from 'react';
import reducer from 'app/main/store';
import HrefPageContent from './HrefPageContent';
import HrefPageHeader from './HrefPageHeader';
import { TableStatusContextProvider } from 'app/main/Context/tableStatusContext';

function Href(props) {
  const categoryCode = props.match.params.categoryCode;

  return (
    <TableStatusContextProvider>
      <FusePageCarded
        classes={{
          content: 'flex',
          contentCard: 'overflow-hidden',
          header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
        }}
        header={<HrefPageHeader categoryCode={categoryCode} />}
        content={<HrefPageContent categoryCode={categoryCode} />}
        innerScroll
      />
    </TableStatusContextProvider>
  );
}

export default withReducer('BasicData', reducer)(memo(Href));