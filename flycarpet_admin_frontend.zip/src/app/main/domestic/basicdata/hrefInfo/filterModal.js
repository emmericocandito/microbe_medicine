import React, { useEffect, useState, memo } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  Modal, Backdrop, Button, TextField, TextareaAutosize,
  Grid, FormHelperText, FormControl, FormControlLabel, Select, Checkbox,
} from '@material-ui/core';


const FilterModal = (props) => {
  const { open, extraData, onMessage: sendMessage } = props;

  const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: '2px 5px',
      minWidth: 60,
    },
    modal: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      textAlign: "center",
      maxHeight: "100vh",
      overflowY: "auto",
    },
    checkboxform: {
      display: 'block',
    },
  }));
  const classes = useStyles();

  const [openFilter, setOpenFilter] = useState(false);
  const handleCloseModal = () => {
    setOpenFilter(false);
    sendMessage({
      type: 'action',
      action: 'close',
    });
  }

  const [code, setCode] = useState('');
  const [pageId, setPageId] = useState('');
  const [itemId, setItemId] = useState('');
  const [captionEn, setCaptionEn] = useState('');
  const [captionHe, setCaptionHe] = useState('');
  const [captionRu, setCaptionRu] = useState('');
  const [captionAr, setCaptionAr] = useState('');
  const [description, setDescription] = useState('');
  const [href, setHref] = useState('');
  const [active, setActive] = useState('null');

  const initialize = () => {
    initialState();
  }
  const initialState = () => {
    setCode('');
    setPageId('');
    setItemId('');
    setCaptionEn('');
    setCaptionHe('');
    setCaptionRu('');
    setCaptionAr('');
    setDescription('');
    setHref('');
    setActive('null');
  }

  const handleFilter = () => {
    const action = 'filter';
    sendMessage({
      type: 'action',
      action,
      extraData: {
        code: code || null,
        pageId: pageId || null,
        itemId: itemId || null,
        captionTranslationEng: captionEn || null,
        captionTranslationHeb: captionHe || null,
        captionTranslationRus: captionRu || null,
        captionTranslationArb: captionAr || null,
        description: description || null,
        href: href || null,
        active,
      }
    })
  }

  const handleChangePageId = (ev) => {
    let idPage = ev.target.value.replace(/ /g, '');
    idPage = ev.target.value.replace(/InDmstc/g, '');
    if (!idPage.includes('InDmstc')) idPage = `${idPage}InDmstc`;
    setPageId(idPage);
  }

  const handleChangeItemId = (ev) => {
    const idItem = ev.target.value.replace(/ /g, '');
    setItemId(idItem);
  }

  useEffect(() => {
    initialState();
    setOpenFilter(open);
  }, [open]);

  useEffect(() => {
    initialize();
  }, []);

  return (
    <div className="w-full flex flex-col">
      <Modal
        open={openFilter}
        onClose={handleCloseModal}
        className={classes.modal}
        closeAfterTransition
        aria-labelledby='transition-modal-title'
        aria-describedby='transition-modal-description'
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <div className={classes.paper}>
          <h2 id="server-modal-title" >Airport Name Filter</h2>
          <Grid container justify='space-between' style={{ margin: '20px 5px', display: 'grid' }}>
            <FormControl >
              <TextField className='min-w-256' label='Page ID' defaultValue={pageId} onChange={ev => handleChangePageId(ev)} />
            </FormControl>
            <FormControl >
              <TextField className='min-w-256' label='Item Id' defaultValue={itemId} onChange={ev => handleChangeItemId(ev)} />
            </FormControl>
            <FormControl className='mt-10'>
              <TextField className='min-w-256' label='English' defaultValue={captionEn} onChange={ev => setCaptionEn(ev.target.value)} />
            </FormControl>
            <FormControl className='mt-10'>
              <TextField className='min-w-256' label='Hebrew' defaultValue={captionHe} onChange={ev => setCaptionHe(ev.target.value)} />
            </FormControl>
            <FormControl className='mt-10'>
              <TextField className='min-w-256' label='Russian' defaultValue={captionRu} onChange={ev => setCaptionRu(ev.target.value)} />
            </FormControl>
            <FormControl className='mt-10'>
              <TextField className='min-w-256' label='Arabic' defaultValue={captionAr} onChange={ev => setCaptionAr(ev.target.value)} />
            </FormControl>
            <FormControl className='mt-10'>
              <TextField className='min-w-256' label='description' defaultValue={description} onChange={ev => setDescription(ev.target.value)} />
            </FormControl>
            <FormControl className='mt-10'>
              <TextField className='min-w-256' label='href' defaultValue={href} onChange={ev => setHref(ev.target.value)} />
            </FormControl>
            <FormControl required className={classes.formControl}>
              <FormHelperText>Active State</FormHelperText>
              <Select
                native
                onChange={ev => setActive(ev.target.value)}
                value={active}
                inputProps={{
                  id: 'age-native-required',
                }}
              >
                <option aria-label='None' value={'null'}>All</option>
                <option value={true}>Active</option>
                <option value={false}>Unactive</option>
              </Select>
            </FormControl>
          </Grid>
          <Grid container justify='space-around' style={{ margin: '10px 5px' }}>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="primary"
              onClick={handleFilter}>Filter
            </Button>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="secondary"
              onClick={handleCloseModal}>Close
            </Button>
          </Grid>
        </div>
      </Modal>
    </div>
  );
}

export default memo(FilterModal);