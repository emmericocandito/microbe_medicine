import React, { useEffect, useState, memo, useContext } from 'react';
import FuseLoading from '@fuse/core/FuseLoading';

import {
  Button
} from '@material-ui/core'

import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import SearchIcon from '@material-ui/icons/Search';

import { MultiActionModal } from 'app/main/BasicComponents/customModal';
import EditorModal from './editorModal';
import FilterModal from './filterModal';
import HrefTable from './HrefTable';

import { TableStatusContext } from 'app/main/Context/tableStatusContext';
import { useHref } from 'app/main/store/hooks';
const numberLoadingItems = 10000;

function HrefPageContent(props) {

  const {
    loading,
    total,
    domesticItems: allItems,

    createItemStore,
    deleteItemStore,
    saveItemStore,

    fetchAllItems,
    searchItems,
  } = useHref();

  const { initTableStatus, setStatusTotal, statusRowsPerPage } = useContext(TableStatusContext);

  const [showingRows, setShowingRows] = useState([]);
  const [activeItemId, setActiveItemId] = useState('');
  const [pickedData, setPickedData] = useState(null);

  const [titleActionModal, setTitleActionModal] = useState('WARNING !');
  const [wordActionModal, setWordActionModal] = useState('');
  const [openActionModal, setOpenActionModal] = useState(false);
  const [actionsModal, setActionsModal] = useState([
    { label: 'Close', code: 'close' }
  ])
  const showActionModal = (pOption) => {
    setTitleActionModal(pOption.title);
    setWordActionModal(pOption.word);
    setActionsModal(pOption.actions);
    setOpenActionModal(true);
  };
  const onMessageActionModal = (pType, pMsg) => {
    if (pType === 'selectAction') {
      switch (pMsg.code) {
        case 'agreeDelete':
          deleteItem(activeItemId);
          break;
        case 'close':
          break;
        default:
          console.log(`missed the handle of ${pType}`);
      }
      setOpenActionModal(false);
    } else if (pType === 'closeModal') {
      setOpenActionModal(false);
    }
  }
  const deleteItem = async (pID) => {
    const data = { id: pID };
    const response = await deleteItemStore(data);
    if (response.payload.status !== 'success') {
      const options = {
        ...response.payload.data,
        actions: [
          { label: 'Close', code: 'close' }
        ]
      }
      showActionModal(options);
    }
    setPickedData(null);
  }

  const [openEditModal, setOpenEditModal] = useState(false);
  const onMessageEditModal = (pMsg) => {
    console.log(pMsg)
    if (pMsg.type === 'action') {
      switch (pMsg.action) {
        case 'save': case 'update': case 'create':
          saveItem(pMsg.extraData);
          break;
        case 'confirmDelete':
          confirmDelete({ id: pMsg.id });
          break;
        case 'close':
          break;
        default:
          console.log(`missed the handle of ${pMsg.type}`)
      }

      setOpenEditModal(false);
    }
  }
  const saveItem = async (pData) => {
    const data = pData;
    if (activeItemId === '') { // create
      const response = await createItemStore(data);
      if (response.payload.status !== 'success') {
        const options = {
          ...response.payload.data,
          actions: [
            { label: 'Close', code: 'close' }
          ]
        }
        showActionModal(options);
      }
    } else { //update
      const response = await saveItemStore({ id: activeItemId, data });
      if (response.payload.status !== 'success') {
        const options = {
          ...response.payload.data,
          actions: [
            { label: 'Close', code: 'close' }
          ]
        }
        showActionModal(options);
      }
      setActiveItemId('');
      setPickedData(null);
    }
  }

  const [searchOption, setSearchOption] = useState(null);
  const [openFilterModal, setOpenFilterModal] = useState(false);
  const onMessageFilterModal = async (pMsg) => {
    if (pMsg.type === 'action') {
      switch (pMsg.action) {
        case 'filter':
          await searchItem({ data: pMsg.extraData });
          break;
        case 'close':
          break;
        default:
          console.log(`missed the handle of ${pMsg.type}`)
      }
      setOpenFilterModal(false);
    }
  }
  const searchingItems = async (pOption) => {
    const response = await searchItems(pOption);
    if (response.payload.status !== 'success') {
      const options = {
        ...response.payload.data,
        actions: [
          { label: 'Close', code: 'close' }
        ]
      }
      showActionModal(options);
    }
  }
  const searchItem = async (pData) => {
    initTableStatus();
    let option = {
      ...pData,
      from: 1,
      to: numberLoadingItems,
    };
    setSearchOption(option);
    searchingItems(option);
  }

  const addItem = () => {
    setActiveItemId('');
    setPickedData(null);
    setOpenEditModal(true);
  }
  const editItem = (pData) => {
    if (pData.id !== '' && pData.id !== null) {
      const activeItem = showingRows.find(el => el.code === pData.id);
      setActiveItemId(`${activeItem.pageId}/${activeItem.itemId}`);
      setPickedData(activeItem);
      setOpenEditModal(true);
    }
  }
  const confirmDelete = (pData) => {
    if (pData.id !== '' && pData.id !== null) {
      const activeItem = showingRows.find(el => el.code === pData.id);
      setActiveItemId(`${activeItem.pageId}/${activeItem.itemId}`);
      setPickedData(activeItem);
      showActionModal({
        title: 'NOTICE !',
        word: 'Do you want to drop the product content ?',
        actions: [
          { label: 'Ok', code: 'agreeDelete' },
          { label: 'Cancel', code: 'close' }
        ]
      });
    }
  }
  const onMessageTable = async (pMsg) => {
    if (pMsg.action === 'edit') {
      editItem(pMsg);
    } else if (pMsg.action === 'delete') {
      confirmDelete(pMsg);
    } else if (pMsg.action === 'loadMore') {
      if (searchOption === null) {
        await fetchingItems({
          from: allItems.length,
          to: allItems.length + Math.max(numberLoadingItems, statusRowsPerPage) - 1,
        });
      } else {
        searchingItems({
          ...searchOption,
          from: searchOption.to,
          to: searchOption.to + Math.max(numberLoadingItems, statusRowsPerPage) - 1,
        })
      }
    } else {
      console.log(`please add the handler for ${pMsg.action} action`);
    }
  }

  useEffect(() => {
    setShowingRows(allItems);
    setStatusTotal(allItems.length);
  }, [allItems])

  const fetchingItems = async (pOption) => {
    const response = await fetchAllItems(pOption);
    if (response.payload.status !== 'success') {
      const options = {
        ...response.payload.data,
        actions: [
          { label: 'Close', code: 'close' }
        ]
      }
      showActionModal(options);
    }
  }
  const initialize = async () => {
    await fetchAllItems({ from: 1, to: numberLoadingItems });
  }

  useEffect(() => {
    initialize();
  }, []);

  if (loading) {
    return <FuseLoading />
  }

  return (
    <div className='w-full flex flex-col'>
      <div>
        <Button
          className="whitespace-no-wrap normal-case"
          variant="contained"
          color="secondary"
          style={{ float: 'right', margin: '15px 5px' }}
          onClick={() => setOpenFilterModal(true)}
        >
          <span className="hidden sm:flex">
            <SearchIcon />
            Filter
          </span>
          <span className="flex sm:hidden">
            <SearchIcon />
          </span>
        </Button>
        <Button
          className='whitespace-no-wrape normal-case'
          variant='contained'
          color='secondary'
          style={{ float: 'right', margin: '15px 5px' }}
          onClick={() => addItem()}
        >
          <span className="hidden sm:flex">
            <AddCircleOutlineIcon />
            New
          </span>
          <span className="flex sm:hidden">
            <AddCircleOutlineIcon />
          </span>
        </Button>
      </div>
      <HrefTable
        rowsData={showingRows}
        onMessage={onMessageTable}
      />
      <MultiActionModal
        open={openActionModal}
        title={titleActionModal}
        description={wordActionModal}
        actionList={actionsModal}
        onMessage={onMessageActionModal}
      />
      <EditorModal
        open={openEditModal}
        extraData={{ editData: pickedData }}
        onMessage={onMessageEditModal}
      />
      <FilterModal
        open={openFilterModal}
        onMessage={onMessageFilterModal}
      />
    </div>
  )
}

export default memo(HrefPageContent);