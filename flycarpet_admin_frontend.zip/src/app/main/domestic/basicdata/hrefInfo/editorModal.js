import React, { useEffect, useState, memo } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import {
  Modal, Backdrop, Button, TextField, TextareaAutosize,
  Grid, FormHelperText, FormControl, FormControlLabel, Select, Checkbox,
} from '@material-ui/core';
import { Autocomplete } from '@material-ui/lab';

const EditorModal = (props) => {
  const { open, extraData, onMessage: sendMessage } = props;

  const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: '2px 5px',
      minWidth: 60,
    },
    modal: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    },
    paper: {
      backgroundColor: theme.palette.background.paper,
      border: '2px solid #000',
      boxShadow: theme.shadows[5],
      padding: theme.spacing(2, 4, 3),
      textAlign: "center",
      maxHeight: "100vh",
      overflowY: "auto",
    },
    checkboxform: {
      display: 'block',
    },
  }));
  const classes = useStyles();

  const [kind, setKind] = useState('create');
  const [openEdit, setOpenEdit] = useState(false);
  const handleCloseModal = () => {
    setOpenEdit(false);
    sendMessage({
      type: 'action',
      action: 'close',
    });
  }

  const [code, setCode] = useState('');
  const [pageId, setPageId] = useState('');
  const [itemId, setItemId] = useState('');
  const [captionEn, setCaptionEn] = useState('');
  const [captionHe, setCaptionHe] = useState('');
  const [captionRu, setCaptionRu] = useState('');
  const [captionAr, setCaptionAr] = useState('');
  const [description, setDescription] = useState('');
  const [href, setHref] = useState('');
  const [active, setActive] = useState(false);

  const initialize = () => {
    initialState();
  }
  const initialState = () => {
    setKind('create');
    setCode('');
    setPageId('');
    setItemId('');
    setCaptionEn('');
    setCaptionHe('');
    setCaptionRu('');
    setCaptionAr('');
    setDescription('');
    setHref('');
    setActive(false);
  }

  const handleSave = () => {
    const action = extraData?.editData ? 'update' : 'create';
    sendMessage({
      type: 'action',
      action,
      extraData: {
        code,
        pageId,
        itemId,
        captionTranslationEng: captionEn || null,
        captionTranslationHeb: captionHe || null,
        captionTranslationRus: captionRu || null,
        captionTranslationArb: captionAr || null,
        description,
        href,
        active,
      }
    })
  }

  const handleChangePageId = (ev) => {
    let idPage = ev.target.value.replace(/ /g, '');
    idPage = ev.target.value.replace(/InDmstc/g, '');
    if (!idPage.includes('InDmstc')) idPage = `${idPage}InDmstc`;
    setPageId(idPage);
    setCode(`${idPage}_${itemId}`);
  }

  const handleChangeItemId = (ev) => {
    const idItem = ev.target.value.replace(/ /g, '');
    setItemId(idItem);
    setCode(`${pageId}_${idItem}`);
  }

  useEffect(() => {
    const data = extraData?.editData ?? null;
    if (data) {
      setKind('update');
      setCode(data.code);
      setPageId(data.pageId);
      setItemId(data.itemId);
      setCaptionEn(data.captionTranslationEng);
      setCaptionHe(data.captionTranslationHeb);
      setCaptionRu(data.captionTranslationRus);
      setCaptionAr(data.captionTranslationArb);
      setDescription(data.description);
      setHref(data.href);
      setActive(data.active);
    } else {
      initialState();
    }
    setOpenEdit(open);
  }, [open, extraData]);

  useEffect(() => {
    initialize();
  }, []);

  return (
    <div className="w-full flex flex-col">
      <Modal
        open={openEdit}
        onClose={handleCloseModal}
        className={classes.modal}
        closeAfterTransition
        aria-labelledby='transition-modal-title'
        aria-describedby='transition-modal-description'
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}
      >
        <div className={classes.paper}>
          <h2 id="server-modal-title" >Airport Name Editor</h2>
          <Grid container justify='space-between' style={{ margin: '20px 5px', display: 'grid' }}>
            <FormControl >
              <TextField className='min-w-256' label='Page ID' value={pageId} inputProps={{ readOnly: kind === 'update' }} onChange={ev => handleChangePageId(ev)} />
            </FormControl>
            <FormControl >
              <TextField className='min-w-256' label='Item Id' defaultValue={itemId} inputProps={{ readOnly: kind === 'update' }} onChange={ev => handleChangeItemId(ev)} />
            </FormControl>
            <FormControl className='mt-10'>
              <TextField className='min-w-256' label='English' defaultValue={captionEn} onChange={ev => setCaptionEn(ev.target.value)} />
            </FormControl>
            <FormControl className='mt-10'>
              <TextField className='min-w-256' label='Hebrew' defaultValue={captionHe} onChange={ev => setCaptionHe(ev.target.value)} />
            </FormControl>
            <FormControl className='mt-10'>
              <TextField className='min-w-256' label='Russian' defaultValue={captionRu} onChange={ev => setCaptionRu(ev.target.value)} />
            </FormControl>
            <FormControl className='mt-10'>
              <TextField className='min-w-256' label='Arabic' defaultValue={captionAr} onChange={ev => setCaptionAr(ev.target.value)} />
            </FormControl>
            <FormControl className='mt-10'>
              <TextField className='min-w-256' label='description' defaultValue={description} onChange={ev => setDescription(ev.target.value)} />
            </FormControl>
            <FormControl className='mt-10'>
              <TextField className='min-w-256' label='href' defaultValue={href} onChange={ev => setHref(ev.target.value)} />
            </FormControl>
            <FormControlLabel
              control={
                <Checkbox
                  checked={active}
                  onChange={e => { setActive(e.target.checked) }}
                  name='checkedB'
                  color='primary'
                />
              }
              label='Active'
              className={classes.checkboxform}
            />
          </Grid>
          <Grid container justify='space-around' style={{ margin: '10px 5px' }}>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="primary"
              onClick={handleSave}>SAVE
            </Button>
            <Button className="whitespace-no-wrap normal-case"
              variant="contained"
              color="secondary"
              onClick={handleCloseModal}>Close
            </Button>
          </Grid>
        </div>
      </Modal>
    </div>
  );
}

export default memo(EditorModal);