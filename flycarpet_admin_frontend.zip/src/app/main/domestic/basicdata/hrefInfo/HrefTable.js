import React, { memo, useEffect, useState } from 'react'
import ActionTable from 'app/main/BasicComponents/ActionTable'

function AirportTable(props) {
  const { rowsData, onMessage: sendMessage } = props;
  const propColumns = [
    {
      id: 'idx',
      align: 'left',
      disablePadding: false,
      label: 'Index',
      sort: false,
      type: 'text',
    },
    {
      id: 'id',
      align: 'left',
      disablePadding: false,
      label: 'ID',
      sort: true,
      type: 'text',
      show: 'hide'
    },
    {
      id: 'pageId',
      align: 'left',
      disablePadding: false,
      label: 'Page Id',
      sort: true,
      type: 'text'
    },
    {
      id: 'itemId',
      align: 'left',
      disablePadding: false,
      label: 'Item',
      sort: true,
      type: 'text'
    },
    {
      id: 'captionEn',
      align: 'left',
      disablePadding: false,
      label: 'caption(EN)',
      sort: true,
      type: 'text'
    },
    {
      id: 'captionHe',
      align: 'left',
      disablePadding: false,
      label: 'caption(HEB)',
      sort: true,
      type: 'text'
    },
    {
      id: 'captionRu',
      align: 'left',
      disablePadding: false,
      label: 'caption(RUS)',
      sort: true,
      type: 'text'
    },
    {
      id: 'captionAr',
      align: 'left',
      disablePadding: false,
      label: 'caption(ARB)',
      sort: true,
      type: 'text'
    },
    {
      id: 'active',
      align: 'left',
      disablePadding: false,
      label: 'Active',
      sort: false,
      type: 'boolean'
    },
    {
      id: 'edit',
      align: 'center',
      disablePadding: false,
      label: 'Edit',
      sort: false,
      type: 'button',
    },
    {
      id: 'delete',
      align: 'center',
      disablePadding: false,
      label: 'Delete',
      sort: false,
      type: 'button'
    },
  ]

  const [bodyRows, setBodyRows] = useState([]);

  const initialize = () => {
    setBodyRows([]);
  }

  useEffect(() => {
    initialize();
  }, [])

  useEffect(() => {
    if (!rowsData) return;
    const rows = rowsData.map((row, idx) => {
      const { code, pageId, itemId, captionTranslationEng, captionTranslationHeb, captionTranslationRus, captionTranslationArb, active } = row;
      return { idx: idx + 1, id: code, itemId, pageId, captionEn: captionTranslationEng, captionHe: captionTranslationHeb, captionRu: captionTranslationRus, captionAr: captionTranslationArb, active }
    })
    setBodyRows(rows);
  }, [rowsData]);

  const onMessage = (pMsg) => {
    if (pMsg.evtType === 'button') {
      switch (pMsg.kind) {
        case 'edit': case 'delete':
          sendMessage({
            action: pMsg.kind,
            id: pMsg.id,
          });
          break;
        default:
      }
    } else if (pMsg.evtType === 'column') {
      sendMessage({
        action: 'edit',
        id: pMsg.id,
      })
    } else if (pMsg.evtType === 'loadMore') {
      sendMessage({
        action: pMsg.evtType,
        extraData: pMsg.extraData
      })
    }
  }

  return (
    <ActionTable
      propColumns={propColumns}
      bodyRows={bodyRows}
      onMessage={onMessage}
    />
  )
}

export default memo(AirportTable);