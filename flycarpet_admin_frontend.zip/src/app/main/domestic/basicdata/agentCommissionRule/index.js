import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../../store';
import AgentHeader from './AgentCommRuleHeader';
import AgentTable from './AgentCommRuleTable';

function AgentCommRule() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<AgentHeader operation="domestic"/>}
			content={<AgentTable operation="domestic"/>}
			innerScroll
		/>
	);
}
 
export default withReducer('BasicData', reducer)(AgentCommRule);
