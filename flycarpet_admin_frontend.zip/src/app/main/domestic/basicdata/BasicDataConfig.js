import React from 'react';
import Login from '../../login/Login';
const token = window.localStorage.getItem('jwt_access_token');
const DealType = {
	settings: {
		layout: token == null ? {
			config: {
				navbar: {
					display: false
				},
				toolbar: {
					display: false
				},
				footer: {
					display: false
				},
				leftSidePanel: {
					display: false
				},
				rightSidePanel: {
					display: false
				}
			}
		} : {
			config: {}
		}
	},
	routes: token == null ? [
		{
			path: '/',
			component: Login
		}
	] : [
			{
				path: '/manage_href/:categoryCode?',
				component: React.lazy(() => import('./hrefInfo/index'))
			},
			{
				path: '/domestic/domehotelPricePDF',
				component: React.lazy(() => import('./HotelPricePDF/index')),
			},
			{
				path: '/domestic/domehotelchain',
				component: React.lazy(() => import('./HotelChain/HotelChain'))
			},
			{
				path: '/domestic/domecategory',
				component: React.lazy(() => import('./deal_category/Category'))
			},
			{
				path: '/domestic/domehotelconversion',
				component: React.lazy(() => import('./HotelConversion/index'))
			},
			{
				path: '/domestic/domehotelinfo',
				component: React.lazy(() => import('./HotelInfo/HotelInfo'))
			},
			{
				path: '/domestic/remarkManagement',
				component: React.lazy(() => import('./RemarkManage/index'))
			},
			{
				path: '/domestic/staticPage/domesticFooter',
				component: React.lazy(() => import('../../EditStaticPage/footer/index'))
			},
			{
				path: '/domestic/agentCommRule',
				component: React.lazy(() => import('./agentCommissionRule/index')),
			},
			{
				path: '/domestic/externalAgentCommRule',
				component: React.lazy(() => import('./externalAgentCommRule/index')),
			},
			{
				path: '/domestic/specialRemarkKeyword',
				component: React.lazy(() => import('./specialRemarkKeyword/index')),
			},
			{
				path: '/domestic/conversionCrmToOdyAgent',
				component: React.lazy(() => import('./ConversionCRMOdyAgent')),
			},
			{
				path: '/domestic/dclick2call',
				component: React.lazy(() => import('./lead/index')),
			},
	]
};
export default DealType;
