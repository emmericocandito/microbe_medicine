import React from 'react';
import Login from '../../login/Login';
const token = window.localStorage.getItem('jwt_access_token');
const Deal = {
	settings: {
		layout: token == null ? {
			config: {
				navbar: {
					display: false
				},
				toolbar: {
					display: false
				},
				footer: {
					display: false
				},
				leftSidePanel: {
					display: false
				},
				rightSidePanel: {
					display: false
				}
			}
		} : {
				config: {}
			}
	},
	routes: token == null ? [
		{
			path: '/',
			component: Login
		}
	] :[
		{
			path: '/domestic/dealBuilder',
			component: React.lazy(() => import('./DealInsert/index'))
		},
		{
			path: '/domestic/dealUpdate',
			component: React.lazy(() => import('./DealUpdate/index'))
		},
		{
			path: '/domestic/autoDealbuilder',
			component: React.lazy(() => import('./AutoDeal/index'))
		}
	]
};

export default Deal;
