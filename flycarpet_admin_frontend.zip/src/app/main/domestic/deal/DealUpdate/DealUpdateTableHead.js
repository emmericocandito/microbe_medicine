import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Tooltip from '@material-ui/core/Tooltip';
import React from 'react';

const rows = [

    {
        id: 'id',
        align: 'left',
        disablePadding: false,
        label: 'Deal ID',
        sort: true
    },
    {
        id: 'Hotel',
        align: 'left',
        disablePadding: false,
        label: 'Hotel',
        sort: true
    },
    {
        id: 'hotelSource',
        align: 'left',
        disablePadding: false,
        label: 'HotelSource',
        sort: true
    },
    {
        id: 'hotelName',
        align: 'left',
        disablePadding: false,
        label: 'HotelName',
        sort: true
    },
    {
        id: 'roomCode',
        align: 'left',
        disablePadding: false,
        label: 'RoomCode',
        sort: true
    },
    {
        id: 'basisName',
        align: 'left',
        disablePadding: false,
        label: 'BasisName',
        sort: true
    },
    {
        id: 'basisCode',
        align: 'left',
        disablePadding: false,
        label: 'BasisCode',
        sort: true
    },
    {
        id: 'totalPrice',
        align: 'center',
        disablePadding: false,
        label: 'Price',
        sort: true
    },
    {
        id: 'priceList',
        align: 'left',
        disablePadding: false,
        label: 'PriceList',
        sort: true
    },
    {
        id: 'checkIndate',
        align: 'left',
        disablePadding: false,
        label: 'CheckIn',
        sort: true
    },
    {
        id: 'checkOutdate',
        align: 'left',
        disablePadding: false,
        label: 'CheckOut',
        sort: true
    },
    {
        id: 'priority',
        align: 'left',
        disablePadding: false,
        label: 'Priority',
        sort: true
    },
    {
        id: 'discount',
        align: 'left',
        disablePadding: false,
        label: 'Discount',
        sort: true
    },
    {
        id: 'dealCategory',
        align: 'left',
        disablePadding: false,
        label: 'Category',
        sort: true
    },
    {
        id: 'priceRemark',
        align: 'left',
        disablePadding: false,
        label: 'PriceRemark',
        sort: true
    },
    {
        id: 'start',
        align: 'left',
        disablePadding: false,
        label: 'Start Date',
        sort: true
    },
    {
        id: 'end',
        align: 'left',
        disablePadding: false,
        label: 'End Date',
        sort: true
    },
    {
        id: 'active',
        align: 'center',
        disablePadding: false,
        label: 'Active',
        sort: true
    },
    {
        id: 'immediateDebit',
        align: 'center',
        disablePadding: false,
        label: 'ImmediateDebit',
        sort: true
    },
    {
        id: 'autoUpdatePrice',
        align: 'center',
        disablePadding: false,
        label: 'AutoUpdatePrice',
        sort: true
    },
    {
        id: 'promotion',
        align: 'center',
        disablePadding: false,
        label: 'Promotion',
        sort: true
    },
    {
        id: 'edit',
        align: 'center',
        disablePadding: false,
        label: 'Edit',
        sort: true
    },
    {
        id: 'delete',
        align: 'center',
        disablePadding: false,
        label: 'Delete',
        sort: true
    }

];

function ProductsTableHead(props) {

    const createSortHandler = property => event => {
        props.onRequestSort(event, property);
    };

    return (
        <TableHead>
            <TableRow className="h-64">
                {rows.map(row => {
                    return (
                        <TableCell
                            className="p-4 md:p-16"
                            key={row.id}
                            align={row.align}
                            padding={row.disablePadding ? 'none' : 'default'}
                            sortDirection={props.order.id === row.id ? props.order.direction : false}
                        >
                            {row.sort && (
                                <Tooltip
                                    title="Sort"
                                    placement={row.align === 'right' ? 'bottom-end' : 'bottom-start'}
                                    enterDelay={300}
                                >
                                    <TableSortLabel
                                        active={props.order.id === row.id}
                                        direction={props.order.direction}
                                        onClick={createSortHandler(row.id)}
                                    >
                                        {row.label}
                                    </TableSortLabel>
                                </Tooltip>
                            )}
                        </TableCell>
                    );
                }, this)}
            </TableRow>
        </TableHead>
    );
}

export default ProductsTableHead;
