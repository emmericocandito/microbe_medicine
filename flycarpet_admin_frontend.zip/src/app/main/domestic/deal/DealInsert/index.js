import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../../store';
import DealHeader from './mainlHeader';
import DealTable from './mainPanel';

function DealInsert() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<DealHeader />}
			content={<DealTable />}
			innerScroll
		/>
	);
}

export default withReducer('BasicData', reducer)(DealInsert);
