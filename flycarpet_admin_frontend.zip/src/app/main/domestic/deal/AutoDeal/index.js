import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React from 'react';
import reducer from '../../../store';
import AutoDealBuilderHeader from './AutoDealBuilderHeader';
import AutoDealBuilderTable from './AutoDealBuilderTable';

function AutoDealBuilder() {
	return (
		<FusePageCarded
			classes={{
				content: 'flex',
				contentCard: 'overflow-hidden',
				header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
			}}
			header={<AutoDealBuilderHeader />}
			content={<AutoDealBuilderTable />}
			innerScroll
		/>
	);
}

export default withReducer('BasicData', reducer)(AutoDealBuilder);
