import React, { useEffect, useState, memo, useContext } from 'react';
import FuseLoading from '@fuse/core/FuseLoading';

import {
  Button
} from '@material-ui/core'

import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import SearchIcon from '@material-ui/icons/Search';

import { MultiActionModal } from 'app/main/BasicComponents/customModal';
import EditorModal from './editorModal';
import FilterModal from './filterModal';
import PartnerBookingsTable from './PartnerBookingsTable';

import { usePartner } from 'app/main/store/hooks';

import { TableStatusContext } from 'app/main/Context/tableStatusContext';
const numberLoadingItems = 100;


function PartnerBookingsPageContent(props) {
  const {type} = props;  
  const isAbsoluteCommission = type === 'absolute';

  const {    
    loading,
    total,
    allItems,

    // searchItems,

    // saveCommissionStore,

    // fetchAllItems,

    searchAllBookingListStore,
    totalBooks,
    allBooks,
  } = usePartner();

  const { initTableStatus, setStatusTotal, statusRowsPerPage } = useContext(TableStatusContext);

  const [showingRows, setShowingRows] = useState([]);
  const [activeItemId, setActiveItemId] = useState('');
  const [pickedData, setPickedData] = useState(null);

  const [titleActionModal, setTitleActionModal] = useState('WARNING !');
  const [wordActionModal, setWordActionModal] = useState('');
  const [openActionModal, setOpenActionModal] = useState(false);
  const [actionsModal, setActionsModal] = useState([
    { label: 'Close', code: 'close' }
  ])
  const showActionModal = (pOption) => {
    setTitleActionModal(pOption.title);
    setWordActionModal(pOption.word);
    setActionsModal(pOption.actions);
    setOpenActionModal(true);
  };
  const onMessageActionModal = (pType, pMsg) => {
    if (pType === 'selectAction') {
      switch (pMsg.code) {
        case 'close':
          break;
        default:
          console.log(`missed the handle of ${pType}`);
      }
      setOpenActionModal(false);
    } else if (pType === 'closeModal') {
      setOpenActionModal(false);
    }
  }

  const [openEditModal, setOpenEditModal] = useState(false);
  const onMessageEditModal = (pMsg) => {
    if (pMsg.type === 'action') {
      switch (pMsg.action) {
        case 'close':
          break;
        default:
          console.log(`missed the handle of ${pMsg.type}`)
      }

      setOpenEditModal(false);
    }
  }

  const [searchOption, setSearchOption] = useState({
    "BookingTransId": null,
    "Source": null,
    "HotelName": null,
    "CheckinDate": null,
    "CheckoutDate": null,
    "BookDateFrom": "2023-01-28",
    "BookDateTo": null,
    "PaxName": null,
    "PayerName": null,
    "BookSubmitted": null,
    "CardVerified" : null,
    "BookSucceeded": null,
    "Payed": null,
    "ExpiredCheckoutOnly" : false,
    "ProfitableOnly" : null,
    "Pnr": null,
    "HotelOrderNumber": null
  });
  const [openFilterModal, setOpenFilterModal] = useState(false);
  const onMessageFilterModal = async (pMsg) => {
    if (pMsg.type === 'action') {
      switch (pMsg.action) {
        case 'filter':
          await searchItem({ data: pMsg.extraData });
          break;
        case 'close':
          break;
        default:
          console.log(`missed the handle of ${pMsg.type}`)
      }
      setOpenFilterModal(false);
    }
  }
  const searchingItems = async (pOption) => {
    const response = await searchAllBookingListStore(pOption);
    if (response.payload.status !== 'success') {
      const options = {
        ...response.payload.data,
        actions: [
          { label: 'Close', code: 'close' }
        ]
      }
      showActionModal(options);
    }
  }
  const searchItem = async (pData) => {
    initTableStatus();
    let option = {
      ...pData,
      from: 1,
      to: numberLoadingItems,
    };
    setSearchOption(option);
    searchingItems(option);
  }

  const addItem = () => {
    setActiveItemId('');
    setPickedData(null);
    setOpenEditModal(true);
  }
  const editItem = (pData) => {
    if (pData.id !== '' && pData.id !== null) {
      setActiveItemId(pData.id);
      const activeItem = showingRows.find(el => el.id === pData.id);
      setPickedData(activeItem);
      setOpenEditModal(true);
    }
  }
  const confirmDelete = (pData) => {
    if (pData.id !== '' && pData.id !== null) {
      setActiveItemId(pData.id);
      const activeItem = showingRows.find(el => el.id === pData.id);
      setPickedData(activeItem);
      showActionModal({
        title: 'NOTICE !',
        word: 'Do you want to drop the product content ?',
        actions: [
          { label: 'Ok', code: 'agreeDelete' },
          { label: 'Cancel', code: 'close' }
        ]
      });
    }
  }
  const onMessageTable = async (pMsg) => {
    if (pMsg.action === 'edit') {
      editItem(pMsg);
    } else if (pMsg.action === 'delete') {
      confirmDelete(pMsg);
    } else if (pMsg.action === 'loadMore') {
      if (searchOption === null) {
        searchingItems({
          from: allBooks.length,
          to: allBooks.length + Math.max(numberLoadingItems, statusRowsPerPage) - 1,
        });
      } else {
        searchingItems({
          ...searchOption,
          from: searchOption.to,
          to: searchOption.to + Math.max(numberLoadingItems, statusRowsPerPage) - 1,
        })
      }
    } else {
      console.log(`please add the handler for ${pMsg.action} action`);
    }
  }

  useEffect(() => {
    const fullBooksData = [];
    allBooks.forEach(book => {
      let tmpBook = {...book};
      const partner = allItems.find(item => item.guid === tmpBook.partnerId);
      tmpBook.userName = partner?.fullName ?? '';
      tmpBook.email = partner?.email ?? '';
      fullBooksData.push(tmpBook);
    });
    console.log(fullBooksData, allBooks);
    setShowingRows(fullBooksData);
    setStatusTotal(totalBooks);
  }, [allBooks, allItems])

  const fetchingItems = async (pOption) => {
    // const response = await fetchAllItems(pOption);
    // if (response.payload.status !== 'success') {
    //   const options = {
    //     ...response.payload.data,
    //     actions: [
    //       { label: 'Close', code: 'close' }
    //     ]
    //   }
    //   showActionModal(options);
    // }
  }
  const initialize = async () => {
    await searchItem(searchOption);
    // await fetchAllItems({
    //   from: 1,
    //   to: numberLoadingItems
    // });
    // fetchingItems({
    //   from: 1,
    //   to: numberLoadingItems,
    // });
  }

  useEffect(() => {
    setShowingRows([]);
    setStatusTotal(0);
    initialize();
  }, [type]);

  if (loading) {
    return <FuseLoading />
  }

  return (
    <div className='w-full flex flex-col'>
      <div>
        {/* <Button
          className="whitespace-no-wrap normal-case"
          variant="contained"
          color="secondary"
          style={{ float: 'right', margin: '15px 5px' }}
          onClick={() => setOpenFilterModal(true)}
        >
          <span className="hidden sm:flex">
            <SearchIcon />
            Filter
          </span>
          <span className="flex sm:hidden">
            <SearchIcon />
          </span>
        </Button> */}
        {/* <Button
          className='whitespace-no-wrape normal-case'
          variant='contained'
          color='secondary'
          style={{ float: 'right', margin: '15px 5px' }}
          onClick={() => addItem()}
        >
          <span className="hidden sm:flex">
            <AddCircleOutlineIcon />
            New
          </span>
          <span className="flex sm:hidden">
            <AddCircleOutlineIcon />
          </span>
        </Button> */}
      </div>
      <PartnerBookingsTable
        rowsData={showingRows}
        onMessage={onMessageTable}
      />
      <MultiActionModal
        open={openActionModal}
        title={titleActionModal}
        description={wordActionModal}
        actionList={actionsModal}
        onMessage={onMessageActionModal}
      />
      <EditorModal
        open={openEditModal}
        extraData={{ editData: pickedData, isAbsolute: isAbsoluteCommission}}
        onMessage={onMessageEditModal}
      />
      <FilterModal
        open={openFilterModal}
        onMessage={onMessageFilterModal}
        isAbsolute={isAbsoluteCommission}
      />
    </div>
  )
}

export default memo(PartnerBookingsPageContent);
