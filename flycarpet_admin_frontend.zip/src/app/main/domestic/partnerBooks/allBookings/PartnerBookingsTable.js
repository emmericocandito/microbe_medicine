import React, { memo, useEffect, useState } from 'react'

import { useAgency } from 'app/main/store/hooks'
import ActionTable from 'app/main/BasicComponents/ActionTable'

function PartnerBookingsTable(props) {

  const { getAgencyNameByCode } = useAgency();

  const { rowsData, onMessage: sendMessage } = props;

  const propColumns = [
    {
      id: 'idx',
      align: 'center',
      disablePadding: false,
      label: '',
      sort: false,
      type: 'text',
      children: [
        {
          id: 'idx',
          align: 'left',
          disablePadding: false,
          label: 'Index',
          sort: false,
          type: 'text',
          splite: true,
        },
      ]
    },
    {
      id: 'Partner',
      align: 'center',
      disablePadding: false,
      label: 'Partner',
      sort: false,
      type: 'text',
      splite: true,
      children: [
        {
          id: 'id',
          align: 'left',
          disablePadding: false,
          label: 'code',
          sort: true,
          type: 'text',
          show: 'hide'
        },
        {
          id: 'userName',
          align: 'left',
          disablePadding: false,
          label: 'User Name',
          sort: true,
          type: 'text'
        },
        {
          id: 'email',
          align: 'left',
          disablePadding: false,
          label: 'Email',
          sort: true,
          type: 'text',
          splite: true,
        },
      ]
    },
    {
      id: 'OK',
      align: 'center',
      disablePadding: false,
      label: 'OK',
      sort: false,
      type: 'text',
      splite: true,
      children: [
        {
          id: 'OrdersOk',
          align: 'center',
          disablePadding: false,
          label: 'Orders',
          sort: true,
          type: 'text'
        },
        {
          id: 'PayedOk',
          align: 'center',
          disablePadding: false,
          label: 'Payed',
          sort: true,
          type: 'text'
        },
        {
          id: 'GrossedOk',
          align: 'center',
          disablePadding: false,
          label: 'Grossed',
          sort: true,
          type: 'text'
        },
        {
          id: 'DiscountOk',
          align: 'center',
          disablePadding: false,
          label: 'Discount',
          sort: true,
          type: 'text',
          splite: true,
        },
      ]
    },
    {
      id: 'RQ',
      align: 'center',
      disablePadding: false,
      label: 'RQ',
      sort: false,
      type: 'text',
      splite: true,
      children: [
        {
          id: 'OrdersRQ',
          align: 'center',
          disablePadding: false,
          label: 'Orders',
          sort: true,
          type: 'text'
        },
        {
          id: 'PayedRQ',
          align: 'center',
          disablePadding: false,
          label: 'Payed',
          sort: true,
          type: 'text'
        },
        {
          id: 'GrossedRQ',
          align: 'center',
          disablePadding: false,
          label: 'Grossed',
          sort: true,
          type: 'text'
        },
        {
          id: 'DiscountRQ',
          align: 'center',
          disablePadding: false,
          label: 'Discount',
          sort: true,
          type: 'text',
          splite: true,
        },
      ]
    },
    {
      id: 'CXL',
      align: 'center',
      disablePadding: false,
      label: 'CXL',
      sort: false,
      type: 'text',
      splite: true,
      children: [
        {
          id: 'OrdersCXL',
          align: 'center',
          disablePadding: false,
          label: 'Orders',
          sort: true,
          type: 'text'
        },
        {
          id: 'PayedCXL',
          align: 'center',
          disablePadding: false,
          label: 'Payed',
          sort: true,
          type: 'text'
        },
        {
          id: 'GrossedCXL',
          align: 'center',
          disablePadding: false,
          label: 'Grossed',
          sort: true,
          type: 'text'
        },
        {
          id: 'DiscountCXL',
          align: 'center',
          disablePadding: false,
          label: 'Discount',
          sort: true,
          type: 'text',
          splite: true,
        },
      ]
    },
    {
      id: 'OTHERS',
      align: 'center',
      disablePadding: false,
      label: 'Others',
      sort: false,
      type: 'text',
      splite: true,
      children: [
        {
          id: 'OrdersOTHERS',
          align: 'center',
          disablePadding: false,
          label: 'Orders',
          sort: true,
          type: 'text'
        },
        {
          id: 'PayedOTHERS',
          align: 'center',
          disablePadding: false,
          label: 'Payed',
          sort: true,
          type: 'text'
        },
        {
          id: 'GrossedOTHERS',
          align: 'center',
          disablePadding: false,
          label: 'Grossed',
          sort: true,
          type: 'text'
        },
        {
          id: 'DiscountOTHERS',
          align: 'center',
          disablePadding: false,
          label: 'Discount',
          sort: true,
          type: 'text',
          splite: true,
        },
      ]
    },
    // {
    //   id: 'active',
    //   align: 'left',
    //   disablePadding: false,
    //   label: 'Active',
    //   sort: false,
    //   type: 'boolean'
    // },
    // {
    //   id: 'edit',
    //   align: 'center',
    //   disablePadding: false,
    //   label: 'Edit',
    //   sort: false,
    //   type: 'button',
    // },
    // {
    //   id: 'delete',
    //   align: 'center',
    //   disablePadding: false,
    //   label: 'Delete',
    //   sort: false,
    //   type: 'button'
    // },
  ]

  const [bodyRows, setBodyRows] = useState([]);

  useEffect(() => {
    if (!rowsData  || rowsData.length===0) return;
    // const rows = rowsData.map((row, idx) => {
    //   const { partnerId, userName, email, payedAmount, originalAmount,  equivalentDiscount, confirmedPnrStatus } = row;
    //   const hotelStatus = confirmedPnrStatus?.hotelStatus || 'Others';
    //   const commissionPct = extProps?.partnerSpecificProps?.commissionPct ?? '';
    //   return {
    //     idx: idx + 1, id: partnerId, userName, email, commissionPct, active: enabled,
    //   }
    // })
    const rows = rowsData.reduce((accumulator, row) => {
      const { partnerId, userName, email, payedAmount, originalAmount,  equivalentDiscount, confirmedPnrStatus } = row;
      const status = confirmedPnrStatus?.hotelStatus?.toUpperCase() || 'OTHERS';
      const partner = accumulator?.find(el => el.id === partnerId);
      if(partner){
        if(partner[`Orders${status}`]) {
          partner[`Orders${status}`] += 1;
        } else {
          partner[`Orders${status}`] = 1;
        }
        if(partner[`Payed${status}`]) {
          partner[`Payed${status}`] += payedAmount;
        } else {
          partner[`Payed${status}`] = payedAmount;
        }
        if(partner[`Grossed${status}`]) {
          partner[`Grossed${status}`] += originalAmount;
        } else {
          partner[`Grossed${status}`] = originalAmount;
        }
        if(partner[`Discount${status}`]) {
          partner[`Discount${status}`] += equivalentDiscount;
        } else {
          partner[`Discount${status}`] = equivalentDiscount;
        }
      } else {
        let newPartner = {
          idx: (accumulator?.length || 0) + 1,
          id : partnerId,
          userName,
          email,
        };
        newPartner[`Orders${status}`] = 1;
        newPartner[`Payed${status}`] = payedAmount;
        newPartner[`Grossed${status}`] = originalAmount;
        newPartner[`Discount${status}`] = equivalentDiscount;
        accumulator.push(newPartner);
      }      
      return accumulator;
    }, []);
    console.log(rows);
    setBodyRows(rows);
  }, [rowsData]);

  const onMessage = (pMsg) => {
    if (pMsg.evtType === 'button') {
      switch (pMsg.kind) {
        case 'edit': case 'delete':
          sendMessage({
            action: pMsg.kind,
            type: pMsg.evtType,
            id: pMsg.id,
          });
          break;
        default:
      }
    } else if (pMsg.evtType === 'column') {
      // sendMessage({
      //   action: 'edit',
      //   type: pMsg.evtType,
      //   id: pMsg.id,
      // })
    }
  }

  return (
    <ActionTable
      propColumns={propColumns}
      bodyRows={bodyRows}
      onMessage={onMessage}
    />
  )
}

export default memo(PartnerBookingsTable);