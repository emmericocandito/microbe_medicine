import FusePageCarded from '@fuse/core/FusePageCarded';
import withReducer from 'app/store/withReducer';
import React, { memo } from 'react';
import reducer from 'app/main/store';
import PartnerBookingsPageContent from './PartnerBookingsPageContent';
import PartnerBookingsPageHeader from './PartnerBookingsPageHeader';
import { TableStatusContextProvider } from 'app/main/Context/tableStatusContext';

function PartnerBookings(props) {
  const {type} = props.match.params;
  return (
    <TableStatusContextProvider>
      <FusePageCarded
        classes={{
          content: 'flex',
          contentCard: 'overflow-hidden',
          header: 'min-h-72 h-72 sm:h-72 sm:min-h-72'
        }}
        header={<PartnerBookingsPageHeader type={type} />}
        content={<PartnerBookingsPageContent type={type} />}
        innerScroll
      />
    </TableStatusContextProvider>
  );
}

export default withReducer('BasicData', reducer)(memo(PartnerBookings));