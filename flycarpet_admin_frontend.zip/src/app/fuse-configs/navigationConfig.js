import i18next from 'i18next';
import jwt from 'jwt-decode';
import ar from './navigation-i18n/ar';
import en from './navigation-i18n/en';
import tr from './navigation-i18n/tr';


i18next.addResourceBundle('en', 'navigation', en);
i18next.addResourceBundle('tr', 'navigation', tr);
i18next.addResourceBundle('ar', 'navigation', ar);
var token = window.localStorage.getItem('jwt_access_token');
var userRole = (token === null ? '' : jwt(token).role);
var userName = (token === null ? '' : jwt(token).name);

var navigationConfig = userRole === 'agency' ? [
	{
		id: 'applications',
		title: 'Applications',
		translate: 'APPLICATIONS',
		type: 'group',
		icon: 'apps',
		children: [
			{
				id: 'dashboards',
				title: 'Home',
				translate: 'DASHBOARDS',
				type: 'item',
				icon: 'dashboard',
				url: '/dashboard'
			},
			{
				id: 'agencyContent',
				title: 'AgencyContent',
				translate: 'Agency_Content',
				type: 'item',
				icon: 'image',
				url: '/content_agency',
			},
			{
				id: 'imagebuilder',
				title: 'Image Builder',
				translate: 'Image_Builder',
				type: 'item',
				icon: 'satellite',
				url: '/content_landing',
			},
			{
				id: 'pack-footer',
				title: 'Footer Pages Edit',
				translate: 'FOOTER_PAGES_EDIT',
				type: 'item',
				icon: 'low_priority',
				url: '/staticPage/footer'
			},
			// {
			// 	id: 'discount_builder',
			// 	title: 'Discount builder',
			// 	translate: 'DISCOUNT_BUILDER',
			// 	type: 'item',
			// 	icon: 'monetization_on',
			// 	url: '/discount_builder'
			// },
			// {
			// 	id: 'deal_builder',
			// 	title: 'Deal Builder',
			// 	translate: 'DEAL_BUILDER',
			// 	type: 'collapse',
			// 	icon: 'local_offer',
			// 	children: [
			// 		{
			// 			id: 'Insert',
			// 			title: 'Insert',
			// 			translate: 'INSERT',
			// 			type: 'item',
			// 			icon: 'insert_chart',
			// 			url: '/deal_builder',
			// 		},
			// 		{
			// 			id: 'Update',
			// 			title: 'Update',
			// 			translate: 'UPDATE',
			// 			type: 'item',
			// 			icon: 'update',
			// 			url: '/deal_Update',
			// 		},

			// 	]
			// },
		]
	}
] : userRole === 'user' ? [
	{
		id: 'applications',
		title: 'Applications',
		translate: 'APPLICATIONS',
		type: 'group',
		icon: 'apps',
		children: [
			{
				id: 'dashboards',
				title: 'Home',
				translate: 'DASHBOARDS',
				type: 'item',
				icon: 'dashboard',
				url: '/dashboard'
			},
			{
				id: 'contents',
				translate: 'Contents_Management',
				title: 'Contents Management',
				type: 'collapse',
				icon: 'snippet_folder',
				children: [
					{
						id: 'imagebuilder',
						title: 'Image Builder',
						translate: 'Image_Builder',
						type: 'item',
						icon: 'satellite',
						url: '/content_landing',
					},
					{
						id: 'hotelImage',
						title: 'hotelImage',
						translate: 'HOTEL_IMAGE',
						type: 'item',
						icon: 'image',
						url: '/content_hotel',
					},
					{
						id: 'agencyContent',
						title: 'Agency Content',
						translate: 'Agency_Content',
						type: 'item',
						icon: 'image',
						url: '/content_agency',
					},
					// {
					// 	id: 'hrefContent',
					// 	title: 'HrefContent',
					// 	translate: 'Href_Content',
					// 	type: 'item',
					// 	icon: 'image',
					// 	url: '/content_href',
					// },
				]
			},
			{
				id: 'basicdata',
				title: 'basicdata',
				translate: 'BasicData',
				type: 'collapse',
				icon: 'category',
				children: [
					{
						id: 'dealType',
						title: 'dealType',
						translate: 'DealType',
						type: 'item',
						icon: 'api',
						url: '/deal_type',
					},
					{
						id: 'category',
						title: 'Category',
						translate: 'CATEGORY',
						type: 'item',
						icon: 'api',
						url: '/category',
					},
					{
						id: 'agency',
						title: 'agency',
						translate: 'agency',
						type: 'item',
						icon: 'api',
						url: '/agency'
					},

				]
			},
			{
				id: 'discount_builder_user',
				title: 'Discount builder',
				translate: 'DISCOUNT_BUILDER',
				type: 'item',
				icon: 'monetization_on',
				url: '/discount_builder'
			},
			{
				id: 'deal_builder',
				title: 'Deal Builder',
				translate: 'DEAL_BUILDER',
				type: 'collapse',
				icon: 'local_offer',
				children: [
					{
						id: 'Insert',
						title: 'Insert',
						translate: 'INSERT',
						type: 'item',
						icon: 'insert_chart',
						url: '/deal_builder',
					},
					{
						id: 'Update',
						title: 'Update',
						translate: 'UPDATE',
						type: 'item',
						icon: 'update',
						url: '/deal_Update',
					},
					{
						id: 'lastTimeDeal',
						title: 'Auto Deal Builder',
						translate: 'Auto Deal Builder',
						type: 'item',
						icon: 'update',
						url: '/lastTimeDeal',
					},
				]
			},
			{
				id: 'template_builder',
				title: 'Template Builder',
				translate: 'TAMP_BUILDER',
				type: 'collapse',
				icon: 'local_offer',
				children: [
					{
						id: 'Email',
						title: 'Email',
						translate: 'EMAIL',
						type: 'item',
						icon: 'insert_chart',
						url: '/sms_builder',
					},
					{
						id: 'Update',
						title: 'Update',
						translate: 'UPDATE',
						type: 'item',
						icon: 'update',
						url: '/email_Update',
					},

				]
			},
			{
				id: 'analysis',
				title: 'Analysis',
				translate: 'ANALYSIS',
				type: 'collapse',
				icon: 'analytics',
				children: [
					{
						id: 'bookingInfoAll',
						title: 'report',
						translate: 'BookingInfoAll',
						type: 'item',
						icon: 'receipt_long',
						url: '/bookingInfoAll',
					},
					{
						id: 'unpaidcustomer',
						title: 'unpaidcustomer',
						translate: 'U_Customer',
						type: 'item',
						icon: 'sms',
						url: '/unpaidcustomer',
					},
					{
						id: 'unpaidphone',
						title: 'unpaidphone',
						translate: 'U_Phone',
						type: 'item',
						icon: 'email',
						url: '/unpaidphone',
					},
					{
						id: 'report',
						title: 'report',
						translate: 'report',
						type: 'item',
						icon: 'receipt_long',
						url: '/report',
					},

				]
			},
			{
				id: 'translation_management',
				translate: 'TRANSLATION_MANAGEMENT',
				title: 'TRANSLATION MANAGEMENT',
				type: 'collapse',
				icon: 'translate',
				children: [
					{
						id: 'subject',
						title: 'SUBJECT',
						translate: 'SUBJECT',
						type: 'item',
						icon: 'subject',
						url: '/subject'
					},
					{
						id: 'hotel_manager',
						title: 'Hotel Manager',
						translate: 'HOTEL_MANAGER',
						type: 'item',
						icon: 'emoji_transportation',
						url: '/hotel'
					},
					{
						id: 'roomclass',
						title: 'RoomClass',
						type: 'item',
						translate: 'ROOM_CLASS',
						icon: 'hotel',
						url: '/roomclass'
					},
					{
						id: 'roomtype',
						title: 'RoomType',
						type: 'item',
						translate: 'ROOM_TYPE',
						icon: 'escalator_warning',
						url: '/roomtype'
					},
				]
			},
			{
				id: 'domestic',
				translate: 'domestic',
				title: 'domestic',
				type: 'collapse',
				icon: 'dashboard',
				children: [
					{
						id: 'discount_builder_domestic',
						title: 'Discount builder',
						translate: 'DISCOUNT_BUILDER',
						type: 'item',
						icon: 'monetization_on',
						url: '/domestic/discountBuilder'
					},
					{
						id: 'deal_builder',
						title: 'Deal Builder',
						translate: 'DEAL_BUILDER',
						type: 'collapse',
						icon: 'local_offer',
						children: [
							{
								id: 'Insert',
								title: 'Insert',
								translate: 'INSERT',
								type: 'item',
								icon: 'insert_chart',
								url: '/domestic/dealBuilder',
							},
							{
								id: 'Update',
								title: 'Update',
								translate: 'UPDATE',
								type: 'item',
								icon: 'update',
								url: '/domestic/dealUpdate',
							},

						]
					},
					{
						id: 'basicdata_domestic',
						title: 'basicdata',
						translate: 'BasicData',
						type: 'collapse',
						icon: 'category',
						children: [
							{
								id: 'dealCategory',
								title: 'DealCategory',
								translate: 'DealCatergory',
								type: 'item',
								icon: 'api',
								url: '/domestic/domecategory',
							},
							{
								id: 'hotelchian',
								title: 'HotelChain',
								translate: 'HotelChain',
								type: 'item',
								icon: 'api',
								url: '/domestic/domehotelchain'
							},
							{
								id: 'hotelCoversion',
								title: 'HotelConversion',
								translate: 'HotelConversion',
								type: 'item',
								icon: 'api',
								url: '/domestic/domehotelconversion'
							},
							{
								id: 'hotelInfo',
								title: 'HotelConversion',
								translate: 'Hotel_Info',
								type: 'item',
								icon: 'api',
								url: '/domestic/domehotelinfo'
							},

						]
					},

				]
			},
			{
				id: 'app',
				translate: 'APP',
				title: 'App Lock Time',
				type: 'collapse',
				icon: 'event_available',
				children: [
					{
						id: 'applocktime_builder',
						title: 'App Lock Time Builder',
						translate: 'APPLOCKTIME_BUILDER',
						type: 'item',
						icon: 'add_alarm',
						url: "/app_lock_time_builder"
					},
					{
						id: 'appdealcategory_builder',
						title: 'App Deal Category Builder',
						translate: 'APPDEALCATEGORY_BUILDER',
						type: 'item',
						icon: 'category',
						url: '/app_deal_categories'
					},
					{
						id: 'manualupdatingappdeal',
						title: 'Manual Updating App Deal',
						translate: 'MANUALUPDATE_APPDEAL',
						type: 'item',
						icon: 'update',
						url: '/manual_update_app_deal'
					},
					{
						id: 'appbannerimage_builder',
						title: 'App Banner Image Builder',
						translate: 'APPBANNERIMAGE_BUILDER',
						type: 'item',
						icon: 'wallpaper',
						url: '/app_banner_image'
					}
				]
			}
		]
	}
] : [
	{
		id: 'applications',
		title: 'Applications',
		translate: 'APPLICATIONS',
		type: 'group',
		icon: 'apps',
		children: [
			{
				id: 'dashboards',
				title: 'Home',
				translate: 'DASHBOARDS',
				type: 'item',
				icon: 'dashboard',
				url: '/dashboard'
			},
			{
				id: 'common',
				title: 'Common',
				translate: 'COMMON',
				type: 'collapse',
				icon: 'dashboard',
				children: [
					{
						id: 'user_manager',
						title: 'User Manager',
						translate: 'USER_MANAGER',
						type: 'item',
						icon: 'person',
						url: '/user_management'
					},
					{
						id: 'partner_manager',
						title: 'Partner Manager',
						translate: 'PARTNER_MANAGER',
						type: 'collapse',
						icon: 'group',
						children: [
							{
								id: 'partner_commission',
								title: 'Partner Commission',
								translate: 'Partner_Commission',
								type: 'item',
								icon: 'monetization_on',
								url: '/partner_commission'
							},
						]
					},
					{
						id: 'mailinglist',
						title: 'Mailing List Management',
						translate: 'MAILING_LIST',
						type: 'item',
						icon: 'person',
						url: '/mailing_list'
					},
					{
						id: 'agency',
						title: 'agency',
						translate: 'agency',
						type: 'item',
						icon: 'confirmation_number',
						url: '/agency'
					},
					{
						id: 'googleaudience',
						title: 'googleaudience',
						translate: 'GoogleAudience',
						type: 'item',
						icon: 'person',
						url: '/google_audience'
					},
					{
						id: 'agencyContent',
						title: 'AgencyContent',
						translate: 'Agency_Content',
						type: 'item',
						icon: 'image',
						url: '/content_agency',
					},
					{
						id: 'imagebuilder',
						title: 'Image Builder',
						translate: 'Image_Builder',
						type: 'item',
						icon: 'satellite',
						url: '/content_landing',
					},
					{
						id: 'message',
						title: 'MessageEdit',
						translate: 'MESSAGE_EDIT',
						type: 'item',
						icon: 'sms',
						url: '/staticPage/message'
					},
					{
						id: 'maintenancemessage',
						title: 'Maintenance Message',
						translate: 'MAINENANCE_MESSAGE',
						type: 'item',
						icon: 'sms',
						url: '/maintenance_message_management'
					},
					{
						id: '404redirection',
						title: 'EditRedirection',
						translate: 'EDIT_REDIRECTION',
						type: 'item',
						icon: 'near_me_disabled',
						url: '/staticPage/redirection404'
					},
					{
						id: 'coupon',
						title: 'Coupon',
						translate: 'Coupon',
						type: 'collapse',
						icon: 'dashboard',
						children: [
							{
								id: 'coupon_list',
								title: 'Coupon Manager',
								translate: 'Coupon Management',
								type: 'item',
								icon: 'local_offer',
								url: '/coupon_management'
							}
						]
					},
				]
			},
			{
				id: 'packsite',
				title: 'PackSite',
				translate: 'PACKSITE',
				type: 'collapse',
				icon: 'dashboard',
				children: [
					{
						id: 'contents_packsite',
						translate: 'Contents_Management',
						title: 'Contents',
						type: 'collapse',
						icon: 'snippet_folder',
						children: [
							{
								id: 'hotelImage',
								title: 'HotelImage',
								translate: 'HOTEL_IMAGE',
								type: 'item',
								icon: 'image',
								url: '/content_hotel',
							},
							{
								id: 'productContent',
								title: 'ProductContent',
								translate: 'Product_Content',
								type: 'item',
								icon: 'image',
								url: '/Product_Content',
							},
							{
								id: 'contentBanner',
								translate: 'Banner_Content',
								title: 'Banner Content',
								type: 'collapse',
								icon: 'snippet_folder',
								children: [
									{
										id: 'destinationBanner',
										title: 'Destination Banner',
										translate: 'Destination_Banner',
										type: 'item',
										icon: 'image',
										url: '/destination_banner',
									},
									{
										id: 'areaBanner',
										title: 'Area Banner',
										translate: 'Area_Banner',
										type: 'item',
										icon: 'image',
										url: '/area_banner',
									},
								]
							},
							// {
							// 	id: 'hrefContent',
							// 	title: 'HrefContent',
							// 	translate: 'Href_Content',
							// 	type: 'item',
							// 	icon: 'image',
							// 	url: '/content_href',
							// },
						]
					},
					{
						id: 'basicdata_packsite',
						title: 'basicdata',
						translate: 'BasicData',
						type: 'collapse',
						icon: 'category',
						children: [
							{
								id: 'dealType',
								title: 'dealType',
								translate: 'DealType',
								type: 'item',
								icon: 'local_offer',
								url: '/deal_type',
							},
							{
								id: 'category',
								title: 'Category',
								translate: 'CATEGORY',
								type: 'item',
								icon: 'category',
								url: '/category',
							},
							{
								id: 'subcategory',
								title: 'Sub Category',
								translate: 'SUBCATEGORY',
								type: 'item',
								icon: 'category',
								url: '/subcategory',
							},
							{
								id: 'area',
								title: 'area',
								translate: 'Area',
								type: 'item',
								icon: 'crop_original',
								url: '/area'
							},
							{
								id: 'clubMember',
								title: 'club member',
								translate: 'CLUB_MEMBER',
								type: 'item',
								icon: 'person',
								url: '/club-member'
							},
							{
								id: 'holiday',
								title: 'holiday management',
								translate: 'HOLIDAY_MANAGEMENT',
								type: 'item',
								icon: 'calendar_today',
								url: '/holiday'
							},
							{
								id: 'airline',
								title: 'airline company',
								translate: 'AIRLINE_COMPANY',
								type: 'item',
								icon: 'airplanemode_active',
								url: '/airline'
							},
							{
								id: 'banerTimer',
								title: 'banner timer',
								translate: 'BANNER_TIMER',
								type: 'item',
								icon: 'av_timer',
								url: '/bannerTimer'
							},
						]
					},
					{
						id: 'sabredata_packsite',
						title: 'sabredata',
						translate: 'SabreData',
						type: 'collapse',
						icon: 'category',
						children: [
							{
								id: 'flightsAllowance',
								title: 'flights allowance',
								translate: 'FLIGHTS_ALLOWANCE',
								type: 'item',
								icon: 'airplanemode_active',
								url: '/flightsAllowance'
							},
							{
								id: 'sabreFlightsCommission',
								title: 'flights commission',
								translate: 'SABRE_FLIGHTS_COMMISSION',
								type: 'item',
								icon: 'airplanemode_active',
								url: '/sabreFlightsCommission'
							},
						]
					},
					{
						id: 'discount_builder',
						title: 'Discount builder',
						translate: 'DISCOUNT_BUILDER',
						type: 'item',
						icon: 'monetization_on',
						url: '/discount_builder'
					},
					{
						id: 'commission',
						title: 'Commission',
						translate: 'COMMISSION',
						type: 'collapse',
						icon: 'snippet_folder',
						children: [
							{
								id: 'absolute_commission_rule_builder',
								title: 'Absolute Commission Rule Builder',
								translate: 'ABSOLUTE_COMMISSION_RULE_BUILDER',
								type: 'item',
								icon: 'monetization_on',
								url: '/commission_builder/absolute'
							},
							{
								id: 'dynamic_commission_rule_builder',
								title: 'Dynamic Commission Rule Builder',
								translate: 'DYNAMIC_COMMISSION_RULE_BUILDER',
								type: 'item',
								icon: 'monetization_on',
								url: '/commission_builder/dynamic'
							},
						]
					},
					{
						id: 'deal_builder',
						title: 'Deal Builder',
						translate: 'DEAL_BUILDER',
						type: 'collapse',
						icon: 'local_offer',
						children: [
							{
								id: 'Insert',
								title: 'Insert',
								translate: 'INSERT',
								type: 'item',
								icon: 'insert_chart',
								url: '/deal_builder',
							},
							// {
							// 	id: 'Update',
							// 	title: 'Update',
							// 	translate: 'UPDATE',
							// 	type: 'item',
							// 	icon: 'update',
							// 	url: '/deal_Update',
							// },
							{
								id: 'Update',
								title: 'Update',
								translate: 'UPDATE',
								type: 'collapse',
								icon: 'update',
								children: [
									{
										id: 'Update_manual',
										title: 'Update Manual Deal',
										translate: 'UPDATE_MANUAL_DEAL',
										type: 'item',
										icon: 'pan_tool',
										url: '/deal_Update/manual',
									},
									{
										id: 'Update_auto',
										title: 'Update Auto Deal',
										translate: 'UPDATE_AUTO_DEAL',
										type: 'item',
										icon: 'autorenew',
										url: '/deal_Update/auto',
									}

								]
							},
							{
								id: 'lastTimeDeal',
								title: 'Auto Deal Builder',
								translate: 'Auto Deal Builder',
								type: 'item',
								icon: 'update',
								url: '/lastTimeDeal',
							},
						]
					},
					{
						id: 'template_builder',
						title: 'Template Builder',
						translate: 'TAMP_BUILDER',
						type: 'collapse',
						icon: 'perm_phone_msg',
						children: [
							{
								id: 'sms',
								title: 'SMS',
								translate: 'SMS',
								type: 'item',
								icon: 'sms',
								url: '/sms_builder',
							},
							{
								id: 'email',
								title: 'Email',
								translate: 'EMAIL',
								type: 'item',
								icon: 'email',
								url: '/email_builder',
							},

						]
					},
					{
						id: 'analysis',
						title: 'Analysis',
						translate: 'ANALYSIS',
						type: 'collapse',
						icon: 'analytics',
						children: [
							{
								id: 'bookingInfoAll',
								title: 'report',
								translate: 'BookingInfoAll',
								type: 'item',
								icon: 'receipt_long',
								url: '/bookingInfoAll',
							},
							{
								id: 'unpaidcustomer',
								title: 'unpaidcustomer',
								translate: 'U_Customer',
								type: 'item',
								icon: 'family_restroom',
								url: '/unpaidcustomer',
							},
							{
								id: 'unpaidphone',
								title: 'unpaidphone',
								translate: 'U_Phone',
								type: 'item',
								icon: 'no_cell',
								url: '/unpaidphone',
							},
							{
								id: 'report',
								title: 'report',
								translate: 'report',
								type: 'item',
								icon: 'receipt_long',
								url: '/report',
							},

						]
					},
					{
						id: 'app',
						translate: 'App',
						title: 'App',
						type: 'collapse',
						icon: 'event_available',
						children: [
							{
								id: 'applocktime_builder',
								title: 'App Lock Time Builder',
								translate: 'APPLOCKTIME_BUILDER',
								type: 'item',
								icon: 'add_alarm',
								url: "/app_lock_time_builder"
							},
							{
								id: 'appdealcategory_builder',
								title: 'App Deal Category Builder',
								translate: 'APPDEALCATEGORY_BUILDER',
								type: 'item',
								icon: 'category',
								url: '/app_deal_categories'
							},
							{
								id: 'appdealsubcategory_builder',
								title: 'App Deal Subcategory Builder',
								translate: 'APP_DEAL_SUBCATEGORY_BUILDER',
								type: 'item',
								icon: 'category',
								url: '/app_deal_subcategories'
							},
							{
								id: 'appdeal_builder',
								title: 'App Deal Builder',
								translate: 'APPDEAL_BUILDER',
								type: 'item',
								icon: 'insert_chart',
								url: '/app_deal_builder'
							},
							{
								id: 'app_autodeal_builder',
								title: 'App Auto Deal Builder',
								translate: 'APP_AUTODEAL_BUILDER',
								type: 'item',
								icon: 'update',
								url: '/app_auto_deal_builder'
							},
							{
								id: 'manualupdatingappdeal',
								title: 'Manual Updating App Deal',
								translate: 'MANUALUPDATE_APPDEAL',
								type: 'item',
								icon: 'update',
								url: '/manual_update_app_deal'
							},
							{
								id: 'appbannerimage_builder',
								title: 'App Banner Image Builder',
								translate: 'APPBANNERIMAGE_BUILDER',
								type: 'item',
								icon: 'wallpaper',
								url: '/app_banner_image'
							},
							{
								id: 'contact_info_for_app',
								title: 'Contact info for app user',
								translate: 'CONTACT_INFO_FOR_APP_USER',
								type: 'item',
								icon: 'connect_without_contact',
								url: '/contact_info_for_app'
							}
						]
					},
					{
						id: 'lead',
						title: 'Lead',
						translate: 'LEAD',
						type: 'collapse',
						icon: 'dashboard',
						children: [
							{
								id: 'click2call',
								title: 'Click2Call',
								translate: 'CLICK_2_CALL',
								type: 'item',
								icon: 'monetization_on',
								url: '/click2call'
							},
						]
					},
					{
						id: 'edit_static_content',
						title: 'Edit Static Content',
						translate: 'EDIT_STATIC_CONTENT',
						type: 'collapse',
						icon: 'contact_page',
						children: [
							{
								id: 'pack-footer',
								title: 'Footer Pages Edit',
								translate: 'FOOTER_PAGES_EDIT',
								type: 'item',
								icon: 'low_priority',
								url: '/staticPage/footer'
							},
							{
								id: 'questionAnswer',
								title: 'QuestionAnswer',
								translate: 'Question_Answer',
								type: 'item',
								icon: 'question_answer',
								url: '/staticPage/QuestionAnswer'
							}
							// {
							// 	id: 'meta',
							// 	title: 'MetaItemsEdit',
							// 	translate: 'META_ITEMS_EDIT',
							// 	type: 'item',
							// 	icon: 'near_me_disabled',
							// 	url: '/staticPage/meta'
							// },
							// {
							// 	id: 'position',
							// 	title: 'SetPosition',
							// 	translate: 'SET_POSITION',
							// 	type: 'item',
							// 	icon: 'picture_in_picture',
							// 	url: '/staticPage/position'
							// }
						],
					},
					{
						id: 'translation_management',
						translate: 'TRANSLATION_MANAGEMENT',
						title: 'TRANSLATION MANAGEMENT',
						type: 'collapse',
						icon: 'translate',
						children: [
							{
								id: 'subject',
								title: 'SUBJECT',
								translate: 'SUBJECT',
								type: 'item',
								icon: 'subject',
								url: '/subject'
							},
							{
								id: 'pack_destination',
								title: 'Pack Destination',
								type: 'item',
								translate: 'PACK_DESTINATION',
								icon: 'assignment_turned_in',
								url: '/packDestination'
							},
							{
								id: 'hotel_manager',
								title: 'Hotel Manager',
								translate: 'HOTEL_MANAGER',
								type: 'item',
								icon: 'emoji_transportation',
								url: '/hotel'
							},
							{
								id: 'roomclass',
								title: 'RoomClass',
								type: 'item',
								translate: 'ROOM_CLASS',
								icon: 'hotel',
								url: '/roomclass'
							},
							{
								id: 'roomtype',
								title: 'RoomType',
								type: 'item',
								translate: 'ROOM_TYPE',
								icon: 'escalator_warning',
								url: '/roomtype'
							},
							{
								id: 'basis',
								title: 'basis',
								translate: 'Basis Name',
								type: 'item',
								icon: 'foundation',
								url: '/basis'
							},
							{
								id: 'hotelService',
								title: 'hotel service',
								translate: 'HOTEL_SERVICE',
								type: 'item',
								icon: 'room_service',
								url: '/hotelService'
							},
							{
								id: 'country',
								title: 'country service',
								translate: 'CONTRY_SERVICE',
								type: 'item',
								icon: 'emoji_flags',
								url: '/countryService'
							},
							{
								id: 'airport',
								title: 'airport service',
								translate: 'AIRPORT_SERVICE',
								type: 'item',
								icon: 'emoji_flags',
								url: '/airportService'
							}
						]
					},
					{
						id: 'dynamic_pricing',
						translate: 'Dynamic Pricing',
						title: 'Dynamic Pricing',
						type: 'collapse',
						icon: 'subject',
						children: [
							{
								id: 'fc_to_ldss',
								title: 'FC one-way to Ldss',
								translate: 'FC one-way to Ldss',
								type: 'item',
								icon: 'subject',
								url: '/fc_to_ldss'
							},
							{
								id: 'one_way_citizen',
								title: 'One-way Citizen',
								translate: 'One-way Citizen',
								type: 'item',
								icon: 'subject',
								url: '/one_way_citizen'
							},
							{
								id: 'one_way_fc',
								title: 'One-way FC Rate',
								translate: 'One-way FC Rate',
								type: 'item',
								icon: 'subject',
								url: '/one_way_fc'
							},
							{
								id: 'comparison_rule',
								title: 'By-Comparison Pricing Rule',
								translate: 'By-Comparison Pricing Rule',
								type: 'item',
								icon: 'subject',
								url: '/comparison_rule'
							},
							{
								id: 'demand_rule',
								title: 'By-Demand Pricing Rule',
								translate: 'By-Demand Pricing Rule',
								type: 'item',
								icon: 'subject',
								url: '/demand_rule'
							},
							{
								id: 'season',
								title: 'season',
								translate: 'SEASON',
								type: 'item',
								icon: 'av_timer',
								url: '/pricing-season'
							},
						]
					},
					{
						id: 'bypass_all_disc_rules',
						title: 'Bypass All Disc Rules',
						translate: 'Bypass All Disc Rules',
						type: 'item',
						icon: 'monetization_on',
						url: '/bypass_all_disc_rules'
					},
				]
			},
			{
				id: 'domestic',
				translate: 'domestic',
				title: 'domestic',
				type: 'collapse',
				icon: 'dashboard',
				children: [
					{
						id: 'discount_builder_domestic',
						title: 'Discount builder',
						translate: 'DISCOUNT_BUILDER',
						type: 'item',
						icon: 'monetization_on',
						url: '/domestic/discountBuilder'
					},
					{
						id: 'deal_builder',
						title: 'Deal Builder',
						translate: 'DEAL_BUILDER',
						type: 'collapse',
						icon: 'local_offer',
						children: [
							{
								id: 'Insert',
								title: 'Insert',
								translate: 'INSERT',
								type: 'item',
								icon: 'insert_chart',
								url: '/domestic/dealBuilder',
							},
							{
								id: 'Update',
								title: 'Update',
								translate: 'UPDATE',
								type: 'item',
								icon: 'update',
								url: '/domestic/dealUpdate',
							},
							{
								id: 'DomesticAutoDeal',
								title: 'Auto Deal',
								translate: 'Auto Deal',
								type: 'item',
								icon: 'insert_chart',
								url: '/domestic/autoDealbuilder',
							},
						]
					},
					{
						id: 'basicdata_domestic',
						title: 'basicdata',
						translate: 'BasicData',
						type: 'collapse',
						icon: 'category',
						children: [
							{
								id: 'href',
								title: 'Href Items',
								translate: 'HrefItems',
								type: 'item',
								icon: 'api',
								url: '/manage_href/domestic',
							},
							{
								id: 'dealCategory',
								title: 'DealCategory',
								translate: 'DealCatergory',
								type: 'item',
								icon: 'api',
								url: '/domestic/domecategory',
							},
							{
								id: 'hotelPricePDF',
								title: 'Hotel Price PDF',
								translate: 'HotelPricePDF',
								type: 'item',
								icon: 'api',
								url: '/domestic/domehotelPricePDF'
							},
							{
								id: 'hotelchian',
								title: 'HotelChain',
								translate: 'HotelChain',
								type: 'item',
								icon: 'api',
								url: '/domestic/domehotelchain'
							},
							{
								id: 'hotelCoversion',
								title: 'HotelConversion',
								translate: 'HotelConversion',
								type: 'item',
								icon: 'api',
								url: '/domestic/domehotelconversion'
							},
							{
								id: 'hotelInfo',
								title: 'DomesticHotelInfo',
								translate: 'Hotel_Info',
								type: 'item',
								icon: 'api',
								url: '/domestic/domehotelinfo'
							},
							{
								id: 'remark-manage',
								title: 'Room Rate Remark',
								translate: 'ROOM_RATE_REMARK',
								type: 'item',
								icon: 'low_priority',
								url: '/domestic/remarkManagement'
							},
							{
								id: 'domestic-footer',
								title: 'Domestic Footer Edit',
								translate: 'DOMESTIC_FOOTER_PAGES_EDIT',
								type: 'item',
								icon: 'low_priority',
								url: '/domestic/staticPage/domesticFooter'
							},
							// {
							// 	id: 'domestic-agent-comm-rule',
							// 	title: 'Agent Commission Rule',
							// 	translate: 'AGENT_COMM_RULE',
							// 	type: 'item',
							// 	icon: 'support',
							// 	url: '/domestic/agentCommRule'
							// },
							{
								id: 'domestic-external-agent-comm-rule',
								title: 'Agent Commission Rule',
								translate: 'AGENT_COMM_RULE',
								type: 'item',
								icon: 'support',
								url: '/domestic/externalAgentCommRule'
							},
							{
								id: 'domestic-special-remark-keywords',
								title: 'Special remark keywords',
								translate: 'SPECIAL_REMARK_KEYWORD',
								type: 'item',
								icon: 'api',
								url: '/domestic/specialRemarkKeyword'
							},
							{
								id: 'domestic-conversion-crm-to-ody-agent',
								title: 'Conversion CRM to Ody Agent',
								translate: 'CONVERSION_CRM_TO_ODY_AGENT',
								type: 'item',
								icon: 'api',
								url: '/domestic/conversionCrmToOdyAgent'
							},
						]
					},
					{
						id: 'analysis',
						title: 'Analysis',
						translate: 'ANALYSIS',
						type: 'collapse',
						icon: 'analytics',
						children: [
							{
								id: 'bookingInfoAll',
								title: 'report',
								translate: 'BookingInfoAll',
								type: 'item',
								icon: 'receipt_long',
								url: '/domestic/domebookingInfoAll',
							},
							{
								id: 'statsInfoAgent',
								title: 'report',
								translate: 'StatsInfoAgent',
								type: 'item',
								icon: 'receipt_long',
								url: '/domestic/stats_info_agent',
							},
							{
								id: 'partners',
								title: 'partners',
								translate: 'Partners Analysis',
								type: 'item',
								icon: 'receipt_long',
								url: '/domestic/partner_analysis',
							},
						]
					},
					// {
					// 	id: 'partnerbooks',
					// 	title: 'partnerbooks',
					// 	translate: 'Partner Books',
					// 	type: 'collapse',
					// 	icon: 'dashboard',
					// 	children: [
					// 		{
					// 			id: 'allbookings',
					// 			title: 'All Bookings',
					// 			translate: 'All Bookings',
					// 			type: 'item',
					// 			icon: 'receipt_long',
					// 			url: '/domestic/booking_partner',
					// 		},
					// 		{
					// 			id: 'bookingstats',
					// 			title: 'Booking Stats',
					// 			translate: 'Booking Stats',
					// 			type: 'item',
					// 			icon: 'receipt_long',
					// 			url: '/domestic/booking_stats',
					// 		},
					// 		{
					// 			id: 'commission_stats',
					// 			title: 'Commission Stats',
					// 			translate: 'Commission Stats',
					// 			type: 'item',
					// 			icon: 'receipt_long',
					// 			url: '/domestic/commission_stats',
					// 		},
					// 	]
					// },
					{
						id: 'lead',
						title: 'Lead',
						translate: 'LEAD',
						type: 'collapse',
						icon: 'dashboard',
						children: [
							{
								id: 'click2call',
								title: 'Click2Call',
								translate: 'CLICK_2_CALL',
								type: 'item',
								icon: 'monetization_on',
								url: '/domestic/dclick2call'
							},
						]
					},
					{
						id: 'domestic_destination',
						title: 'Domestic Destination',
						type: 'item',
						translate: 'DOMESTIC_DESTINATION',
						icon: 'assignment_return',
						url: '/domesticDestination'
					},
				]
			},
			{
				id: 'camingo',
				translate: 'Camingo',
				title: 'Camingo',
				type: 'collapse',
				icon: 'dashboard',
				children: [
					{
						id: 'camingo_discount_builder',
						title: 'Camingo Discount builder',
						translate: 'CAMINGO_DISCOUNT_BUILDER',
						type: 'item',
						icon: 'monetization_on',
						url: '/camingo/camingoDiscountBuilder'
					},
					{
						id: 'deal_builder',
						title: 'Deal Builder',
						translate: 'DEAL_BUILDER',
						type: 'collapse',
						icon: 'local_offer',
						children: [
							{
								id: 'CamingoInsert',
								title: 'CamingoInsert',
								translate: 'CAMINGO_INSERT',
								type: 'item',
								icon: 'insert_chart',
								url: '/camingo/camingoDealBuilder',
							},
							{
								id: 'CamingoUpdate',
								title: 'CamingoUpdate',
								translate: 'CAMINGO_UPDATE',
								type: 'item',
								icon: 'update',
								url: '/camingo/camingoDealUpdate',
							},
							{
								id: 'CamingoAutoDeal',
								title: 'CamingoAutoDeal',
								translate: 'CAMINGO_AUTO_DEAL',
								type: 'item',
								icon: 'insert_chart',
								url: '/camingo/camingoAutoDeal',
							},
						]
					},
					{
						id: 'basicdata_camingo',
						title: 'basicdata',
						translate: 'BasicData',
						type: 'collapse',
						icon: 'category',
						children: [
							{
								id: 'dealCategory',
								title: 'DealCategory',
								translate: 'DealCategory',
								type: 'item',
								icon: 'api',
								url: '/camingo/camingoCategory',
							},
							{
								id: 'hotelchian',
								title: 'HotelChain',
								translate: 'HotelChain',
								type: 'item',
								icon: 'api',
								url: '/camingo/camingoChain'
							},
							{
								id: 'hotelConversion',
								title: 'HotelConversion',
								translate: 'HotelConversion',
								type: 'item',
								icon: 'api',
								url: '/camingo/camingoHotelConversion'
							},
							{
								id: 'camingo_hotel_info',
								title: 'CamingoHotelInformation',
								translate: 'Hotel_Info',
								type: 'item',
								icon: 'loupe',
								url: '/camingo/camingoHotelInfo'
							},
							{
								id: 'remark-manage',
								title: 'Room Rate Remark',
								translate: 'ROOM_RATE_REMARK',
								type: 'item',
								icon: 'low_priority',
								url: '/camingo/remarkManagement'
							},
							{
								id: 'camingo_footer',
								title: 'Camingo Footer Edit',
								translate: 'CAMINGO_FOOTER_PAGES_EDIT',
								type: 'item',
								icon: 'low_priority',
								url: '/camingo/staticPage/camingoFooter'
							},
							{
								id: 'camingo_agent_manage',
								title: 'Camingo Agent Manage',
								translate: 'CAMINGO_AGENT_MANAGE',
								type: 'item',
								icon: 'support_agent',
								url: '/camingo/camingoInternalAgent'
							},
							{
								id: 'camingo-agent-comm-rule',
								title: 'Agent Commission Rule',
								translate: 'AGENT_COMM_RULE',
								type: 'item',
								icon: 'surround_sound',
								url: '/camingo/agentCommRule'
							},
							{
								id: 'camingo-supplement-service',
								title: 'Supplement Service',
								translate: 'SUPPLEMENT_SERVICE',
								type: 'item',
								icon: 'swap_calls',
								url: '/camingo/supplementService'
							},
							{
								id: 'camingo-nationality',
								title: 'Nationality',
								translate: 'NATIONALITY',
								type: 'item',
								icon: 'swap_horiz',
								url: '/camingo/nationality'
							},
						]
					},
					{
						id: 'analysis',
						title: 'Analysis',
						translate: 'ANALYSIS',
						type: 'collapse',
						icon: 'analytics',
						children: [
							{
								id: 'camingoBookingInfoAll',
								title: 'report',
								translate: 'BookingInfoAll',
								type: 'item',
								icon: 'receipt_long',
								url: '/camingo/camingoBookingInfoAll',
							},
						]
					},
					{
						id: 'camingo_destination',
						title: 'Camingo Destination',
						type: 'item',
						translate: 'CAMINGO_DESTINATION',
						icon: 'assignment_late',
						url: '/camingoDestination'
					},
				]
			},
			{
				id: 'emalon',
				translate: 'EMALON',
				title: 'Emalon',
				type: 'collapse',
				icon: 'dashboard',
				children: [
					{
						id: 'emalon_discount_builder',
						title: 'Emalon Discount builder',
						translate: 'EMALON_DISCOUNT_BUILDER',
						type: 'item',
						icon: 'monetization_on',
						url: '/emalon/emalonDiscountBuilder'
					},
					{
						id: 'emalon_deal_builder',
						title: 'Emalon Deal Builder',
						translate: 'EMALON_DEAL_BUILDER',
						type: 'collapse',
						icon: 'local_offer',
						children: [
							// {
							// 	id: 'EmalonDealManage',
							// 	title: 'EmalonDealManage',
							// 	translate: 'EmalonDeal(test)',
							// 	type: 'item',
							// 	icon: 'local_offer',
							// 	url: '/emalon/emalonDeal',
							// },
							{
								id: 'EmaonInsert',
								title: 'EmalonInsert',
								translate: 'EMALON_DEAL_INSERT',
								type: 'item',
								icon: 'insert_chart',
								url: '/emalon/emalonDealBuilder',
							},
							{
								id: 'EmalonUpdate',
								title: 'EmalonUpdate',
								translate: 'EMALON_DEAL_UPDATE',
								type: 'item',
								icon: 'update',
								url: '/emalon/emalonDealUpdate',
							},
							{
								id: 'EmalonAutoDeal',
								title: 'EmalonAutoDeal',
								translate: 'EMALON_AUTO_DEAL',
								type: 'item',
								icon: 'insert_chart',
								url: '/emalon/emalonAutoDeal',
							},
						]
					},
					{
						id: 'emalon_image_manage',
						title: 'Emalon Image Manage',
						translate: 'EMALON_IMAGE_MANAGE',
						type: 'item',
						icon: 'satellite',
						url: '/emalon/emalonImageManagement'
					},
				]
			},
			// {
			// 	id: 'manualTranslate',
			// 	title: 'Bulk translate',
			// 	translate: 'Bulk translate',
			// 	type: 'item',
			// 	icon: 'dashboard',
			// 	url: '/manualTranslate'
			// },
		]
	}
];

if(userName === 'test'){
	navigationConfig = [
		{
			id: 'highteck',
			translate: 'highteck zone',
			title: 'highteck zone',
			type: 'collapse',
			icon: 'dashboard',
			children: [
				{
					id: 'basicdata_domestic',
					title: 'basicdata',
					translate: 'BasicData',
					type: 'collapse',
					icon: 'category',
					children: [
						{
							id: 'dealCategory',
							title: 'DealCategory',
							translate: 'DealCatergory',
							type: 'item',
							icon: 'api',
							url: '/domestic/domecategory',
						},
						{
							id: 'hotelchian',
							title: 'HotelChain',
							translate: 'HotelChain',
							type: 'item',
							icon: 'api',
							url: '/domestic/domehotelchain'
						},
						{
							id: 'hotelCoversion',
							title: 'HotelConversion',
							translate: 'HotelConversion',
							type: 'item',
							icon: 'api',
							url: '/domestic/domehotelconversion'
						},
						{
							id: 'hotelInfo',
							title: 'HotelConversion',
							translate: 'Hotel_Info',
							type: 'item',
							icon: 'api',
							url: '/domestic/domehotelinfo'
						},
						{
							id: 'domestic_destination',
							title: 'Domestic Destination',
							type: 'item',
							translate: 'DOMESTIC_DESTINATION',
							icon: 'assignment_return',
							url: '/domesticDestination'
						},
					]
				},
				{
					id: 'discount_builder_domestic',
					title: 'Discount builder',
					translate: 'DISCOUNT_BUILDER',
					type: 'item',
					icon: 'monetization_on',
					url: '/domestic/discountBuilder'
				},
				{
					id: 'deal_builder',
					title: 'Deal Builder',
					translate: 'DEAL_BUILDER',
					type: 'collapse',
					icon: 'local_offer',
					children: [
						{
							id: 'Insert',
							title: 'Insert',
							translate: 'INSERT',
							type: 'item',
							icon: 'insert_chart',
							url: '/domestic/dealBuilder',
						},
						{
							id: 'Update',
							title: 'Update',
							translate: 'UPDATE',
							type: 'item',
							icon: 'update',
							url: '/domestic/dealUpdate',
						},
						{
							id: 'DomesticAutoDeal',
							title: 'Auto Deal',
							translate: 'Auto Deal',
							type: 'item',
							icon: 'insert_chart',
							url: '/domestic/autoDealbuilder',
						},
					]
				},
			]
		}
	];
}

export default navigationConfig;
