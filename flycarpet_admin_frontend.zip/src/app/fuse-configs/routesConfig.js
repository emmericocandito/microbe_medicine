import FuseUtils from '@fuse/utils';
import LoginConfig from 'app/main/login/LoginConfig';
import LogoutConfig from 'app/main/logout/LogoutConfig';
import RegisterConfig from 'app/main/register/RegisterConfig';
import Dashboard from 'app/main/dashboard/DashboardAppConfig';
import ErrorConfig from 'app/main/errors/404/Error404PageConfig';

import CommonConfig from 'app/main/common/CommonConfig';
import AgencyContentConfig from 'app/main/common/AgencyContents/AgencyContentConfig';

import packSiteConfig from 'app/main/packsite/packSiteConfig';
import BasicDataConfig from 'app/main/packsite/basicData/BasicDataConfig';
import SabreDataConfig from 'app/main/packsite/sabre/SabreDataConfig';
import Deal from 'app/main/packsite/deal/DealConfig';
import Discount from 'app/main/packsite/discount/DiscountConfig';
import Template from 'app/main/packsite/template/TemplateConfig';
import Analysis from 'app/main/packsite/booking/AnalysisConfig';
import BypassBookingInfo from 'app/main/packsite/booking/BypassBookingInforConfig';
import MobileApp from 'app/main/MobileApp/MobileAppConfig';
import Lead from 'app/main/packsite/lead/LeadConfig';
import Subject from 'app/main/packsite/translation/subject/SubjectConfig';
import Destination from 'app/main/packsite/translation/destination/DestinationConfig';
import Hotel from 'app/main/packsite/translation/hotel/HotelConfig';
import RoomClass from 'app/main/packsite/translation/roomclass/RoomClassConfig';
import RoomType from 'app/main/packsite/translation/roomtype/RoomTypeConfig';
import Translation from 'app/main/packsite/translation/TranslationConfig';
import DyanmicPricingConfig from 'app/main/packsite/dynamicPricing/dynamicPricingConfig';

import DomesticConfig from 'app/main/domestic/domesticConfig';
import DomesticHotelInfoConfig from 'app/main/domestic/basicdata/HotelInfo/DomesticHotelInfoConfig';
import domesticDiscountConfig from 'app/main/domestic/discount/DiscountConfig';
import domesticDealConfig from 'app/main/domestic/deal/DealConfig';
import domesticBasicConfig from 'app/main/domestic/basicdata/BasicDataConfig';
import domesticBookingInfo from 'app/main/domestic/analysis/BookingInfoConfig';
import domesticAnalysis from 'app/main/domestic/analysis/analysisConfig';

import CamingoConfig from 'app/main/camingo/camingoConfig'
import camingoBasicConfig from 'app/main/camingo/basicData/BasicDataConfig';
import camingoHotelInfoConfig from 'app/main/camingo/basicData/HotelInfo/CamingoHotelInfoConfig';
import camingoDiscountConfig from 'app/main/camingo/discount/CamingoDiscountConfig';
import camingoDealConfig from 'app/main/camingo/camingoDeal/CamingoDealConfig';
import camingoBookingInfo from 'app/main/camingo/analysis/BookingInfoConfig';

import emalonDiscountConfig from 'app/main/emalon/emalonDiscount/EmalonDiscountConfig';
import emalonDealConfig from 'app/main/emalon/emalonDeal/EmalonDealConfig';
import emalonImageConfig from 'app/main/emalon/emalonImage/EmalonImageConfig';

import StaticPage from 'app/main/EditStaticPage/StaticPageConfig';
import ManualTranslateConfig from 'app/main/utils/manualTranslate/manualTranslateConfig'

import DirectLinkConfig from 'app/main/directLink/DirectLinkConfig'

import React from 'react';
import { Redirect } from 'react-router-dom';
import jwt from 'jwt-decode';
const token = window.localStorage.getItem('jwt_access_token');
const userRole = token == null ? '' : jwt(token).role;
const userName = (token === null ? '' : jwt(token).name);

var routeConfigs = userRole == 'agency' ? [
	DirectLinkConfig,
	LoginConfig,
	// RegisterConfig,
	LogoutConfig,
	Dashboard,
	ErrorConfig,
	AgencyContentConfig,
	// Deal,
	// Discount,
	DomesticHotelInfoConfig,
	camingoHotelInfoConfig,
	StaticPage,
] : [
	DirectLinkConfig,
	LoginConfig,
	RegisterConfig,
	LogoutConfig,
	BypassBookingInfo,
	domesticBookingInfo,
	camingoBookingInfo,
	ErrorConfig,
	Dashboard,

	CommonConfig,
	AgencyContentConfig,

	packSiteConfig,
	BasicDataConfig,
	SabreDataConfig,
	Discount,
	Deal,
	Lead,
	Template,
	Analysis,
	Destination,
	Hotel,
	RoomClass,
	RoomType,
	Subject,
	Translation,
	DyanmicPricingConfig,

	DomesticConfig,
	domesticDiscountConfig,
	domesticDealConfig,
	domesticBasicConfig,
	domesticAnalysis,

	CamingoConfig,
	camingoBasicConfig,
	camingoDiscountConfig,
	camingoDealConfig,

	emalonDiscountConfig,
	emalonDealConfig,
	emalonImageConfig,

	MobileApp,
	StaticPage,

	ManualTranslateConfig,
];

if(userName === 'test'){
	routeConfigs = [
		DomesticConfig,
		domesticDiscountConfig,
		domesticDealConfig,
		domesticBasicConfig,
	]
}

const routes = [
	// if you want to make whole app auth protected by default change defaultAuth for example:
	// ...FuseUtils.generateRoutesFromConfigs(routeConfigs, ['admin','staff','user']),
	// The individual route configs which has auth option won't be overridden.
	...FuseUtils.generateRoutesFromConfigs(routeConfigs, null),
	{
		path: '/',
		exact: true,
		component: () => <Redirect to="/dashboard" />
	},
	{
		component: () => <Redirect to="/errors/error-404" />
	}
];

export default routes;
