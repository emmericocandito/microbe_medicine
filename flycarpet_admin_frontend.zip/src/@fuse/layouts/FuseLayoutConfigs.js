export { default } from 'app/fuse-layouts/FuseLayoutConfigs';
