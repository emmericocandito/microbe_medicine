export { default } from './FuseScrollbars';
