export { default } from './FuseSuspense';
