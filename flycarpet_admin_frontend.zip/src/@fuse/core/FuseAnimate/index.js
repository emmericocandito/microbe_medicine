export { default } from './FuseAnimate';
