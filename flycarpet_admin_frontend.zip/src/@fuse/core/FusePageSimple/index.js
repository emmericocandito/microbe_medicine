export { default } from './FusePageSimple';
