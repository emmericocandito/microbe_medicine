export { default } from './DemoContent';
