/* eslint-disable no-global-assign */
// const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');

require = require('esm')(module);
const { routes } = require('./src/router.js');

module.exports = {
  // configureWebpack: {
  //   devtool: 'source-map',
  //   optimization: {
  //     splitChunks: false,
  //   },
  //   // externals: {
  //   //   moment: 'moment',
  //   // },
  //   devServer: {
  //     watchOptions: {
  //       ignored: [/node_modules/, /public/],
  //     },
  //   },
  //   module: {
  //     rules: [{ sideEffects: false }],
  //   },
  //   plugins: [
  //     // new BundleAnalyzerPlugin(),
  //   ],
  // },
  pluginOptions: {
    sitemap: {
      baseURL: 'http://www.flying-carpet.co.il',
      defaults: {
        lastmod: '2022-01-31',
        priority: 0.1,
        changefreq: 'daily',
      },
      routes,
    },
  },
};
