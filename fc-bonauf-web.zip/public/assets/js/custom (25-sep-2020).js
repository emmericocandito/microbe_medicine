
jQuery(document).ready(function($){

    /* Scripts will be placed here */

    $('.banner-slider').owlCarousel({
        loop:true,
        margin:0,
        nav:false,
        rtl:true,
        autoplay:true,
        autoplayTimeout: 5000,
        smartSpeed: 2550,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:1
            },
            1000:{
                items:1
            }
        }
    })

    $('.feathers-slider').owlCarousel({
        loop:true,
        margin:20,
        nav:true,
        navText: ["<i class='fa fa-angle-right'></i>", "<i class='fa fa-angle-left'></i>"],
        dots: false,
        rtl:true,
        autoplay:true,
        smartSpeed: 1050,
        responsive:{
            0:{
                items:2
            },
            600:{
                items:3
            },
            1000:{
                items:5
            },
            1200: {
                items:7
            }
        }
    })

    $('.prices-of-flight').owlCarousel({
        loop:true,
        margin:20,
        nav:true,
        navText: ["<i class='fa fa-angle-right'></i>", "<i class='fa fa-angle-left'></i>"],
        dots: false,
        //rtl:true,
        autoplay:true,
        smartSpeed: 2050,
        //autoplayTimeout: 10000,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            1000:{
                items:3
            },
            1200:{
                items:4
            }
        }
    })

    $('.property-type').owlCarousel({
        loop:true,
        margin:20,
        nav:true,
        navText: ["<i class='fa fa-angle-right'></i>", "<i class='fa fa-angle-left'></i>"],
        dots: false,
        rtl:true,
        autoplay:true,
        smartSpeed: 1050,
        responsive:{
            0:{
                items:2
            },
            600:{
                items:3
            },
            1000:{
                items:5
            }
        }
    })

    $('.inspir-trip').owlCarousel({
        loop:true,
        margin:20,
        nav:true,
        navText: ["<i class='fa fa-angle-right'></i>", "<i class='fa fa-angle-left'></i>"],
        dots: false,
        autoplay:true,
        smartSpeed: 1050,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            1000:{
                items:2
            }
        }
    })

    $('.travel-connect').owlCarousel({
        loop:true,
        margin:20,
        nav:true,
        navText: ["<i class='fa fa-angle-right'></i>", "<i class='fa fa-angle-left'></i>"],
        dots: false,
        rtl:true,
        autoplay:true,
        smartSpeed: 1050,
        responsive:{
            0:{
                items:2
            },
            600:{
                items:3
            },
            1000:{
                items:4
            }
        }
    })

    $('.guest-love').owlCarousel({
        loop:true,
        margin:20,
        nav:true,
        navText: ["<i class='fa fa-angle-right'></i>", "<i class='fa fa-angle-left'></i>"],
        dots: false,
        autoplay:true,
        smartSpeed: 1050,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            1000:{
                items:4
            }
        }
    })

    $('.longer-stays').owlCarousel({
        loop:true,
        margin:20,
        nav:true,
        navText: ["<i class='fa fa-angle-right'></i>", "<i class='fa fa-angle-left'></i>"],
        dots: false,
        rtl:true,
        autoplay:true,
        smartSpeed: 1050,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:2
            },
            1000:{
                items:4
            }
        }
    })

    $('.discover-slider').owlCarousel({
        loop:true,
        margin:20,
        nav:true,
        navText: ["<i class='fa fa-angle-right'></i>", "<i class='fa fa-angle-left'></i>"],
        dots: false,
        autoplay:true,
        smartSpeed: 1050,
        responsive:{
            0:{
                items:2
            },
            600:{
                items:3
            },
            1000:{
                items:5
            }
        }
    })

    $('.slider-offerOne').owlCarousel({
        loop:true,
        margin:15,
        nav:true,
        navText: ["<i class='fa fa-angle-right'></i>", "<i class='fa fa-angle-left'></i>"],
        dots: false,
        rtl:true,
        autoplay:true,
        smartSpeed: 1050,
        responsive:{
            0:{
                items:2
            },
            600:{
                items:3
            },
            1199:{
                items:4
            },
            1200:{
                items:5
            }
        }
    })



    $('[data-toggle="popover"]').popover({
        trigger: 'focus'
    });


    /* Default date and time picker */
		$('.datetimepicker-default').datetimepicker({
			//locale: 'ru'
            //'format' : "YYYY-MM-DD hh:mm:ss", // HH:mm:ss
		});
		$('.datetimepicker').datetimepicker({
            'format' : "DD-MMM-YYYY",
            locale: 'he',
		});

		/* Time picker only */
		$('.timepicker').datetimepicker({
            locale: 'he',
            format: 'LT',
		});
		
		/* Linked date and time picker */
		// start date date and time picker 
		$('.datepicker-start').datetimepicker({
            locale: 'he',
            'format' : "ddd-DD-MMM-YYYY",
        });

		// End date date and time picker 
        $('.datepicker-end').datetimepicker({
            locale: 'he',
            'format' : "ddd-DD-MMM-YYYY",
            useCurrent: false ,
        });
		
		// start date picke on chagne event [select minimun date for end date datepicker]
        $(".datepicker-start").on("dp.change", function (e) {
            $('.datepicker-end').data("DateTimePicker").minDate(e.date);
        });
		// Start date picke on chagne event [select maxmimum date for start date datepicker]
        $(".datepicker-end").on("dp.change", function (e) {
            $('.datepicker-start').data("DateTimePicker").maxDate(e.date);
        });
		
		// View mode datepicker [shows only years and month]
		$('.datepicker-view-mode').datetimepicker({
            locale: 'he',
			viewMode: 'years',
            format: 'MM/YYYY'
		});
		
		// Disabled Days of the Week (Disable sunday and saturday) [ 0-Sunday, 1-Monday, 2-Tuesday   3-wednesday 4-Thusday 5-Friday 6-Saturday]
		$('.datepicker-disabled-days').datetimepicker({
            locale: 'he',
			 daysOfWeekDisabled: [0, 6]
		});
		
		// Inline datepicker
		$('.datepicker-inline').datetimepicker({
            locale: 'he',
			inline: true
		});
		
		// Datepicker in popup
		$('.datepicker-popup-inline').datetimepicker({
            locale: 'he',
			inline: true
		});
		
		// get date from popup datepicker
		$(".datepicker-dialog .btn-primary").on("click", function () {
			$(".datepicker-dialog").modal('hide');

			var datepickerID =  $("[data-datepicker-popup='true']").attr("data-datepicker");
			var popupDatepickerValue = $("."+datepickerID).data('date');
			var elementTagName = $("[data-datepicker-popup='true']").prop("tagName")

			if(elementTagName == "INPUT" || elementTagName == "TEXTAREA"){
				$("[data-datepicker="+datepickerID+"]").val(popupDatepickerValue);	
			}else {
				$("[data-datepicker="+datepickerID+"]").text(popupDatepickerValue);	
			}
			
        });
		$("[data-header-left='true']").parent().addClass("pmd-navbar-left");
		// Datepicker left header
		$('.datepicker-left-header').datetimepicker({
            locale: 'he',
			'format' : "YYYY-MM-DD HH:mm:ss", // HH:mm:ss
        });


        
        $('.ui.rating').rating();
        $("input[type='number']").inputSpinner();
        /* $("[data-toggle='popover']").popover({});
        $('.popover-dismiss').popover({
            trigger: 'focus'
          });
        $('[data-toggle="popover"]').popover(); */

        /* Banner filterTab: Dropdown Custom content */
        $(function () {
            $('.dropdown-menu :input').on('focus click blur', function (e) {
                e.stopPropagation();
            })
        });



        
        
        // multiple handled with value 
        var pmdSliderValueRange = document.getElementById('pmd-slider-value-range');
        
        noUiSlider.create(pmdSliderValueRange, {
            start: [ 20, 80 ], // Handle start position
            connect: true, // Display a colored bar between the handles
            tooltips: [ wNumb({ decimals: 0 }), wNumb({ decimals: 0 }) ],
            format: wNumb({
                decimals: 0,
                thousand: '',
                postfix: '',
            }),
            range: { // Slider can select '0' to '100'
                'min': 0,
                'max': 100
            }
        });
        
        var valueMax = document.getElementById('value-max'),
            valueMin = document.getElementById('value-min');
        
        // When the slider value changes, update the input and span
        pmdSliderValueRange.noUiSlider.on('update', function( values, handle ) {
            if ( handle ) {
                valueMax.innerHTML = values[handle];
            } else {
                valueMin.innerHTML = values[handle];
            }
        });	





});