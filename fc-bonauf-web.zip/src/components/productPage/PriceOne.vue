<template>
  <div>
    <div class="chooseroombox mb-2" v-if="device === 'mobile'">
      <button class="js-del-row" v-if="index > 0" @click="remove">
        <i class="far fa-window-close"></i>
      </button>
      <h2>
        {{ $t('product-page.room') }} {{ index + 1 }} :
        {{ $t('product-page.choose-room') }}
      </h2>
      <div class="row row-0 mx-n2">
        <div class="col-6">
          <div class="form-group">
            <b-form-select v-model="currentType" :disabled="priceLoading" :options="optionByRoomTypes" ></b-form-select>
          </div>
        </div>
        <div class="col-6">
          <div class="form-group">
            <b-form-select v-model="currentClassCode" :disabled="priceLoading" :options="optionByRoomClasses" v-if="!isOrganizeTour" ></b-form-select>
            <input v-else class="form-control room-option text-center" type="text" :value="getRoomClassName(currentClassCode)" readonly/>
          </div>
        </div>
        <div class="col-6">
          <div class="form-group">
            <b-form-select v-model="currentBasis" :disabled="priceLoading" :options="optionsBasis" v-if="!isOrganizeTour" ></b-form-select>
            <input v-else class="form-control room-option text-center" type="text" :value="getRoomBasisName(currentBasis)" readonly/>
          </div>
        </div>
        <div class="col-6" v-if="!isOrganizeTour">
          <div class="form-group">
            <b-form-select v-model="countOfBaby" :disabled="priceLoading || babyDisallowed" :options="babies" ></b-form-select>
            <!-- <input v-else class="form-control room-option text-center" type="text" :value="`babies: ${countOfBaby}`" readonly/> -->
          </div>
        </div>
        <!-- <div class="col-4">
        </div> -->
        <div class="col-12 ptag">
          <p class="pl-2 mb-1">
            {{ $t('product-page.price-room') }}
          </p>
          <!--
          <p class="mb-2" v-if="countOfBaby === 0">
            ({{ $t('product-page.no-babies') }})
          </p>
          -->
          <p class="mb-2" v-if="countOfBaby && countOfBaby === 1">
            ({{ $t('product-page.infant') }} {{ countOfBaby }}<img :src="`${speedSizeDomain}/assets/img/icon_x.png`" alt="icon-x" width="15" height="15" />{{ getPriceWithSymbol(data.cc, 120) }})
          </p>
          <p class="mb-2" v-if="countOfBaby && countOfBaby > 1">
            ({{ $t('product-page.infants') }} {{ countOfBaby }}<img :src="`${speedSizeDomain}/assets/img/icon_x.png`" alt="icon-x" width="15" height="15" />{{ getPriceWithSymbol(data.cc, 120) }})
          </p>
          <p class="mb-2 p-price">
            <strong class="mx-3">{{ getPriceWithSymbol(data.cc, currentPrice) }}</strong>
            <s v-if="!isOdysseySite && !bypassPaymentState && !isMobileApp">{{ getPriceWithSymbol(data.cc, oldPrice) }}</s>
          </p>
        </div>
      </div>
    </div>
    <div class="card-body" v-if="device === 'desktop'">
      <h5>
        <strong v-if="lang === 'he'">
          <!-- {{ roomClassName }}, {{ $t('product-page.room') }} -->
          {{ roomClassName }},
          {{ $t(`product-page.ordered-number[${index}]`) }} :
          {{ personString }}
        </strong>
        <strong v-else>
          {{ roomClassName }},
          {{ $t(`product-page.ordered-number[${index}]`) }}
          {{ $t('product-page.room') }} : {{ personString }}
        </strong>
      </h5>
      <table class="table">
        <thead>
          <tr>
            <th class="text-center font-weight-bold">{{ $t('product-page.room-type') }}</th>
            <th class="text-center font-weight-bold">{{ $t('product-page.room-class') }}</th>
            <th class="text-center font-weight-bold">{{ $t('product-page.basis') }}</th>
            <th class="text-center font-weight-bold">{{ $t('product-page.price') }}</th>
          </tr>
        </thead>
        <tr>
          <td>
            <b-form-select v-model="currentType" ref="roomType" :disabled="priceLoading" :options="optionByRoomTypes"></b-form-select>
          </td>
          <td style="width: 100px;">
            <b-form-select v-model="currentClassCode" :disabled="priceLoading" :options="optionByRoomClasses" v-if="!isOrganizeTour"></b-form-select>
            <input v-else class="form-control room-option text-center" type="text" :value="getRoomClassName(currentClassCode)" readonly/>
          </td>
          <!-- <td>{{ currentBasisText }}</td> -->
          <td>
            <b-form-select v-model="currentBasis" :disabled="priceLoading" :options="optionsBasis" v-if="!isOrganizeTour"></b-form-select>
            <input v-else class="form-control room-option text-center" type="text" :value="getRoomBasisName(currentBasis)" readonly/>
          </td>
          <td>
            <b-spinner v-if="priceLoading"></b-spinner>
            <div v-else>
              <span>{{getPriceWithSymbol(data.cc, currentPrice)}}</span><br />
              <s v-if="!isOdysseySite && !bypassPaymentState && Number(oldPrice) > Number(currentPrice)">{{getPriceWithSymbol(data.cc, oldPrice)}}</s>
            </div>
          </td>
        </tr>
        <tr v-if="isMaccabiAgency"><td colspan="4"><span>{{ $t('product-page.enter-employee-number') }}</span></td></tr>
        <tr v-if="!isOrganizeTour && !isMaccabiAgency">
          <th class="align-middle">{{ $t('product-page.babies') }}:</th>
          <td colspan="2"> <b-form-select v-model="countOfBaby" :disabled="priceLoading || babyDisallowed" :options="babies"></b-form-select></td>
          <td></td>
          <td></td>
        </tr>
      </table>

      <button class="js-del-row" v-if="index > 0" @click="remove">
        <i class="far fa-window-close"></i>
      </button>
    </div>
  </div>
</template>

<script>
import { BFormSelect, BSpinner } from 'bootstrap-vue';
import dayjs from 'dayjs';
import { mapGetters } from 'vuex';
import gMixin from '@/utils/mixins';
import imageUrlMixin from '@/utils/imageUrlMixin';

const { VUE_APP_CHANNEL_MOBILE_APP, VUE_APP_MAX_DISCOUNT } = process.env;

export default {
  mixins: [gMixin, imageUrlMixin],
  components: {
    BFormSelect,
    BSpinner,
  },
  props: {
    index: {
      type: Number,
      default: 0,
    },
    data: {
      type: Object,
      default: null,
    },
    hotels: {
      type: Array,
      default: () => [],
    },
    translations: {
      type: Object,
      default: null,
    },
  },
  computed: {
    ...mapGetters({
      category: 'GET_CURRENT_CATEGORY',
      product: 'GET_PRODUCT',
      roomClassList: 'GET_ROOM_CLASS',
      roomTypeList: 'GET_ROOM_TYPE',
      lang: 'GET_LANGUAGE',
      device: 'GET_DEVICE',
      typeChannel: 'GET_TYPE_CHANNEL',
      flights: 'GET_FLIGHT_ID',
      isOdysseySite: 'GET_ODYSSEY_AGENT_STATE',
      bypassPaymentState: 'GET_BYPASS_PAYMENT_STATE',
      isMaccabiAgency: 'GET_IS_MACCABI_AGENCY',
    }),
  },
  data() {
    return {
      isOrganizeTour: '',
      personString: '',
      optionByRoomTypes: [],
      optionByRoomClasses: [],
      basisPackage: [],
      optionsBasis: [],
      conjugationBasis: [],
      currentClassCode: '',
      currentType: { code: '', kind: '' },
      currentTypeCode: '',
      currentBasis: '',
      currentBasisText: '',
      countOfBaby: 0,
      babies: [
        { value: 0, text: this.$t('product-page.noBabies') },
        { value: 1, text: 1 },
        { value: 2, text: 2 },
        { value: 3, text: 3 },
      ],
      currentPrice: 0,
      roomClassName: '',
      totalPrice: 0,
      oldPrice: 0,
      oldTotal: 0,
      priceLoading: false,
      isMobileApp: false,
      babyDisallowed: false,
      maccabiRoomTypeText: {
        SG: 'עובד חדר סינגל',
        DB: 'עובד + בן זוג   /  עובד + עובד',
      },
    };
  },
  watch: {
    data: {
      handler() {
        if (this.data.roomBasis !== this.currentBasis) {
          this.currentBasis = this.data.roomBasis;
          this.updateItem();
        }
      },
      deep: true,
    },
    currentClassCode(newValue, oldValue) {
      if (newValue === oldValue) return;
      // this.getRoomBasisOptions();
      this.updateItem();
      this.roomClassName = this.getRoomClassName(this.currentClassCode);
    },
    currentType(newValue, oldValue) {
      if (newValue === oldValue) return;
      this.currentTypeCode = this.currentType.code;
      this.getRoomClassOptions(this.currentTypeCode === this.$route.query.roomType);
      this.updateItem();
    },
    currentBasis(newValue, oldValue) {
      if (newValue === oldValue) return;
      this.updateItem();
    },
    countOfBaby(newValue, oldValue) {
      if (newValue === oldValue) return;
      this.updateItem();
    },
    priceLoading() {
      this.$emit('setPriceLoading', this.priceLoading);
    },
    flights() {
      this.updateItem();
    },
    lang() {
      this.updateItem();
      this.getRoomTypeOptions();
      // this.getRoomClassOptions('lang');
      this.getRoomBasisOptions();
      this.babies = [
        { value: 0, text: this.$t('product-page.noBabies') },
        { value: 1, text: 1 },
        { value: 2, text: 2 },
        { value: 3, text: 3 },
      ];
      this.roomClassName = this.getRoomClassName(this.currentClassCode);
    },
  },
  async created() {
    this.isOrganizeTour = this.category.code === 'Organize_tour_packages';

    // this.basisPackage = await this.$store.dispatch('FETCH_ROOM_BASIS_CONJUGATE', this.$route.query.packId);
    this.basisPackage = this.product.conjugatePackages;
    this.getRoomBasisOptions();
    if (this.data.roomBasis !== '') this.currentBasis = this.data.roomBasis;
    this.isMobileApp = this.typeChannel === VUE_APP_CHANNEL_MOBILE_APP;
  },
  beforeMount() {
    this.currentTypeCode = this.data.roomType?.value || this.$route.query.roomType;
    this.getRoomTypeOptions();
    this.countOfBaby = this.data.infant || Number(this.$route.query.infant);
  },
  methods: {
    async getRoomBasisOptions() {
      if (this.basisPackage.length === 0) return;
      const basis = [...new Set(this.basisPackage.map((item) => ({
        value: item.basis,
        text: item.basisTranslations[this.lang],
        packId: item.packId,
      })))];
      this.optionsBasis = basis;
      if (this.optionsBasis.length === 0) {
        this.$bvModal
          .msgBoxOk(this.$t('product-page.expire-message'), {
            title: this.$t('product-page.expire-title'),
            okVariant: 'danger',
            okTitle: this.$t('product-page.go-back'),
            headerClass: 'p-2 border-bottom-0',
            footerClass: 'p-2 border-top-0',
            centered: true,
          })
          .then(() => {
            // this.$router.push('/');
          })
          .catch(() => {
            // An error occurred
          });
      }
      const currBasis = basis.find((item) => item.packId === Number(this.$route.query.packId));
      this.currentBasis = currBasis?.value || basis[0].value;
    },
    getRoomTypeOptions() {
      const types = [...new Set(this.hotels.map((item) => item.Room_Type))];
      // this.optionByRoomTypes = types.map((item) => ({
      //   value: item,
      //   text: this.getRoomTypeName(item),
      // }));
      const onlyAdult = this.hotels[0].desc.includes('מבוגרים בלבד');
      this.optionByRoomTypes = [];
      types.forEach((item) => {
        const { adult, child } = this.getOccupancy(item);
        if (item === 'TR3') {
          if (this.currentTypeCode === item) {
            this.currentType = { code: item, kind: (Number(this.$route.query.adult) === 2 && Number(this.$route.query.child) === 1) ? 'TR3-2adu-1chd' : 'TR3-3adu' };
          }
          this.optionByRoomTypes.push({
            value: { code: item, kind: 'TR3-3adu' },
            text: this.lang === 'he' ? '3 מבוגרים' : '3adults',
            occupancy: adult + child,
          });
          if (!onlyAdult) {
            this.optionByRoomTypes.push({
              value: { code: item, kind: 'TR3-2adu-1chd' },
              text: this.lang === 'he' ? '2 מבוגרים וילד' : '2adults + 1child',
              occupancy: adult + child,
            });
          }
        } else {
          if (this.currentTypeCode === item) {
            this.currentType = { code: item, kind: item };
          }
          this.optionByRoomTypes.push({
            value: { code: item, kind: item },
            text: this.getRoomTypeName(item),
            occupancy: adult + child,
          });
        }
      });
      this.optionByRoomTypes.sort((a, b) => a.occupancy - b.occupancy);
      if (!this.$route.query.roomType) {
        this.currentType = this.optionByRoomTypes[0].value;
      }
      if (this.optionByRoomTypes.length === 0) {
        this.$bvModal
          .msgBoxOk(this.$t('product-page.expire-message'), {
            title: this.$t('product-page.expire-title'),
            okVariant: 'danger',
            okTitle: this.$t('product-page.go-back'),
            headerClass: 'p-2 border-bottom-0',
            footerClass: 'p-2 border-top-0',
            centered: true,
          })
          .then(() => {
            // this.$router.push('/');
          })
          .catch(() => {
            // An error occurred
          });
      }
    },
    getRoomClassOptions(isMounted) {
      const classes = [...new Set(this.hotels.filter((item) => item.Room_Type === this.currentTypeCode).map((item) => item.Room_Class))];
      const clsStd = this.data.roomClass?.value || this.$route.query.roomClass;
      const stdIdx = classes.indexOf(clsStd);
      if (stdIdx !== -1) {
        classes.splice(stdIdx, 1);
        classes.unshift(clsStd);
      }
      this.optionByRoomClasses = classes.map((item) => ({
        value: item,
        text: this.getRoomClassName(item),
      }));
      if (this.optionByRoomClasses.length === 0) {
        this.$bvModal
          .msgBoxOk(this.$t('product-page.expire-message'), {
            title: this.$t('product-page.expire-title'),
            okVariant: 'danger',
            okTitle: this.$t('product-page.go-back'),
            headerClass: 'p-2 border-bottom-0',
            footerClass: 'p-2 border-top-0',
            centered: true,
          })
          .then(() => {
            // this.$router.push('/');
          })
          .catch(() => {
            // An error occurred
          });
      }
      if (isMounted !== 'lang') {
        const existingClass = classes.indexOf(clsStd);
        if (existingClass !== -1) {
          this.currentClassCode = clsStd;
        } else {
          this.currentClassCode = classes[0];
        }
      }
    },
    getRoomClassName(roomClassCode) {
      const ts = this.translations?.Room_Class?.[roomClassCode]?.[this.lang] || this.translations?.Room_Class?.[roomClassCode]?.en;
      const classHotel = this.hotels.find((hotel) => (hotel.Room_Class === roomClassCode));
      return (this.isOdysseySite) ? `${ts || roomClassCode} ${classHotel.status}-${classHotel.free}` : ts || roomClassCode;
    },
    getRoomTypeName(roomTypeCode) {
      const { isMaccabiAgency, maccabiRoomTypeText } = this;
      const ts = isMaccabiAgency ? maccabiRoomTypeText[roomTypeCode] : this.translations?.Room_Type?.[roomTypeCode]?.[this.lang] || '';

      return ts || roomTypeCode;
    },
    getRoomBasisName(roomBasis) {
      const basis = this.optionsBasis.find((item) => item.value === roomBasis);
      return basis.text;
    },
    getPersonString(adult, child, infant) {
      let str = '';
      if (adult === 1) {
        str = `${adult} ${this.$t('product-page.adult')}`;
      } else {
        str = `${adult} ${this.$t('product-page.adults')}`;
      }
      if (child === 1) {
        str += ` + ${child} ${this.$t('product-page.child')}`;
      } else if (child > 1) {
        str += ` + ${child} ${this.$t('product-page.children')}`;
      }
      if (infant === 1) {
        str += ` + ${infant}  ${this.$t('product-page.infant')}`;
      } else if (infant > 1) {
        str += ` + ${infant}  ${this.$t('product-page.infants')}`;
      }
      return str;
    },
    remove() {
      this.$emit('closed', this.index);
    },
    availableDiscount(pPriceData) {
      let available = true;
      // if ((pPriceData.price_average / pPriceData.originalPrice.price_average) * 100 < (100 - VUE_APP_MAX_DISCOUNT)) available = false;
      if (pPriceData.discountPercent > VUE_APP_MAX_DISCOUNT) available = false;
      available = true;
      return available;
    },
    async updateItem() {
      if (this.priceLoading) return;
      let roomtype = this.currentTypeCode,
        { adult, child } = this.$route.query;
      const { packId, laId } = this.$route.query;

      const roomOption = this.optionByRoomTypes.filter(
        (opt) => opt.value.code === roomtype,
      )[0];

      const dataRoomType = this.roomTypeList.find((item) => item.code === this.currentTypeCode);

      if (roomOption && this.currentClassCode !== '' && dataRoomType) {
        // const { child: decideChild, adult: decideAdult, roomType: decideRoomType } = this.getOccupancy(roomtype);
        // if (decideRoomType === 'DB' || decideRoomType === 'TR3') {
        //   adult = decideAdult;
        //   child = decideChild;
        //   roomtype = decideRoomType;
        // }
        if (dataRoomType.code === 'DB') {
          adult = 2;
          child = 0;
        } else if (dataRoomType) {
          adult = dataRoomType.adultsMin;
          child = dataRoomType.maxPaX - dataRoomType.adultsMin;
        }
        if (this.currentTypeCode === 'TR3') {
          switch (this.currentType.kind) {
            case 'TR3-3adu':
              adult = 3; child = 0;
              break;
            case 'TR3-2adu-1chd':
              adult = 2; child = 1;
              break;
            default:
              adult = 3; child = 0;
          }
          roomtype = 'TR3';
        }

        const currBasis = this.currentBasis !== '' ? this.optionsBasis.find((item) => item.value === this.currentBasis) : this.optionsBasis.find((item) => item.packId === Number(packId));
        /**
         * This 'fromDate' variable was updated with 'hotel_shift_1' property in 'analysisProductData' function of the 'TemplateProductPage.vue'.
         */
        const { fromDate } = this.product;
        const body = {
          packId: currBasis ? currBasis.packId : packId,
          hotelid: laId,
          packSelectionId: this.product.packSelectionId,
          cls: this.currentClassCode,
          typ: roomtype,
          dateArv: dayjs(fromDate).format('DD/MM/YYYY'),
          infant: this.countOfBaby,
          flights: this.flights,
          adult,
          child,
        };
        this.priceLoading = true;
        const priceData = await this.$store.dispatch(
          'FETCH_PRICES_BY_CLASS_TYPE',
          body,
        );
        let updateData = null;
        if (priceData === 'error') {
          this.currentPrice = 0;
          this.priceLoading = false;
          this.totalPrice = 0;
          this.$emit('update', {
            success: false,
            message: {
              kind: 'error-fetching-price',
              message: this.$t('product-page.error-fetching-price'),
            },
          });
        // } else if (priceData.notAllowedExcessviveDiscount) {
        //   this.priceLoading = false;
        //   // this.totalPrice = 0;
        //   this.$emit('update', {
        //     success: false,
        //     message: {
        //       kind: 'error-discount',
        //       message: this.$t('product-page.error-discount'),
        //     },
        //   });
        } else {
          this.babyDisallowed = priceData.babyDisallowed;
          if (priceData.babyDisallowed && this.countOfBaby > 0) {
            this.countOfBaby = 0;
            const title = this.$t('product-page.title-warning-baby'),
              message = this.$t('product-page.message-warning-baby');
            this.$bvToast.toast(
              message,
              {
                title,
                autoHideDelay: 5000,
                appendToast: true,
                variant: 'warning',
                toaster: 'b-toaster-top-right',
                noClosebutton: true,
                bodyClass: this.lang === 'he' ? 'rtl' : 'ltr',
              },
            );
            this.priceLoading = false;
            this.totalPrice = 0;
            this.$emit('update', {
              success: false,
              message: {
                kind: 'error-disable-baby',
                message: this.$t('product-page.message-warning-baby'),
              },
            });
          } else {
            if (priceData.price_average > 9999) {
              this.$bvModal
                .msgBoxOk(this.$t('product-page.updating-now-message'), {
                  title: this.$t('product-page.expire-title'),
                  okVariant: 'danger',
                  okTitle: this.$t('product-page.go-back'),
                  headerClass: 'p-2 border-bottom-0',
                  footerClass: 'p-2 border-top-0',
                  centered: true,
                })
                .then(() => {
                  // this.$router.push('/');
                })
                .catch(() => {
                  // An error occurred
                });
              priceData.price_average = 0;
              priceData.price = 0;
            }
            this.currentPrice = priceData.price_average;
            if (priceData.price_average > 0) {
              updateData = {
                success: true,
                index: this.index,
                hotelId: laId,
                packSelectionId: this.product.packSelectionId,
                roomClass: {
                  text: this.roomClassName,
                  value: this.currentClassCode,
                },
                roomType: {
                  text: roomOption?.text,
                  value: roomOption?.value?.code,
                },
                roomBasis: this.currentBasis,
                roomBasisCode: currBasis,
                price: priceData.price_average,
                adult: priceData.adults,
                child: priceData.child,
                infant: this.countOfBaby,
                priceInf: priceData.priceInf,
                totalPrice: priceData.price, // TODO: should sum infant value
                oldPrice: priceData.originalPrice
                  ? priceData.originalPrice.price_average
                  : (Number(priceData.price_average) * 1.1).toFixed(0),
                oldTotal: priceData.originalPrice
                  ? priceData.originalPrice.price
                  : (Number(priceData.price) * 1.1).toFixed(0),
                cc: this.data.cc,
              };
              this.totalPrice = priceData.price;
              this.oldPrice = updateData.oldPrice;
              this.oldTotal = updateData.oldTotal;
              this.personString = this.getPersonString(
                updateData.adult,
                updateData.child,
                updateData.infant,
              );
              this.priceLoading = false;
              this.$emit('update', updateData);
            } else {
              this.priceLoading = false;
              this.totalPrice = 0;
              this.$emit('update', {
                success: false,
                message: {
                  kind: 'error-room-type',
                  message: this.$t('product-page.error-room-type'),
                },
              });
            }
          }
        }
      } else {
        this.priceLoading = false;
        this.totalPrice = 0;
        this.$emit('update', {
          success: false,
          message: {
            kind: 'error-room-type',
            message: this.$t('product-page.error-room-type'),
          },
        });
      }
    },
    getOccupancy(pRoomType) {
      let adult = 0, child = 0, roomType = pRoomType;

      const dataRoomType = this.roomTypeList.find((item) => item.code === pRoomType);

      if (dataRoomType.code === 'DB') {
        adult = 2;
        child = 0;
      } else if (dataRoomType) {
        adult = dataRoomType.adultsMin;
        child = dataRoomType.maxPaX - dataRoomType.adultsMin;
      }
      if (pRoomType === 'TR3') {
        switch (this.currentType.kind) {
          case 'TR3-3adu':
            adult = 3; child = 0;
            break;
          case 'TR3-2adu-1chd':
            adult = 2; child = 1;
            break;
          default:
            adult = 3; child = 0;
        }
        roomType = 'TR3';
      }
      return { adult, child, roomType };
    },
  },
};
</script>

<style scoped>
s {
  opacity: 0.5;
}
.ptag {
  text-align: center;
}
.p-price {
  display: inline-flex;
  align-items: baseline;
}
.table > thead > tr > th {
  padding: 12px 3px;
}
.table td {
  padding: 0.75rem 0.1rem;
  vertical-align: middle;
  text-align: center;
}
@media (max-width: 479px) {
  .card-body {
    padding: 0.25rem;
  }
  .flight-details-leftbox .table > tbody > tr > td,
  .flight-details-leftbox .table > tbody > tr > th,
  .flight-details-leftbox .table > tfoot > tr > td,
  .flight-details-leftbox .table > tfoot > tr > th,
  .flight-details-leftbox .table > thead > tr > td,
  .flight-details-leftbox .table > thead > tr > th {
    padding: 4px;
  }
}
.form-check-input {
  right: -15px;
}
.form-control[readonly] {
  background: #FFF !important;
}
.room-option {
  font-size: 16px;
}
</style>
<style>

.chooseroom_area .custom-select {
  padding: 0.375rem 1.55rem 0.375rem 0.05rem;
}
</style>
