<template>
  <form action="" @submit.stop.prevent="() => {}">
    <div class="form-row desktop_form" v-if="type === 'tabs'">
      <div class="form-group col-md-2">
        <ComboBox
          @change="changedCountry"
          type="fa fa-map-marker-alt"
          :options="countries"
          :selected="country"
          :placeholder="$t('search-tab.choose-country')"
          @optionSelect="optionSelectCountry"
        />
      </div>
      <div class="form-group col-md-3">
        <ComboBox
          @change="changedDestination"
          type="fa fa-hotel"
          :options="listDestinations"
          :selected="destination"
          :placeholder="$t('search-tab.choose-destination')"
          :showList="selectedCountry"
          @optionSelect="optionSelectDestination"
        />
      </div>
      <div class="form-group col-md-3">
        <perioddatepicker
          :calendarShow="destinationChanged"
          @finalDateSelect="finalDateSelect"
          @dates="chooseDate"
          :selectedFrom="fromDate"
          :selectedTo="toDate"
        ></perioddatepicker>
      </div>
      <div class="form-group col-md-3">
        <PaxInformation
          @changeBodyCount="changeCount"
          @changedAgeState="changedAgeState"
          :dropdownShow="dropdownShow"
          :tourists="tourists"
        />
      </div>
      <div class="form-group col-md-1 d-flex">
        <button
          class="btn flex-fill p-0"
          @click="submitSearch"
          :disabled="searchDisable"
        >
          {{ $t('search-tab.search') }}
          <b-spinner v-if="isLoading"></b-spinner>
          <i class="fas fa-search" v-else></i>
        </button>
      </div>
    </div>

    <!-- <MobileSearchForm/> -->
    <div
      class="card card-body boxSideSearch border-0"
      :class="{ mobile_form: type === 'tabs' }"
    >
      <div class="form-row">
        <div class="form-group col-12">
          <label for="serchItem">{{
            $t('search-tab.mobile-form.country-label')
          }}</label>
          <ComboBox
            @change="changedCountry"
            :options="countries"
            :selected="country"
            type="fa fa-map-marker-alt"
            :placeholder="$t('search-tab.choose-country')"
            @optionSelect="optionSelectCountry"
          />
        </div>
        <div class="form-group col-12">
          <label for="serchItem">{{
            $t('search-tab.mobile-form.destination-label')
          }}</label>
          <ComboBox
            @change="changedDestination"
            type="fa fa-hotel"
            :options="listDestinations"
            :selected="destination"
            :placeholder="$t('search-tab.choose-destination')"
            :showList="selectedCountry"
            @optionSelect="optionSelectDestination"
          />
        </div>
        <div class="form-group col-12">
          <label for="startDate">{{
            $t('search-tab.mobile-form.start-date')
          }}</label>
          <div class="input-group">
            <perioddatepicker
              :calendarShow="destinationChanged"
              @finalDateSelect="finalDateSelect"
              @dates="chooseDate"
              :selectedFrom="fromDate"
              :selectedTo="toDate"
            ></perioddatepicker>
          </div>
        </div>
        <div class="form-group col-4">
          <b-form-select class="form-control" v-model="countAdult">
            <template #first>
              <b-form-select-option :value="0" disabled>{{
                $t('search-tab.adult')
              }}</b-form-select-option>
            </template>
            <option v-for="inx in 6" :key="inx" :value="inx - 1">{{
              inx - 1
            }}</option>
          </b-form-select>
        </div>
        <div class="form-group col-4">
          <b-form-select class="form-control" v-model="countChild">
            <template #first>
              <b-form-select-option :value="0" disabled>{{
                $t('search-tab.child')
              }}</b-form-select-option>
            </template>
            <option v-for="inx in 6" :key="inx" :value="inx - 1">{{
              inx - 1
            }}</option>
          </b-form-select>
          <PaxAge
            v-for="i in Number(countChild)"
            :key="i"
            :index="i"
            :selected="listAgeChildren[i]"
            :options="rangeAgeChildren"
            @change="updateAgeChildren"
          ></PaxAge>
        </div>
        <div class="form-group col-4">
          <b-form-select class="form-control" v-model="countInfant">
            <template #first>
              <b-form-select-option :value="0" disabled>{{
                $t('search-tab.infant')
              }}</b-form-select-option>
            </template>
            <option v-for="inx in 6" :key="inx" :value="inx - 1">{{
              inx - 1
            }}</option>
          </b-form-select>
          <PaxAge
            v-for="i in Number(countInfant)"
            :key="i"
            :index="i"
            :selected="listAgeInfants[i]"
            :options="rangeAgeInfants"
            @change="updateAgeInfants"
          ></PaxAge>
        </div>
        <div class="form-group col-6 d-flex">
          <button
            class="btn flex-fill btn-outline-dark btn-search"
            @click="submitSearch"
            :disabled="searchDisable"
          >
            {{ $t('search-tab.search') }}
            <b-spinner v-if="isLoading" small></b-spinner>
            <i class="fas fa-search" v-else></i>
          </button>
        </div>
      </div>
    </div>
  </form>
</template>

<script>
import { mapGetters } from 'vuex';
import { BFormSelect, BFormSelectOption, BSpinner } from 'bootstrap-vue';

export default {
  name: 'SearchTab',
  components: {
    PaxAge: () => import('@/components/atoms/PaxAge'),
    PaxInformation: () => import('@/components/atoms/PaxInformation'),
    ComboBox: () => import('@/components/atoms/ComboSearchSelect'),
    perioddatepicker: () => import('@/components/atoms/PeriodDatepicker'),
    BFormSelect,
    BFormSelectOption,
    BSpinner,
  },
  props: {
    category: {
      type: Object,
      default: null,
    },
    type: {
      type: String,
      default: 'tabs',
    },
  },
  data() {
    return {
      query: '',

      categoryId: null,

      countries: [],
      country: null,
      selectedCountry: false,

      listDestinations: [],
      destination: null,
      destinationChanged: false,

      fromDate: '',
      toDate: '',
      dropdownShow: false,

      listAgeChildren: [],
      listAgeInfants: [],

      tourists: {
        adult: 0,
        child: 0,
        infant: 0,
        listAgeChildren: [],
        listAgeInfants: [],
      },
      fullAgeChildren: true,

      isReload: true,
      isActive: false,
    };
  },
  computed: {
    ...mapGetters({
      listCountries: 'GET_LIST_COUNTRIES',
      isLoading: 'GET_LOADING_STATE',
      lang: 'GET_LANGUAGE',
      searchContent: 'GET_SEARCH_CONTENT',
      rangeAgeChildren: 'GET_RANGE_AGE_CHILDREN',
      rangeAgeInfants: 'GET_RANGE_AGE_INFANTS',
      isFcAgentMarketerMode: 'GET_FC_AGENT_MARKETER_MODE',
    }),
    searchDisable() {
      return (
        !this.country
        || !this.destination
        || !this.fromDate
        || !this.toDate
        || !this.countAdult
        || !this.fullAgeChildren
      );
    },
    countAdult: {
      get() {
        return this.$store.getters.GET_SEARCH_CONTENT.adult
          ? this.$store.getters.GET_SEARCH_CONTENT.adult
          : 2;
      },
      set(value) {
        if (this.countAdult !== value) this.$store.dispatch('SET_SEARCH_ITEM', ['adult', value]);
      },
    },
    countChild: {
      get() {
        return this.$store.getters.GET_SEARCH_CONTENT.child
          ? this.$store.getters.GET_SEARCH_CONTENT.child
          : 0;
      },
      set(value) {
        if (this.countChild !== value) this.$store.dispatch('SET_SEARCH_ITEM', ['child', value]);
      },
    },
    countInfant: {
      get() {
        return this.$store.getters.GET_SEARCH_CONTENT.infant
          ? this.$store.getters.GET_SEARCH_CONTENT.infant
          : 0;
      },
      set(value) {
        if (this.countInfant !== value) this.$store.dispatch('SET_SEARCH_ITEM', ['infant', value]);
      },
    },
    isSearchResultPage() {
      return this.$route.name === 'search-result';
    },
  },
  watch: {
    countChild() {
      this.updateFullAgeChildren();
    },
    countInfant() {
      this.updateFullAgeChildren();
    },
    searchContent: {
      handler(value) {
        if (!this.country || this.country.value !== value.country) {
          this.country = this.countries.find(
            (item) => item.value === value.country,
          );
        }
        if (!this.destination || this.destination.value !== value.dest) {
          if (this.listDestinations) {
            this.destination = this.listDestinations.find(
              (item) => item.value === value.dest,
            );
          }
        }
        // this.tourists = {
        //   adult: value.adult ? value.adult : 2,
        //   child: value.child,
        //   infant: value.infant,
        //   listAgeChildren: value.listAgeChildren,
        //   listAgeInfants: value.listAgeInfants,
        // };
      },
      deep: true,
    },
  },
  created() {
    this.query = this.$route.query;
    if (this.isSearchResultPage && this.query.categoryId === 'Hotel_Only') {
      const ages = this.query.ages.split(',');
      let idxChild = 1,
        idxInfant = 1;
      ages.forEach((el) => {
        if (el > 2) {
          this.listAgeChildren[idxChild] = Number(el);
          idxChild += 1;
        } else {
          this.listAgeInfants[idxInfant] = Number(el);
          idxInfant += 1;
        }
      });
      this.tourists = {
        adult: this.query.adult,
        child: this.query.child,
        infant: this.query.infant,
        listAgeChildren: this.listAgeChildren,
        listAgeInfants: this.listAgeInfants,
      };
      if (this.tourists.adult !== this.searchContent.adult) {
        this.$store.dispatch('SET_SEARCH_ITEM', ['adult', this.tourists.adult]);
      }
      if (this.tourists.child !== this.searchContent.child) {
        this.$store.dispatch('SET_SEARCH_ITEM', ['child', this.tourists.child]);
      }
      if (this.tourists.infant !== this.searchContent.infant) {
        this.$store.dispatch('SET_SEARCH_ITEM', [
          'infant',
          this.tourists.infant,
        ]);
      }
      if (
        this.tourists.listAgeChildren.join(',')
        !== this.searchContent.listAgeChildren.join(',')
      ) {
        this.$store.dispatch('SET_SEARCH_ITEM', [
          'listAgeChildren',
          this.tourists.listAgeChildren,
        ]);
      }
      if (
        this.tourists.listAgeInfants.join(',')
        !== this.searchContent.listAgeInfants.join(',')
      ) {
        this.$store.dispatch('SET_SEARCH_ITEM', [
          'listAgeInfants',
          this.tourists.listAgeInfants,
        ]);
      }
    } else {
      this.tourists = {
        adult: 2,
        child: 0,
        infant: 0,
        listAgeChildren: this.listAgeChildren,
        listAgeInfants: this.listAgeInfants,
      };
      this.isReload = false;
    }
    this.changedCategory();
  },
  methods: {
    async submitSearch(event) {
      event.preventDefault();
      if (this.isLoading) {
        this.$bvModal.msgBoxOk(
          this.$t('search-tab.is-loading-warning-message'),
          {
            title: this.$t('search-tab.is-loading-warning-message-title'),
            size: 'sm',
            buttonSize: 'sm',
            okVariant: 'success',
            headerClass: 'p-2 border-bottom-0',
            footerClass: 'p-2 border-top-0',
            centered: true,
          },
        );
        return false;
      }

      if (this.searchDisable) {
        return false;
      }
      const ages = [];
      this.searchContent.listAgeChildren
        .concat(this.searchContent.listAgeInfants)
        .forEach((el) => {
          ages.push(el);
        });
      const body = {
        country: this.country.value,
        dest: this.destination.value,
        fromDate: this.fromDate,
        toDate: this.toDate,
        categoryId: this.category.code,
        adult: this.countAdult,
        child: this.countChild,
        infant: this.countInfant,
        ages: ages.join(','),
      };
      if (
        Object.keys(body).every(
          (key) => String(body[key]) === String(this.query[key]),
        )
      ) return false;

      this.$router.push({ path: '/search-result', query: body });
      return true;
    },
    resetDate() {
      this.fromDate = '';
      this.toDate = '';
      this.destinationChanged = false;
    },
    resetDestination() {
      this.description = null;
      this.$store.dispatch('SET_SEARCH_ITEM', ['dest', '']);
      this.selectedCountry = false;
    },
    async changedCategory() {
      this.categoryId = this.category.code;
      if (this.isSearchResultPage && this.listCountries.length === 0) {
        await this.$store.dispatch('FETCH_LIST_COUNTRIES');
      }

      let currCountry = null;
      this.listCountries.forEach((item, idx) => {
        const countryItem = {
          id: idx,
          value: item.code,
          label: item.description.content,
        };
        this.countries.push(countryItem);
        if (
          this.isReload
          && this.isSearchResultPage
          && countryItem.value === this.query.country
        ) currCountry = countryItem;
      });
      if (this.isSearchResultPage && currCountry) this.changedCountry(currCountry);
    },
    async changedCountry(pCountry) {
      // this.resetDate();
      this.resetDestination();

      this.country = pCountry;
      await this.$store.dispatch('SET_SEARCH_ITEM', [
        'country',
        pCountry.value,
      ]);

      let currDest = null;
      if (!pCountry) {
        this.listDestinations = [];
        // this.changedDestination(currDest);
      } else {
        const response = await this.$store.dispatch(
          'FETCH_LIST_DESTINATION',
          pCountry.value,
        );
        this.listDestinations = [];
        response.data.forEach((item, idx) => {
          const dest = {
            id: idx,
            value: item.code,
            label: item.name.content,
          };
          this.listDestinations.push(dest);
          if (
            this.isReload
            && this.isSearchResultPage
            && dest.value === this.query.dest
          ) currDest = dest;
        });
        this.changedDestination(currDest);

        this.selectedCountry = this.isActive;
      }
    },
    optionSelectCountry(value) {
      if (
        (value === true && this.listDestinations.lenght > 0)
        || value === false
      ) {
        this.selectedCountry = value;
      }
      this.isActive = true;
      this.isReload = false;
    },
    optionSelectDestination(value) {
      this.isActive = true;
      this.isReload = false;
      this.destinationChanged = value;
    },
    changedDestination(pDestination) {
      if (pDestination) {
        // this.resetDate();
        this.destination = pDestination;
        this.$store.dispatch('SET_SEARCH_ITEM', ['dest', pDestination.value]);
        this.selectedCountry = false;

        if (this.isSearchResultPage) {
          this.fromDate = this.query.fromDate;
          this.toDate = this.query.toDate;
          this.countAdult = Number(this.query.adult);
          this.countChild = Number(this.query.child);
          this.countInfant = Number(this.query.infant);

          this.$emit(
            'updatedDestination',
            `${this.destination.label} ${this.country.label}`,
          );
        }

        this.destinationChanged = this.isActive;
        this.isReload = false;
      }
    },
    finalDateSelect(value) {
      this.dropdownShow = value;
    },
    changeCount({ adult, child, infant }) {
      this.countAdult = adult;
      this.countChild = child;
      this.countInfant = infant;
    },
    chooseDate(date) {
      this.fromDate = date.from;
      this.toDate = date.to;
    },
    updateAgeChildren(pObj) {
      this.listAgeChildren.splice(this.countChild);
      this.listAgeChildren[pObj.index] = pObj.value;
      this.$store.dispatch('SET_SEARCH_ITEM', [
        'listAgeChildren',
        this.listAgeChildren,
      ]);
      this.updateFullAgeChildren();
    },
    updateAgeInfants(pObj) {
      this.listAgeInfants.splice(this.countInfant);
      this.listAgeInfants[pObj.index] = pObj.value;
      this.$store.dispatch('SET_SEARCH_ITEM', [
        'listAgeInfants',
        this.listAgeInfants,
      ]);
      this.updateFullAgeChildren();
    },
    updateFullAgeChildren() {
      let ageState = true;
      for (let i = 0; i < this.countChild; i += 1) {
        if (this.searchContent.listAgeChildren[i + 1] === undefined) {
          ageState = false;
          break;
        }
      }
      for (let i = 0; i < this.countInfant; i += 1) {
        if (this.searchContent.listAgeInfants[i + 1] === undefined) {
          ageState = false;
          break;
        }
      }
      this.fullAgeChildren = ageState;
    },
    changedAgeState(pState) {
      this.$store.dispatch('SET_SEARCH_ITEM', [
        'listAgeChildren',
        pState.listAgeChildren,
      ]);
      this.$store.dispatch('SET_SEARCH_ITEM', [
        'listAgeInfants',
        pState.listAgeInfants,
      ]);
      this.fullAgeChildren = pState.full;
    },

    // finalDateSelect(value) {
    //   this.dropdownShow = value;
    // },
  },
};
</script>

<style scoped>
@media (max-width: 479px) {
  .mobile_form {
    display: block;
  }
  .desktop_form {
    display: none;
  }
}
.custom-control {
  padding-right: 1rem;
}
</style>

<style>
.custom-control-input {
  left: auto;
  right: 0;
}
.filter-tab .custom-control-label::before,
.filter-tab .custom-control-label::after {
  right: -1.5rem;
  left: auto;
}
.vs__dropdown-toggle {
  background: #e9ecef !important;
}
</style>
