<template>
  <form action="" @submit.stop.prevent="() => {}">
    <b-form-group class="mr-5">
      <b-form-radio-group
      v-model="selectedCategory"
      :options="categoryOptions"
      name="radio-sub-category"
      @change="changeCategory"
      ></b-form-radio-group>
    </b-form-group>
    <div class="form-row desktop_form" v-if="type === 'tabs'">
      <div class="form-group col-md-3">
        <Select
          @changeDestination="changed"
          :type="type"
          @optionSelect="optionSelect"
        />
      </div>
      <div class="form-group col-md-3">
        <app-datepicker
          :availableDates="availableDates"
          :calendarShow="destinationChanged"
          @finalDateSelect="finalDateSelect"
          @dates="chooseDate"
        ></app-datepicker>
      </div>
      <div class="form-group col-md-3">
        <Dropdown @changeBodyCount="changeCount" :dropdownShow="dropdownShow" />
      </div>
      <div class="form-group col-md-3 d-flex" syle="height:3rem;">
        <button
          class="btn flex-fill"
          @click="submitSearch"
          :disabled="searchDisable"
        >
          {{ categoryId ? $t(`search-tab.search_${categoryId}`) : '' }}
          <b-spinner v-if="isLoading"></b-spinner>
          <i class="fas fa-search ml-3" v-else></i>
        </button>
      </div>
    </div>

    <!-- <MobileSearchForm/> -->
    <div class="card card-body boxSideSearch border-0" :class="{ mobile_form: type === 'tabs' }">
      <div class="form-row">
        <div class="form-group col-12">
          <Select
            @changeDestination="changed"
            :type="type"
            @optionSelect="optionSelect"
          />
        </div>
        <div class="form-group col-12">
          <div class="input-group">
            <app-datepicker
              :availableDates="availableDates"
              :calendarShow="destinationChanged"
              @dates="chooseDate"
              type="side"
            ></app-datepicker>
          </div>
        </div>
        <div class="form-group col-4">
          <b-form-select class="form-control" v-model="countAdult">
            <template #first>
              <b-form-select-option :value="0" disabled>{{ $t('search-tab.adult') }}</b-form-select-option>
            </template>
            <option v-for="inx in 6" :key="inx" :value="inx - 1">{{ inx - 1 }}</option>
          </b-form-select>
        </div>
        <div class="form-group col-4">
          <b-form-select class="form-control" v-model="countChild">
            <template #first>
              <b-form-select-option :value="0" disabled>{{ $t('search-tab.child') }}</b-form-select-option>
            </template>
            <option v-for="inx in 6" :key="inx" :value="inx - 1">{{ inx - 1 }}</option>
          </b-form-select>
        </div>
        <div class="form-group col-4">
          <b-form-select class="form-control" v-model="countInfant">
            <template #first>
              <b-form-select-option :value="0" disabled>{{
                $t('search-tab.infant')
              }}</b-form-select-option>
            </template>
            <option v-for="inx in 6" :key="inx" :value="inx - 1">{{ inx - 1 }}</option>
          </b-form-select>
        </div>
        <div class="form-group d-flex">
          <button
            class="btn flex-fill btn-outline-dark btn-search mobile"
            @click="submitSearch"
            :disabled="searchDisable"
          >
            {{ categoryId ? $t(`search-tab.search_${categoryId}`): '' }}
            <b-spinner v-if="isLoading" small></b-spinner>
            <i class="fas fa-search" v-else></i>
          </button>
        </div>
      </div>
    </div>
  </form>
</template>

<script>
import { mapGetters } from 'vuex';
import {
  BFormGroup,
  BFormRadioGroup,
  // BFormRadio,
  BFormSelect,
  BFormSelectOption,
  BSpinner,
} from 'bootstrap-vue';

export default {
  name: 'SearchTab',
  components: {
    Dropdown: () => import('@/components/atoms/Dropdown'),
    Select: () => import('@/components/atoms/SearchSelect'),
    'app-datepicker': () => import('@/components/atoms/CustomDatepicker'),
    BFormGroup,
    BFormRadioGroup,
    // BFormRadio,
    BFormSelect,
    BFormSelectOption,
    BSpinner,
  },
  props: {
    category: {
      type: Object,
      default: null,
    },
    type: {
      type: String,
      default: 'tabs',
    },
  },
  computed: {
    ...mapGetters({
      categories: 'GET_CATEGORIES',
      currCategory: 'GET_CURRENT_CATEGORY',
      calendarData: 'GET_CALENDAR_DATA',
      isLoading: 'GET_LOADING_STATE',
      lang: 'GET_LANGUAGE',
      isLanding: 'GET_IS_LANDING_PAGE',
      landingInfo: 'GET_LANDING_INFO',
      marketerId: 'GET_MARKETER_ID',
      isFcAgentMarketerMode: 'GET_FC_AGENT_MARKETER_MODE',
    }),
    searchDisable() {
      return (
        !this.destination || !this.fromDate || !this.toDate || !this.countAdult
      );
    },
    countAdult: {
      get() {
        return this.$store.getters.GET_SEARCH_CONTENT.adult ? this.$store.getters.GET_SEARCH_CONTENT.adult : 2;
      },
      set(value) {
        this.$store.dispatch('SET_SEARCH_ITEM', ['adult', value]);
      },
    },
    countChild: {
      get() {
        return this.$store.getters.GET_SEARCH_CONTENT.child ? this.$store.getters.GET_SEARCH_CONTENT.child : 0;
      },
      set(value) {
        this.$store.dispatch('SET_SEARCH_ITEM', ['child', value]);
      },
    },
    countInfant: {
      get() {
        return this.$store.getters.GET_SEARCH_CONTENT.infant ? this.$store.getters.GET_SEARCH_CONTENT.infant : 0;
      },
      set(value) {
        this.$store.dispatch('SET_SEARCH_ITEM', ['infant', value]);
      },
    },
    categoryOptions() {
      const options = [];
      this.categories.forEach((cate) => {
        if (cate.code === 'Flight_Only' || cate.code === 'Flight_Drive') options.push({ text: cate.name[this.lang], value: cate.code });
      });
      return options;
    },
  },
  watch: {
    category: 'changedCategory',
    currCategory() {
      this.selectedCategory = this.currCategory.code;
    },
  },
  data() {
    return {
      categoryId: '',
      availableDates: [],
      minDate: 'today',
      travelWork: false,

      selectedCategory: 'Flight_Only',

      destination: '',
      selectFamilyAll: 'all',
      fromDate: '',
      toDate: '',
      destinationChanged: false,
      dropdownShow: false,
      progressValue: 0,
    };
  },
  async beforeMount() {
    if (!this.calendarData) {
      await this.$store.dispatch('FETCH_CALENDAR_DATA');
    }
    this.changedCategory();
  },
  methods: {
    async submitSearch(event) {
      event.preventDefault();
      if (this.isLoading) {
        this.$bvModal.msgBoxOk(
          this.$t('search-tab.is-loading-warning-message'),
          {
            title: this.$t('search-tab.is-loading-warning-message-title'),
            size: 'sm',
            buttonSize: 'sm',
            okVariant: 'success',
            headerClass: 'p-2 border-bottom-0',
            footerClass: 'p-2 border-top-0',
            centered: true,
          },
        );
        return false;
      }
      if (this.type === 'mobile') {
        this.$emit('closeSearchMobile');
      }

      if (this.searchDisable) {
        return false;
      }
      const body = {
        dest: this.destination,
        fromDate: this.fromDate,
        toDate: this.toDate,
        categoryId: this.selectedCategory,
        adult: this.countAdult,
        child: this.countChild,
        infant: this.countInfant,
      };
      if (this.$route.query.utm_source) body.utm_source = this.$route.query.utm_source;
      if (this.isLanding) body.utm_source = this.landingInfo.utm_source;
      if (this.marketerId) body.marketerId = this.marketerId;
      if (this.$route.query.secret) body.secret = this.$route.query.secret; // temporary param for Ran's search
      if (this.isFcAgentMarketerMode) body['fc-agent-mode'] = '';
      const { query } = this.$route;
      if (Object.keys(body).every((key) => String(body[key]) === String(query[key]))) return false;

      this.$router.push({ path: '/search-result', query: body });
      if (this.isLanding) {
        setTimeout(() => {
          this.$router.go();
        }, 10);
      }
      return true;
    },
    resetDate() {
      this.$store.dispatch('SET_SEARCH_ITEM', ['from', '']);
      this.$store.dispatch('SET_SEARCH_ITEM', ['to', '']);
    },
    optionSelect(value) {
      this.destinationChanged = value;
    },
    changed(dest) {
      if (!dest) return false;
      this.resetDate();
      this.destination = dest.value;

      const activeCategory = this.categories.find((cate) => this.categoryId === cate.code),
        categorySubjectIdList = activeCategory?.subjectCodes || [];

      if (this.calendarData) {
        this.availableDates = this.calendarData.filter(
          (rec) => rec.dest === dest.value && categorySubjectIdList.includes(rec.sub),
          // (rec) => categorySubjectIdList.includes(rec.sub),
        );
      }
      return true;
    },
    chooseDate(date) {
      this.fromDate = date.from;
      this.toDate = date.to;
    },
    finalDateSelect(value) {
      this.dropdownShow = value;
    },
    changeCount({ adult, child, infant }) {
      this.countAdult = adult;
      this.countChild = child;
      this.countInfant = infant;
    },
    changedCategory() {
      this.selectedCategory = this.$route.query.categoryId || this.category?.code || 'Flight_Only';
      this.categoryId = this.category.code;
    },
    changeCategory() {
      this.destinationChanged = false;
      this.categoryId = this.selectedCategory;
      this.$store.dispatch('UPDATE_CURRENT_CATEGORY', { categoryId: this.selectedCategory });
      this.$store.dispatch('RESET_SEARCH_CONTENT');
    },
  },
};
</script>

<style scoped>
@media (max-width: 479px) {
  .mobile_form {
    display: block;
  }
  .desktop_form {
    display: none;
  }
  .btn-search{
    padding-right: 20px;
  }
}
.custom-control {
  padding-right: 1rem;
}
</style>

<style>
.custom-control-input {
  left: auto;
  right: 0;
}
.filter-tab .custom-control-label::before,
.filter-tab .custom-control-label::after {
  right: -1.5rem;
  left: auto;
}
.vs__dropdown-toggle {
  background: #e9ecef !important;
}
</style>
