<template>
  <div v-if="(type==='price' || !hideCondition)"
    class="filter-tab py-sm-5 py-md-0"
    :class="{ 'search-result': isSearchPage, 'set-background': (device === 'mobile' && !isLanding), 'side-panel': type === 'side' }"
  >
    <div class="container" v-if="type==='tabs' || type==='side'">
      <div class="row">
        <div class="col-12 filter-Wrap1" :class="{'mb-1': isOdysseySite}">
          <b-tabs card fill @input="changeCategory" v-model="tabIndex">
            <b-tab
              v-for="(cate, index) in showingCategories"
              :key="index"
              :active="index === tabIndex"
            >
              <template #title>
                <img :src="images[cate.sort]" alt="category-image" class="img-fluid m-auto m-0" width="32" height="32"/>
                {{ cate.name[lang] }}
              </template>
              <!-- <div v-if="isLoading" class="loading-message">
                {{ $t('search-tab.loading-message') }}
              </div>
              <ContentLoading v-if="isLoading" type="search-tab" /> -->
              <b-card-text v-if="activeCategory && activeCategory.dealTypeCode === 'vacation_pack'">
                <SearchTabFH
                  :category="activeCategory"
                  :agentList="agentList"
                  v-if="tabIndex === index"
                  :type="device === 'mobile' ? 'mobile' : type"
                  @closeSearchMobile="closeSearchMobile" />
              </b-card-text>
              <b-card-text v-if="activeCategory && activeCategory.dealTypeCode === 'Flight_Only'">
                <SearchTab
                  :category="activeCategory"
                  :agentList="agentList"
                  v-if="tabIndex === index"
                  :type="device === 'mobile' ? 'mobile' : type"
                  @closeSearchMobile="closeSearchMobile" />
              </b-card-text>
              <b-card-text v-else-if="activeCategory && activeCategory.dealTypeCode === 'Organize_tour_packages'">
                <SearchTabOT
                  :category="activeCategory"
                  :agentList="agentList"
                  v-if="tabIndex === index"
                  :type="device === 'mobile' ? 'mobile' : type"
                  @closeSearchMobile="closeSearchMobile" />
              </b-card-text>
              <!-- <b-card-text v-else-if="activeCategory && activeCategory.dealTypeCode === 'Flight_Only'">
                <SearchTabFOD
                  :category="activeCategory"
                  v-if="tabIndex === index"
                  :type="device === 'mobile' ? 'mobile' : type"
                  @closeSearchMobile="closeSearchMobile" />
              </b-card-text> -->
            </b-tab>

            <!-- <b-tab :key="hotelOnly.sort" :active="tabIndex === 3">
              <template #title>
                <img :src="images[4]" alt="hotel-only" class="img-fluid" />
                {{ hotelOnly.name[lang] }}
              </template>
              <div v-if="isLoading" class="loading-message">
                {{ $t('search-tab.loading-message') }}
              </div>
              <ContentLoading v-if="isLoading" type="search-tab" />
              <b-card-text v-else>
                <SeatchTabHO :category="hotelOnly" v-if="tabIndex === 3" />
              </b-card-text>
            </b-tab> -->
          </b-tabs>
        </div>
      </div>
    </div>
    <div class="container" v-else-if="type==='price'">
      <div class="row">
        <div class="col-12 filter-Wrap1">
          <b-tabs card fill v-model="tabIndex" @input="changeCategory">
            <b-tab
              v-for="(cate, index) in showingCategories"
              :key="index"
              :active="index === tabIndex"
            >
              <template #title>
                <img :src="images[cate.sort]" alt="category-image" class="img-fluid m-auto m-0" />
                {{ cate.name[lang] }}
              </template>

              <b-card-text>
                <price-plan-search-box :category="cate" v-if="activeCategory && activeCategory.dealTypeCode === cate.code"/>
              </b-card-text>
            </b-tab>
          </b-tabs>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { BTabs, BTab, BCardText } from 'bootstrap-vue';
import TemplateSearchTabs from './TemplateSearchTabs';

export default {
  name: 'SearchTabsTheme0',
  components: {
    BTabs,
    BTab,
    BCardText,
    SearchTab: () => import('@/components/search/searchTab/SearchTabTheme0'),
    SearchTabFH: () => import('@/components/search/searchTabFH/SearchTabFHTheme0'),
    SearchTabOT: () => import('@/components/search/searchTabOT/SearchTabOTTheme0'),
    // SearchTabFOD: () => import('./SearchTabFOD'),
    // SeatchTabHO: () => import('./SearchTabHO'),
    // ContentLoading: () => import('@/components/atoms/ContentLoading'),
    PricePlanSearchBox: () => import('@/components/pricePlan/PricePlanSearchBox'),
  },
  extends: TemplateSearchTabs,
};
</script>

<style>
/** side bar search panel style */
.side-panel .container{
  padding: 0px;
}
.side-panel .container .tab-pane.card-body {
  padding: 0;
}
.side-panel.filter-tab .tabs .card-header {
  padding-top: 0;
}
.side-panel.filter-tab form button.btn.btn-search {
  color: #343a40;
}
.side-panel.filter-tab .tabs .card-header ul.nav.nav-tabs.card-header-tabs.nav-fill {
  flex-wrap: nowrap;
}
.side-panel .nav-fill > .nav-link,
.side-panel .nav-fill .nav-item {
  flex: 1 1 0px;
}
.side-panel.filter-tab .nav-tabs .nav-link {
  display: grid;
  flex-wrap: wrap;
  line-height: 14px;
  align-items: center;
  justify-content: unset;
}
.side-panel.filter-tab .nav-fill .nav-item {
  background-color: rgba(188, 225, 253, 0.5);
}
.side-panel.filter-tab .nav-fill .nav-item .nav-link{
  padding: 0.5rem 0rem;
  margin: 0px;
}

.mobile_form {
  display: none;
}
/* @media (min-width: 1200px) {
  .container {
    max-width: 1400px;
  }
} */
.filter-tab form .input-group-append .input-group-text,
.sportspage_area form .input-group-append .input-group-text,
.boxSideSearch .input-group-append .input-group-text {
  border-top-left-radius: 50px !important;
  border-bottom-left-radius: 50px !important;
}
.filter-tab .input-group > .form-control:not(:last-child),
.sportspage_area .input-group > .form-control:not(:last-child),
.boxSideSearch .input-group > .form-control:not(:last-child) {
  border-top-right-radius: 50px !important;
  border-bottom-right-radius: 50px !important;
}
.filter-tab .nav-tabs .nav-link.active,
.filter-tab .nav-tabs .nav-item.show .nav-link {
  color: #ffffff;
  background-color: rgba(var(--theme-primary));
  border-color: #dee2e6 #dee2e6 #fff;
}
.filter-tab .nav-tabs .nav-link.active img {
  filter: drop-shadow(2px 4px 6px rgb(255, 255, 255));
}
.filter-tab .nav-fill > .nav-link,
.filter-tab .nav-fill .nav-item {
  background-color: rgba(255, 255, 255, 0.7);
  border-top-left-radius: 0.5em;
  border-top-right-radius: 0.5em;
}
.filter-tab .nav-fill .nav-item:not(:first-child) {
  border-right: 1px solid #fff;
}
.filter-tab .nav-tabs .nav-link {
  color: black;
}
.filter-tab .tab-content {
  background-color: #fff;
}
.filter-tab .tabs .card-header {
  padding: 0.7rem 0.6rem;
}
.filter-tab .tabs .card-header ul.nav.nav-tabs.card-header-tabs.nav-fill {
  padding: 0;
}

.tab-content {
  border: 1px solid rgba(0, 0, 0, 0.125);
  border-radius: 0.25rem;
}

.filter-tab .nav-tabs .nav-link {
  justify-content: space-between;
  display: -webkit-inline-box;
  align-items: center;
  float: right;
  width: 100%;
}

@media (max-width: 767px) and (min-width: 480px) {
  .filter-tab .nav-tabs .nav-link {
    justify-content: space-between;
    display: flex;
    align-items: center;
  }

  .filter-tab .nav-fill > .nav-link,
  .filter-tab .nav-fill .nav-item {
    width: 100%;
  }
}
@media (max-width: 768px) {
  .filter-tab .input-group {
    overflow: unset;
  }
}
@media (max-width: 479px) {
  .filter-tab .tabs .card-header ul.nav.nav-tabs.card-header-tabs.nav-fill {
    flex-wrap: nowrap;
  }
  .nav-fill > .nav-link,
  .nav-fill .nav-item {
    flex: 1 1 0px;
  }
  .filter-tab .nav-tabs .nav-link {
    display: grid;
    flex-wrap: wrap;
    line-height: 14px;
    align-items: center;
    justify-content: unset;
  }
  .banner-area .filter-tab .filter-Wrap1 .card-header img {
    margin: auto;
  }

  .banner-area .search-result.filter-tab {
    display: none;
  }
  .loading-message {
    font-size: 1.3rem;
  }
}

@media all and (-ms-high-contrast: none), (-ms-high-contrast: active) {
  .dropdown-menu {
    width: 100%;
  }
}
</style>
<style scoped>
  .img-fluid {
    width: 32px;
    margin-left: 35px;
  }
  .set-background{
    min-height: 350px;
    background: url('https://cdn.speedsize.com/05b4c650-ae31-47ac-b679-5cd058f0cc68/https://www.flying.co.il/assets/img/banner_landing.jpg');
  }
</style>
