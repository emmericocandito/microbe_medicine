<template>
  <main class="body_warrper">
    <!-- order area start -->
    <section class="order-area card">
      <div class="card-header">
        <div class="container">
          <h1><img :src="`${speedSizeDomain}/assets/img/app/order-icon1.png`" title="" />{{ $t('booking.your-order-no-is') + ' '}}<strong class="order_no">{{ orderNo }}</strong></h1>
        </div>
      </div>
      <div class="card-body">
        <div class="container">
          <div class="order-body-area">
            <div class="heading">
              <h3>{{ $t("booking.order-no") }} : {{ orderNo }}</h3>
            </div>

            <div class="body">
              <ul>
                <li><img :src="`${speedSizeDomain}/assets/img/app/order-icon2.png`" alt="#" />{{ $t("booking.status") }} : <strong>{{ payer.status }}</strong></li>
                <li><img :src="`${speedSizeDomain}/assets/img/app/order-icon3.png`" alt="#" />{{ $t("booking.date") }} : <strong>{{ today }}</strong></li>
              </ul>
            </div>

            <div class="body">
              <ul>
                <li><img :src="`${speedSizeDomain}/assets/img/app/order-icon4.png`" alt="#" />{{ $t("booking.name") }} : <strong>{{ name }}</strong></li>
                <li><img :src="`${speedSizeDomain}/assets/img/app/order-icon5.png`" alt="#" />{{ $t("booking.phone") }} : <strong>{{ mobile }}</strong></li>
                <li><img :src="`${speedSizeDomain}/assets/img/app/order-icon6.png`" alt="#" />{{ $t("booking.email") }} : <strong>{{ email }}</strong></li>
              </ul>
            </div>
            <div class="body">
              <ul>
                <li><img :src="`${speedSizeDomain}/assets/img/app/order-icon7.png`" alt="#" />{{ $t("booking.total-to-pay") }} : <strong>{{ price }}</strong></li>
              </ul>
            </div>
            <div class="button-box">
              <button class="btn-primary">פרטי ההזמנה המלאים</button>
            </div>

          </div>
        </div>
      </div>
    </section>
  </main>
</template>

<script>
import dayjs from 'dayjs';
import imageUrlMixin from '@/utils/imageUrlMixin';

export default {
  mixins: [imageUrlMixin],
  props: {
    payer: {
      type: Object,
      default: null,
    },
  },
  data() {
    return {
      today: '01/01/2000',
      orderNo: 'N/A',
      status: 'ERROR',
      name: '',
      mobile: '',
      email: '',
      price: '0',
    };
  },
  watch: {
    payer() {
      this.updateInformation();
    },
  },
  created() {
    this.today = dayjs(new Date().toString()).format('DD/MM/YYYY');
    this.updateInformation();
  },
  methods: {
    updateInformation() {
      if (this.payer) {
        this.orderNo = this.payer.orderNo;
        this.status = this.payer.status;
        this.name = this.payer.name || `${this.payer.firstName} ${this.payer.lastName}`;
        this.mobile = this.payer.mobile || this.payer.phone;
        this.email = this.payer.email;
        this.price = this.payer.price;
      }
    },
  },
};
</script>

<style scoped>
.body_warrper .card {
  border: none;
}
.order_no_details_box {
  box-sizing: border-box;
  border-radius: 5px;
  overflow: hidden;
  margin-bottom: 25px;
}
.order_no_details_box .order_heading {
  background: rgb(2, 0, 36);
  background: linear-gradient(
    0deg,
    rgba(2, 0, 36, 1) 0%,
    rgba(39, 136, 210, 1) 0%,
    rgba(1, 98, 172, 1) 100%
  );
  padding: 15px 20px;
}
.order_no_details_box .order_heading h2 {
  margin: 0 0;
  padding: 0 0;
  color: #fff;
  text-transform: uppercase;
  font-size: 24px;
}
.order_no_details_box .order_details_contain {
  padding: 25px 20px;
  background: #0763ab;
}
.order_no_details_box .order_details_contain .order_details_box {
  width: 100%;
  box-sizing: border-box;
  padding: 35px 15px;
  margin-left: 20px;
  background: #0c68ae;
  height: 180px;
  border-radius: 10px;
  box-shadow: 0 0 5px rgb(7 80 138 / 60%);
}
.order_no_details_box .order_details_contain .order_details_box ul {
  padding: 0 0;
  margin: 0 0;
  list-style: none;
}
.order_no_details_box .order_details_contain .order_details_box ul li {
  border-bottom: 1px solid #1774bb;
  padding-bottom: 8px;
  margin-bottom: 8px;
  text-transform: uppercase;
  color: #fff;
  font-size: 14px;
}
.order_no_details_box .order_details_contain .order_details_box ul li .icon {
  margin-left: 12px;
}

@media (max-width: 479px) {
  .order_no_details_box .order_heading h2 {
    font-size: 20px;
  }
  .order_details_contain .d-flex {
    display: block !important;
  }
  .order_no_details_box .order_details_contain .order_details_box {
    padding: 15px 18px;
    margin-left: 0;
    height: auto;
    border-radius: 0;
    margin-bottom: 10px;
  }
}
</style>

<style lang="less" scoped>
  
  .bonauf-desktop {
    .apparea {
      .order-area {
        .card-header {
          h1 {
            font-size: 30px;
            padding: 20px 0px;
            justify-content: right;
          }
        }
        .card-body {
          h3 {
            font-size: 28px;
          }
          .order-body-area {
            .heading {
              padding-bottom: 35px;
            }
            .heading::after {
              height: 35px;
            }
          }
        }
        .container {
          max-width: 780px;
          margin: auto;
        }
      }
    }
  }
</style>
