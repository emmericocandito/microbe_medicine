<template>
  <div>
    <Banner :imageList="bannerImages" type="home" :showSlider="showTopSlider" />
    <h1 class="flying-advertisement text-center mt-3 mb-0">{{ $t("home.flying-advertisement")}}</h1>
    <TopBanner :topBanner="topBanner" v-if="topBanner.length > 0 && !forPricePlanOnly"/>

    <div v-if="!promotionList.length && !dealData && !bypassPaymentState && !forPricePlanOnly" class="loading-message">{{ $t('home.deal-loading-message') }}</div>

    <Lesiurpackages :promotionData="promotionList" v-if="!!promotionList.length && !forPricePlanOnly" />

    <Lesiurtabs
      :hasDealType="hasDealTypeList"
      :banner="middleBanner"
      ref="dealTab"
      :showBanner="showMiddleBanner"
      :bannerHref="middleBannerHref"
      v-if="!!hasDealTypeList && !!middleBanner && !forPricePlanOnly"
    />
    <ContentLoading v-else-if="!forPricePlanOnly" type="deal" />
    <Footer v-if="!hideCondition"/>

  </div>
</template>

<script>
import TemplateHome from './templateHome';

export default {
  name: 'HomeTheme1',
  components: {
    Banner: () => import('@/components/content/banner/BannerTheme1'),
    Lesiurpackages: () => import('@/components/home/Lesiurpackages'),
    Lesiurtabs: () => import('@/components/home/lesiurtabs/LesiurtabsTheme1'),
    Footer: () => import('@/components/HeaderFooter/footer/FooterTheme1'),
    ContentLoading: () => import('@/components/atoms/ContentLoading'),
    TopBanner: () => import('@/components/home/topBanner/TopBannerTheme1'),
  },
  extends: TemplateHome,
};
</script>

<style scoped>
  .flying-advertisement {
    font-family: "ploni";
    font-weight: bold;
    font-size: 3rem;
    text-transform: capitalize;
  }

@media (max-width: 767px) {
  .flying-advertisement {
    font-size: 2rem;
    padding: 5px;
  }
}
</style>
