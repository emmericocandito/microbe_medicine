<template>
  <section class="lesiurpackages_mobail">
    <h2 class="text-center offers-title">{{ $t('home.special-offers') }}</h2>
    <div class="container">
      <div class="row">
        <div class="col-12">
          <Agile :options="myOptions" class="owl-carousel owl-theme feathers-slider theme-slider ltr" ref="agile">
            <div class="everiting_box" v-for="(slide, index) in promotionData" :key="index" ref="everitingBox">
              <LesiurPackageItem :slide="slide" />
            </div>

            <template slot="prevButton"><i class="fas fa-chevron-left"></i></template>
            <template slot="nextButton"><i class="fas fa-chevron-right"></i></template>
          </Agile>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'Lesiurpackages',
  components: {
    Agile: () => import('@/components/atoms/agile/Agile'),
    LesiurPackageItem: () => import('@/components/home/LesiurpackageItem'),
  },
  props: {
    promotionData: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      slide: 0,
      myOptions: {
        autoplay: false,
        infinite: true,
        navButtons: true,
        slidesToShow: 1,
        autoplaySpeed: 4000,
        rtl: true,
        dots: false,
        speed: 2000,
        responsive: [
          {
            breakpoint: 1500,
            settings: {
              slidesToShow: 5,
            },
          },
          {
            breakpoint: 1000,
            settings: {
              slidesToShow: 4,
            },
          },
          {
            breakpoint: 800,
            settings: {
              slidesToShow: 3,
            },
          },
          {
            breakpoint: 440,
            settings: {
              slidesToShow: 2,
            },
          },
        ],
      },
    };
  },
  mounted() {
    if (/* @cc_on!@ */false || !!document.documentMode) {
      setTimeout(() => {
        this.$refs.agile.getWidth();
      }, 1000);
    }
  },
};
</script>
<style scoped>
.offers-title {
  font-family: 'ploni';
  font-weight: bold;
  text-transform: capitalize;
}
.everiting_box {
  padding: 0 8px;
}
@media (max-width: 767px) {
  .offers-title {
    font-size: 1.5rem;
  }
}
</style>
<style>
@media (max-width: 768px) {
  .agile__nav-button--prev {
    left: -15px;
  }
  .agile__nav-button--next {
    right: -15px;
  }
}
</style>
