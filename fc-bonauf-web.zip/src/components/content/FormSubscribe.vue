<template>
    <section class="form-subscribe">
      <div class="container">
        <div class="row">
          <div class="col-12 text-center top-text">
            <h3>{{$t('form-subscribe.title')}}</h3>
            <h3>{{$t('form-subscribe.sub-title')}}</h3>
          </div>
          <div class="col-12">
            <form>
              <div class="form-row">
                <div class="input-group col-12 col-md-6 mx-auto mb-3">
                  <input type="text" class="form-control" :placeholder="$t('form-subscribe.your-mail')" aria-label="Example text with button addon" aria-describedby="button-addon1">
                  <div class="input-group-append">
                    <button class="btn btn-outline-secondary" type="button" id="button-addon1">{{$t('form-subscribe.button-label')}}</button>
                  </div>
                </div>
                <div class="custom-control col-12 custom-checkbox">
                  <input type="checkbox" class="custom-control-input" id="customCheck1">
                  <label class="custom-control-label" for="customCheck1">{{$t('form-subscribe.checkbox-label')}}</label>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
</template>

<script>
export default {
  name: 'FormSubscribe',
  components: {
    // NavMenu: () => import('@/components/menu/NavMenu'),
    // ContentWrapper: () => import('@/components/content/ContentWrapper')
  },
  props: {
    msg: String,
  },
};
</script>

<style scoped>
.form-subscribe .input-group .btn{
  border-radius: 50px;
}
</style>
