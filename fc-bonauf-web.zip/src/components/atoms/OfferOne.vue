<template>
  <div class="card" >
    <div class="card-body text-center">
      <p>Aug 31 - Sep1</p>
      <p>1 night</p>
      <p>Mon - Tue</p>
    </div>
    <div class="card-footer">
      <p>From $ 500</p>
    </div>
  </div>
</template>
<script>
export default {
  name: 'OfferOne',
  props: {
    item: {
      type: Object,
      defult: null,
    },
  },

};
</script>
<style scoped>

</style>
