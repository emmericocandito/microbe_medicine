<template>
  <div class="locale-changer mx-5 my-2">
    <span>{{ $t("menu.select-language")}}</span>
    <b-form-select
      id="select_language"
      v-model="$i18n.locale"
      :options="langs"
      size="sm"
      @change="changeLanguage()"
    ></b-form-select>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';
import { BFormSelect } from 'bootstrap-vue';

export default {
  name: 'SelectLanguage',
  components: {
    BFormSelect,
  },
  data() {
    return {
      langs: [
        { value: 'he', text: 'עברית' },
        { value: 'en', text: 'English' },
        // { value: 'ru', text: 'Russian' },
        { value: 'ar', text: 'عربي' },
      ],
    };
  },
  computed: {
    ...mapGetters({
      categoryID: 'GET_CURRENT_CATEGORY',
    }),
    queryLang() {
      const qLang = this.$route?.query?.langCode?.toUpperCase() || '';
      // eslint-disable-next-line no-nested-ternary
      return qLang === 'HEB' ? 'he' : qLang === 'ENG' ? 'en' : qLang === 'ARA' ? 'ar' : '';
    },
  },
  mounted() {
    // if the langCode is specified in params, set it default lang. Or set system language.
    let shortLangCode = this.queryLang;
    if (shortLangCode === '') {
      let langCode = window.navigator.languages ? window.navigator.languages[0] : null;
      langCode = langCode || window.navigator.language || window.navigator.browserLanguage || window.navigator.userLanguage;

      if (langCode.indexOf('-') !== -1) {
        shortLangCode = langCode.split('-')[0];
      }
      if (langCode.indexOf('_') !== -1) {
        shortLangCode = langCode.split('_')[0];
      }

      if (shortLangCode !== 'ar') {
        shortLangCode = 'he';
      }
    }

    this.$i18n.locale = shortLangCode || 'he';
    this.changeLanguage();
  },
  methods: {
    async changeLanguage() {
      if (this.categoryID && this.categoryID.categoryId === 'Hotel_Only') {
        await this.$store.dispatch('FETCH_LIST_COUNTRIES');
      }
      this.$store.dispatch('UPDATE_LANGUAGE', this.$i18n.locale);
      window.sessionStorage.setItem('language', this.$i18n.locale);
    },
  },
};
</script>
