<template>
  <b-dropdown variant="outline-secondary" class="d-flex" ref="dropdown" :disabled="disabled">
    <template slot="button-content">
      <i class="fa fa-user-friends"></i>
      {{allCount === 0 ? $t('search-tab.who-is-traveling') : `${allCount} ${$t('search-result.persons-selected')}`}}
    </template>
    <b-card href="#" class="border-0">
      <b-dropdown-item
        ><h5 class="text-center">
          <b-button variant="outline-primary" class="w-100">{{
            $t("search-tab.choose-count-select")
          }}</b-button>
        </h5></b-dropdown-item
      >
      <div class="form-group row align-items-center">
        <label class="col-sm-4 col-form-label">
          <div class="small-label">{{ $t("search-tab.adult") }}</div>
          <div class="text-muted small">(12+)</div>
        </label>
        <div class="col-sm-8">
          <b-form-spinbutton
            v-model="adult"
            min="0"
            max="5"
            step="1"
            size="lg"
          ></b-form-spinbutton>
        </div>
      </div>
      <div class="form-group row align-items-center">
        <label class="col-sm-4 col-form-label">
          <div class="small-label">{{ $t("search-tab.child") }}</div>
          <div class="text-muted small">(2-12)</div>
        </label>
        <div class="col-sm-8">
          <b-form-spinbutton
            v-model="child"
            min="0"
            max="5"
            step="1"
            size="lg"
          ></b-form-spinbutton>
        </div>
      </div>
      <div class="form-group row align-items-center">
        <label class="col-sm-4 col-form-label">
          <div class="small-label">{{ $t("search-tab.infant") }}</div>
          <div class="text-muted small">(0-2)</div>
        </label>
        <div class="col-sm-8">
          <b-form-spinbutton
            v-model="infant"
            min="0"
            max="5"
            step="1"
            size="lg"
          ></b-form-spinbutton>
        </div>
      </div>
    </b-card>
  </b-dropdown>
</template>

<script>
import { BDropdown, BCard, BFormSpinbutton, BDropdownItem, BButton } from 'bootstrap-vue';
import TemplateOccupancyPax from './TemplateOccupancyPax';

export default {
  name: 'occupancyPaxTheme0',
  components: {
    BDropdown,
    BCard,
    BFormSpinbutton,
    BDropdownItem,
    BButton,
  },
  extends: TemplateOccupancyPax,
};
</script>

<style>
.filter-tab .dropdown .btn.dropdown-toggle {
  background-color: #fff;
  color: #212529;
  border-color: rgba(0, 0, 0, 0.2);
  padding: 0.6rem;
  font-size: 1rem;
}
.b-form-spinbutton output{
  padding: 0;
}
.b-form-spinbutton output > div, .b-form-spinbutton output > bdi{
  min-width: fit-content;
}
</style>
<style scoped>
.col-sm-4.col-form-label{
  padding: 7px;
  text-align: center;
}
.col-form-label .small-label{
  font-size: 11px;
}
.form-group .col-sm-8 {
  padding: 0;
}
</style>
