<template>
  <div ref="position">
    <b-dropdown variant="success" size="sm" ref="dropdown" no-caret>
      <template #button-content>
        <i class="fas fa-arrow-circle-down"></i>{{ "\xa0" }}{{$t('home.more-date-click')}}
      </template>
      <b-dropdown-item v-for="(item, inx) in items" :key="inx" :href="getLink(item)">
        <div class="display-flex">
          <div class="date-range" onclick="return false;">
            <span dir="ltr">{{ changeDateFormat(item.departureDate) }} - {{ changeDateFormat(item.arrivalDate) }}</span>
          </div>
          <div class="night-box" onclick="return false;">
            <span> {{item.nights}} {{ (item.nights > 1) ? $t("home.nights"): $t("home.night")}} </span>
          </div>
          <div class="price-box" onclick="return false;">
            <span class="currency-symbol">{{item.currenySymbol}}</span><strong>{{item.packageType === "F" ? item.discountedPriceFO.priceByAge[0].price: item.discountedPrice.price_average}}</strong>
          </div>
          <div class="pl-0 pr-2 py-0" @click="recordLocation">
            <b-button size="sm" variant="primary">
              <a :href="getLink(item)" v-if="isLanding" class="more-link-button">
                 {{ $t("home.slide-deal.order-now") }}
              </a>
              <router-link :to="getLink(item)" v-else class="more-link-button">
                 {{ $t("home.slide-deal.order-now") }}
              </router-link>
            </b-button>
          </div>
        </div>
      </b-dropdown-item>

    </b-dropdown>
  </div>
</template>
<script>
import { mapGetters } from 'vuex';
import {
  VBToggle,
  BButton,
  BDropdown,
  BDropdownItem,
} from 'bootstrap-vue';

export default {
  name: 'MoreDealCollapse',
  components: {
    BButton,
    BDropdown,
    BDropdownItem,
  },
  directives: {
    'b-toggle': VBToggle,
  },
  props: {
    moreItems: {
      type: Array,
      default: () => [],
    },
    index: {
      type: String,
      default: '',
    },
  },
  data() {
    return {
      show: false,
      utmSource: this.$route.query.utm_source || '',
      locationInfo: null,
    };
  },
  computed: {
    ...mapGetters({
      isLanding: 'GET_IS_LANDING_PAGE',
      landingInfo: 'GET_LANDING_INFO',
      isFcAgentMarketerMode: 'GET_FC_AGENT_MARKETER_MODE',
    }),
    fcAgentModeParam() {
      return (this.isFcAgentMarketerMode) ? '&fc-agent-mode' : '';
    },
    items() {
      const { moreItems } = this;
      if (!moreItems || moreItems.length === 0) return [];
      // const restrictedItems = moreItems.filter((dl) => dl.nights > 2);
      // const nights2Deal = moreItems.find((dl) => dl.nights === 2);
      // if (nights2Deal) restrictedItems.push(nights2Deal);
      // return [...restrictedItems.sort((a, b) => new Date(a.departureDate) - new Date(b.departureDate))].slice(0, 4);
      return [...moreItems.sort((a, b) => new Date(a.departureDate) - new Date(b.departureDate))].slice(0, 4);
    },
  },
  mounted() {
    document.querySelector('.st-content').addEventListener('scroll', () => {
      if (this.$refs.dropdown) this.$refs.dropdown.hide();
    });
    this.locationInfo = { location: this.$refs.position?.offsetParent?.offsetParent?.offsetTop, categoryId: this.items[0].categoryId };
  },
  methods: {
    changeDateFormat(str) {
      return str.split('-').reverse().join('.');
    },
    getLink(elm) {
      if (this.isLanding) {
        return elm.toOldSite ? `${elm.productPageUrlInOldSite}&utm_source=${this.landingInfo.utm_source}` : `${elm.selectedPackageUrl}&utm_source=${this.landingInfo.utm_source}`;
      } else {
        return elm.toOldSite ? `${elm.productPageUrlInOldSite}&utm_source=${this.utmSource}${this.fcAgentModeParam}` : `${elm.selectedPackageUrl}&utm_source=${this.utmSource}${this.fcAgentModeParam}`;
      }
    },
    recordLocation() {
      this.$store.commit('SET_DEAL_LOCATION', this.locationInfo);
    },
  },
};
</script>
<style>
  .collapse-button .dropdown-toggle{
    padding: 1px 4px;
  }
  .collapse-button .dropdown-menu{
    box-shadow: grey 1px 1px 10px;
  }
  .collapse-button .dropdown-item {
    cursor: default;
  }
  .dropdown-item:active {
    color: #000;
    text-decoration: none;
    background-color: white;
  }
  @media (max-width: 768px) {
    .collapse-button .dropdown-item {
      padding: 0.25rem 1rem;
    }
  }
</style>
<style scoped>
  .more-link-button {
    color: #fff;
    text-decoration: none;
  }
  .display-flex{
    display: flex;
    text-align: right;
  }
  .date-range, .price-box {
    background-color: #313232;
    color: white;
  }
  .date-range {
    width: 180px;
    text-align-last: justify;
  }
  .price-box {
    font-size: 24px;
    width: 75px;
  }
  .dropdown-item .date-range, .dropdown-item .price-box, .dropdown-item .night-box {
    padding: 0.25rem 0.8rem;
  }
  @media (max-width: 768px) {
    .dropdown-item .date-range, .dropdown-item .price-box, .dropdown-item .night-box{
      font-size: 13px;
    }
    .date-range {
      width: 142px;
    }
    .price-box {
      font-size: 24px;
      width: 40px;
    }
    .dropdown-item .date-range, .dropdown-item .price-box, .dropdown-item .night-box {
      padding: 0.25rem 0.5rem;
    }
  }
</style>
