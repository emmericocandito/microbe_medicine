<template>
  <div id="st-container" class="st-container">
    <v-select
      v-model="currSelect"
      :options="options"
      dir="rtl"
      :clearable="false"
      :placeholder="placeholder"
      class="style-chooser"
      :focus="showList"
      @option:selecting="selecting"
      @search:focus="deselecting"
      ref="refSelect"
    >
      <template #selected-option="{ label }">
        <div style="display: flex; align-items: baseline;">
          <span style="margin-left:10px;">
            <i :class="type" aria-hidden="true"></i>
          </span>
          {{ label }}
        </div>
      </template>
      <template v-slot:option="{ label }">
        <span style="margin-left:10px;font-size:1.5rem;">
          <i class="fa fa-map-marker-alt" aria-hidden="true"></i>
        </span>
        {{ label }}
      </template>
    </v-select>
  </div>
</template>

<script>
import vSelect from 'vue-select';
import 'vue-select/dist/vue-select.css';

export default {
  name: 'ComboSearchSelect',
  components: {
    vSelect,
  },
  props: {
    options: {
      type: Array,
      default: () => [],
    },
    type: {
      type: String,
      default: 'fa fa-map-marker-alt',
    },
    placeholder: {
      type: String,
      default: 'choose...',
    },
    selected: {
      type: Object,
      default: null,
    },
    showList: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      oldState: '',
      currSelect: '',
    };
  },
  computed: {},
  created() {
    this.oldState = this.selected;
    this.currSelect = this.selected;
  },
  watch: {
    showList(value) {
      this.$refs.refSelect.open = value;
    },
    selected(value) {
      this.currSelect = value;
    },
    currSelect(value) {
      if (this && this.oldState !== value) {
        this.$emit('change', value);
        this.oldState = value;
      }
    },
  },
  methods: {
    selecting() {
      this.$emit('optionSelect', true);
    },
    deselecting() {
      this.$emit('optionSelect', false);
    },
  },
};
</script>
<style scoped>
.st-container {
  overflow: visible;
}
</style>
<style>
input[type='search'] {
  margin: 0;
  padding: 0;
  border: 0;
}
.st-container .vs--searchable .vs__dropdown-toggle {
  border-radius: 50px;
  padding: 0.575rem 1.35rem;
  height: auto;
}
.vs__selected {
  width: max-content;
}

.style-chooser .vs__dropdown-menu li {
  height: 45px;
  line-height: 35px;
  transition: 0.2s;
}
</style>
