<template>
  <div class="input-group" style="height:3rem;">
    <input
      type="text"
      readonly
      class="form-control text-right"
      :placeholder="$t('search-tab.choose-date')"
      @click="toggleCalendar"
      style="cursor: auto; height: auto;"
      :value="inputText"
      dir="ltr"
      :disabled="disabled"
    />
    <div class="input-group-append">
      <span class="input-group-text">
        <!-- <i class="far fa-calendar-alt"></i> -->
        <img :src="`${speedSizeDomain}/assets/img/calendar.png`" style="width:25px;" width="25" height="25" alt="calendar"/>
      </span>
    </div>
    <div class="col-12 calendar-body" v-if="show" :class="{'side-calendar': type === 'side', 'middle-position': type !== 'side' && enableSearchAgentState}">
      <div class="card mb-2 calendar-card" v-if="isLoading">
        <div class="loading-message">
          {{ $t('search-tab.loading-message') }}
        </div>
        <ContentLoading type="app" />
      </div>
      <div class="card mb-2 calendar-card" ref="inputControl" v-else>
        <div class="card-text p-2">
          <div class="text-center w-100 month-title">{{mode === 'startSelect' ? $t('calendar.choose-departure'): $t('calendar.choose-return')}} ({{destinationText}})</div>
          <div class="row">
            <div v-for="(monthYear, i) of monthYears" :key="i" class="month-container" :style="{ width: 100 / noOfMonthsInRow + '%' }">
              <table>
                <thead>
                  <tr>
                    <th class="text-center month-title" :colspan="weekDays.length">
                      <span v-if="(monthYear.month() < lastAbleMonth || monthYear.year() < lastAbleYear) && ((noOfMonthsInRow === 1 && i === 0) ||(noOfMonthsInRow === 2 && i === 1))"
                        class="float-left"
                        style="cursor: pointer; padding-left: 8px"
                        @click="nextMonth">
                        <i class="arrow left"></i>
                      </span>
                      {{ displayMonthYear(monthYear) }}
                      <span v-if="(monthYear.month() > firstAbleMonth || monthYear.year() > firstAbleYear) && ((noOfMonthsInRow === 1 && i === 0) ||(noOfMonthsInRow === 2 && i === 0))"
                        class="float-right"
                        style="cursor: pointer; padding-right: 8px"
                        @click="previousMonth">
                        <i class="arrow right"></i>
                      </span>
                    </th>
                  </tr>
                  <tr>
                    <th v-for="(weekDay, i) of weekDays" :key="i" class="day-header text-center">{{ weekDay }}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="(daysOfWeek, i) of weekWiseDays(monthYear)" :key="i">
                    <td v-for="(day, j) of daysOfWeek" :key="j" class="text-center" :title="isHoliday(day)"
                      :class="{
                        available: isAvailable(day) ? true : false,
                        'start-date': isStartDate(day),
                        'under-selection': isUnderSelection(day),
                        'holiday': !!isHoliday(day),
                        'run-out': day && !isHoliday(day) && !isAvailable(day) && isUnavailable(day),
                        today: isToday(day),
                      }"
                      @click="isAvailable(day) ? selectDate(day) : null"
                    >
                      <div v-if="day"> {{ day.format('D') }}
                        <div class="price-text">
                          <p v-if="dayDuration(day)" class="duration m-0">{{dayDuration(day)}} {{ $t("home.nights") }}</p>
                          <p>{{ dayPrice(day) }}</p>
                        </div>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          <div :class="{'d-flex flex-row' : type!=='side'}">
            <ul class="reference-list d-flex p-0 align-self-center m-0" style="color: black;">
              <li class="d-flex"><div class="reference available m-1"></div>{{$t('calendar.available')}}</li>
              <li class="d-flex"><div class="reference holiday m-1"></div>{{$t('calendar.holiday')}}</li>
              <li class="d-flex"><div class="reference run-out m-1"></div>{{$t('calendar.run-out')}}</li>
            </ul>
            <div class="flex-fill m-1" :class="{'mr-4': type!=='side'}">
              <button class="btn btn-secondary btn-sm btn-block" @click="clearDatesSelection" :disabled="selectionDate1 == null ? true : false">
                {{ $t('calendar.clear') }}
              </button>
            </div>
            <div class="flex-fill m-1">
              <button class="btn btn-primary btn-sm btn-block" @click="finalizeSelection" :disabled="selectionDate1 && selectionDate2 ? false : true">
                {{ $t('calendar.continue') }}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <b-modal id="calendar-modal" scrollable class="w-100" ref="calendar-modal" v-model="showCalendar"
     :title="mode === 'startSelect' ? `${$t('calendar.choose-departure')} (${destinationText})`: `${$t('calendar.choose-return')} (${destinationText})`">
      <div class="modal-calendar-body mb-3 content-loading" v-if="isLoading">
        <div class="loading-message">
          {{ $t('search-tab.loading-message') }}
        </div>
        <ContentLoading type="app" />
      </div>
      <div class="modal-calendar-body mb-3" v-else>
        <div v-for="(monthYear, i) of monthYears" :key="i" class="month-container" style="width: 100%;">
          <table>
            <thead>
              <tr>
                <th class="text-center month-title" :colspan="weekDays.length">
                  {{ displayMonthYear(monthYear) }}
                </th>
              </tr>
              <tr>
                <th v-for="(weekDay, i) of weekDays" :key="i" class="day-header text-center">{{ weekDay }}</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(daysOfWeek, i) of weekWiseDays(monthYear)" :key="i">
                <td v-for="(day, j) of daysOfWeek" :key="j" class="text-center"  :title="isHoliday(day)"
                  :class="{
                    available: isAvailable(day) ? true : false,
                    'start-date': isStartDate(day),
                    'under-selection': isUnderSelection(day),
                    'holiday': isHoliday(day),
                    'run-out': day && !isHoliday(day) && !isAvailable(day) && isUnavailable(day),
                    today: isToday(day),
                  }"
                  @click="isAvailable(day) ? selectDate(day) : null"
                >
                  <div v-if="day"> {{ day.format('D') }}
                    <div class="price-text">
                      <p v-if="dayDuration(day)" class="duration m-0">{{dayDuration(day)}} {{ $t("home.nights") }} </p>
                      <p>{{ dayPrice(day) }}</p>
                    </div>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <template #modal-footer>
        <div class="d-flex flex-row text-center border-top range-date-show">
          <div class="col-md-6">
            <i class="fas fa-calendar-week"></i> {{ selectionDate1 && selectionDate1.format('DD-MM-YYYY') || '' }}
          </div>
          <div class="separator">|</div>
          <div class="col-md-6">
            <i class="fas fa-calendar-week"></i> {{ selectionDate2 && selectionDate2.format('DD-MM-YYYY') || '' }}
          </div>
        </div>

        <ul class="reference-list d-flex p-0 align-self-center m-0" style="color: black;">
          <li class="d-flex"><div class="reference available m-1"></div>{{$t('calendar.available')}}</li>
          <li class="d-flex"><div class="reference holiday m-1"></div>{{$t('calendar.holiday')}}</li>
          <li class="d-flex"><div class="reference run-out m-1"></div>{{$t('calendar.run-out')}}</li>
        </ul>

        <div class="d-flex flex-row">
          <div class="flex-fill m-1">
            <button class="btn btn-secondary btn-sm btn-block" @click="clearDatesSelection" :disabled="selectionDate1 == null ? true : false">
              {{ $t('calendar.clear') }}
            </button>
          </div>
          <div class="flex-fill m-1">
            <button class="btn btn-primary btn-sm btn-block" @click="finalizeSelection" :disabled="selectionDate1 && selectionDate2 ? false : true">
              {{ $t('calendar.continue') }}
            </button>
          </div>
        </div>
      </template>
    </b-modal>

  </div>
</template>

<script>
import { mapGetters } from 'vuex';
import { BModal } from 'bootstrap-vue';
import dayjs from 'dayjs';
import isSameOrBefore from 'dayjs/plugin/isSameOrBefore';
import isSameOrAfter from 'dayjs/plugin/isSameOrAfter';
import duration from 'dayjs/plugin/duration';
import gMixin from '@/utils/mixins';
import imageUrlMixin from '@/utils/imageUrlMixin';

require('dayjs/locale/he');
require('dayjs/locale/ru');
require('dayjs/locale/ar');

dayjs.extend(isSameOrBefore);
dayjs.extend(isSameOrAfter);
dayjs.extend(duration);

export default {
  props: {
    availableDates: {
      type: Array,
      required: true,
    },
    calendarShow: {
      type: Boolean,
      default: false,
    },
    type: {
      type: String,
      default: 'tabs',
    },
    destinationText: {
      type: String,
      default: '',
    },
    disabled: {
      type: Boolean,
      default: false,
    },
  },
  components: {
    BModal,
    ContentLoading: () => import('@/components/atoms/ContentLoading'),
  },
  mixins: [gMixin, imageUrlMixin],
  data() {
    return {
      // selectionDate1: null,
      // selectionDate2: null,
      weekDays: [],
      startMonthYear: dayjs().format('YYYY-MM'),
      today: dayjs().startOf('day'),
      show: false,
      showCalendar: false,
      mode: 'startSelect',
      endDatesInfo: [],
      endUnableDatesInfo: [],
      containerWidth: 0,
      query: this.$route.query,
      // scrollPosition: 0,
      // clientHeight: 0,
      // scrollHeight: 0,
      // availHeight: window.screen.availHeight,
    };
  },
  computed: {
    ...mapGetters({
      lang: 'GET_LANGUAGE',
      device: 'GET_DEVICE',
      holidayList: 'GET_HOLIDAY_DATA',
      isLoading: 'GET_DATE_LOADING_STATE',
      isFcAgentMarketerMode: 'GET_FC_AGENT_MARKETER_MODE',
      enableSearchAgentState: 'GET_ENABLE_SEARCH_AGENT_STATE',
    }),
    // holidayList() {
    //   return this.holiday.holidays;
    // },
    thisMonth() {
      return dayjs().month();
    },
    thisYear() {
      return dayjs().year();
    },
    firstAbleDay() {
      const { availableDates } = this;
      if (!availableDates || (availableDates && availableDates.length === 0)) return dayjs();

      const day = availableDates.sort((a, b) => new Date(b.date) - new Date(a.date))[availableDates.length - 1].date;
      return dayjs(day);
    },
    lastAbleDay() {
      const { availableDates } = this;
      if (!availableDates || (availableDates && availableDates.length === 0)) return dayjs();

      const day = availableDates.sort((a, b) => new Date(a.date) - new Date(b.date))[availableDates.length - 1].date;
      return dayjs(day);
    },
    firstAbleMonth() {
      return this.firstAbleDay.month();
    },
    lastAbleMonth() {
      return this.lastAbleDay.month();
    },
    firstAbleYear() {
      return this.firstAbleDay.year();
    },
    lastAbleYear() {
      return this.lastAbleDay.year();
    },
    ableLastMonthCount() {
      const { availableDates, firstAbleDay, lastAbleDay } = this;
      if (!availableDates || (availableDates && availableDates.length === 0)) return 2;

      const lastMonthFirstDay = lastAbleDay.set('date', 28);
      const nowMonthFirstDay = firstAbleDay.set('date', 1);
      return dayjs(lastMonthFirstDay).diff(dayjs(nowMonthFirstDay), 'month') + 2;
    },
    monthYears() {
      const monthYears = [];
      const count = this.isDesktop ? 2 : this.ableLastMonthCount;
      for (let i = 0; i < count; i += 1) {
        const monthYear = dayjs(`${this.startMonthYear}-01`).add(i, 'months');
        monthYears.push(monthYear);
      }
      return monthYears;
    },
    datesInfo() {
      const dates = {};
      this.setStartDate();
      this.availableDates.forEach((rec) => {
        if (dates[rec.date] && rec.dur[0] !== 0 && rec.av !== 0) {
          dates[rec.date].push(rec);
        } else if (rec.dur[0] !== 0 && rec.av !== 0) dates[rec.date] = [rec];
      });
      return dates;
    },
    unavDatesInfo() {
      const dates = {};
      this.setStartDate();
      this.availableDates.forEach((rec) => {
        if (dates[rec.date] && rec.dur[0] !== 0 && rec.av === 0) {
          dates[rec.date].push(rec);
        } else if (rec.dur[0] !== 0 && rec.av === 0) dates[rec.date] = [rec];
      });
      return dates;
    },
    inputText() {
      let text = '';
      if (this.selectionDate1) {
        text += `${this.selectionDate1.format('DD/MM/YY')} - `;
      }
      if (this.selectionDate2) {
        text += this.selectionDate2.format('DD/MM/YY');
      }
      return text;
    },
    noOfMonthsInRow() {
      let slots = Math.floor(this.containerWidth / 240);
      if (slots > 2) {
        slots = 2;
      }
      return slots;
    },
    selectionDate1: {
      get() {
        return this.$store.getters.GET_SEARCH_CONTENT.from ? this.$store.getters.GET_SEARCH_CONTENT.from : '';
      },
      set(value) {
        this.$store.dispatch('SET_SEARCH_ITEM', ['from', value]);
      },
    },
    selectionDate2: {
      get() {
        return this.$store.getters.GET_SEARCH_CONTENT.to ? this.$store.getters.GET_SEARCH_CONTENT.to : '';
      },
      set(value) {
        this.$store.dispatch('SET_SEARCH_ITEM', ['to', value]);
      },
    },
    isDesktop() {
      return this.device === 'desktop';
    },
    isDomainVercel() {
      return window.location.host.includes('vercel') || window.location.host.includes('localhost');
    },
  },
  watch: {
    selectionDate1() {
      this.emitDates();
    },
    selectionDate2() {
      this.emitDates();
    },
    lang() {
      dayjs.locale(this.lang);
      this.getWeekName();
      this.nextMonth();
      this.previousMonth();
    },
    calendarShow() {
      this.clearDatesSelection();
      if (this.isDesktop) {
        this.show = this.calendarShow;
      } else {
        this.showCalendar = this.calendarShow;
      }
    },
    showCalendar() {
      if (this.showCalendar) {
        this.clearDatesSelection();
      }
      // this.addRemoveScrollBehavior();
    },
    $route: {
      immediate: true,
      handler() {
        if (this.isFcAgentMarketerMode) return;
        setTimeout(() => {
          this.selectionDate1 = (this.$route.query.fromDate) ? dayjs(this.$route.query.fromDate) : null;
          this.selectionDate2 = (this.$route.query.toDate) ? dayjs(this.$route.query.toDate) : null;
        }, 500);
      },
      deep: true,
    },
    show() {
      if (this.type === 'side' && this.show) {
        this.clearDatesSelection();
      }
    },
  },
  created() {
    dayjs.locale(this.lang);
    this.getWeekName();

    window.addEventListener('resize', this.refreshContainerSize);
  },
  mounted() {
    this.refreshContainerSize();
  },
  destroyed() {
    window.removeEventListener('resize', this.refreshContainerSize);
  },
  methods: {
    setStartDate() {
      // const firstDate = this.availableDates.filter((item) => item.dur[0] !== 0);
      // const minDate = Math.min.apply(
      //   Math,
      //   this.availableDates.filter((item) => item.dur[0] !== 0).map((item) => item.date)
      // );
      const minDate = this.availableDates.filter((item) => item.dur[0] !== 0).map((item) => item.date)
        .sort()[0];
      this.startMonthYear = minDate ? dayjs(minDate).format('YYYY-MM') : dayjs().format('YYYY-MM');
    },
    getWeekName() {
      this.weekDays = [
        this.$t('weekShortName.sun'),
        this.$t('weekShortName.mon'),
        this.$t('weekShortName.tue'),
        this.$t('weekShortName.wed'),
        this.$t('weekShortName.thu'),
        this.$t('weekShortName.fri'),
        this.$t('weekShortName.sat'),
      ];
    },
    emitDates() {
      if (this.selectionDate1 && this.isDesktop) this.startMonthYear = dayjs(this.selectionDate1).format('YYYY-MM');
      this.$emit('dates', {
        from: this.selectionDate1 ? this.selectionDate1.format('YYYY-MM-DD') : '',
        to: this.selectionDate2 ? this.selectionDate2.format('YYYY-MM-DD') : '',
      });
    },
    weekWiseDays(monthYear) {
      const days = [];
      let day = monthYear.clone();
      while (day.format('YYYY-MM') === monthYear.format('YYYY-MM')) {
        days.push(day);
        day = day.add(1, 'days');
      }

      const weekWiseDays = [];
      let i = 0;
      days.forEach((dday) => {
        if (!weekWiseDays[i]) {
          weekWiseDays[i] = [];
        }
        const position = dday.day();
        if (position != null) {
          weekWiseDays[i][position] = dday;
          if (position === this.weekDays.length - 1) {
            i += 1;
          }
        }
      });
      return weekWiseDays;
    },
    displayMonthYear(monthYear) {
      return `${monthYear.format('MMMM')} ${monthYear.format('YYYY')}`;
    },
    toggleCalendar() {
      if (this.isDesktop) {
        this.show = !this.show;
        if (this.show) {
          this.mode = 'startSelect';
        }
        this.refreshContainerSize();
      } else {
        this.showCalendar = !this.showCalendar;
      }
    },
    nextMonth() {
      this.startMonthYear = dayjs(`${this.startMonthYear}-01`).add(1, 'months').format('YYYY-MM');
    },
    previousMonth() {
      this.startMonthYear = dayjs(`${this.startMonthYear}-01`).subtract(1, 'months').format('YYYY-MM');
    },
    isAvailable(day) {
      if (!day) {
        return false;
      }
      if (!day.isSameOrAfter(this.today)) {
        return false;
      }
      if (this.mode === 'startSelect') {
        return !!this.datesInfo[day.format('YYYY-MM-DD')];
      } else if (this.mode === 'endSelect') {
        return !!this.endDatesInfo[day.format('YYYY-MM-DD')];
      }
      return false;
    },
    isUnavailable(day) {
      if (!day) {
        return false;
      }
      if (!day.isSameOrAfter(this.today)) {
        return false;
      }
      if (this.mode === 'startSelect') {
        return !!this.unavDatesInfo[day.format('YYYY-MM-DD')];
      } else if (this.mode === 'endSelect') {
        return !!this.endUnableDatesInfo[day.format('YYYY-MM-DD')];
      }
      return false;
    },
    dayPrice(day) {
      let dayString = '';
      if (this.mode === 'startSelect') {
        dayString = day.format('YYYY-MM-DD');
        if (this.datesInfo[dayString]) {
          const symbol = this.datesInfo[dayString][0].cc;
          return `${this.getPriceWithSymbol(symbol, this.getMinPrice(this.datesInfo, day))}`;
        } else if (this.unavDatesInfo[dayString]) {
          const symbol = this.unavDatesInfo[dayString][0].cc;
          return `${this.getPriceWithSymbol(symbol, this.getMinPrice(this.unavDatesInfo, day))}`;
        } else {
          return '';
        }
      } else if (this.mode === 'endSelect') {
        dayString = day.format('YYYY-MM-DD');
        if (this.endDatesInfo[dayString]) {
          const symbol = this.endDatesInfo[dayString].cc;
          return `${this.getPriceWithSymbol(symbol, this.endDatesInfo[dayString].price)}`;
        } else if (this.endUnableDatesInfo[dayString]) {
          const symbol = this.endUnableDatesInfo[dayString].cc;
          return `${this.getPriceWithSymbol(symbol, this.endUnableDatesInfo[dayString].price)}`;
        } else {
          return '';
        }
      }
      return '';
    },
    dayDuration(day) {
      let dayString = '';
      if (this.mode === 'endSelect') {
        dayString = day.format('YYYY-MM-DD');
        if (this.endDatesInfo[dayString]) {
          return this.endDatesInfo[dayString].dur;
        } else if (this.endUnableDatesInfo[dayString]) {
          return this.endUnableDatesInfo[dayString].dur;
        } else {
          return '';
        }
      }
      return '';
    },
    selectDate(day) {
      if (this.mode === 'startSelect') {
        this.selectionDate1 = day;
        this.selectionDate2 = null;

        /**
         * Get available date when select first date.
         */
        this.endDatesInfo = [];
        const info = this.datesInfo[day.format('YYYY-MM-DD')];
        for (let i = 0; i < info.length; i += 1) {
          this.endDatesInfo[day.add(info[i].dur[0], 'days').format('YYYY-MM-DD')] = {
            price: info[i].durPrice,
            cc: info[i].cc,
            dur: info[i].dur[0],
          };
        }

        /**
         * Get unavailable date when select first date.
         */
        this.endUnableDatesInfo = [];
        const unableInfo = this.unavDatesInfo[day.format('YYYY-MM-DD')] || [];
        for (let i = 0; i < unableInfo.length; i += 1) {
          this.endUnableDatesInfo[day.add(unableInfo[i].dur[0], 'days').format('YYYY-MM-DD')] = {
            price: unableInfo[i].durPrice,
            cc: unableInfo[i].cc,
            dur: unableInfo[i].dur[0],
          };
        }

        this.mode = 'endSelect';
      } else {
        this.selectionDate2 = day;
        // if (this.type === 'side') this.finalizeSelection();
        this.finalizeSelection();
      }
    },
    isStartDate(day) {
      if (!day) {
        return false;
      }
      if (
        this.selectionDate1
        && this.selectionDate1.format('YYYY-MM-DD') === day.format('YYYY-MM-DD')
      ) {
        return true;
      }
      return false;
    },
    isToday(day) {
      if (!day) {
        return false;
      }
      if (this.today.format('YYYY-MM-DD') === day.format('YYYY-MM-DD')) {
        return true;
      }
      return false;
    },
    clearDatesSelection() {
      this.selectionDate1 = null;
      this.selectionDate2 = null;
      this.mode = 'startSelect';
      this.$emit('finalDateSelect', false);
    },
    finalizeSelection() {
      if (this.isDesktop) {
        this.show = false;
      } else {
        this.showCalendar = false;
      }
      this.$emit('finalDateSelect', true);
    },
    isUnderSelection(day) {
      if (!day) {
        return false;
      }
      if (
        this.selectionDate1
        && this.selectionDate2
        && day.isSameOrAfter(this.selectionDate1)
        && day.isSameOrBefore(this.selectionDate2)
      ) {
        return true;
      }
      return false;
    },
    isHoliday(day) {
      if (!day) {
        return '';
      }
      const formattedDay = day.format('YYYY-MM-DD');
      return this.holidayList?.find((item) => item.active && item.date === formattedDay)?.hebrew;
    },
    refreshContainerSize() {
      const width = this.type !== 'side' ? 550 : 250;// this.$refs.inputControl?.clientWidth;
      this.containerWidth = width < 250 ? 250 : width;
    },
    getMinPrice(obj, day) {
      // eslint-disable-next-line prefer-spread
      return Math.min.apply(
        Math,
        obj[day.format('YYYY-MM-DD')].map((item) => item.price),
      );
    },
  },
};
</script>

<style scoped>
.priv-month-blinking, .next-month-blinking {
  text-align: center;
  position: absolute;
  width: 100%;
  height: 30px;
  background: linear-gradient(to top, rgba(255,255,255,0.7), rgba(255,255,255,1));
  z-index: 2;
}
.priv-month-blinking i, .next-month-blinking i{
  animation: blink 0.5s infinite;
}
.priv-month-blinking {
  top: 0rem;
}
.next-month-blinking {
  bottom: 5.5rem;
}
.arrow.up {
  transform: rotate(-135deg);
}
.arrow.down {
  transform: rotate(45deg);
}
.calendar-body .month-title {
  color: black;
}
.calendar-body {
  position: absolute;
  top: 40px;
  z-index: 11;
}
.calendar-body.middle-position {
  top: auto;
  bottom: 40px;
}
.calendar-card {
  min-width: 250px;
}
.calendar-body:not(.side-calendar) .calendar-card {
  width: 550px;
}
.month-container {
  padding: 10px;
}

.month-container table {
  width: 100%;
  margin-bottom: 10px;
}

.month-container td {
  color: #c3ceda;
  pointer-events: none;
  cursor: default;
  position: relative;
}

.today {
  color: #95a5b9;
  background-color: #ebf0f1;
}

.month-container .day-header {
  color: rgba(var(--theme-primary));
}

.month-container td.start-date,
.month-container td.under-selection {
  background-color: #0172df !important;
  color: #fff !important;
  background-image: none !important;
}
.reference.available, .month-container td.available {
  pointer-events: all;
  background-color: #e0efff;
  color: #000;
  cursor: pointer;
  user-select: none; /* supported by Chrome and Opera */
  -webkit-user-select: none; /* Safari */
  -khtml-user-select: none; /* Konqueror HTML */
  -moz-user-select: none; /* Firefox */
  -ms-user-select: none; /* Internet Explorer/Edge */
  /* background-image: linear-gradient(-45deg, #e0efff 65%, #0db04b 35%); */
  /* background-image: linear-gradient(-45deg, #b6ddff, #fff, #b6ddff); */
  /* border-radius: 3px; */
}
.month-container td:hover {
  box-shadow: inset 0 0 0 1px transparent!important;
  /* transition: background-color .2s cubic-bezier(0.68, -0.55, 0.27, 1.55); */
  background-color: #0172df;
  border-radius: 2px;
  background-image: none;
}
.month-container td.holiday:after, .month-container td.run-out:after {
  content: "";
  height: 18px;
  left: 0;
  position: absolute;
  top: 0;
  width: 18px;
}
.reference.holiday, .month-container td.holiday:after{
  background-image: url(data:image/svg+xml;base64,PHN2ZyBpZD0iTGF5ZXJfMSIgZGF0YS1uYW1lPSJMYXllciAxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxOCIgaGVpZ2h0PSIxOCIgdmlld0JveD0iMCAwIDY5LjU1IDY5LjU1Ij48ZGVmcz48c3R5bGU+LmNscy0ye2ZpbGw6I2ZmZn08L3N0eWxlPjwvZGVmcz48cGF0aCBkPSJNNjkuNTUgMCAwIDY5LjU1VjBoNjkuNTVabTAgMCIgc3R5bGU9ImZpbGw6IzAxNzJkZiIvPjxwYXRoIGNsYXNzPSJjbHMtMiIgZD0iTTkuNzQgMjUuNDFhNi4xOCA2LjE4IDAgMCAxIDEuNDgtMS4xNSAyLjczIDIuNzMgMCAwIDEgMS4zNC0uMzMgMi42NSAyLjY1IDAgMCAxIDEuMjkuNCA2LjgyIDYuODIgMCAwIDEgMS4zMSAxLjA2bDYuMTEgNi4xMWExMi43NyAxMi43NyAwIDAgMCAyLjQxIDEuOSAxNC44IDE0LjggMCAwIDAgMi40NCAxLjIxTDIzLjcyIDM3YTUgNSAwIDAgMS0xLjM3LS41OSAxMi4yOSAxMi4yOSAwIDAgMS0xLjI3LS44NmMtLjQ0LS4zNS0uODctLjcyLTEuMy0xLjExYTcuNDYgNy40NiAwIDAgMSAuODEgMS42IDUuMTkgNS4xOSAwIDAgMSAuMzIgMS45NiA0LjI3IDQuMjcgMCAwIDEtLjQ0IDEuODkgNi41MiA2LjUyIDAgMCAxLTEuMjYgMS43bC0xLjA3IDEuMDEtMi4yMS0yLjIxIDEuMzEtMS4zYTQuNCA0LjQgMCAwIDAgMS0xLjg3IDQuNzUgNC43NSAwIDAgMCAuMS0xLjkxIDUuNDYgNS40NiAwIDAgMC0uNjQtMS44MSA3Ljg3IDcuODcgMCAwIDAtMS4yOS0xLjY4bC0zLjc2LTMuNzZhMSAxIDAgMCAwLS41OS0uMzUuOS45IDAgMCAwLS42NC4zNWwtMi4xNCAyLjE4LTIuMTgtMi4xOVpNMzAuNTIgOWwtMS4xNyAxLjE3TDQwIDIwLjc5bC0yLjYzIDIuNjEtMTAuNjUtMTAuNjUtNC44NCA0Ljg0IDEwLjY0IDEwLjY1LTIuNjIgMi42Mi0xMC42Mi0xMC42Mi0xLjIxIDEuMjEtMi4xOS0yLjE5TDI4LjM0IDYuODFaIi8+PC9zdmc+);
  background-position: 0 0;
  background-repeat: no-repeat;
}
.reference.run-out, .month-container td.run-out:after{
  background-image: url(data:image/svg+xml;base64,PHN2ZyBpZD0iZVRlU1JQckI1cTExIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2aWV3Qm94PSIwIDAgNjkuNTUgNjkuNTUiIHNoYXBlLXJlbmRlcmluZz0iZ2VvbWV0cmljUHJlY2lzaW9uIiB0ZXh0LXJlbmRlcmluZz0iZ2VvbWV0cmljUHJlY2lzaW9uIj48cGF0aCBkPSJNNjkuNTUsMEwwLDY5LjU1TDAsMGg2OS41NVptMCwwIiBmaWxsPSIjZjAwIi8+PHRleHQgZHg9IjAiIGR5PSIwIiBmb250LWZhbWlseT0iJnF1b3Q7ZVRlU1JQckI1cTExOjo6Tm90byBTYW5zIEhlYnJldyZxdW90OyIgZm9udC1zaXplPSIzLjQ3NzUiIGZvbnQtd2VpZ2h0PSI0MDAiIHRyYW5zZm9ybT0ibWF0cml4KDYuOTE1MzI4LTYuNzkyMjM0IDUuNTI3NDYzIDUuNjI3NjM3IDE0LjQyODk2MSA0Ni41ODQ2MzEpIiBmaWxsPSIjZmZmIiBzdHJva2Utd2lkdGg9IjAiPjx0c3BhbiB5PSIwIiBmb250LXdlaWdodD0iNDAwIiBzdHJva2Utd2lkdGg9IjAiPjwhW0NEQVRBW9eQ15bXnF1dPjwvdHNwYW4+PC90ZXh0PjxzdHlsZT48IVtDREFUQVtAZm9udC1mYWNlIHtmb250LWZhbWlseTogJ2VUZVNSUHJCNXExMTo6Ok5vdG8gU2FucyBIZWJyZXcnO2ZvbnQtc3R5bGU6IG5vcm1hbDtmb250LXdlaWdodDogNDAwO2ZvbnQtc3RyZXRjaDogbm9ybWFsO3NyYzogdXJsKGRhdGE6Zm9udC90dGY7Y2hhcnNldD11dGYtODtiYXNlNjQsQUFFQUFBQU9BSUFBQXdCZ1IwUkZSZ0FVQUFJQUFBRU1BQUFBR2tkUVQxTVpyU0JqQUFBQ1hBQUFBRjVIVTFWQ3B3QzA3Z0FBQWJBQUFBQW9UMU12TW9qWUVFc0FBQUs4QUFBQVlGTlVRVlR3MWR6MkFBQUJhQUFBQUNSamJXRndFWDhBc3dBQUFoQUFBQUJNWjJ4NVp1M3A2amNBQUFNY0FBQUJMbWhsWVdRVjlVVWtBQUFCMkFBQUFEWm9hR1ZoQmwwQW1nQUFBWXdBQUFBa2FHMTBlQWt5QU00QUFBRDRBQUFBRkd4dlkyRUF4d0VaQUFBQTdBQUFBQXh0WVhod0FCNEF2d0FBQVNnQUFBQWdibUZ0WlNxdlRqa0FBQVJNQUFBQ0RIQnZjM1QvbndBeUFBQUJTQUFBQUNBQUFBQVVBRmtBYmdCdUFKY0NXQUJlQW5nQUpBSUtBQ0lCRGdBQUFVb0FLZ0FCQUFBQURBQUFBQUFBQUFBQkFBRUFCQUFCQUFFQUFBQUJBQUFBQVFBQUFBVUFnQUFRQUQwQUJRQUJBQUFBQUFBQUFBQUFBQUFBQUFNQUFRQURBQUFBQUFBQS81d0FNZ0FBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFFQUFRQUlBQUlBQUFBVUFBQUFBQUFBQUFKM1oyaDBBUUFBQUhka2RHZ0JBUUFCQUFFQUFBUXMvdHdBQUFNTy95NytxZ01BQUFFQUFBQUFBQUFBQUFBQUFBQUFBQUFGQUFFQUFBQUtBQ1lBSmdBQ1JFWk1WQUFTYUdWaWNnQU9BQUFBQUFBRUFBQUFBUC8vQUFBQUFBQUJBQUFBQXdBQVp6ZlpVbDhQUFBVQUF3UG9BQUFBQU5tcGdiOEFBQUFBMndTQVl2OHUvd1VEQUFNYkFBQUFCZ0FDQUFBQUFBQUFBQUFBQWdBQUFBTUFBQUFVQUFNQUFRQUFBQlFBQkFBNEFBQUFDZ0FJQUFJQUFnQWdCZEFGMWdYYy8vOEFBQUFnQmRBRjFnWGMvLy8vNC9veCtpNzZKZ0FCQUFBQUFBQUFBQUFBQUFBQkFBQUFDZ0FrQURJQUFrUkdURlFBRG1obFluSUFEZ0FFQUFBQUFQLy9BQUVBQUFBQmEyVnliZ0FJQUFBQUFRQUFBQUVBQkFBQ0FBZ0FBUUFJQUFFQURBQUZBQUFBQVFBU0FBRUFBUUFCQUFJQUF2LzYvL29BQkFBQUFBQUFBQUFFQWY4QmtBQUZBQUFDaWdKWUFBQUFTd0tLQWxnQUFBRmVBRElCUWdBQUFBQUFBQUFBQUFBQUFJQUFDQU5BQUNBQ0FBQUFBQUFBQUFCSFQwOUhBVUFBQVB0UEJDeiszQUFBQkN3QkpBQUFBQ0FBQUFBQUFoZ0N5Z0FBQUNBQUF3QUNBRjRBQUFINUFzb0FBd0FIQUFBekVTRVJKU0VSSVY0Qm0vNllBVFgreXdMSy9UWXpBbVFBQXdBa0FBQUNWQUpSQUJJQUhnQXFBQUFoTGdJbkxnTW5NeDRDRng0Q0Z5RTNQZ0kzRnc0Q0J3Y2xKejRDTnpjekJ3NENBZXNzWEZzc0dUQXBJdzF2RXlveUhpdGlaQzM5MEJnSUkwUTVIaVFxRmdjWUFSVWVKakFaQkFsY0NRVW9TMHVNZlRZZk96UXFEeFkyUHlZN2lKSkxwanBoU1JjOEVUbExMYVAyUEJJNFNpMWVZVHBnU0FBQUFRQWlBQUFCNXdMNEFBZ0FBQk1oQndNakV5RTFOMzRCYVFxelg2LytxRndDVVRyOTZRSUY2QXNBQWdBcUFBRUJLd0pSQUJNQUZ3QUFOeTRETlRRMk5qY1hEZ0lYSGdNWEF6VWhCM2tIRGdvRkVqQXJYak14RGdFQkNRd09CYTRCQVFzQksyQmRUaG9nUmowVEFnODRReUFhVldOaUpnSUVURXdBQUFBQUFBQUtBSDRBQXdBQkJBa0FBQUJlQVRBQUF3QUJCQWtBQVFBZ0FSQUFBd0FCQkFrQUFnQU9BUUlBQXdBQkJBa0FBd0JDQU1BQUF3QUJCQWtBQkFBd0FKQUFBd0FCQkFrQUJRQWFBSFlBQXdBQkJBa0FCZ0FzQUVvQUF3QUJCQWtBRGdBMEFCWUFBd0FCQkFrQkFBQU1BQW9BQXdBQkJBa0JBUUFLQUFBQVZ3QnBBR1FBZEFCb0FGY0FaUUJwQUdjQWFBQjBBR2dBZEFCMEFIQUFPZ0F2QUM4QWN3QmpBSElBYVFCd0FIUUFjd0F1QUhNQWFRQnNBQzRBYndCeUFHY0FMd0JQQUVZQVRBQk9BRzhBZEFCdkFGTUFZUUJ1QUhNQVNBQmxBR0lBY2dCbEFIY0FMUUJTQUdVQVp3QjFBR3dBWVFCeUFGWUFaUUJ5QUhNQWFRQnZBRzRBSUFBekFDNEFNQUF3QURBQVRnQnZBSFFBYndBZ0FGTUFZUUJ1QUhNQUlBQklBR1VBWWdCeUFHVUFkd0FnQUZJQVpRQm5BSFVBYkFCaEFISUFNd0F1QURBQU1BQXdBRHNBUndCUEFFOEFSd0E3QUU0QWJ3QjBBRzhBVXdCaEFHNEFjd0JJQUdVQVlnQnlBR1VBZHdBdEFGSUFaUUJuQUhVQWJBQmhBSElBVWdCbEFHY0FkUUJzQUdFQWNnQk9BRzhBZEFCdkFDQUFVd0JoQUc0QWN3QWdBRWdBWlFCaUFISUFaUUIzQUVNQWJ3QndBSGtBY2dCcEFHY0FhQUIwQUNBQU1nQXdBREVBT1FBZ0FFY0Fid0J2QUdjQWJBQmxBQ0FBU1FCdUFHTUFMZ0FnQUVFQWJBQnNBQ0FBVWdCcEFHY0FhQUIwQUhNQUlBQlNBR1VBY3dCbEFISUFkZ0JsQUdRQUxnPT0pIGZvcm1hdCgndHJ1ZXR5cGUnKTt9XV0+PC9zdHlsZT48L3N2Zz4=);
  background-position: 0 0;
  background-repeat: no-repeat;
  background-size: cover;
}

.month-container td .price-text {
  font-size: 0.75rem;
  line-height: 1rem;
}
.month-container td .price-text .duration {
  font-size: 0.65rem;
  line-height: 0.55rem;
  font-weight: bold;
}

.month-container table {
  width: 100%;
}

/* .month-container th,
.month-container td {
  padding: 5px;
} */

.month-title {
  font-weight: bolder;
}

.arrow {
  border: solid black;
  border-width: 0 3px 3px 0;
  display: inline-block;
  padding: 3px;
}

.arrow.right {
  transform: rotate(-45deg);
  -webkit-transform: rotate(-45deg);
}

.arrow.left {
  transform: rotate(135deg);
  -webkit-transform: rotate(135deg);
}
.modal-calendar-body {
  width: 100%;
  /* height: calc(100vh - 350px); */
  overflow-y: auto;
}
.modal-calendar-body.content-loading {
  height: calc(100vh - 350px);
}
.range-date-show{
  color: rgba(var(--theme-primary));
}
.reference-list li{
  list-style: none;
}
.reference{
  width: 18px;
  height: 18px;
}
@media(max-width: 600px){
  .calendar-card {
    min-width: 250px;
    width: auto;
  }
}
</style>
<style>

#calendar-modal .modal-footer{
  display: block;
  border: none;
}
#calendar-modal .modal-header .modal-title{
  margin: auto;
}
.loading-message {
  font-size: 1.3rem;
}
#calendar-modal .modal-dialog {
  width: 100%;
}
/* #calendar-modal {
  direction: ltr;
} */
#calendar-modal .modal-body {
  margin: 0;
  padding: 0;
}
</style>
