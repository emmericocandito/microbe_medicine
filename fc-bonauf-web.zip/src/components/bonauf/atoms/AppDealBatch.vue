<template>
  <div v-if="batch.length>0" class="p-2 deal-wrapper col-xl-4 col-lg-6 col-md-6 col-sm-12" >
    <div class="box1">
      <div class="share-button" @click="() => showModal( batch[0])" v-if="testMode">
        <img :src="`${speedSizeDomain}/assets/img/share-icon-white.png`" alt="share-icon" class="share-icon" width="23" height="20"/>
      </div>
      <div class="inner-box" @click="gotoDealTabPage(batch[0])">
          <img :class="roundImage" :src="imgLink(batch[0])" alt="#" >
          <ul class="tag">
              <li><img class="remark" :src="typeIcon(batch[0])" /> {{type(batch[0])}}</li>
              <li><img class="remark" :src="`${speedSizeDomain}/assets/img/app/suitcase-line.png`" /> {{baggage(batch[0])}}</li>
              <li v-if="isTransfer(batch[0])"><img class="remark" :src="`${speedSizeDomain}/assets/img/app/school-bus.png`" /> כולל העברות</li>
              <li v-if="isDailyTour(batch[0])" class="mr-5 pointer" @click="showItineraryDetail(batch[0])"><img class="remark" :src="`${speedSizeDomain}/assets/img/app/map.png`" /> מסלול הטיול</li>
              <li v-if="hasTitleRemark(batch[0])" class="mr-4">{{ titleRemark(batch[0]) }}</li>
              <li v-if="basis(batch[0]).length>0" class="remark"><img class="remark" :src="basisIcon(batch[0])" /> {{ basisName(batch[0]) }}</li>
          </ul>
          <div class="box-contain">
              <div class="text">
                  <div class="text1 col-8 px-0">{{ title(batch[0]) }}</div>
                  <div class="text1 col-4 px-0 align-self-end price text-left"><sub>החל מ-</sub>{{price(batch[0])}}</div>
              </div>
              <p>{{subtitle(batch[0])}}</p>
          </div>
      </div>
      <div v-if="countExtraDeals>0" :class="[device==='desktop' && 'hidden-date-wrapper']" >
        <div class="hidden-date">
          <ul>
              <li v-for="(deal, index) in batch.slice(1, countExtraDeals+1)" :key=index class="justify-content-around">
                <!-- <div class="share-button" @click="() => showModal(deal)" v-if="testMode">
                  <img :src="`${speedSizeDomain}/assets/img/share-icon-white.png`" alt="share-icon" class="share-icon" width="23" height="20"/>
                </div> -->
                <div class="text subtitle">{{subtitle(deal)}}</div>
                <div class="text"><span class="m-auto">{{ price(deal) }}</span></div>
                <div class="text d-flex">
                    <button class="btn-text" @click="gotoDealTabPage(deal)">הזמן עכשיו</button>
                </div>
              </li>
          </ul>
          <div class="view-more">
              <button v-if="isMoreDeal" class="btn-more" @click="showMoreExtraDeals">תאריכים נוספים <i class="fa-solid fa-angle-down"></i></button>
              <button class="btn-cross" @click="hideExtraDeals"><i class="fa-solid fa-xmark"></i></button>
          </div>
        </div>
      </div>
      <button v-if="batch.length>1" class="btn" @click="showMoreExtraDeals">תאריכים נוספים <i class="fa-solid fa-angle-down"></i></button>
    </div>
    <b-modal v-model="showItinerary" modal-class="itinerary-modal"
      centered size="xl" :dir="lang == 'he' ? 'rtl' : 'ltr'"
      :no-close-on-backdrop="true" :ok-only="true" :hide-footer="true">
      <div class="kremlindatelist-area" v-if="this.detailItinerary">
        <div class="kremlindatelistbox" v-for="(day, idx) in detailItinerary.itineraryDetail" :key="idx">
          <div class="media align-items-center">
            <figure class="media-img"><img src="/assets/img/app/icon4.png" alt="#" title=""></figure>
            <div class="media-body">
              <h3 class="tabs_blue_content_title text-right mr-2">{{ `יום ${day.day}: ${day.header}` }}</h3>
            </div>
          </div>
          <p class="description">{{day.text}}}</p>
        </div>
      </div>
      <div v-else class="d-flex loading">
          <img class="m-auto" src="/assets/img/loading1.gif" alt="Loading..." />
        </div>
    </b-modal>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';
import { BModal } from 'bootstrap-vue';
import {
  getId,
  getShareLink,
  getDestCode,
  getLinkImageDeal,
  getTitleDeal,
  getSubtitleDeal,
  getPriceDeal,
  getIsTransfer,
  getBaggage,
  getType,
  getTitleRemark,
  getBasis,
  getCategoryCode,
} from '@/utils/bonauf/controllerCommon';
import imageUrlMixin from '@/utils/imageUrlMixin';

const { VUE_APP_BONAUF_DOMAIN_MOBILE } = process.env;

export default {
  name: 'AppDealBatch',
  mixins: [imageUrlMixin],
  components: {
    BModal,
  },
  props: {
    batch: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return ({
      countExtraDeals: 0,
      showItinerary: false,
      detailItinerary: null,
    });
  },
  computed: {
    ...mapGetters({
      device: 'GET_DEVICE',
      lang: 'GET_LANGUAGE',
      testMode: 'GET_TEST_MODE',
      getDestinationName: 'GET_DEST_NAME',
      getCategoryName: 'GET_CATEGORY_NAME',
      // detailItinerary: 'GET_ITINERARY_DETAIL',
    }),
    isMoreDeal() {
      return this.countExtraDeals < this.batch.length;
    },
    roundImage() {
      return this.batch.length>1 ? 'round-top' : 'round-all';
    }
  },
  created() {
  },
  methods: {
    isTransfer(pDeal) {
      return getIsTransfer(pDeal);
    },
    hasTitleRemark(pDeal) {
      return this.titleRemark(pDeal) !== '';
    },
    baggage(pDeal) {
      return getBaggage(pDeal);
    },
    isDailyTour(pDeal) {
      return getCategoryCode(pDeal) === '41990';
    },
    type(pDeal) {
      return getType(pDeal);
    },
    typeIcon(pDeal) {
      let iconPath = '';
      switch (getCategoryCode(pDeal)) {
        case '40400':
          iconPath = `${this.speedSizeDomain}/assets/img/app/flying.png`;
          break;
        case '41990':
          iconPath = `${this.speedSizeDomain}/assets/img/app/man.png`;
          break;
        default:
          iconPath = `${this.speedSizeDomain}/assets/img/app/vacationPack.png`;
      }
      return iconPath;
    },
    titleRemark(pDeal) {
      return getTitleRemark(pDeal);
    },
    basis(pDeal) {
      return getBasis(pDeal);
    },
    basisIcon(pDeal) {
      const codeBasis = this.basis(pDeal)?.[0]?.[0];
      let pathIcon = '';
      switch (codeBasis) {
        case 'HB':
          pathIcon = `${this.speedSizeDomain}/assets/img/app/dinner.png`;
          break;
        default:
          pathIcon = `${this.speedSizeDomain}/assets/img/app/breakfast.png`;
      }
      return pathIcon;
    },
    basisName(pDeal) {
      return this.basis(pDeal)?.[0]?.[1];
    },
    imgLink(pDeal) {
      return getLinkImageDeal(pDeal);
    },
    title(pDeal) {
      return getTitleDeal(pDeal);
    },
    subtitle(pDeal) {
      return getSubtitleDeal(pDeal);
    },
    price(pDeal) {
      return getPriceDeal(pDeal);
    },
    hideExtraDeals() {
      this.countExtraDeals = 0;
    },
    showMoreExtraDeals() {
      if (this.isMoreDeal) {
        this.countExtraDeals += this.countExtraDeals === 0 ? (this.device === 'desktop' ? 5 : 3) : 5;
      }
    },
    async showItineraryDetail() {
      this.showItinerary = true;
      if (this.detailItinerary === null && this.batch.length > 0 && this.isDailyTour(this.batch[0])) {
        this.detailItinerary = await this.$store.dispatch('FETCH_ITINERARY_DETAIL', { id: this.batch[0].id });
      }
    },
    gotoDealTabPage(pDeal) {
      const kind = window.location.pathname.includes('app-desktop') ? 'app-desktop' : 'app';
      if (!this.showItinerary) this.$router.push({ path: `/deal-tab/${kind}?id=${pDeal.id}&channel=App` });
    },
    showModal(pDeal) {
      let link = getShareLink(pDeal);
      link = link.replace(VUE_APP_BONAUF_DOMAIN_MOBILE, '');
      this.$emit('emitMessage', {
        kind: 'showShareModal',
        data: {
          id: getId(pDeal),
          link: encodeURI(`${link}&text=מצאתי דיל בבוא נעוף שיכול לעניין אותך, בוא נעוף ביחד`),
          category: this.getCategoryName(getCategoryCode(pDeal)),
          dest: this.getDestinationName(getDestCode(pDeal)),
          hotel: getTitleDeal(pDeal),
          image: getLinkImageDeal(pDeal),
          country: '',
        },
      });
    },
  },
};
</script>

<style lang="less" scoped>
  .deal-wrapper {
    margin-bottom: 2.5rem;
  }
  .box1 {
    // overflow: hidden;
    position: relative;
    border-radius: 20px;
    padding: 0px;

    .share-button {
      left: 12px;
      top: 12px;
      background: transparent;
    }
    .inner-box {
      height: 235px;
      display: flex;
      position: relative;

      .round-top {
        border-radius: 20px 20px 0px 0px;
      }
      .round-all {
        border-radius: 20px;
      }
    }
    .inner-box::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 1;
      cursor: pointer;
    }
    img{
      width: 100%;
      object-fit: cover;
      position: relative;
    }
    ul.tag {
      position: absolute;
      top: 15px;
      right: 15px;
      z-index: 1;
      list-style-type: none;
      padding: 0;
      margin: 0;

      li {
        display: inline-block;
        background: rgb(251,109,47);
        background: -moz-linear-gradient(90deg, rgba(251,109,47,1) 0%, rgba(249,255,0,1) 100%);
        background: -webkit-linear-gradient(90deg, rgba(251,109,47,1) 0%, rgba(249,255,0,1) 100%);
        background: linear-gradient(90deg, rgba(251,109,47,1) 0%, rgba(249,255,0,1) 100%);
        box-sizing: border-box;
        border-radius: 30px;
        padding: 0px 5px;
        color: #000;
        font-family: 'FbCoherentiSansBold';
        margin: 5px 0 0 5px;
        font-size: 16px;

        img.remark {
          width: 15px;
          height: auto;
        }
      }
    }
    .box-contain{
      width: 100%;
      position: absolute;
      z-index: 1;
      bottom: 0;
      left: 0;
    }
    .btn{
      width: 100%;
      padding: 8px 20px;
      color: #000000;
      font-family: 'FbCoherentiSansBold';
      font-size: 18px;
      background: rgb(251,109,47);
      background: -moz-linear-gradient(90deg, rgba(251,109,47,1) 0%, rgba(249,255,0,1) 100%);
      background: -webkit-linear-gradient(90deg, rgba(251,109,47,1) 0%, rgba(249,255,0,1) 100%);
      background: linear-gradient(90deg, rgba(251,109,47,1) 0%, rgba(249,255,0,1) 100%);
      border: 0;
      z-index: 9;
      position: absolute;
      border-radius: 0px 0px 20px 20px;
    }

    .hidden-date {
      width: 100%;
      box-sizing: border-box;
      padding: 10px;
      background: rgb(1,147,207);
      background: -moz-linear-gradient(90deg, rgba(1,147,207,1) 0%, rgba(132,219,255,1) 100%);
      background: -webkit-linear-gradient(90deg, rgba(1,147,207,1) 0%, rgba(132,219,255,1) 100%);
      background: linear-gradient(90deg, rgba(1,147,207,1) 0%, rgba(132,219,255,1) 100%);
      position: absolute;
      z-index: 10;
      border-radius: 0px 0px 20px 20px;

      ul{
        width: 100%;
        box-sizing: border-box;
        padding: 0 0 12px;
        margin: 0 0 12px;
        border-bottom: 1px solid #ffffff6e;
        max-height: 160px;
        overflow-y: auto;

        li {
          width: 100%;
          box-sizing: border-box;
          padding: 0 0 2px;
          margin: 0 0 2px;
          border-bottom: 1px solid #ffffff;
          display: flex;
          justify-content: space-between;

          .subtitle {
            width: 220px;
          }
          .text{
            width: fit-content;
            box-sizing: border-box;
            color: #000000;
            font-family: inherit;
            font-size: 16px;
            font-weight: bold;
          }
        }
      }
      .view-more {
        width: 100%;
        height: 40px;
        box-sizing: border-box;
        padding-top: 10px;
        text-align: center;
        position: relative;

        .btn-more {
          background-color: transparent;
          border: 0;
          font-family: 'FbCoherentiSansBold';
          font-size: 18px;
        }
        .btn-cross {
          position: absolute;
          background-color: transparent;
          border: 0;
          top: 13px;
          left: 10px;
          color: #000000;
          font-size: 18px;
        }
      }
    }
    .hidden-date-wrapper {
      width: 100%;
      box-sizing: border-box;
      padding: 10px;
      top: 40px;
      position: absolute;
      z-index: 10;

      .hidden-date {
        position: unset;
        border-radius: 10px;
      }
    }
    .btn-text {
      border: 1px solid #fff;
      background-color: #ffffff;
      font-size: 16px;
      padding: 2px 10px;
      border-radius: 30px;
      font-family: 'FbCoherentiSansBold';
    }
    .box-contain {
      .text {
        width: 100%;
        border-bottom: 1px solid #ffffff;
        margin-bottom: 6px;
        display: flex;
        justify-content: space-between;
        padding: 6px;

        .text1{
          color: #ffffff;
          font-size: 18px;
          font-family: 'Rubik-Bold';

          sub {
            bottom: 1px;
            font-size: 75%;
            font-family: inherit;
            font-weight: normal;
          }
        }
        .text1.price {
          font-family: inherit;
          font-weight: bold;
          font-size: 20px;
        }
      }
      p {
        box-sizing: border-box;
        color: #ffffff;
        font-family: inherit;
        font-size: 20px;
        padding: 0 10px;
        margin: 0 0 6px;
      }
    }

  }
</style>
