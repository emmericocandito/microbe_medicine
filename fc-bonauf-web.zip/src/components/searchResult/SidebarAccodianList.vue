<template>
  <div class="card card-body border-0 px-0">
    <div class="accordion sidePanel" id="accordionParent">
      <SidebarFilterRadio :item="radioItem"/>
      <SidebarFilterSlide :item="sliderItem"/>
      <SidebarFilterCheckbox :item="checkboxItem"/>
    </div>
  </div>
</template>

<script>
export default {
  name: 'SidebarAccodianList',
  components: {
    SidebarFilterRadio: () => import('@/components/searchResult/atoms/SidebarFilterRadio'),
    SidebarFilterSlide: () => import('@/components/searchResult/atoms/SidebarFilterSlide'),
    SidebarFilterCheckbox: () => import('@/components/searchResult/atoms/SidebarFilterCheckbox'),
  },
  props: {
    msg: String,
  },
  data() {
    return {
      radioItem: {
        title: 'One Trip Found',
        subItems: [
          {
            label: 'Recomemded',
            price: '$1199',
          },
          {
            label: 'Special',
            price: '$999',
          },
        ],
      },
      sliderItem: {
        title: 'Price',
      },
      checkboxItem: {
        title: 'Star Rating',
        subItems: [
          {
            label: 'Start 1',
            price: 7,
          },
          {
            label: 'Start 2',
            price: 12,
          },
          {
            label: 'Start 3',
            price: 39,
          },
          {
            label: 'Start 4',
            price: 127,
          },
        ],
      },
    };
  },
};
</script>
