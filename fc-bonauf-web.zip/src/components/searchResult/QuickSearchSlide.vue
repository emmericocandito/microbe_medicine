<template>
  <section class="lesiurpackages_mobail">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <Agile v-if="showSlider" :options="myOptions" class="owl-carousel owl-theme feathers-slider theme-slider ltr">
            <div class="everiting_box" v-for="(item, index) in searches" :key="index">
              <div class="everiting_box_body">
                <img
                  v-bind="mainProps"
                  :src="getDestinationImage(item.dest) || item.backgroundImageUrl"
                  alt="Not Found"
                  @error="showDefaultImage"
                   width="100" height="100"
                />
                <div class="contain_body">
                  <div class="card-title">
                    <!-- <h6>{{ item.name[lang] || item.categoryId }}</h6> -->
                    <!-- <h6> {{ $t("search-result.from") }} {{ (item.translations.flightDestinationName && item.translations.flightDestinationName[item.start]) && item.translations.flightDestinationName[item.start][lang] || item.start }}</h6> -->
                    <!-- <h6> {{ $t("search-result.to") }} {{ (item.translations.flightDestinationName && item.translations.flightDestinationName[item.dest]) && item.translations.flightDestinationName[item.dest][lang] || item.dest }}</h6> -->
                    <h6 >
                      <span v-if="item.categoryId === 'vacation_pack'">{{ item.name[lang] }} {{ $t("search-result.to") }}</span>
                      <span v-if="item.categoryId === 'Organize_tour_packages'">{{ $t("search-result.organized-tours-to") }}</span>
                      <span v-if="item.categoryId === 'Flight_Only'">{{ $t("search-result.cheep-flight-to") }}</span>
                      {{ searchCategory.destinations.find(d => {return d.code === item.dest}).name[lang] }}
                    </h6>
                    <h6> {{ searchCategory.destinations.find(d => {return d.code === item.dest}).countryName[lang] }} </h6>
                  </div>
                  <p class="first-paragraph" v-if="item.categoryId === 'vacation_pack'">{{ $t("search-result.more-search-vacation-message") }}</p>
                  <p class="first-paragraph" v-if="item.categoryId === 'Organize_tour_packages'">{{ $t("search-result.more-search-organize-message") }}</p>
                  <p class="first-paragraph" v-if="item.categoryId === 'Flight_Only'">{{ $t("search-result.more-search-flight-only-message") }}</p>
                  <p>
                    {{ convertDateFormat(item.packStartDate) + " " }} :
                    {{ $t("search-result.departure") }}
                    <span class="icon"><i class="fas fa-plane-departure"></i></span>
                  </p>
                  <p>
                    {{ convertDateFormat(item.packEndDate) + " " }} :
                    {{ $t("search-result.arrival") }}
                    <span class="icon"><i class="fas fa-plane-arrival"></i></span>
                  </p>
                  <p>
                    {{ item.packDuration }} : {{ $t("search-result.duration") }}
                    <span class="icon"><i class="fas fa-bed"></i></span>
                  </p>
                  <p class="price">{{ "$" + item.baselinePrice }}</p>
                  <a @click="search($event, item)" href="#">
                    <div class="order-button">
                      {{ $t("search-result.search") }}
                      <span class="icon"><i class="fas fa-search"></i></span></div
                  ></a>
                </div>
              </div>
              <!-- </a> -->
            </div>

            <template slot="prevButton"><i class="fas fa-chevron-left"></i></template>
            <template slot="nextButton"><i class="fas fa-chevron-right"></i></template>
          </Agile>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import { mapGetters } from 'vuex';
import dayjs from 'dayjs';
import imageUrlMixin from '@/utils/imageUrlMixin';

export default {
  mixins: [imageUrlMixin],
  props: {
    searches: {
      type: Array,
      default: () => [],
    },
  },
  computed: {
    ...mapGetters({
      category: 'GET_CURRENT_CATEGORY',
      lang: 'GET_LANGUAGE',
      destinationImages: 'GET_DESTINATION_IMAGES',
    }),
  },
  components: {
    Agile: () => import('@/components/atoms/agile/Agile'),
  },
  data() {
    return {
      myOptions: {
        autoplay: false,
        infinite: true,
        navButtons: true,
        slidesToShow: 1,
        autoplaySpeed: 4000,
        rtl: true,
        dots: false,
        speed: 2000,
        responsive: [
          {
            breakpoint: 540,
            settings: {
              slidesToShow: 2,
            },
          },
          {
            breakpoint: 1000,
            settings: {
              slidesToShow: 3,
            },
          },
          {
            breakpoint: 1200,
            settings: {
              slidesToShow: 4,
            },
          },
          {
            breakpoint: 1280,
            settings: {
              slidesToShow: 5,
            },
          },
        ],
      },
      mainProps: {
        fluidGrow: true,
        blank: true,
        blankColor: '#bbb',
        class: 'card-img-top img-fluid',
      },
      searchURL: '#',
      showSlider: true,
      searchCategory: null,
    };
  },
  created() {
    this.searchCategory = this.category;
  },
  watch: {
    searches() {
      this.showSlider = false;
      setTimeout(() => { this.showSlider = true; }, 10);
    },
  },
  methods: {
    showDefaultImage(ev) {
      ev.target.src = `${this.speedSizeDomain}/assets/img/banner-2.jpg`;
    },
    search(ev, pItem) {
      ev.preventDefault();
      this.$emit('quickSearch', pItem);
    },
    getDestinationImage(dest) {
      const matchedItem = this.destinationImages.find((d) => d.code === dest);
      const url = (matchedItem) ? this.destinationImages.find((d) => d.code === dest).imageUrls[0] : '';
      return url;
    },
    convertDateFormat(pDate) {
      const format = 'DD-MM-YYYY';
      return dayjs(pDate).format(format);
    },
  },
};
</script>
<style>
.lesiurpackages_mobail .agile__nav-button {
  background: #fff;
  border: 1px solid #4285f4;
  color: #4285f4;
  cursor: pointer;
  font-size: 20px;
  top: calc(50% - 40px);
  transition-duration: 0.3s;
}
.lesiurpackages_mobail .agile__nav-button--next {
  right: -10px;
  left: auto;
}
.lesiurpackages_mobail .agile__nav-button--prev {
  left: -10px;
  right: auto;
}
</style>
<style scoped>
.everiting_box {
  padding: 0 10px;
}
.everiting_box_body .contain_body .card-title {
  position: absolute;
  z-index: 1;
  margin: 0;
  padding: 5px 0;
  top: 20px;
  right: 5px;
  width: 95%;
  height: 75px;
  color: white;
}
.everiting_box_body .contain_body p:nth-child(2) {
  padding-bottom: 55px;
  font-size: 18px;
  text-align: center;
}
.everiting_box_body .contain_body .card-title h6{
  font-size: 1.2rem;
  font-weight: bold;
  margin: 0;
}
.everiting_box_body .card-title:after {
  content: "";
  height: 100%;
  width: 110%;
  position: absolute;
  display: block;
  top: 0;
  right: -20%;
  transform: skew(25deg, 0deg);
  z-index: -1;
  background-color: #00adef;
  box-shadow: #023b50 2px 10px 15px;
}
.everiting_box_body .ui.rating {
  height: auto;
  color: #025575;
  background: transparent;
  border: none;
  direction: rtl;
  padding: 0;
}
a {
  color: #007bff;
  text-decoration: none;
  background-color: transparent;
}
.everiting_box .everiting_box_body .order-button {
  transition-duration: 0.1s;
  content: "";
  position: absolute;
  bottom: 10px;
  left: 10px;
  margin: 0 auto;
  padding: 6px;
  background: #005ca3;
  color: #fff;
  max-width: 120px;
  font-size: 14px;
  text-align: center;
  text-transform: capitalize;
  border-radius: 20px;
  border: 1px solid rgb(255 255 255 / 0.5);
  z-index: 91;
}
.everiting_box .everiting_box_body .contain_body p.price {
  font-size: 25px;
}

@media (max-width: 476px) {
  .lesiurpackages_mobail {
    padding-top: 5px;
    padding-bottom: 20px;
  }
}
</style>
