<template>
  <div>
    <Breadcrumb type="search-area" :data="linkData" :categoryName="categoryName" v-if="linkData" />
    <Banner :banner="bannerImage" type="search-result" />
    <InfoStrip :count="searchResultCount" :categoryName="categoryName" :loading="isLoading"/>

    <!-- <MobileFilter
      :category="category"
      v-if="category"
      :sortButtonList="mobileSortButtonList"
      @updateSort="doSort"
      @filterChange="filterByOption"
      :filterOptions="filterOptions"
    /> -->

    <div v-if="category" class="my-5 sportspage_area" ref="calc-offset">
      <div class="container">
        <div class="row">
          <!-- <div class="col-lg-3 col-12 sideBar desktop_form">
            <SearchTabs type="side"/>
          </div> -->
          <div v-if="isLoading" class="col-lg-12 col-12 filter-cont package-organize">
            <ContentLoading />
          </div>
          <div v-else class="col-lg-10 col-12 filter-cont package-organize m-auto">
              <div class="desktop_form" :class="isScroll && 'sticky'">
                <h3>
                  {{ $t('search-result.goa') }}: {{ countFilteredItems }}
                  <span>{{ $t('search-result.properties-found-sportPack') }}{{ destinationString }}</span>
                </h3>
                <!-- <SortButtons :buttonList="sortButtonList" @updateSort="doSort" :isFixed="isScroll"/> -->
              </div>
              <div v-if="listEvents.length>0" class="list_content_tickets_group">
                <ol class="w-list-unstyled">
                  <event-item
                    v-for="(item, idx) in listEvents"
                    :key="idx"
                    :event="item"
                    :itemIndex="idx"
                  />
                </ol>
              </div>
          </div>
        </div>
      </div>
    </div>
    <Footer v-if="(device !== 'mobile' || !isLoading)"/>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';
// import dayjs from 'dayjs';
// import { BModal, BButton } from 'bootstrap-vue';
import bannerImageDestination from '@/utils/bannerImageDestination';

export default {
  name: 'SearchResultSportPack',
  components: {
    // BButton,
    Banner: () => import('@/components/productPage/ProductBanner'),
    InfoStrip: () => import('@/components/searchResult/InforStrip'),
    EventItem: () => import('@/components/searchResult/atoms/EventItem'),
    // FilterPanel: () => import('@/components/searchResult/atoms/FilterPanel'),
    // MobileFilter: () => import('@/components/searchResult/MobileFilter'),
    // SearchPopup: () => import('@/components/searchResult/SearchPopup'),
    // SearchTab: () => import('@/components/search/SearchTab'),
    // SearchTabOT: () => import('@/components/search/SearchTabOT'),
    // SearchTabHO: () => import('@/components/search/SearchTabHO'),
    // SearchTabs: () => import('@/components/search/searchTabs/SearchTabsTheme0'),
    // FilterItem: () => import('@/components/searchResult/atoms/FilterItem'),
    // SortButtons: () => import('@/components/searchResult/atoms/SortButtons'),
    ContentLoading: () => import('@/components/atoms/ContentLoading'),
    Breadcrumb: () => import('@/components/productPage/Breadcrumb'),
    // Slider: () => import('@/components/productPage/ProductSlider'),
    // BModal,
  },
  mixins: [bannerImageDestination],
  props: {
    msg: String,
  },
  data() {
    return {
      searchResultCount: 0,
      destinationString: '',
      countFilteredItems: 0,
      isScroll: false,
      query: this.$route.query,

      listEvents: [],
    };
  },
  metaInfo() {
    return {
      meta: [
        { property: 'og:title', content: `חופשות ב ${this.destinationString}` },
      ],
    };
  },
  computed: {
    ...mapGetters({
      category: 'GET_CURRENT_CATEGORY',
      subjectCategory: 'GET_SUBJECTS_CATEGORY',
      storedSearchQuery: 'GET_SEARCH_QUERY',
      packages: 'GET_PACKAGES',
      isLoading: 'GET_LOADING_STATE',
      lang: 'GET_LANGUAGE',
      dealItinerary: 'GET_DEAL_ITINERARY',
      destinationImages: 'GET_DESTINATION_IMAGES',
      marketerId: 'GET_MARKETER_ID',
      device: 'GET_DEVICE',
      whiteLabel: 'GET_WHITE_LABEL_DATA',
      marketerAgencyContent: 'GET_MARKETER_AGENCY_CONTENT',
      isAgencyLogin: 'IS_AGENCY_AUTHORIZED',
      bypassPaymentState: 'GET_BYPASS_PAYMENT_STATE',
      limitDealsState: 'GET_LIMIT_DEALS_STATE',
      agentContent: 'GET_ODYSSEY_AGENT_CONTENT',
      isOdysseySite: 'GET_ODYSSEY_AGENT_STATE',
      odyAgentCode: 'GET_SELECTED_ODYSSEY_AGENT_CODE',
    }),
    linkData() {
      return {
        dest: this.destinationString,
        searchQuery: `/search-result-sportpack?${new URLSearchParams(this.query).toString()}`,
      };
    },
    categoryName() {
      return this.category?.code ?? '';
    },
  },
  watch: {
    category() {
      this.initSearchResult();
    },
    packages: 'takeListEvents',
  },
  async created() {
    this.$store.commit('SET_CURRENT_PAGE', 'searchResult');
    await this.fetchData();
  },
  async mounted() {
    if (this.isOdysseySite) this.$store.commit('SET_SELECTED_ODYSSEY_AGENT_CODE', this.query.odyAgentCode || this.agentContent.odyAgentCode);
    document.querySelector('.st-content').addEventListener('scroll', this.onScroll);
  },
  methods: {
    async fetchData() {
      if (this.hideCondition) return;
      this.query = this.$route.query;

      this.$store.commit('SET_SEARCH_QUERY', this.query);
      sessionStorage.setItem('search-query', JSON.stringify(this.query));

      if (!this.query.dest || !this.query.adult || !this.query.categoryId) {
        this.$bvModal.msgBoxOk(
          this.$t('search-result.dont-remove-query'),
          {
            title: this.$t('product-page.expire-title'),
            dialogClass: 'noSearchResult',
            okVariant: 'success',
            headerClass: 'p-2 border-bottom-0',
            footerClass: 'p-2 border-top-0',
            centered: true,
          },
        );
        return;
      }

      await this.fetchBannerImageByDestination();

      const destList = decodeURIComponent(this.query.dest).split(',');
      this.destinationString = destList.map((dest) => this.category?.destinations?.find((item) => item.code === dest)?.name[this.lang] || dest).join(',') ?? '';

      if (this.subjectCategory.length === 0) await this.$store.dispatch('FETCH_SUBJECT_CATEGORY');
      this.$store.dispatch('FETCH_SUBJECTS');
      if (this.query.marketerId) this.$store.commit('SET_MARKETER_ID', this.query.marketerId);

      await this.$store.dispatch('FETCH_PACKAGE_BY_SEARCH', this.query);

      // document.querySelector('.st-content').scrollTo(0, this.usableHeight);
    },
    takeListEvents() {
      this.listEvents = [];
      if (this.packages && this.packages.length === 0) {
        this.$bvModal.msgBoxOk(this.$t('search-result.no-events-message'),
          {
            title: this.$t('product-page.expire-title'),
            dialogClass: 'noSearchResult',
            okVariant: 'success',
            headerClass: 'p-2 border-bottom-0',
            footerClass: 'p-2 border-top-0',
            centered: true,
          });
      }
      if (this.packages) {
        this.packages.forEach((packItem) => {
          // this.listEvents.push(...packItem.events);
          packItem.events.forEach((eventItem) => {
            this.listEvents.push({
              ...eventItem,
              subj_id: packItem.subj_id,
            });
          });
        });
        this.countFilteredItems = this.listEvents.length;
      }
    },
    initSearchResult() {

    },
    onScroll() {
      this.isScroll = false; // Number(event.target.scrollTop) > 260;
    },
  },
};
</script>

<style scoped>
.list_content_tickets_group {
    width: 100%;
    float: left;
    clear: both;
}
.w-list-unstyled {
    padding-left: 0;
    list-style: none;
}
ol {
    margin-top: 0;
    margin-bottom: 0;
    padding-right: 0;
    padding-left: 0;
}
ol {
    display: block;
    list-style-type: decimal;
    margin-block-start: 1em;
    margin-block-end: 1em;
    margin-inline-start: 0px;
    margin-inline-end: 0px;
    padding-inline-start: 40px;
}
.desktop_form.sticky{
  position: sticky;
  top: 53px;
  z-index: 10;
  color: #004085;
  background-color: #cce5ff;
  display: flex;
  justify-content: space-around;
  padding: 0.75rem 1.25rem;
  border: 1px solid transparent;
  border-radius: 0.25rem
}
.desktop_form.sticky h3, .desktop_form.sticky h4{
  margin-bottom: 0;
  align-self: center;
}
.desktop_form.sticky h3{
  font-size: 1.2rem;
}
.desktop_form.sticky h4{
  font-size: 1rem;
}
@media (max-width: 768px){
  .desktop_form.sticky h3 {
    margin-top: 0;
  }
}
@media (max-width: 479px) {
  .sportspage_area {
    margin: 0 !important;
  }
}
</style>

<style>
#gallery-modal .modal-body {
  margin: 0;
  padding: 0;
}
.list-inline {
  padding-right: 0;
}

.filter-hotel
  .custom-radio
  .custom-control-input:checked
  ~ .custom-control-label::after {
  right: -0.5rem;
}

.dVacation-pack.filter-cont .filterItem:not(:first-child) {
  margin-top: 0px;
}

/* .modal.show .modal-dialog.noSearchResult {
  display: inline-block;
  top: calc(50vh - 100px);
} */

.modal-dialog.noSearchResult .modal-body{
  text-align: center;
}

@media (max-width: 479px) {
  .modal.show .modal-dialog.noSearchResult {
    display: flex;
    left: -10px;
    top: unset;
  }
}
</style>
