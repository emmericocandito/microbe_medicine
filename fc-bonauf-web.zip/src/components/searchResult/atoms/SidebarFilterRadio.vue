<template>
<div class="card" >
  <div class="card-header">
    <h2 class="mb-0">
      <b-button v-b-toggle="'radioFilter'" class="btn btn-link" variant="link">
        {{item.title}}
      </b-button>
    </h2>
  </div>

  <b-collapse id="radioFilter" v-model="isVisible">
    <b-card>
      <ul class="list-group list-group-flush filter-hotel">
        <li class="list-group-item" v-for="(d, inx) in item.subItems" :key="inx">
          <b-form-radio v-model="value" name="radio-stacked" :value="d.label">
            <span>{{d.label}}</span>
            <span class="text-muted ml-5" v-if="!!d.price">{{d.price}}</span>
          </b-form-radio>
        </li>
      </ul>
    </b-card>
  </b-collapse>
</div>
</template>

<script>
import { BButton, BCollapse, VBToggle, BCard, BFormRadio } from 'bootstrap-vue';

export default {
  name: 'SidebarCollapseItem',
  components: {
    BButton, BCollapse, BCard, BFormRadio,
  },
  directives: {
    'b-toggle': VBToggle,
  },
  props: {
    item: {
      type: Object,
      default: null,
    },
  },
  data() {
    return {
      isVisible: true,
      value: this.item.subItems[0].label,
    };
  },
  watch: {
    value() {
      this.$emit('change', this.value);
    },
  },
};
</script>

<style scoped>
  .list-group {
    padding-right: 0;
  }
  .custom-control {
    padding-left: 0;
  }
  .list-group-flush > .list-group-item {
    border-width: 0 0 2px;
  }
  .list-group-flush > .list-group-item:last-child {
    border-bottom-width: 0;
  }
</style>
<style>
  .filter-hotel .custom-control.custom-radio .custom-control-label::before,
  .filter-hotel .custom-control.custom-radio .custom-control-label::after {
    right: 0;
  }
  .filter-hotel .custom-control-label::after {
    right: -0.5rem;
  }
</style>
