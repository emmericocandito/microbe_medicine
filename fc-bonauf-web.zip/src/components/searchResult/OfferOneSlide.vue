<template>
  <Agile
    ref="slide"
    :options="myOptions"
    class="owl-carousel owl-theme slider-offerOne theme-slider mb-5 ltr"
    v-if="isActive"
    :class="type === 'mobile' ? 'mobile_form' : 'desktop_form'"
  >
    <div class="card" v-for="(item, inx) in flights" :key="inx">
      <div class="card-body text-center">
        <p>{{ getDuration(item).dayDuration }}</p>
        <!-- <p>{{getDuration(item).nightDuration}} night</p> -->
        <p>{{ item.duration }} {{ $t("search-result.night") }}</p>
        <p>{{ getDuration(item).weekDuration }}</p>
      </div>
      <div class="card-footer">
        <p>{{ $t("search-result.from") }} $ {{ item.minPrice }}</p>
      </div>
    </div>
    <!-- <OfferOne v-for="inx in (1,7)" :key="inx"/> -->
    <template slot="prevButton"><i class="fas fa-chevron-left"></i></template>
    <template slot="nextButton"><i class="fas fa-chevron-right"></i></template>
  </Agile>
</template>

<script>
import dayjs from 'dayjs';

export default {
  name: 'OfferOneSlide',
  components: {
    Agile: () => import('@/components/atoms/agile/Agile'),
    // OfferOne: () => import('@/components/atoms/OfferOne')
  },
  props: {
    type: String,
    flights: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      myOptions: {
        autoplay: true,
        infinite: true,
        navButtons: true,
        slidesToShow: 2,
        autoplaySpeed: 4000,
        rtl: true,
        dots: false,
        speed: 2000,
        responsive: [
          {
            breakpoint: 1200,
            settings: {
              slidesToShow: 5,
            },
          },
          {
            breakpoint: 1000,
            settings: {
              slidesToShow: 4,
            },
          },
          {
            breakpoint: 700,
            settings: {
              slidesToShow: 3,
            },
          },
          {
            breakpoint: 1000,
            settings: {
              navButtons: true,
            },
          },
        ],
      },
      isActive: true,
    };
  },
  watch: {
    flights() {
      this.isActive = false;
      setTimeout(() => {
        this.isActive = true;
      }, 10);
    },
  },
  methods: {
    getDuration(flight) {
      const day1 = flight.FlightDetail[1].FL_Date;
      const day2 = flight.FlightDetail[0].FL_Date;
      return {
        dayDuration: `${this.getDayFormat(day1)}-${this.getDayFormat(day2)}`,
        weekDuration: `${this.getDayWeek(day1)}-${this.getDayWeek(day2)}`,
        nightDuration: this.getDayDuration(day1, day2),
      };
    },
    getDayFormat(day) {
      return dayjs(day).format('MMM D');
    },
    getDayWeek(str) {
      const week = [
        this.$t('weekName.sun'),
        this.$t('weekName.mon'),
        this.$t('weekName.tue'),
        this.$t('weekName.wed'),
        this.$t('weekName.thu'),
        this.$t('weekName.fri'),
        this.$t('weekName.sat'),
      ];
      return week[dayjs(str).day()];
    },
    getDayDuration(day1, day2) {
      const a = dayjs(day1);
      const b = dayjs(day2);
      return a.diff(b, 'day');
    },
  },
};
</script>
<style>
.agile__nav-button {
  top: 50%;
  transform: translateY(-50%);
}
</style>

<style scoped>
@media (max-width: 479px) {
  .slider-offerOne.theme-slider.mobile_form {
    display: block !important;
  }
}
.agile__slide {
  padding: 0 7px;
}
.slider-offerOne .card {
  border: none;
}
.slider-offerOne .card .card-body {
  border: 1px solid rgba(var(--theme-primary), 45%);
  border-top-left-radius: 8px;
  border-top-right-radius: 8px;
}
.slider-offerOne .card .card-footer {
  border: 1px solid rgba(var(--theme-primary), 45%);
  border-bottom-left-radius: 8px;
  border-bottom-right-radius: 8px;
}
</style>
