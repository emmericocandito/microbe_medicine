import Vue from 'vue';
import VueAxios from 'vue-axios';
import axios from 'axios';
import { ModalPlugin, ToastPlugin, TooltipPlugin, BButton } from 'bootstrap-vue';
import VueLogger from 'vuejs-logger';
import ScrollLoader from 'vue-scroll-loader';
import VueNativeSock from 'vue-native-websocket';
import VueMeta from 'vue-meta';
// import VueSocialSharing from 'vue-social-sharing';
import router from './router';
import store from './store/index';
import i18n from './i18n';
import App from './App';

require('dayjs/locale/he');
require('dayjs/locale/ru');
require('dayjs/locale/ar');

const isProduction = process.env.NODE_ENV === 'production';
const { VUE_APP_SOCKET_ENDPOINT, VUE_APP_SOCKET_ENDPOINT_STAGING } = process.env;
let SOCKET_HOST = VUE_APP_SOCKET_ENDPOINT;
if (window.location.href.includes('staging-frontend.vercel.app')) {
  SOCKET_HOST = VUE_APP_SOCKET_ENDPOINT_STAGING;
}

const options = {
  isEnabled: true,
  logLevel: isProduction ? 'error' : 'debug',
  stringifyArguments: false,
  showLogLevel: true,
  showMethodName: true,
  separator: '|',
  showConsoleColors: true,
};
// Vue.use(VueSocialSharing);
Vue.use(ScrollLoader);
Vue.use(ModalPlugin);
Vue.use(ToastPlugin);
Vue.use(TooltipPlugin);
Vue.component('b-button', BButton);
Vue.use(VueLogger, options);
Vue.use(VueMeta);
Vue.use(VueAxios, axios);
Vue.use(VueNativeSock, `${SOCKET_HOST}`, { store, connectManually: true });
Vue.config.productionTip = false;

new Vue({
  router,
  store,
  i18n,
  render: (h) => h(App),
}).$mount('#app');
