const STATUS_LIST_SITE = {
  0: 'normal',
  1: 'maintenance',
  2: 'order-agent',
};

const getTypeStatusSite = (pKind) => STATUS_LIST_SITE[pKind] ?? pKind;

export { STATUS_LIST_SITE, getTypeStatusSite };
