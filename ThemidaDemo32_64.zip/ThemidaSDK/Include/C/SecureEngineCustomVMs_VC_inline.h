/******************************************************************************
 * Header: SecureEngineCustomVMs_VC_inline.h
 * Description: VC inline assembly macros definitions
 *
 * Author/s: Oreans Technologies 
 * (c) 2023 Oreans Technologies
 *
 * --- File generated automatically from Oreans VM Generator (16/9/2023) ---
 ******************************************************************************/

/***********************************************
 * Definition as inline assembly
 ***********************************************/

#ifdef PLATFORM_X32

#ifndef VM_TIGER_WHITE_START
#define VM_TIGER_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x64 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_WHITE_END
#define VM_TIGER_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xF4 \
  __asm _emit 0x01 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_RED_START
#define VM_TIGER_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x65 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_RED_END
#define VM_TIGER_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xF5 \
  __asm _emit 0x01 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_BLACK_START
#define VM_TIGER_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x66 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_BLACK_END
#define VM_TIGER_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xF6 \
  __asm _emit 0x01 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_WHITE_START
#define VM_FISH_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x6A \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_WHITE_END
#define VM_FISH_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xFA \
  __asm _emit 0x01 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_RED_START
#define VM_FISH_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x6C \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_RED_END
#define VM_FISH_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xFC \
  __asm _emit 0x01 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_BLACK_START
#define VM_FISH_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x6E \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_BLACK_END
#define VM_FISH_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xFE \
  __asm _emit 0x01 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_WHITE_START
#define VM_PUMA_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x70 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_WHITE_END
#define VM_PUMA_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x00 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_RED_START
#define VM_PUMA_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x72 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_RED_END
#define VM_PUMA_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x02 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_BLACK_START
#define VM_PUMA_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x74 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_BLACK_END
#define VM_PUMA_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x04 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_WHITE_START
#define VM_SHARK_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x76 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_WHITE_END
#define VM_SHARK_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x06 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_RED_START
#define VM_SHARK_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x78 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_RED_END
#define VM_SHARK_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x08 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_BLACK_START
#define VM_SHARK_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x7A \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_BLACK_END
#define VM_SHARK_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x0A \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_WHITE_START
#define VM_DOLPHIN_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x86 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_WHITE_END
#define VM_DOLPHIN_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x16 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_RED_START
#define VM_DOLPHIN_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x88 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_RED_END
#define VM_DOLPHIN_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x18 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_BLACK_START
#define VM_DOLPHIN_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x8A \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_BLACK_END
#define VM_DOLPHIN_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x1A \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_WHITE_START
#define VM_EAGLE_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x92 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_WHITE_END
#define VM_EAGLE_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x22 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_RED_START
#define VM_EAGLE_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x94 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_RED_END
#define VM_EAGLE_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x24 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_BLACK_START
#define VM_EAGLE_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x96 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_BLACK_END
#define VM_EAGLE_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x26 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_WHITE_START
#define VM_LION_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xA0 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_WHITE_END
#define VM_LION_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x30 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_RED_START
#define VM_LION_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xA2 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_RED_END
#define VM_LION_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x32 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_BLACK_START
#define VM_LION_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xA4 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_BLACK_END
#define VM_LION_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x34 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_WHITE_START
#define VM_COBRA_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xA6 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_WHITE_END
#define VM_COBRA_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x36 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_RED_START
#define VM_COBRA_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xA8 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_RED_END
#define VM_COBRA_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x38 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_BLACK_START
#define VM_COBRA_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xAA \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_BLACK_END
#define VM_COBRA_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x3A \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_WHITE_START
#define VM_WOLF_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xAC \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_WHITE_END
#define VM_WOLF_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x3C \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_RED_START
#define VM_WOLF_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xAE \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_RED_END
#define VM_WOLF_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x3E \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_BLACK_START
#define VM_WOLF_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xB0 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_BLACK_END
#define VM_WOLF_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x40 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_MUTATE_ONLY_START
#define VM_MUTATE_ONLY_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x10 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_MUTATE_ONLY_END
#define VM_MUTATE_ONLY_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x11 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FALCON_TINY_START
#define VM_FALCON_TINY_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xD9 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FALCON_TINY_END
#define VM_FALCON_TINY_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x69 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#endif

#ifdef PLATFORM_X64

#ifndef VM_TIGER_WHITE_START
#define VM_TIGER_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x67 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_WHITE_END
#define VM_TIGER_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xF7 \
  __asm _emit 0x01 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_RED_START
#define VM_TIGER_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x68 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_RED_END
#define VM_TIGER_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xF8 \
  __asm _emit 0x01 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_BLACK_START
#define VM_TIGER_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x69 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_BLACK_END
#define VM_TIGER_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xF9 \
  __asm _emit 0x01 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_WHITE_START
#define VM_FISH_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x6B \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_WHITE_END
#define VM_FISH_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xFB \
  __asm _emit 0x01 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_RED_START
#define VM_FISH_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x6D \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_RED_END
#define VM_FISH_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xFD \
  __asm _emit 0x01 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_BLACK_START
#define VM_FISH_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x6F \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_BLACK_END
#define VM_FISH_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xFF \
  __asm _emit 0x01 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_WHITE_START
#define VM_PUMA_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x71 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_WHITE_END
#define VM_PUMA_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x01 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_RED_START
#define VM_PUMA_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x73 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_RED_END
#define VM_PUMA_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x03 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_BLACK_START
#define VM_PUMA_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x75 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_BLACK_END
#define VM_PUMA_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x05 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_WHITE_START
#define VM_SHARK_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x77 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_WHITE_END
#define VM_SHARK_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x07 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_RED_START
#define VM_SHARK_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x79 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_RED_END
#define VM_SHARK_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x09 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_BLACK_START
#define VM_SHARK_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x7B \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_BLACK_END
#define VM_SHARK_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x0B \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_WHITE_START
#define VM_DOLPHIN_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x87 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_WHITE_END
#define VM_DOLPHIN_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x17 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_RED_START
#define VM_DOLPHIN_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x89 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_RED_END
#define VM_DOLPHIN_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x19 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_BLACK_START
#define VM_DOLPHIN_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x8B \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_BLACK_END
#define VM_DOLPHIN_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x1B \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_WHITE_START
#define VM_EAGLE_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x93 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_WHITE_END
#define VM_EAGLE_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x23 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_RED_START
#define VM_EAGLE_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x95 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_RED_END
#define VM_EAGLE_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x25 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_BLACK_START
#define VM_EAGLE_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x97 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_BLACK_END
#define VM_EAGLE_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x27 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_WHITE_START
#define VM_LION_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xA1 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_WHITE_END
#define VM_LION_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x31 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_RED_START
#define VM_LION_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xA3 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_RED_END
#define VM_LION_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x33 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_BLACK_START
#define VM_LION_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xA5 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_BLACK_END
#define VM_LION_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x35 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_WHITE_START
#define VM_COBRA_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xA7 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_WHITE_END
#define VM_COBRA_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x37 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_RED_START
#define VM_COBRA_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xA9 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_RED_END
#define VM_COBRA_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x39 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_BLACK_START
#define VM_COBRA_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xAB \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_BLACK_END
#define VM_COBRA_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x3B \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_WHITE_START
#define VM_WOLF_WHITE_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xAD \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_WHITE_END
#define VM_WOLF_WHITE_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x3D \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_RED_START
#define VM_WOLF_RED_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xAF \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_RED_END
#define VM_WOLF_RED_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x3F \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_BLACK_START
#define VM_WOLF_BLACK_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xB1 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_BLACK_END
#define VM_WOLF_BLACK_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x41 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_MUTATE_ONLY_START
#define VM_MUTATE_ONLY_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x10 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_MUTATE_ONLY_END
#define VM_MUTATE_ONLY_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x11 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FALCON_TINY_START
#define VM_FALCON_TINY_START \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xDA \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FALCON_TINY_END
#define VM_FALCON_TINY_END \
  __asm _emit 0xEB \
  __asm _emit 0x10 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x6A \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#endif

#ifdef PLATFORM_ARM64

#ifndef VM_TIGER_WHITE_START
#define VM_TIGER_WHITE_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xB2 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_WHITE_END
#define VM_TIGER_WHITE_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x42 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_RED_START
#define VM_TIGER_RED_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xB3 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_RED_END
#define VM_TIGER_RED_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x43 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_BLACK_START
#define VM_TIGER_BLACK_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xB4 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_BLACK_END
#define VM_TIGER_BLACK_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x44 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_WHITE_START
#define VM_FISH_WHITE_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xB5 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_WHITE_END
#define VM_FISH_WHITE_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x45 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_RED_START
#define VM_FISH_RED_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xB6 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_RED_END
#define VM_FISH_RED_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x46 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_BLACK_START
#define VM_FISH_BLACK_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xB7 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_BLACK_END
#define VM_FISH_BLACK_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x47 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_WHITE_START
#define VM_PUMA_WHITE_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xB8 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_WHITE_END
#define VM_PUMA_WHITE_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x48 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_RED_START
#define VM_PUMA_RED_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xB9 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_RED_END
#define VM_PUMA_RED_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x49 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_BLACK_START
#define VM_PUMA_BLACK_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xBA \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_PUMA_BLACK_END
#define VM_PUMA_BLACK_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x4A \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_WHITE_START
#define VM_SHARK_WHITE_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xBB \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_WHITE_END
#define VM_SHARK_WHITE_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x4B \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_RED_START
#define VM_SHARK_RED_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xBC \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_RED_END
#define VM_SHARK_RED_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x4C \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_BLACK_START
#define VM_SHARK_BLACK_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xBD \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_SHARK_BLACK_END
#define VM_SHARK_BLACK_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x4D \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_EXTREME_START
#define VM_FISH_EXTREME_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xBE \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_EXTREME_END
#define VM_FISH_EXTREME_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x4E \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_EXTREME_START
#define VM_TIGER_EXTREME_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xBF \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_EXTREME_END
#define VM_TIGER_EXTREME_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x4F \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_LITE_START
#define VM_FISH_LITE_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xC0 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_LITE_END
#define VM_FISH_LITE_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x50 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_LONDON_START
#define VM_FISH_LONDON_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xC1 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FISH_LONDON_END
#define VM_FISH_LONDON_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x51 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_LONDON_START
#define VM_TIGER_LONDON_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xC2 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_LONDON_END
#define VM_TIGER_LONDON_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x52 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_WHITE_START
#define VM_DOLPHIN_WHITE_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xC3 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_WHITE_END
#define VM_DOLPHIN_WHITE_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x53 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_RED_START
#define VM_DOLPHIN_RED_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xC4 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_RED_END
#define VM_DOLPHIN_RED_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x54 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_BLACK_START
#define VM_DOLPHIN_BLACK_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xC5 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_DOLPHIN_BLACK_END
#define VM_DOLPHIN_BLACK_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x55 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_WHITE_START
#define VM_EAGLE_WHITE_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xC9 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_WHITE_END
#define VM_EAGLE_WHITE_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x59 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_RED_START
#define VM_EAGLE_RED_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xCA \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_RED_END
#define VM_EAGLE_RED_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x5A \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_BLACK_START
#define VM_EAGLE_BLACK_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xCB \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_EAGLE_BLACK_END
#define VM_EAGLE_BLACK_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x5B \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_LITE_START
#define VM_TIGER_LITE_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xCF \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_TIGER_LITE_END
#define VM_TIGER_LITE_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x5F \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_WHITE_START
#define VM_LION_WHITE_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xD0 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_WHITE_END
#define VM_LION_WHITE_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x60 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_RED_START
#define VM_LION_RED_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xD1 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_RED_END
#define VM_LION_RED_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x61 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_BLACK_START
#define VM_LION_BLACK_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xD2 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_LION_BLACK_END
#define VM_LION_BLACK_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x62 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_WHITE_START
#define VM_COBRA_WHITE_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xD3 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_WHITE_END
#define VM_COBRA_WHITE_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x63 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_RED_START
#define VM_COBRA_RED_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xD4 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_RED_END
#define VM_COBRA_RED_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x64 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_BLACK_START
#define VM_COBRA_BLACK_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xD5 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_COBRA_BLACK_END
#define VM_COBRA_BLACK_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x65 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_WHITE_START
#define VM_WOLF_WHITE_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xD6 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_WHITE_END
#define VM_WOLF_WHITE_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x66 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_RED_START
#define VM_WOLF_RED_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xD7 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_RED_END
#define VM_WOLF_RED_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x67 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_BLACK_START
#define VM_WOLF_BLACK_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xD8 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_WOLF_BLACK_END
#define VM_WOLF_BLACK_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x68 \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FALCON_TINY_START
#define VM_FALCON_TINY_START \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0xDB \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#ifndef VM_FALCON_TINY_END
#define VM_FALCON_TINY_END \
  __asm _emit 0x05 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x14 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 \
  __asm _emit 0x6B \
  __asm _emit 0x02 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x00 \
  __asm _emit 0x57\
  __asm _emit 0x4C\
  __asm _emit 0x20 \
  __asm _emit 0x20 
#endif

#endif

