mw.loader.state({"site":"ready"});
/* cache key: friendlyarm_wiki:resourceloader:filter:minify-js:7:507d50f037763c9b2048d374c6b390f9 */